<?php
/**
 * Order Bumps template.
 *
 * @package RT_FoodMenuPro
 *
 * @var array  $products WC_Product objects.
 * @var string $heading  Section heading.
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenu\Helpers\Fns;

//phpcs:disable PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage

$dir = is_rtl() ? 'rtl' : 'ltr';
?>
<div class="fmp-order-bumps">
	<h4 class="fmp-order-bumps-title"><?php echo esc_html( $heading ); ?></h4>

	<div class="fmp-order-bumps-slider swiper"
		dir="<?php echo esc_attr( $dir ); ?>">

		<div class="swiper-wrapper">
			<?php foreach ( $products as $product ) : ?>
				<div class="swiper-slide fmp-order-bump-item">
					<a class="fmp-bump-thumb" href="<?php echo esc_url( $product->get_permalink() ); ?>">
						<?php echo wp_kses_post( $product->get_image( [ 60, 60 ] ) ); ?>
					</a>

					<div class="fmp-bump-info">
						<a class="fmp-bump-name" href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo esc_html( $product->get_name() ); ?></a>
						<span class="fmp-bump-price"><?php Fns::print_html( $product->get_price_html(), true ); ?></span>

						<?php if ( $product->is_type( 'simple' ) ) : ?>
							<button type="button"
								class="fmp-bump-add-to-cart"
								data-product_id="<?php echo esc_attr( $product->get_id() ); ?>">
								<?php echo esc_html__( 'Add to Cart', 'food-menu-pro' ); ?>
							</button>
						<?php else : ?>
							<a class="fmp-bump-select"
								href="<?php echo esc_url( $product->get_permalink() ); ?>">
								<?php echo esc_html__( 'Select', 'food-menu-pro' ); ?> &rarr;
							</a>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="swiper-pagination"></div>
	</div>
</div>
