<?php
/**
 * Staff Dashboard Template
 * Custom page for order management
 */


use RT\FoodMenuPro\Helpers\FnsPro;
use  RT\FoodMenuPro\Controllers\FrontendOrderManagement\ReportGenerate;

$header_footer_visibility = FnsPro::order_header_footer_visibility();
if ( $header_footer_visibility === 'enable' ) {
    get_header();
} else {
    do_action( 'wp_head' );
}
if ( FnsPro::has_order_manage_capability() ) {
    $current_url = get_permalink( FnsPro::get_frontend_order_page() );

    $settings = get_option( TLPFoodMenu()->options['settings'] );
    // Filters
    $bulk_action      = isset( $_GET['bulk_action'] ) ? sanitize_text_field( $_GET['bulk_action'] ) : '';
    $search_term      = isset( $_GET['search'] ) ? sanitize_text_field( $_GET['search'] ) : '';
    $search_filter_by = isset( $_GET['search_filter_by'] ) ? sanitize_text_field( $_GET['search_filter_by'] ) : '';
    $date_range       = isset( $_GET['date_range'] ) ? sanitize_text_field( $_GET['date_range'] ) : '';
    //$date_to          = isset( $_GET['date_to'] ) ? sanitize_text_field( $_GET['date_to'] ) : '';
    $container_width = ! empty( $settings['fmp_order_container_width'] ) ? $settings['fmp_order_container_width'] : 1200;
    $container_width = $container_width < 1000 ? 1000 : $container_width;


    ?>

    <div class="wrap tlp-foodmenu-orders" style="width:<?php echo esc_attr( $container_width ); ?>px">
        <h2><?php the_title() ?></h2>
        <br>

        <?php
        if ( isset( $_GET['show-report'] ) && $_GET['show-report'] == 1 ) {
            ReportGenerate::get_instance();
        } else {
            ?>
            <div class="action-button-wrapper">
                <a class="view-order fm-view-order add-new-order" data-action="new" href="javascript:void(0)">
                    <span class="plus-icon">+</span>
                    <span class="btn-label"><?php echo esc_html__( 'Add Order', 'food-menu-pro' ); ?></span>
                </a>

                <a href="<?php echo esc_url( $current_url ); ?>?show-report=1" class="button">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
                            <path d="M19.91 15.51h-4.53a1 1 0 0 0 0 2h2.4A8 8 0 0 1 4 12a1 1 0 0 0-2 0 10 10 0 0 0 16.88 7.23V21a1 1 0 0 0 2 0v-4.5a1 1 0 0 0-.97-.99zM12 2a10 10 0 0 0-6.88 2.77V3a1 1 0 0 0-2 0v4.5a1 1 0 0 0 1 1h4.5a1 1 0 0 0 0-2h-2.4A8 8 0 0 1 20 12a1 1 0 0 0 2 0A10 10 0 0 0 12 2z" fill="#FFFFFF" opacity="1" data-original="#FFFFFF" class=""></path>
                        </g></svg>
                    <?php _e( 'Report', 'food-menu-pro' ); ?>
                </a>

                <a href="<?php echo esc_url( $current_url ); ?>inventory" class="button inventory-management-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
                            <path d="M510.015 221.935 457.14 129.65a14.971 14.971 0 0 0-7.818-6.611c-.013-.005-.022-.012-.035-.016L262.795 54.677a15.004 15.004 0 0 0-10.245-.029L62.793 122.994l-.013.008a14.975 14.975 0 0 0-7.919 6.647L1.985 221.935a15 15 0 0 0 7.587 21.44l43.304 16.81v114.709a15 15 0 0 0 9.917 14.112l188.314 67.826a14.913 14.913 0 0 0 6.313 1.407c.033 0 .065-.005.098-.005.039 0 .077.005.115.005 1.72 0 3.44-.296 5.083-.887l189.757-68.346a15 15 0 0 0 9.917-14.112V258.917l40.038-15.542a14.998 14.998 0 0 0 7.587-21.44zM257.589 84.72l143.017 52.413-143.226 52.689-145.358-52.672zM74.622 155.506l160.811 58.272-40.333 69.435-158.416-61.494zm8.254 116.325 113.323 43.99a14.97 14.97 0 0 0 5.424 1.019 15.003 15.003 0 0 0 12.975-7.468l27.821-47.895v160.34L82.876 364.354zm349.514 92.523-159.971 57.617V264.065l24.818 45.015a15 15 0 0 0 18.564 6.741l116.589-45.258zm-115.215-81.247-38.189-69.267 158.424-58.28 37.906 66.159z"
                                  fill="#FFFFFF" opacity="1" data-original="#FFFFFF"></path>
                        </g>
                    </svg>
                    <?php _e( 'Inventory Management', 'food-menu-pro' ); ?>
                </a>

            </div>
            <!-- Filter Top Section -->
            <div class="fm-order-filter-top">
                <div id="fm-filter-status" class="filter-order-status">
                    <?php
                    // Build status list: WC defaults + any enabled custom statuses.
                    $all_statuses   = wc_get_order_statuses();
                    $default_status = array_map( function ( $key ) {
                        return str_replace( 'wc-', '', $key );
                    }, array_keys( $all_statuses ) );
                    $default_status = array_diff( $default_status, [ 'checkout-draft' ] );

                    $total_orders = wc_get_orders( [
                            'limit'  => - 1,
                            'return' => 'ids',
                            'type'   => 'shop_order',
                            'status' => array_values( $default_status ),
                    ] );

                    $total_orders_count = count( $total_orders );

                    // Current page URL
                    $current_url = home_url( add_query_arg( null, null ) );

                    // "All" anchor
                    $base_url = remove_query_arg( [] );
                    ?>
                    <a href="<?php echo esc_url( add_query_arg( 'status', 'all', $base_url ) ); ?>">
                        All (<?php echo intval( $total_orders_count ); ?>)
                    </a>
                    <?php
                    // Get all order statuses
                    $statuses = wc_get_order_statuses();

                    foreach ( $statuses as $status_key => $status_label ) {
                        if ( 'wc-checkout-draft' == $status_key ) {
                            continue;
                        }
                        // Count orders for this status
                        $count = wc_orders_count( str_replace( 'wc-', '', $status_key ) );

                        // Build link to current page with ?status=...
                        $url = add_query_arg(
                                'status',
                                str_replace( 'wc-', '', $status_key ),
                                $base_url
                        );

                        ?>
                        <a href="<?php echo esc_url( $url ); ?>">
                            <?php echo esc_html( $status_label ); ?> (<?php echo intval( $count ); ?>)
                        </a>
                        <?php
                    }

                    ?>
                    <a class="new-order" href="<?php echo esc_url( add_query_arg( 'status', 'new', $base_url ) ); ?>">
                        <div id="fm-new-order-status">
                            <span style="font-size: 24px; color: #555;">🛒</span>
                            <span class="count"></span>
                        </div>
                    </a>
                </div>

            </div>

            <!-- Filter bottom -->
            <div class="fm-order-filter-section">

                <div class="fm-bulk-action" id="fm-bulk-action">
                    <select id="bulk_action_select" name="bulk_action_select" style="min-width: 150px">
                        <option value="" selected><?php esc_html_e( 'Bulk Action', 'food-menu-pro' ); ?></option>
                        <?php
                        $bulk_statuses = wc_get_order_statuses();
                        unset( $bulk_statuses['wc-checkout-draft'], $bulk_statuses['wc-refunded'], $bulk_statuses['wc-failed'] );
                        foreach ( $bulk_statuses as $bulk_key => $bulk_label ) :
                            $bulk_slug = str_replace( 'wc-', '', $bulk_key );
                        ?>
                            <option value="<?php echo esc_attr( $bulk_slug ); ?>">
                                <?php
                                /* translators: %s: order status label */
                                printf( esc_html__( 'Change status to %s', 'food-menu-pro' ), esc_html( $bulk_label ) );
                                ?>
                            </option>
                        <?php endforeach; ?>
                        <option value="trash"><?php esc_html_e( 'Move to Trash', 'food-menu-pro' ); ?></option>
                    </select>

                    <button id="bulk_action_btn" name="bulk_action_btn"><?php esc_html_e( 'Apply', 'food-menu-pro' ); ?></button>
                </div>

                <?php
                $date_start = ! empty( $_GET['date_start'] ) ? sanitize_text_field( $_GET['date_start'] ) : '';
                $date_end   = ! empty( $_GET['date_end'] ) ? sanitize_text_field( $_GET['date_end'] ) : '';
                ?>
                <form method="get" class="fm-order-form" id="fm-order-filter-form">
                    <input type="hidden" name="paged" value="1">

                    <input class="flatpicker_date" type="date" name="date_range" placeholder="Choose date">

                    <input type="hidden" name="date_start" id="date_start" value="<?php echo esc_attr( $date_start ); ?>">
                    <input type="hidden" name="date_end" id="date_end" value="<?php echo esc_attr( $date_end ); ?>">

                    <input type="search" id="orders-search-input-search-input" name="search" value="<?php echo esc_attr( $search_term ) ?>" placeholder="<?php echo esc_attr__( "Search Order", "food-menu-pro" ) ?>">
                    <select name="search_filter_by" id="order-search-filter">
                        <option value="" selected="selected">-Select-</option>
                        <option value="order_id" <?php selected( $search_filter_by, 'order_id' ) ?>>Order ID</option>
                        <option value="customer_email" <?php selected( $search_filter_by, 'customer_email' ) ?>>Customer Email</option>
                        <option value="customer_name" <?php selected( $search_filter_by, 'customer_name' ) ?>>Customer Name</option>
                    </select>

                    <button type="submit" class="button"><?php _e( 'Filter', 'food-menu-pro' ); ?></button>

                </form>

                <a href="<?php echo esc_url( $current_url ); ?>" class="button reset-btn" style="--btn-bg:#0094c3;">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
                            <path d="M19.91 15.51h-4.53a1 1 0 0 0 0 2h2.4A8 8 0 0 1 4 12a1 1 0 0 0-2 0 10 10 0 0 0 16.88 7.23V21a1 1 0 0 0 2 0v-4.5a1 1 0 0 0-.97-.99zM12 2a10 10 0 0 0-6.88 2.77V3a1 1 0 0 0-2 0v4.5a1 1 0 0 0 1 1h4.5a1 1 0 0 0 0-2h-2.4A8 8 0 0 1 20 12a1 1 0 0 0 2 0A10 10 0 0 0 12 2z" fill="#FFFFFF" opacity="1" data-original="#FFFFFF" class=""></path>
                        </g></svg>
                    <?php _e( 'Reset', 'food-menu-pro' ); ?></a>
            </div>
            <div id="fm-order-ajax"></div>

            <?php
            // Output dynamic badge colors for custom order statuses.
            $custom_statuses = get_option( 'fmp_custom_order_statuses', [] );
            if ( ! empty( $custom_statuses ) && is_array( $custom_statuses ) ) :
            ?>
                <style>
                    <?php foreach ( $custom_statuses as $cs ) :
                        if ( empty( $cs['enabled'] ) || empty( $cs['slug'] ) ) {
                            continue;
                        }
                        $cs_slug  = str_replace( 'wc-', '', $cs['slug'] );
                        $cs_color = sanitize_hex_color( $cs['color'] ?? '#999999' );
                        if ( ! $cs_slug || ! $cs_color ) {
                            continue;
                        }
                    ?>
                    .order-status.status-<?php echo esc_attr( $cs_slug ); ?> {
                        background: <?php echo esc_attr( $cs_color ); ?>;
                        border-color: <?php echo esc_attr( $cs_color ); ?>;
                        color: #fff;
                    }
                    <?php endforeach; ?>
                </style>
            <?php endif; ?>

        <?php } ?>
    </div>


    <!-- Order Details Modal -->
    <div id="fm-order-modal">
        <div class="modal-overlay"></div>
        <div class="modal-content">
            <button class="modal-close">&times;</button>
            <div id="fm-order-details"></div>
        </div>
    </div>
    <?php
} else {
    ?>
    <div class="fm-wp-login-form">
        <div class="fm-error-message">
            <span>🚫</span>
            <?php echo esc_html__( 'You do not have permission to view this page. Please log in to continue.', 'food-menu-pro' ) ?>
        </div>
        <div class="login-form">
            <?php
            wp_login_form( [
                    'redirect'       => esc_url( home_url( add_query_arg( null, null ) ) ), // redirect back to current page
                    'label_username' => esc_html__( 'Username', 'food-menu-pro' ),
                    'label_password' => esc_html__( 'Password', 'food-menu-pro' ),
                    'label_remember' => esc_html__( 'Remember Me', 'food-menu-pro' ),
                    'label_log_in'   => esc_html__( 'Log In', 'food-menu-pro' ),
            ] );
            ?>
        </div>
    </div>
    <?php

}


if ( $header_footer_visibility === 'enable' ) {
    get_footer();
} else {
    do_action( 'wp_footer' );
}
?>