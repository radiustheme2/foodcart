<?php
/**
 * Template: Tabs.
 *
 * @package RT_FoodMenuPro
 */

// Do not allow directly accessing this file.
use RT\FoodMenuPro\Helpers\FnsPro;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

$tabs = apply_filters( 'fmp_food_menu_tabs', [] );

global $post;
$ingredient_status = get_post_meta( $post->ID, '_ingredient_status', true );
$nutrition_status  = get_post_meta( $post->ID, '_nutrition_status', true );
$commnet_status    = get_post_meta( $post->ID, 'comment_status', true );
$isTabs            = ( $ingredient_status || $nutrition_status || $commnet_status );
if ( ! empty( $tabs ) && $isTabs ) : ?>
    <div class="fmp-tabs-wrapper tabs-active">
        <ul class="fmp-tabs">
			<?php foreach ( $tabs as $key => $tab ) :
				if ( 'description' == $key && ! get_the_content() ) {
					continue;
				} else if ( 'ingredient' == $key && ! FnsPro::get_fm_ingredient_list() ) {
					continue;
				} else if ( 'nutrition' == $key && ! FnsPro::get_fm_nutrition_list() ) {
					continue;
				}
				?>
                <li class="<?php echo esc_attr( $key ); ?>_tab" data-id="tab-fmp-<?php echo esc_attr( $key ); ?>">
					<?php echo esc_html( $tab['title'] ); ?>
                </li>
			<?php endforeach; ?>
        </ul>
		<?php foreach ( $tabs as $key => $tab ) :
			if ( 'description' == $key && ! get_the_content() ) {
				continue;
			} else if ( 'ingredient' == $key && ! FnsPro::get_fm_ingredient_list() ) {
				continue;
			} else if ( 'nutrition' == $key && ! FnsPro::get_fm_nutrition_list() ) {
				continue;
			}
			?>
            <div class="fmp-tab-panel fmp-tab-panel-<?php echo esc_attr( $key ); ?>" id="tab-fmp-<?php echo esc_attr( $key ); ?>">
				<?php call_user_func( $tab['callback'], $key, $tab ); ?>
            </div>
		<?php endforeach; ?>

    </div>
<?php endif; ?>
