<?php
/**
 * Template: Reviews.
 *
 * @package RT_FoodMenuPro
 */

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

global $post;

$args = [
	'post_id' => $post->ID,
	'status'  => 'approve',
	'orderby' => 'comment_date_gmt',
	'order'   => 'ASC',
];

$comments = get_comments( $args );
?>

<div id="reviews" class="fmp-reviews">
	<div id="comments">
		<?php if ( $comments ) : ?>
			<ol class="commentlist">
				<?php
				wp_list_comments(
					[
						'callback' => [ \RT\FoodMenuPro\Controllers\Hooks\FilterHooks::class, 'comments_template' ],
					],
					$comments
				);
				?>
			</ol>
		<?php else : ?>
			<p class="fmp-noreviews"><?php esc_html_e( 'There are no reviews yet.', 'food-menu-pro' ); ?></p>
		<?php endif; ?>
	</div>

	<?php if ( comments_open() ) : ?>
		<div id="review_form_wrapper">
			<?php
			$commenter = wp_get_current_commenter();

			$comment_form = [
				'title_reply'         => __( 'Add a review', 'food-menu-pro' ),
				'title_reply_to'      => __( 'Leave a Reply to %s', 'food-menu-pro' ),
				'title_reply_before'  => '<span id="reply-title" class="comment-reply-title">',
				'title_reply_after'   => '</span>',
				'comment_notes_after' => '',
				'label_submit'        => __( 'Submit', 'food-menu-pro' ),
				'logged_in_as'        => '',
				'comment_field'       => '',
			];

			$name_email_required = (bool) get_option( 'require_name_email', 1 );
			$required_attribute  = $name_email_required ? ' required' : '';
			$required_indicator  = $name_email_required ? '&nbsp;<span class="required">*</span>' : '';

			if ( ! is_user_logged_in() ) {
				$comment_form['fields'] = [
					'author' => sprintf(
						'<div class="email-name-wrap"><p class="comment-form-author"><label for="author">%s%s</label><input id="author" name="author" type="text" value="%s" size="30"%s /></p>',
						esc_html__( 'Name', 'food-menu-pro' ),
						$required_indicator,
						esc_attr( $commenter['comment_author'] ),
						$required_attribute
					),
					'email'  => sprintf(
						'<p class="comment-form-email"><label for="email">%s%s</label><input id="email" name="email" type="email" value="%s" size="30"%s /></p></div>',
						esc_html__( 'Email', 'food-menu-pro' ),
						$required_indicator,
						esc_attr( $commenter['comment_author_email'] ),
						$required_attribute
					),
				];
			}

			$comment_form['comment_field'] = sprintf(
				'<p class="comment-form-comment"><label for="comment">%s&nbsp;<span class="required">*</span></label><textarea id="comment" name="comment" cols="45" rows="8" required></textarea></p>',
				esc_html__( 'Your review', 'food-menu-pro' )
			);

			// Inside the popup we render via AJAX, so flag the form for the JS handler.
			if ( wp_doing_ajax() ) {
				$comment_form['comment_notes_after'] = sprintf(
					'<input type="hidden" name="fmp_ajax_review" value="1" /><input type="hidden" name="%s" value="%s" /><div class="fmp-review-message" style="display:none;margin-top:10px;"></div>',
					esc_attr( Fns::nonceId() ),
					esc_attr( wp_create_nonce( Fns::nonceText() ) )
				);
			}

			comment_form( apply_filters( 'fmp_food_menu_review_comment_form_args', $comment_form ) );
			?>
		</div>
	<?php endif; ?>
</div>
