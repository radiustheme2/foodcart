<?php

$cancelFormShowHide = ! empty( $settings['fmp_resi_enable_cancel_form'] ) ? $settings['fmp_resi_enable_cancel_form'] : 'on';
?>

<div class="fmp-resi-container">

    <div class="fmp-resi-error-msg"></div>

	<?php if ( ! empty( $_GET['message'] ) ) : ?>
        <div class="fmp-resi-success-msg" style="display: block">
            <?php echo esc_html($_GET['message']) ?>
        </div>
	<?php else : ?>
        <div class="fmp-resi-success-msg"></div>
	<?php endif; ?>

    <form id="fmp-resi-booking-form" method="post" action="" class="fmp-resi-form fmp-resi-booking-form">
        <input type="hidden" name="fmp_resi_action" value="fmp-reservation">
        <div class='fmp-field'>
            <label for='fmp_resi_date'>
				<?php echo esc_html__( 'Date', 'food-menu-pro' ); ?>
                <span class='fmp-required'>*</span>
            </label>
            <input type='text' class='fmp-form-control' id='fmp_resi_date' name='fmp_resi_date' value='' placeholder="<?php echo esc_attr__("Booking date", "food-menu-pro"); ?>" required/>
            <span class="dashicons dashicons-calendar-alt"></span>
        </div>

        <div class="fmp-row">
            <div class="fmp-col-lg-6 fmp-col-md-6 fmp-col-sm-6 fmp-col-xs-12">
                <div class='fmp-field'>
                    <label for='fmp_resi_start_time'>
						<?php echo esc_html__( 'Start Time', 'food-menu-pro' ); ?>
                        <span class='fmp-required'>*</span>
                    </label>
                    <input type='text' class='fmp-form-control' id='fmp_resi_start_time' name='fmp_resi_start_time'
                           value='' placeholder="<?php echo esc_attr__("Start Time", "food-menu-pro"); ?>" required/>
                    <span class="dashicons dashicons-clock"></span>
                </div>
            </div>
            <div class="fmp-col-lg-6 fmp-col-md-6 fmp-col-sm-6 fmp-col-xs-12">
                <div class='fmp-field'>
                    <label for='fmp_resi_end_time'>
						<?php echo esc_html__( 'End Time', 'food-menu-pro' ); ?>
                        <span class='fmp-required'>*</span>
                    </label>
                    <input type='text' class='fmp-form-control' id='fmp_resi_end_time' name='fmp_resi_end_time' value='' placeholder="<?php echo esc_attr__("End time", "food-menu-pro"); ?>"
                           required/>
                    <span class="dashicons dashicons-clock"></span>
                </div>
            </div>
        </div>

        <input type="hidden" name="fmp_visual_selection" class="fmp_visual_selection" value="1"/>
        <input type="hidden" name="fmp_booked_ids" class="fmp_booked_ids" value=""/>
        <input type="hidden" name="fmp_booked_table_ids" class="fmp_booked_table_ids" value=""/>
        <input type="hidden" name="fmp_obj_names" class="fmp_obj_names" value=""/>
        <input type="hidden" name="fmp_intersected_data" class="fmp_intersected_data" value=""/>
        <input type="hidden" name="fmp_mapping_data" class="fmp_mapping_data" value=""/>
        <input type="hidden" name="fmp_resi_guest" id="fmp_resi_guest" class="fmp_resi_guest" value="">
        <div id="fmp-table-layout-frontend"></div>

        <div class="fmp-row">
            <div class="fmp-col-lg-6 fmp-col-md-6 fmp-col-sm-6 fmp-col-xs-12">
                <div class='fmp-field'>
                    <label for='fmp_resi_name'>
						<?php echo esc_html__( 'Name', 'food-menu-pro' ); ?>
                        <span class='fmp-required'>*</span>
                    </label>
                    <input type='text' class='fmp-form-control' id='fmp_resi_name' name='fmp_resi_name' value='' placeholder="<?php echo esc_attr__("Enter your name", "food-menu-pro"); ?>"
                           required/>
                </div>
            </div>
            <div class="fmp-col-lg-6 fmp-col-md-6 fmp-col-sm-6 fmp-col-xs-12">
                <div class='fmp-field'>
                    <label for='fmp_resi_email'>
						<?php echo esc_html__( 'Email', 'food-menu-pro' ); ?>
                        <span class='fmp-required'>*</span>
                    </label>
                    <input type='text' class='fmp-form-control' id='fmp_resi_email' name='fmp_resi_email' value='' placeholder="<?php echo esc_attr__("Enter your email", "food-menu-pro"); ?>"
                           required/>
                </div>
            </div>
        </div>

        <div class='fmp-field'>
            <label for='fmp_resi_phone'>
				<?php echo esc_html__( 'Phone', 'food-menu-pro' ); ?>
                <span class='fmp-required'>*</span>
            </label>
            <input type='text' class='fmp-form-control' id='fmp_resi_phone' name='fmp_resi_phone' value='' placeholder="<?php echo esc_attr__("Enter your phone", "food-menu-pro"); ?>" required/>
        </div>

        <div class='fmp-field'>
            <label for='fmp_resi_message'>
				<?php echo esc_html__( 'Message', 'food-menu-pro' ); ?>
            </label>
            <textarea class='fmp-form-control' id='fmp_resi_message' name='fmp_resi_message' placeholder="<?php echo esc_attr__("Enter your message", "food-menu-pro"); ?>"></textarea>
        </div>

        <div class="fmp-field fmp-resi-submit-btn-wrap">
            <button id="fmp-visual-table-reservation-btn" type="submit" class="fmp-resi-submit-btn" data-form-type="booking-form"><?php echo esc_html__( 'Request Booking', 'food-menu-pro' ); ?></button>
			<?php if ( ! empty( $cancelFormShowHide ) ) : ?>
                <span class="fmp-resi-request-cancel"><?php echo esc_html__( 'Request Cancel', 'food-menu-pro' ); ?></span>
			<?php endif; ?>
        </div>
    </form>

</div>
