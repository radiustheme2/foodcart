<div class="fmp-resi-container">

	<form id="fmp-resi-cancel-form" method="post" class="fmp-resi-form fmp-resi-cancel-form">
		<input type="hidden" name="fmp_resi_action" value="fmp-reservation-cancel">
        <div class='fmp-field'>
            <label for='fmp_resi_cancel_booking_id'>
				<?php echo esc_html__( 'Booking ID', 'food-menu-pro' ); ?>
                <span class='fmp-required'>*</span>
            </label>
            <input type='text' class='fmp-form-control' id='fmp_resi_cancel_booking_id' name='fmp_resi_cancel_booking_id'
                   value='' placeholder="<?php echo esc_attr__("Enter booking ID", "food-menu-pro"); ?>" required/>
        </div>

        <div class='fmp-field'>
            <label for='fmp_resi_cancel_email'>
				<?php echo esc_html__( 'Email', 'food-menu-pro' ); ?>
                <span class='fmp-required'>*</span>
            </label>
            <input type='text' class='fmp-form-control' id='fmp_resi_cancel_email' name='fmp_resi_cancel_email'
                   value='' placeholder="<?php echo esc_attr__("Enter email", "food-menu-pro"); ?>" required/>
        </div>

		<div class='fmp-field'>
			<label for='fmp_resi_cancel_phone'>
				<?php echo esc_html__( 'Phone', 'food-menu-pro' ); ?>
				<span class='fmp-required'>*</span>
			</label>
			<input type='text' class='fmp-form-control' id='fmp_resi_cancel_phone' name='fmp_resi_cancel_phone'
				   value='' placeholder="<?php echo esc_attr__("Enter phone", "food-menu-pro"); ?>" required/>
		</div>

		<div class='fmp-field'>
			<label for='fmp_resi_cancel_message'>
				<?php echo esc_html__( 'Message', 'food-menu-pro' ); ?>
			</label>
			<textarea class='fmp-form-control' id='fmp_resi_cancel_message' name='fmp_resi_cancel_message' placeholder="<?php echo esc_attr__("Enter the reason", "food-menu-pro"); ?>"></textarea>
		</div>

		<div class="fmp-field fmp-resi-cansel-submit-btn-wrap">
			<button type="submit" class="fmp-resi-cancel-submit-btn" data-form-type="cancel-form"><?php echo esc_html__( 'Request Cancel', 'food-menu-pro' ); ?></button>
			<span class="fmp-resi-request-booking"><?php echo esc_html__( 'Request Booking', 'food-menu-pro' ); ?> </span>
		</div>
	</form>

</div>
