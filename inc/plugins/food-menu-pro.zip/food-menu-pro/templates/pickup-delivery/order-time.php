<?php
/**
 * Pickup, delivery and dine in time form in checkout page
 */

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\PickupDelivery\PickupDeliveryFns;

defined( 'ABSPATH' ) || exit;

$checkout             = WC()->checkout;
$settings             = get_option( TLPFoodMenu()->options['settings'] );
$enable_pickup        = $settings['enable_pickup'] ?? 'on';
$enable_delivery      = $settings['enable_delivery'] ?? 'on';
$enable_dinein        = $settings['enable_dinein'] ?? '';
$enable_delivery_time = $settings['enable_delivery_time'] ?? 'on';
$enable_pickup_time   = $settings['enable_pickup_time'] ?? 'on';
$enable_dinein_time   = $settings['enable_dinein_time'] ?? 'on';
wp_nonce_field( Fns::nonceText(), Fns::nonceId() );

// Dine-in tables, filtered by the active location when multi-location is on.
$dinein_location_id = ! empty( $settings['fmp_food_location_popup'] ) && ! empty( $_COOKIE['fmp_location_id'] )
	? absint( $_COOKIE['fmp_location_id'] )
	: 0;
$dinein_tables      = 'on' === $enable_dinein ? PickupDeliveryFns::get_dinein_tables( $dinein_location_id ) : [];
?>

<!--validation message-->
<div class="fmp_error_message"
	 data-pickup_date="<?php echo esc_html__( 'Kindly Pick a Pickup Date', 'food-menu-pro' ); ?>"
	 data-delivery_date="<?php echo esc_html__( 'Kindly Pick a Delivery Date', 'food-menu-pro' ); ?>"
	 data-dinein_date="<?php echo esc_html__( 'Kindly Pick a Dine In Date', 'food-menu-pro' ); ?>"
></div>


<?php
// Build the list of enabled order types, preserving the historical
// delivery-first order so the default selection does not change for
// existing sites.
$fmp_options = [];
if ( 'on' === $enable_delivery ) {
	$fmp_options['delivery'] = esc_html__( 'Delivery', 'food-menu-pro' );
}
if ( 'on' === $enable_pickup ) {
	$fmp_options['pickup'] = esc_html__( 'Pickup', 'food-menu-pro' );
}
if ( 'on' === $enable_dinein ) {
	$fmp_options['dinein'] = esc_html__( 'Dine In', 'food-menu-pro' );
}

$enabled_types = array_keys( $fmp_options );

if ( count( $enabled_types ) > 1 ) {
	$default_type         = in_array( 'delivery', $enabled_types, true ) ? 'delivery' : $enabled_types[0];
	$checked              = $checkout->get_value( 'fmp_order_time_type' ) ?: $default_type;
	$fmp_order_time_array = [
		'type'     => 'radio',
		'class'    => [ 'fmp_order_time_type form-row-wide' ],
		'options'  => $fmp_options,
		'required' => true,
	];
	echo "<div class='pickup-delivery-btn-wrap'>";
	woocommerce_form_field( 'fmp_order_time_type', $fmp_order_time_array, $checked );
	echo "</div>";
} elseif ( 1 === count( $enabled_types ) ) {
	echo '<input type="hidden" name="fmp_order_time_type" value="' . esc_attr( $enabled_types[0] ) . '"/>';
}

// id generate. More than one enabled type means the JS tab switcher drives
// visibility, and those wrappers use the `both-field-` prefix.
$is_multi_enabled = count( $enabled_types ) > 1;
$fmp_pickup_id    = $is_multi_enabled ? 'both-field-pickup' : 'field-pickup';
$fmp_delivery_id  = $is_multi_enabled ? 'both-field-delivery' : 'field-delivery';
$fmp_dinein_id    = $is_multi_enabled ? 'both-field-dinein' : 'field-dinein';
?>

<div class="fmp-pickup-delivery-setting-form-wrap">

	<?php if ( 'on' === $enable_pickup ) : ?>
		<div class="fmp-pickup-wrap" id="<?php echo esc_attr( $fmp_pickup_id ); ?>">

			<div class="form-row fmp-field-row">
					<?php
					$div_class = ! empty( $enable_pickup_time ) ? 'form-row-first' : '';
					woocommerce_form_field(
						'fmp_pickup_date',
						[
							'label'    => esc_html__( 'Pickup date', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_pickup_date ' . $div_class ],
							'required' => true,
						]
					);
					?>

				<?php if ( 'on' == $enable_pickup_time ) : ?>
					<?php
					woocommerce_form_field(
						'fmp_pickup_time',
						[
							'label'    => esc_html__( 'Pickup Time', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_pickup_time form-row-last' ],
							'required' => true,
						]
					);
					?>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $settings['pickup_message'] ) ) : ?>
				<div class="form-row fmp-pickup-message">
					<?php echo esc_html( $settings['pickup_message'] ); ?>
				</div>
			<?php endif; ?>

		</div>
	<?php endif; ?>

	<?php if ( 'on' === $enable_delivery ) : ?>
		<div class="fmp-delivery-wrap" id="<?php echo esc_attr( $fmp_delivery_id ); ?>">

			<div class="form-row fmp-field-row">
					<?php
					$div_class = ! empty( $enable_delivery_time ) ? 'form-row-first' : '';
					woocommerce_form_field(
						'fmp_delivery_date',
						[
							'label'    => esc_html__( 'Delivery Date', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_delivery_date ' . $div_class ],
							'required' => true,
						]
					);
					?>
				<?php if ( 'on' == $enable_delivery_time ) : ?>
					<?php
					woocommerce_form_field(
						'fmp_delivery_time',
						[
							'label'    => esc_html__( 'Delivery Time', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_delivery_time form-row-last' ],
							'required' => true,
						]
					);
					?>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $settings['delivery_message'] ) ) : ?>
				<div class="form-row fmp-delivery-message">
					<?php echo esc_html( $settings['delivery_message'] ); ?>
				</div>
			<?php endif; ?>

		</div>
	<?php endif; ?>

	<?php if ( 'on' === $enable_dinein ) : ?>
		<div class="fmp-dinein-wrap" id="<?php echo esc_attr( $fmp_dinein_id ); ?>">

			<div class="form-row fmp-field-row">
				<?php
				$dinein_table_required = 'on' === ( $settings['dinein_require_table'] ?? 'on' );

				if ( ! empty( $dinein_tables ) ) {
					$table_options = [ '' => esc_html__( 'Select a table', 'food-menu-pro' ) ];
					foreach ( $dinein_tables as $dinein_table ) {
						$table_options[ $dinein_table['name'] ] = $dinein_table['name'];
					}

					woocommerce_form_field(
						'fmp_dinein_table',
						[
							'label'    => esc_html__( 'Table', 'food-menu-pro' ),
							'type'     => 'select',
							'class'    => [ 'fmp_dinein_table form-row-wide' ],
							'options'  => $table_options,
							'required' => $dinein_table_required,
						]
					);
				} else {
					// No tables configured — fall back to a free-text field so the
					// feature still works before any tables are added.
					woocommerce_form_field(
						'fmp_dinein_table',
						[
							'label'       => esc_html__( 'Table Number', 'food-menu-pro' ),
							'type'        => 'text',
							'class'       => [ 'fmp_dinein_table form-row-wide' ],
							'placeholder' => esc_html__( 'e.g. 5', 'food-menu-pro' ),
							'required'    => $dinein_table_required,
						]
					);
				}
				?>
			</div>

			<div class="form-row fmp-field-row">
					<?php
					$div_class = ! empty( $enable_dinein_time ) ? 'form-row-first' : '';
					woocommerce_form_field(
						'fmp_dinein_date',
						[
							'label'    => esc_html__( 'Dine In Date', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_dinein_date ' . $div_class ],
							'required' => true,
						]
					);
					?>
				<?php if ( 'on' == $enable_dinein_time ) : ?>
					<?php
					woocommerce_form_field(
						'fmp_dinein_time',
						[
							'label'    => esc_html__( 'Dine In Time', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_dinein_time form-row-last' ],
							'required' => true,
						]
					);
					?>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $settings['dinein_message'] ) ) : ?>
				<div class="form-row fmp-dinein-message">
					<?php echo esc_html( $settings['dinein_message'] ); ?>
				</div>
			<?php endif; ?>

		</div>
	<?php endif; ?>

</div>
