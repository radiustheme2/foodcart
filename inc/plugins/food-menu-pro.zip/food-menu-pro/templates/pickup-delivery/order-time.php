<?php
/**
 * Pickup and delivery time form in checkout page
 */

defined( 'ABSPATH' ) || exit;

$checkout             = WC()->checkout;
$settings             = get_option( TLPFoodMenu()->options['settings'] );
$allow_order_type     = $settings['allow_order_type_for'] ?? 'both';
$enable_pickup        = $settings['enable_pickup'] ?? 'on';
$enable_delivery      = $settings['enable_delivery'] ?? 'on';
$enable_delivery_time = $settings['enable_delivery_time'] ?? 'on';
$enable_pickup_time   = $settings['enable_pickup_time'] ?? 'on';
$fmp_hidden_field     = '';
wp_nonce_field( \RT\FoodMenu\Helpers\Fns::nonceText(), \RT\FoodMenu\Helpers\Fns::nonceId() );
?>

<!--validation message-->
<div class="fmp_error_message"
	 data-pickup_date="<?php echo esc_html__( 'Kindly Pick a Pickup Date', 'food-menu-pro' ); ?>"
	 data-delivery_date="<?php echo esc_html__( 'Kindly Pick a Delivery Date', 'food-menu-pro' ); ?>"
></div>

<?php
if ( 'delivery' == $allow_order_type || 'pickup' == $allow_order_type ) {
	$fmp_hidden_field .= '<input type="hidden" name="fmp_order_time_type" value="' . esc_attr( $allow_order_type ) . '"/>';
	echo wp_kses_post( $fmp_hidden_field );
} elseif ( 'both' == $allow_order_type ) {
	$fmp_options          = [
		'delivery' => esc_html__( 'Delivery', 'food-menu-pro' ),
		'pickup'   => esc_html__( 'Pickup', 'food-menu-pro' ),
	];
	$checked              = $checkout->get_value( 'fmp_order_time_type' ) ?: 'delivery';
	$fmp_order_time_array = [
		'type'     => 'radio',
		'class'    => [ 'fmp_order_time_type form-row-wide' ],
		'options'  => $fmp_options,
		'required' => true,
	];

	if ( $enable_delivery && $enable_pickup ) {
		woocommerce_form_field( 'fmp_order_time_type', $fmp_order_time_array, $checked );
	}
}

// id generate.
$is_both_order   = 'both' == $allow_order_type;
$fmp_pickup_id   = $is_both_order ? 'both-field-pickup' : 'field-pickup';
$fmp_delivery_id = $is_both_order ? 'both-field-delivery' : 'field-delivery';
?>

<div class="fmp-pickup-delivery-setting-form-wrap">

	<?php if ( 'on' == $enable_pickup && ( 'both' == $allow_order_type || 'pickup' == $allow_order_type ) ) : ?>
		<div class="fmp-pickup-wrap" id="<?php echo esc_attr( $fmp_pickup_id ); ?>">
			
			<div class="form-row fmp-field-row">
					<?php
					$div_class = ! empty( $enable_pickup_time ) ? 'form-row-first' : '';
					woocommerce_form_field(
						'fmp_pickup_date',
						[
							'label'    => esc_html__( 'Pickup date', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_pickup_date ' . $div_class ],
							'required' => true,
						]
					);
					?>

				<?php if ( 'on' == $enable_pickup_time ) : ?>
					<?php
					woocommerce_form_field(
						'fmp_pickup_time',
						[
							'label'    => esc_html__( 'Pickup Time', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_pickup_time form-row-last' ],
							'required' => true,
						]
					);
					?>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $settings['pickup_message'] ) ) : ?>
				<div class="form-row fmp-pickup-message">
					<?php echo esc_html( $settings['pickup_message'] ); ?>
				</div>
			<?php endif; ?>

		</div>
	<?php endif; ?>

	<?php if ( 'on' == $enable_delivery && ( 'both' == $allow_order_type || 'delivery' == $allow_order_type ) ) : ?>
		<div class="fmp-delivery-wrap" id="<?php echo esc_attr( $fmp_delivery_id ); ?>">

			<div class="form-row fmp-field-row">
					<?php
					$div_class = ! empty( $enable_delivery_time ) ? 'form-row-first' : '';
					woocommerce_form_field(
						'fmp_delivery_date',
						[
							'label'    => esc_html__( 'Delivery Date', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_delivery_date ' . $div_class ],
							'required' => true,
						]
					);
					?>
				<?php if ( 'on' == $enable_delivery_time ) : ?>
					<?php
					woocommerce_form_field(
						'fmp_delivery_time',
						[
							'label'    => esc_html__( 'Delivery Time', 'food-menu-pro' ),
							'type'     => 'text',
							'class'    => [ 'fmp_delivery_time form-row-last' ],
							'required' => true,
						]
					);
					?>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $settings['delivery_message'] ) ) : ?>
				<div class="form-row fmp-delivery-message">
					<?php echo esc_html( $settings['delivery_message'] ); ?>
				</div>
			<?php endif; ?>

		</div>
	<?php endif; ?>

</div>
