<?php
/**
 * Public order tracking page template.
 *
 * @package RT_FoodMenuPro
 */

use RT\FoodMenuPro\Models\OrderTimelineModel;
use RT\FoodMenuPro\Controllers\OrderTimeline\OrderTimelineFns;

defined( 'ABSPATH' ) || exit;

$token   = get_query_var( 'fmp_tracking_token', '' );
$entries = OrderTimelineModel::get_by_token( $token );

// Derive order info for OG tags.
$og_title       = get_bloginfo( 'name' );
$og_description = OrderTimelineFns::get_page_title();
$current_status = '';

if ( ! empty( $entries ) ) {
	$order_id = absint( $entries[0]['order_id'] );
	$order    = wc_get_order( $order_id );

	if ( $order ) {
		$current_status = end( $entries )['status_label'] ?? '';
		$og_title       = sprintf(
			/* translators: %1$s: order number, %2$s: status label */
			__( 'Order #%1$s - %2$s', 'food-menu-pro' ),
			$order->get_order_number(),
			$current_status
		);
		$og_description = sprintf(
			/* translators: %s: site name */
			__( 'Track your order from %s', 'food-menu-pro' ),
			get_bloginfo( 'name' )
		);
	}
}

// Enqueue the tracking page assets.
wp_enqueue_style(
	'fmp-order-tracking-public',
	FMP()->assets_url() . 'css/order-tracking-public-css.min.css',
	[],
	FOOD_MENU_PRO_VERSION
);

wp_enqueue_script(
	'fmp-order-tracking-public',
	FMP()->assets_url() . 'js/order-tracking-public.min.js',
	[ 'wp-element', 'wp-i18n' ],
	FOOD_MENU_PRO_VERSION,
	true
);
wp_set_script_translations( 'fmp-order-tracking-public', 'food-menu-pro', FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages' );

$fmp_settings = get_option( 'tpl_food_menu_settings', [] );

wp_localize_script( 'fmp-order-tracking-public', 'fmpTrackingData', [
	'token'           => sanitize_text_field( $token ),
	'restRoot'        => esc_url_raw( rest_url() ),
	'siteName'        => get_bloginfo( 'name' ),
	'pageTitle'       => OrderTimelineFns::get_page_title(),
	'completedStatus' => str_replace( 'wc-', '', $fmp_settings['fmp_tracking_completed_status'] ?? 'wc-completed' ),
] );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="robots" content="noindex, nofollow">

	<!-- Open Graph / WhatsApp Preview -->
	<meta property="og:title" content="<?php echo esc_attr( $og_title ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $og_description ); ?>">
	<meta property="og:type" content="website">
	<meta property="og:url" content="<?php echo esc_url( home_url( '/fmp-track/' . $token ) ); ?>">

	<title><?php echo esc_html( $og_title ); ?></title>

	<?php
	// Generic safety net. This is a standalone, single-purpose page — nothing
	// should float over the timeline. Rather than enumerate every plugin, we
	// hide:
	//   1. Anything appended directly to <body> that isn't our app — this is
	//      how chat widgets, cookie bars, back-to-top buttons, etc. inject
	//      themselves. The WP admin bar and printed scripts/styles are kept.
	//   2. Anything positioned fixed/sticky via inline style (CSS can't match a
	//      computed position, but most floating widgets set it inline).
	// Trade-off: do NOT add a legitimate floating element to this page — it
	// will be hidden by these rules.
	?>
	<style>
		.fmp-tracking-page > *:not( #fmp-order-tracking ):not( #wpadminbar ):not( script ):not( style ):not( noscript ):not( template ),
		.fmp-tracking-page [style*="position:fixed"],
		.fmp-tracking-page [style*="position: fixed"],
		.fmp-tracking-page [style*="position:sticky"],
		.fmp-tracking-page [style*="position: sticky"] {
			display: none !important;
		}
	</style>

	<?php wp_head(); ?>
</head>
<body <?php body_class( 'fmp-tracking-page' ); ?>>

	<div id="fmp-order-tracking"></div>

	<?php wp_footer(); ?>
</body>
</html>
