<?php

/**
 * Frontend Dashboard template
 */

use RT\FoodMenuPro\Helpers\FnsPro;

if ( ! is_user_logged_in() ) {
    wp_safe_redirect( wp_login_url( get_permalink() ) );
    exit;
}


$header_footer_visibility = FnsPro::order_header_footer_visibility();
$is_block_theme           = wp_is_block_theme();

if ( $header_footer_visibility === 'enable' ) {
    if ( $is_block_theme ) {
        echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
        do_action( 'wp_head' );
        block_header_area();
    } else {
        get_header();
    }
    $wrapper_class = 'header-footer-enable';
} else {
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    do_action( 'wp_head' );
    $wrapper_class = 'header-footer-disable';
}

if ( ! FnsPro::has_order_manage_capability() ) {
    ?>
    <div style="display:flex;align-items:center;justify-content:center;min-height:60vh;padding:40px 20px;">
        <div style="text-align:center;max-width:480px;">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin:0 auto 16px;">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
            <h2 style="margin:0 0 8px;font-size:22px;color:#1f2937;"><?php esc_html_e( 'Access Denied', 'food-menu-pro' ); ?></h2>
            <p style="margin:0 0 24px;color:#6b7280;font-size:15px;">
                <?php esc_html_e( 'You do not have permission to access this dashboard. Please contact the site administrator to request access.', 'food-menu-pro' ); ?>
            </p>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="display:inline-block;padding:10px 24px;background:#2563eb;color:#fff;border-radius:8px;text-decoration:none;font-size:14px;font-weight:500;">
                <?php esc_html_e( 'Go to Homepage', 'food-menu-pro' ); ?>
            </a>
        </div>
    </div>
    <?php
} else {
    ?>
    <div id="fmp-frontend-dashboard" class="<?php echo esc_attr( $wrapper_class ); ?>">
        <div class="fmp-fd-loading">
            <!-- Sidebar skeleton -->
            <div class="fmp-fd-skel-sidebar">
                <div class="fmp-fd-skel-logo">
                    <div class="fmp-fd-skel-bone" style="width:32px;height:32px;border-radius:8px"></div>
                    <div class="fmp-fd-skel-bone" style="width:80px;height:14px;border-radius:4px"></div>
                </div>
                <div class="fmp-fd-skel-nav">
                    <div class="fmp-fd-skel-bone" style="width:100%;height:36px;border-radius:8px"></div>
                    <div class="fmp-fd-skel-bone" style="width:100%;height:36px;border-radius:8px"></div>
                    <div class="fmp-fd-skel-bone" style="width:100%;height:36px;border-radius:8px"></div>
                    <div class="fmp-fd-skel-bone" style="width:100%;height:36px;border-radius:8px"></div>
                    <div class="fmp-fd-skel-bone" style="width:100%;height:36px;border-radius:8px"></div>
                </div>
            </div>
            <!-- Content skeleton -->
            <div class="fmp-fd-skel-main">
                <div class="fmp-fd-skel-bone" style="width:180px;height:22px;border-radius:6px;margin-bottom:20px"></div>
                <!-- Stats row -->
                <div class="fmp-fd-skel-stats">
                    <div class="fmp-fd-skel-bone" style="height:90px;border-radius:10px"></div>
                    <div class="fmp-fd-skel-bone" style="height:90px;border-radius:10px"></div>
                    <div class="fmp-fd-skel-bone" style="height:90px;border-radius:10px"></div>
                    <div class="fmp-fd-skel-bone" style="height:90px;border-radius:10px"></div>
                </div>
                <!-- Table skeleton -->
                <div class="fmp-fd-skel-bone" style="width:100%;height:44px;border-radius:8px 8px 0 0;margin-bottom:2px"></div>
                <div class="fmp-fd-skel-bone" style="width:100%;height:44px;border-radius:0;margin-bottom:2px"></div>
                <div class="fmp-fd-skel-bone" style="width:100%;height:44px;border-radius:0;margin-bottom:2px"></div>
                <div class="fmp-fd-skel-bone" style="width:100%;height:44px;border-radius:0;margin-bottom:2px"></div>
                <div class="fmp-fd-skel-bone" style="width:100%;height:44px;border-radius:0;margin-bottom:2px"></div>
                <div class="fmp-fd-skel-bone" style="width:100%;height:44px;border-radius:0 0 8px 8px"></div>
            </div>
        </div>
    </div>
    <style>
        html,
        body {
            margin: 0 !important;
        }
    </style>
    <?php
}
if ( $header_footer_visibility === 'enable' ) {
    if ( $is_block_theme ) {
        block_footer_area();
        do_action( 'wp_footer' );
    } else {
        get_footer();
    }
} else {
    do_action( 'wp_footer' );
}
