<?php
/**
 * Custom checkout page template.
 *
 * Uses the theme's default header and footer.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$checkout     = WC()->checkout();
$layout_class = CheckoutFns::get_layout_class();
$is_two_col   = empty( $layout_class );

WC()->cart->calculate_totals();

// Astra theme support: Astra moves shipping form into billing section, fix that.
if ( class_exists( 'Astra_Woocommerce' ) ) {
	remove_action( 'woocommerce_checkout_billing', [ WC()->checkout(), 'checkout_form_shipping' ] );
	add_action( 'woocommerce_checkout_shipping', [ WC()->checkout(), 'checkout_form_shipping' ] );
}

get_header();
?>
<div class="fmp-checkout-page woocommerce">
<div class="fmp-checkout-container">
	<h1 class="fmp-checkout-heading"><?php echo esc_html( CheckoutFns::get_heading_text() ); ?></h1>

	<div class="fmp-checkout-wrapper <?php echo esc_attr( $layout_class ); ?>">
		<div class="fmp-checkout-main">

			<?php
			// Coupon form (outside the main checkout form).
			if ( CheckoutFns::show_coupon() ) {
				Fns::render( 'checkout/coupon-form' );
			}
			?>

			<?php
			// Show login form only when WC "Allow customers to log in during checkout" is enabled.
			if ( ! is_user_logged_in() && 'yes' === get_option( 'woocommerce_enable_checkout_login_reminder' ) ) {
				Fns::render( 'checkout/login-form' );
			}
			?>

			<?php
			// If guest checkout is off, account creation is off, and user isn't logged in — only show login form (rendered above).
			$must_login = ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in();

			if ( ! $must_login ) {
				?>
				<?php do_action( 'woocommerce_before_checkout_form', $checkout ); ?>

				<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

					<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

                    <?php
					// Step 1: Order Type (Pickup/Delivery).
					if ( CheckoutFns::show_order_type() ) {
						Fns::render( 'checkout/order-type' );
					}
					?>

                    <?php
                    // Step 2: Your location.
                    if ( CheckoutFns::show_your_location() ) {
                        Fns::render( 'checkout/your-location' );
                    }
                    ?>

					<?php
					// Step 2: Your Details (billing fields).
					Fns::render( 'checkout/your-details', [ 'checkout' => $checkout ] );
					?>

					<?php
					// Shipping Address (separate card).
					$has_shipping = CheckoutFns::show_shipping_address();
					if ( $has_shipping ) {
						Fns::render( 'checkout/shipping-address' );
					}
					?>

					<?php
					// Order Notes — after shipping if visible, otherwise after billing.
					if ( CheckoutFns::show_order_notes() ) {
						Fns::render( 'checkout/order-notes', [ 'checkout' => $checkout ] );
					}
					?>

					<?php
					// Step 3: Additional Information (custom checkout fields).
					if ( CheckoutFns::show_additional_info() ) {
						Fns::render( 'checkout/additional-info' );
					}
					?>

					<?php
					// Step 4: Tip.
					if ( CheckoutFns::show_tips() ) {
						Fns::render( 'checkout/tip-section' );
					}
					?>

					<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

					<?php
					// Shipping Method (inside form, before payment).
					if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) {
						Fns::render( 'checkout/shipping-method' );
					}
					?>

					<?php
					// Single-column: order summary before payment.
					if ( ! $is_two_col ) {
						Fns::render( 'checkout/order-summary', [ 'inline' => true ] );
					}
					?>

					<?php
					// Payment.
					Fns::render( 'checkout/payment' );
					?>


				</form>

				<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
				<?php
			}
			?>

		</div><!-- .fmp-checkout-main -->

		<?php if ( $is_two_col ) : ?>
			<div class="fmp-checkout-sidebar">
				<?php Fns::render( 'checkout/order-summary', [ 'inline' => false ] ); ?>
			</div>
		<?php endif; ?>
	</div>
</div>
</div>

<?php get_footer(); ?>
