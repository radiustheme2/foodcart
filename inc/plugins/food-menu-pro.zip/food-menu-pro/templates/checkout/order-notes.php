<?php
/**
 * Custom checkout - Order Notes card.
 *
 * Rendered after shipping address if visible, otherwise after billing.
 *
 * @package RT_FoodMenuPro
 *
 * @var WC_Checkout $checkout
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$step = CheckoutFns::get_step_number( 'order_notes' );
?>
<div class="co-card fmp-order-notes-card">
	<div class="co-card-header">
		<span class="step"><?php echo esc_html( $step ); ?></span>
		<h2><?php esc_html_e( 'Order Notes', 'food-menu-pro' ); ?></h2>
	</div>

	<div class="woocommerce-additional-fields fmp-order-notes-wrap">
		<?php do_action( 'woocommerce_before_order_notes', $checkout ); ?>

		<?php
		$order_notes_fields = $checkout->get_checkout_fields( 'order' );

		if ( ! empty( $order_notes_fields ) ) {
			foreach ( $order_notes_fields as $key => $field ) {
				woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
			}
		}
		?>

		<?php do_action( 'woocommerce_after_order_notes', $checkout ); ?>
	</div>
</div>
