<?php
/**
 * Custom checkout - Shipping Method section.
 *
 * Renders shipping method radios inside the form (before payment).
 * Same approach as ShopBuilder's shopify-shipping-method.php.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$packages = WC()->shipping()->get_packages();
$step     = CheckoutFns::get_step_number( 'shipping' );
?>
<div class="co-card fmp-shipping-method-card">
	<div class="co-card-header">
		<span class="step"><?php echo esc_html( $step ); ?></span>
		<h2><?php esc_html_e( 'Shipping Method', 'food-menu-pro' ); ?></h2>
	</div>

	<div class="fmp-shipping-methods-wrap">
		<ul id="shipping_method" class="woocommerce-shipping-methods fmp-radio-list">
			<?php
			foreach ( $packages as $index => $package ) {
				$available_methods = $package['rates'];
				$chosen_method     = isset( WC()->session->chosen_shipping_methods[ $index ] ) ? WC()->session->chosen_shipping_methods[ $index ] : '';

				foreach ( $available_methods as $method ) {
					$method_id  = sanitize_title( $method->id );
					$is_free    = ( (float) $method->cost === 0.0 );
					$price_html = $is_free
						? '<span class="fmp-shipping-price fmp-shipping-free">' . esc_html__( 'Free', 'food-menu-pro' ) . '</span>'
						: '<span class="fmp-shipping-price">' . wp_kses_post( wc_price( $method->cost ) ) . '</span>';
					?>
					<li>
						<input type="radio" name="shipping_method[<?php echo absint( $index ); ?>]" data-index="<?php echo absint( $index ); ?>" id="shipping_method_<?php echo absint( $index ); ?>_<?php echo esc_attr( $method_id ); ?>" value="<?php echo esc_attr( $method->id ); ?>" class="shipping_method" <?php checked( $method->id, $chosen_method ); ?> />
						<span class="fmp-radio-dot"></span>
						<label for="shipping_method_<?php echo absint( $index ); ?>_<?php echo esc_attr( $method_id ); ?>"><?php echo esc_html( $method->label ); ?></label>
						<?php echo $price_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</li>
					<?php
				}
			}
			?>
		</ul>
	</div>
</div>
