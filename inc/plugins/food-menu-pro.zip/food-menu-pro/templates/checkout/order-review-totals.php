<?php
/**
 * Custom checkout - Order Review Totals partial.
 *
 * Used both for initial render and AJAX refresh.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

$cart = WC()->cart;
?>
<div class="fmp-order-totals">

	<div class="fmp-total-row">
		<span><?php esc_html_e( 'Subtotal', 'food-menu-pro' ); ?></span>
		<span><?php wc_cart_totals_subtotal_html(); ?></span>
	</div>

	<?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
		<div class="fmp-total-row fmp-discount">
			<span><?php wc_cart_totals_coupon_label( $coupon ); ?></span>
			<span><?php wc_cart_totals_coupon_html( $coupon ); ?></span>
		</div>
	<?php endforeach; ?>

	<?php if ( $cart->needs_shipping() && $cart->show_shipping() ) : ?>
		<div class="fmp-total-row">
			<span><?php esc_html_e( 'Shipping', 'food-menu-pro' ); ?></span>
			<span><?php echo wp_kses_post( $cart->get_cart_shipping_total() ); ?></span>
		</div>
	<?php endif; ?>

	<?php foreach ( $cart->get_fees() as $fee ) : ?>
		<div class="fmp-total-row">
			<span><?php echo esc_html( $fee->name ); ?></span>
			<span><?php wc_cart_totals_fee_html( $fee ); ?></span>
		</div>
	<?php endforeach; ?>

	<?php if ( wc_tax_enabled() && ! $cart->display_prices_including_tax() ) : ?>
		<?php
		$tax_totals = $cart->get_tax_totals();
		if ( $tax_totals ) :
			foreach ( $tax_totals as $tax ) :
				?>
				<div class="fmp-total-row">
					<span><?php echo esc_html( $tax->label ); ?></span>
					<span><?php echo wp_kses_post( $tax->formatted_amount ); ?></span>
				</div>
				<?php
			endforeach;
		endif;
		?>
	<?php endif; ?>

	<div class="fmp-total-row fmp-grand-total">
		<span><?php esc_html_e( 'Total', 'food-menu-pro' ); ?></span>
		<span><?php wc_cart_totals_order_total_html(); ?></span>
	</div>

</div>
