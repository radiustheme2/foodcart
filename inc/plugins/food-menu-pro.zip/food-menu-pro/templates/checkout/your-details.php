<?php
/**
 * Custom checkout - Your Details card.
 *
 * Renders all WC billing fields using woocommerce_form_field().
 * CSS restyling makes the WC output match the custom design.
 *
 * @package RT_FoodMenuPro
 *
 * @var WC_Checkout $checkout
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$step = CheckoutFns::get_step_number( 'details' );

?>
<div class="co-card">
	<div class="co-card-header">
		<span class="step"><?php echo esc_html( $step ); ?></span>
		<h2><?php esc_html_e( 'Your Details', 'food-menu-pro' ); ?></h2>
	</div>

	<div class="woocommerce-billing-fields">
		<?php do_action( 'woocommerce_before_checkout_billing_form', $checkout ); ?>

		<div class="woocommerce-billing-fields__field-wrapper fmp-form-grid">
			<?php
			$fields = $checkout->get_checkout_fields( 'billing' );
			foreach ( $fields as $key => $field ) {
				woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
			}
			?>
		</div>

		<?php do_action( 'woocommerce_after_checkout_billing_form', $checkout ); ?>
	</div>

</div>
