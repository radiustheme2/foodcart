<?php
/**
 * Custom checkout - Login form.
 *
 * Shown when user is not logged in and login during checkout is enabled.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="co-card fmp-login-card">
	<div class="co-card-header">
		<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--rtfm-primary-color)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
		<h2><?php esc_html_e( 'Returning customer?', 'food-menu-pro' ); ?></h2>
	</div>

	<form class="fmp-checkout-login-form" method="post">
		<div class="fmp-login-fields">
			<p class="form-row">
				<label for="fmp_login_username"><?php esc_html_e( 'Username or email', 'food-menu-pro' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="text" class="input-text" name="username" id="fmp_login_username" autocomplete="username" required />
			</p>
			<p class="form-row">
				<label for="fmp_login_password"><?php esc_html_e( 'Password', 'food-menu-pro' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="password" class="input-text" name="password" id="fmp_login_password" autocomplete="current-password" required />
			</p>
		</div>

		<div class="fmp-login-actions">
			<label class="fmp-remember-me">
				<input type="checkbox" name="rememberme" value="forever" />
				<?php esc_html_e( 'Remember me', 'food-menu-pro' ); ?>
			</label>
			<button type="submit" class="fmp-login-btn" name="login" value="1"><?php esc_html_e( 'Login', 'food-menu-pro' ); ?></button>
		</div>

		<p class="fmp-lost-password">
			<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Lost your password?', 'food-menu-pro' ); ?></a>
		</p>

		<?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
		<input type="hidden" name="redirect" value="<?php echo esc_url( wc_get_checkout_url() ); ?>" />
	</form>
</div>
