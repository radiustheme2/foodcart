<?php
/**
 * Custom checkout - Order Type (Pickup/Delivery) card.
 *
 * Wraps the existing pickup-delivery form in the custom card design.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$step = CheckoutFns::get_step_number( 'order_type' );
?>
<div class="co-card">
	<div class="co-card-header">
		<span class="step"><?php echo esc_html( $step ); ?></span>
		<h2><?php esc_html_e( 'Pickup & Delivery', 'food-menu-pro' ); ?></h2>
	</div>

	<div class="fmp-custom-checkout-order-type">
		<?php
		// Fire the action so the duplicate-render guard knows we rendered it here.
		do_action( 'fmp_custom_checkout_order_type_rendered' );

		// Render the existing P&D form.
		Fns::render( 'pickup-delivery/order-time' );
		?>
	</div>
</div>
