<?php
/**
 * Custom checkout - Additional Information card.
 *
 * Renders custom checkout fields (Room Number, Your Name, etc.)
 * in a separate card section.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$fields = FnsPro::get_setting( 'fmp_order_custom_fields', [] );

if ( empty( $fields ) ) {
	return;
}

$checkout = WC()->checkout();
$step     = CheckoutFns::get_step_number( 'additional_info' );

// Enqueue Select2 (bundled with WooCommerce).
wp_enqueue_script( 'selectWoo' );
wp_enqueue_style( 'select2' );
?>
<div class="co-card">
	<div class="co-card-header">
		<span class="step"><?php echo esc_html( $step ); ?></span>
		<h2><?php esc_html_e( 'Additional Information', 'food-menu-pro' ); ?></h2>
	</div>

	<div class="fmp-custom-checkout-fields fmp-form-grid">
		<?php
		foreach ( $fields as $idx => $field ) {
			$field_id = 'fmp_custom_field_' . $idx;
			$label    = ! empty( $field['label'] ) ? $field['label'] : 'Field ' . ( $idx + 1 );
			$required = filter_var( $field['required'] ?? false, FILTER_VALIDATE_BOOLEAN );
			$type     = $field['type'] ?? 'text';
			$multiple = filter_var( $field['multiple'] ?? false, FILTER_VALIDATE_BOOLEAN );

			if ( 'select' === $type ) {
				$options  = array_map( 'trim', explode( ',', $field['options'] ?? '' ) );
				$options  = array_filter( $options );
				$req_star = $required ? ' <abbr class="required" title="required">*</abbr>' : '';
				$name     = $multiple ? $field_id . '[]' : $field_id;
				$multi    = $multiple ? ' multiple="multiple"' : '';
				$req_attr = $required ? ' required' : '';
				?>
				<p class="form-row form-row-wide" id="<?php echo esc_attr( $field_id ); ?>_field">
					<label for="<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $label ); ?><?php echo wp_kses_post( $req_star ); ?></label>
					<select name="<?php echo esc_attr( $name ); ?>" id="<?php echo esc_attr( $field_id ); ?>" class="fmp-custom-select2" data-placeholder="<?php esc_attr_e( 'Select...', 'food-menu-pro' ); ?>"<?php echo $multi . $req_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
						<?php if ( ! $multiple ) : ?>
							<option value=""><?php esc_html_e( 'Select...', 'food-menu-pro' ); ?></option>
						<?php endif; ?>
						<?php foreach ( $options as $opt ) : ?>
							<option value="<?php echo esc_attr( $opt ); ?>"><?php echo esc_html( $opt ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<?php
			} else {
				woocommerce_form_field(
					$field_id,
					[
						'type'     => 'text',
						'label'    => $label,
						'required' => $required,
						'class'    => [ 'form-row-wide' ],
					],
					$checkout->get_value( $field_id )
				);
			}
		}
		?>
	</div>

	<?php
	// Initialize Select2.
	add_action(
		'wp_footer',
		function () {
			?>
			<script>jQuery(function($){ $('.fmp-custom-select2').selectWoo({ width: '100%' }); });</script>
			<?php
		}
	);
	?>
</div>
