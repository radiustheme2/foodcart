<?php
/**
 * Custom checkout - Order Type (Pickup/Delivery) card.
 *
 * Wraps the existing pickup-delivery form in the custom card design.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$step = CheckoutFns::get_step_number( 'your_location' );
?>
<div class="co-card">
	<div class="co-card-header">
		<span class="step"><?php echo esc_html( $step ); ?></span>
		<h2><?php echo esc_html( apply_filters( 'fm_order_location_checkout_title', __( 'Food Order Location', 'food-menu-pro' ) ) ); ?></h2>
	</div>

	<div id="fmp-location-field" class="fmp-checkout-location-field">
		<div class="fmp-location-name"></div>
		<input type="hidden" name="fmp_location_name" class="fmp-location-name"/>
	</div>

</div>
