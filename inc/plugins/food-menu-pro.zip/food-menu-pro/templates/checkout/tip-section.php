<?php
/**
 * Custom checkout - Tip card.
 *
 * Wraps the existing tip form in the custom card design.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$step = CheckoutFns::get_step_number( 'tips' );
?>
<div class="co-card fmp-tip-card">
	<div class="co-card-header">
		<span class="step"><?php echo esc_html( $step ); ?></span>
		<h2><?php esc_html_e( 'Add a Tip', 'food-menu-pro' ); ?></h2>
	</div>

	<div class="fmp-custom-checkout-tip">
		<?php
		// Fire the action so the duplicate-render guard knows we rendered it here.
		do_action( 'fmp_custom_checkout_tip_rendered' );

		// Render the existing tip form.
		Fns::render( 'tip/tip-form' );
		?>
	</div>
</div>
