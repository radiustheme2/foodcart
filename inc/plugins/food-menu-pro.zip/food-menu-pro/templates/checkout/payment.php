<?php
/**
 * Custom checkout - Payment card.
 *
 * Renders WooCommerce payment gateways natively.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$step = CheckoutFns::get_step_number( 'payment' );
?>
<div class="co-card fmp-payment-card">
	<div class="co-card-header">
		<span class="step"><?php echo esc_html( $step ); ?></span>
		<h2><?php esc_html_e( 'Payment', 'food-menu-pro' ); ?></h2>
	</div>

	<div class="fmp-custom-checkout-payment woocommerce-checkout-payment" id="fmp-checkout-payment">
		<?php woocommerce_checkout_payment(); ?>
	</div>
</div>
