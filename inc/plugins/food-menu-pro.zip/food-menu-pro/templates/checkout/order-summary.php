<?php
/**
 * Custom checkout - Order Summary.
 *
 * Shows cart items, order bumps, totals, and Place Order button.
 * Used in sidebar (two-column) and inline (single-column).
 *
 * @package RT_FoodMenuPro
 *
 * @var bool $inline Whether this is the inline (single-column) variant.
 */

defined( 'ABSPATH' ) || exit;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;

$cart       = WC()->cart;
$cart_items = $cart->get_cart();
$item_count = $cart->get_cart_contents_count();
$is_inline  = ! empty( $inline );
?>

<div class="co-card fmp-order-summary-card woocommerce-checkout-review-order <?php echo $is_inline ? 'fmp-order-summary-inline' : 'fmp-order-summary-sidebar'; ?>">

	<div class="co-card-header">
		<?php if ( $is_inline ) : ?>
			<span class="step"><?php echo esc_html( CheckoutFns::get_step_number( 'order_summary' ) ); ?></span>
		<?php else : ?>
			<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--rtfm-primary-color)" stroke-width="2.2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
		<?php endif; ?>
		<h2><?php esc_html_e( 'Your Order', 'food-menu-pro' ); ?></h2>
		<span class="fmp-badge">
			<?php
			/* translators: %d: item count */
			printf( esc_html( _n( '%d item', '%d items', $item_count, 'food-menu-pro' ) ), $item_count );
			?>
		</span>
	</div>

	<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

	<?php foreach ( $cart_items as $cart_item_key => $cart_item ) : ?>
		<?php
		$product   = $cart_item['data'];
		$qty       = $cart_item['quantity'];
		$subtotal  = $cart->get_product_subtotal( $product, $qty );
		$thumbnail = $product->get_image( [ 52, 52 ] );
		$name      = $product->get_name();

		// Addon meta — flat text, split into individual lines.
		$addon_lines = [];

		if ( function_exists( 'wc_get_formatted_cart_item_data' ) ) {
			$item_data = wc_get_formatted_cart_item_data( $cart_item, true );

			if ( ! empty( $item_data ) ) {
				$raw = wp_strip_all_tags( $item_data );
				$lines = array_filter( array_map( 'trim', preg_split( '/[\n\r]+/', $raw ) ) );
				$addon_lines = array_values( $lines );
			}
		}
		?>
		<div class="fmp-order-item">
			<div class="fmp-order-item-img"><?php echo wp_kses_post( $thumbnail ); ?></div>
			<div class="fmp-order-item-details">
				<span class="fmp-order-item-name"><?php echo esc_html( $name ); ?> <span class="fmp-order-item-qty">&times; <?php echo esc_html( $qty ); ?></span></span>
				<?php if ( ! empty( $addon_lines ) ) : ?>
					<ul class="fmp-order-item-addons">
						<?php foreach ( $addon_lines as $line ) : ?>
							<li><?php echo esc_html( $line ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
			<span class="fmp-order-item-price"><?php echo wp_kses_post( $subtotal ); ?></span>
		</div>
	<?php endforeach; ?>

	<div class="fmp-order-totals-wrap woocommerce-checkout-review-order-table">
		<?php Fns::render( 'checkout/order-review-totals' ); ?>
	</div>

	<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

	<?php if ( ! $is_inline ) : ?>
		<button type="button" class="fmp-sidebar-place-order fmp-place-order-btn">
			<?php echo esc_html( CheckoutFns::get_place_order_text() ); ?> &rarr;
		</button>

		<div class="fmp-secure-badge">
			<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
			<?php esc_html_e( 'Secure checkout', 'food-menu-pro' ); ?>
		</div>
	<?php endif; ?>
</div>
