<?php
/**
 * Custom checkout coupon form.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

if ( ! wc_coupons_enabled() ) {
	return;
}
?>
<div class="co-card fmp-coupon-card">
	<form class="fmp-coupon-form checkout_coupon woocommerce-form-coupon" method="post">
		<div class="fmp-coupon-form-inline">
			<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--rtfm-primary-color)" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
			<span class="fmp-coupon-label"><?php esc_html_e( 'Have a coupon?', 'food-menu-pro' ); ?></span>
			<input type="text" name="coupon_code" class="fmp-coupon-input" placeholder="<?php esc_attr_e( 'Enter coupon code', 'food-menu-pro' ); ?>" />
			<button type="submit" class="fmp-coupon-apply-btn" name="apply_coupon" value="<?php esc_attr_e( 'Apply', 'food-menu-pro' ); ?>"><?php esc_html_e( 'Apply', 'food-menu-pro' ); ?></button>
			<?php wp_nonce_field( 'woocommerce-coupon', 'coupon_nonce' ); ?>
		</div>
	</form>
</div>
