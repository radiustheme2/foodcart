<?php
/**
 * Custom checkout - Shipping Address card.
 *
 * Ship to a different address section as a separate card.
 *
 * @package RT_FoodMenuPro
 */

defined( 'ABSPATH' ) || exit;

$checkout = WC()->checkout();
?>
<div class="co-card fmp-shipping-address-card">
	<div class="woocommerce-shipping-fields">
		<h3 id="ship-to-different-address">
			<label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
				<input id="ship-to-different-address-checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" <?php checked( apply_filters( 'woocommerce_ship_to_different_address_checked', 'shipping' === get_option( 'woocommerce_ship_to_destination' ) ? 1 : 0 ), 1 ); ?> type="checkbox" name="ship_to_different_address" value="1" />
				<span><?php esc_html_e( 'Ship to a different address?', 'woocommerce' ); ?></span>
			</label>
		</h3>

		<div class="shipping_address">
			<?php do_action( 'woocommerce_before_checkout_shipping_form', $checkout ); ?>

			<div class="woocommerce-shipping-fields__field-wrapper fmp-form-grid">
				<?php
				$shipping_fields = $checkout->get_checkout_fields( 'shipping' );

				foreach ( $shipping_fields as $key => $field ) {
					woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
				}
				?>
			</div>

			<?php do_action( 'woocommerce_after_checkout_shipping_form', $checkout ); ?>
		</div>
	</div>
</div>
