<?php
/**
 * Template: Layout 1 (Free).
 *
 * @package RT_FoodMenu
 */

use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

$add_to_cart = null;
$items       = isset( $items ) ? $items : [];

if ( $source == 'product' && $wc == true ) {
	global $product;
	$product = $_product = wc_get_product( $pID );
	$price   = $_product->get_price_html();
	$pType   = $_product->get_type();
	$pLink   = $_product->get_permalink();
	$add_to_cart_text = $_product->add_to_cart_text();
	if ( $_product->is_purchasable() ) {
		if ( $_product->is_in_stock() ) {
			ob_start();
			woocommerce_template_loop_add_to_cart();
			$add_to_cart .= apply_filters( 'rtfm_el_add_to_cart_btn', ob_get_contents(), $pLink, $pID, $pType, $add_to_cart_text, $items, $addtocart, $quantity, $add_stock );
			ob_end_clean();
		}
	}
} else {
	$price = Fns::getPriceWithLabel( $pID );
	if ( TLPFoodMenu()->has_pro() ) {
		$price = \RT\FoodMenuPro\Helpers\FnsPro::fmpHtmlPrice( $pID );
	}
}

//$class   .= ' fmp-item-' . $pID;
$wooClass = 'product' === $source ? ' woo-template' : null;

$fmp_col = !empty( $dCols ) ? $dCols : 6;
$fmp_tCol = !empty( $tCols ) ? $tCols : 6;
$fmp_mCol = !empty( $mCols ) ? $mCols : 12;

$masonry = ( $grid_style === 'masonry' ) ? 'rt-grid-item' : 'even-grid-item';

$excerpt_text = '';
if ( ! empty( $excerpt ) && 'yes' === $contentswitch ) {
	$content = $excerpt_limit ? wp_trim_words( $excerpt, $excerpt_limit, '.' ) : $excerpt;
	$excerpt_text = '<p>' . esc_html( $content ) . '</p>';
}
$target = $detail_link == 'target' ? ' target="_blank"' : '';
$icon = ( $hovericon === 'yes' ) ? 'fmp-icon-enable' : 'fmp-icon-disable';
$isotope_class = $term_class ? $term_class : '';
$popup = $fmp_el_popup == 'yes' ? 'fmp-popup' : 'fmp-link';
?>

<div class="fmp-col-md-<?php echo esc_attr( $fmp_col );?> fmp-isotope-item  fmp-col-sm-<?php echo esc_attr( $fmp_tCol );?> fmp-col-xs-<?php echo esc_attr( $fmp_mCol );?> <?php echo esc_attr( $masonry ); ?> <?php echo esc_attr( $icon ); ?> <?php echo esc_attr( $isotope_class ); ?> fmp-grid-item fmp-item-<?php echo esc_attr( $pID ); ?>">
    <div class='fmp-<?php echo esc_attr( $layout ); ?> fmp-box-wrapper fmp-el-global fmp-layout-3'>
        <div class="fmp-box">
            <div class="fmp-media">
                <?php
                $image_size = isset( $imgSize ) ? $imgSize : 'full';
                $image      = Fns::getFeatureImage( $pID, $image_size );
                if ( ! empty( $image ) ) :
                    ?>
                    <div class="fmp-image-wrap">
                        <?php if ( ! $detail_link ) : ?>
                            <?php echo $image; ?>
                        <?php else : ?>
                            <a data-id="<?php echo esc_attr( $pID ); ?>" class="<?php echo esc_attr( $popup ) ?>" href="<?php echo esc_url( get_permalink() ); ?>"<?php echo $target; ?>>
                                <?php echo $image; ?>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="fmp-media-body">
                    <div class="fmp-title">
                        <?php if ( ! empty( $title ) && $titleswitch === 'yes' ) : ?>
                            <?php if ( ! $detail_link ) : ?>
                                <h3><?php echo esc_html( $title ); ?></h3>
                            <?php else : ?>
                                <h3>
                                    <a data-id="<?php echo esc_attr( $pID ); ?>" class="<?php echo esc_attr( $popup ) ?>" href="<?php echo esc_url( get_permalink() ); ?>"<?php echo $target; ?> title="<?php echo esc_attr( get_the_title() ); ?>">
                                        <?php echo esc_html( get_the_title() ); ?>
                                    </a>
                                </h3>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if ( !empty($meta['price']) && $priceswitch == 'yes' ) { ?>
                            <div class="fmp-price price">
                                <?php echo wp_kses_post( $price ); ?>
                            </div>
                        <?php } ?>
                    </div>
                    <?php if ( 'product' === $source && 'yes' === $add_stock ) :
                        $_stock_status = get_post_meta( $pID, '_stock_status', true );
                        if ( 'outofstock' === $_stock_status ) : ?>
                            <div class="fmp-outofstock"><?php echo esc_html__( 'Out of stock', 'food-menu-pro' ); ?></div>
                        <?php else : ?>
                            <div class="fmp-wc-stock-status"><?php echo esc_html__( 'In Stock', 'food-menu-pro' ); ?></div>
                        <?php endif; ?>
                    <?php endif; ?>
	                <?php if ( (TLPFoodMenu()->has_pro() && $readmore_switch == 'yes' ) || ( ! empty( $content ) && $contentswitch === 'yes' ) || ( 'product' === $source && 'yes' === $addtocart ) ) : ?>
                        <div class="fmp-info fmp-body">
			                <?php
			                echo wp_kses_post( $excerpt_text );
			                if ( TLPFoodMenu()->has_pro() && $readmore_switch == 'yes' ) {
				                echo '<a data-id="' . esc_attr( $pID ) . '" href="' . esc_url( get_permalink() ) . '"  target="' . esc_attr( $target ) . '"  class="fmp-btn-read-more '.esc_attr( $popup ).'">' . esc_html( $readmore_text ) . '</a>';
			                }
			                if ( 'product' === $source && 'yes' === $addtocart ) {
				                echo '<div class="fmp-wc-add-to-cart-wrap">';
				                if ( ! TLPFoodMenu()->has_pro() || $addtocart === 'yes' ) {
					                echo stripslashes_deep( $add_to_cart );
				                }
				                echo '</div>';
			                }
			                ?>
                        </div>
	                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
