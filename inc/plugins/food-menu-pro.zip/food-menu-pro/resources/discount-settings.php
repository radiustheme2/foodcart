<?php

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\Discount\DiscountFns;

$fmp_menu_settings = FnsPro::get_settings_option();
?>

<?php do_action( 'fmp_before_discount_settings' ); ?>

<div class="fmp-discount-settings-container" id="discount-message">
	<div class="fmp-discount-settings-wrap" data-percentage="<?php echo esc_attr__( 'You have already chosen the percentage discount option', 'food-menu-pro' ); ?>" data-standard="<?php echo esc_attr__( 'You have already chosen the standard discount option', 'food-menu-pro' ); ?>">
		<div class="percentage-block">
			<div class='fmp-discount-fields'>
				<?php echo Fns::rtFieldGenerator( DiscountFns::percentage_settings_field() ); //phpcs:ignore ?>
			</div>
		</div>

		<div class='fixed-block'>
			<div class='fmp-discount-fields'>
				<?php echo Fns::rtFieldGenerator( DiscountFns::fixed_settings_field() ); //phpcs:ignore ?>
			</div>
		</div>

	</div>
</div>

<?php do_action( 'fmp_after_discount_settings' ); ?>
