<?php
/**
 * Delivery settings page
 */

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\PickupDelivery\PickupDeliveryFns;

$week_days    = [
	'Sat',
	'Sun',
	'Mon',
	'Tue',
	'Wed',
	'Thu',
	'Fri',
];
$fmp_settings = get_option( TLPFoodMenu()->options['settings'] );

?>

<div class="delivery-settings-page-wrap">

	<?php echo Fns::rtFieldGenerator( PickupDeliveryFns::delivery_settings_field() ); ?>

	<div class="rt-field-wrapper" id="delivery_weekly_schedule_holder">

		<div class="rt-label">
			<label><?php echo esc_html__( 'Delivery Weekly Schedule', 'food-menu-pro' ); ?></label>
		</div>

		<div class="rt-field">
			<div class="fmp-weekly-schedule-main-wrap delivery_schedule_main_block">
				<p class="description"><?php echo esc_html__( 'Weekly delivery schedule customized for one or multiple days.', 'food-menu-pro' ); ?></p>
				<?php
				$fmp_schedule['fmp_delivery_weekly_schedule']            = $fmp_settings['fmp_delivery_weekly_schedule'] ?? [];
				$fmp_schedule['fmp_delivery_weekly_schedule_start_time'] = $fmp_settings['fmp_delivery_weekly_schedule_start_time'] ?? [];
				$fmp_schedule['fmp_delivery_weekly_schedule_end_time']   = $fmp_settings['fmp_delivery_weekly_schedule_end_time'] ?? [];

				if ( is_array( $fmp_schedule['fmp_delivery_weekly_schedule'] ) && count( $fmp_schedule['fmp_delivery_weekly_schedule'] ) > 0 ) {
					for ( $index = 0; $index < count( $fmp_schedule['fmp_delivery_weekly_schedule'] ); $index++ ) {
						?>
						<div class="delivery_schedule_block delivery_weekly_block delivery_weekly_block_<?php echo esc_attr( $index ); ?>" data-id="<?php echo esc_attr( $index ); ?>">
							<div class="fmp-weekly-schedule-list">
								<?php foreach ( $week_days as $key => $value ) { ?>
									<input type="checkbox"
										   name="fmp_delivery_weekly_schedule[<?php echo intval( $index ); ?>][<?php echo esc_attr( $value ); ?>]"
										   class="<?php echo esc_attr( strtolower( $value ) ); ?>"
										   id="weekly_delivery_<?php echo esc_attr( strtolower( $value ) . $index ); ?>" <?php echo isset( $fmp_schedule['fmp_delivery_weekly_schedule'][ $index ][ $value ] ) ? 'checked' : ''; ?> />
									<label for="weekly_delivery_<?php echo esc_html( strtolower( $value ) . $index ); ?>">
										<?php echo esc_html( $value ); ?>
									</label>
								<?php } ?>
							</div>

							<div class="fmp-schedule-field multi_schedule_wrap">
								<p class="fmp-desc fmp-input-field"><?php echo esc_html__( 'Start Time', 'food-menu-pro' ); ?></p>
								<p class="fmp-desc fmp-input-field"><?php echo esc_html__( 'End Time', 'food-menu-pro' ); ?></p>
							</div>

							<div class="fmp-schedule-field">
								<?php
								$delivery_start_time = $fmp_schedule['fmp_delivery_weekly_schedule_start_time'][ $index ] ?? '';
								$delivery_end_time   = $fmp_schedule['fmp_delivery_weekly_schedule_end_time'][ $index ] ?? '';
								?>
								<div class="fmp_delivery_weekly_start_wrap">
									<input type="text" name="fmp_delivery_weekly_schedule_start_time[]" value="<?php echo esc_html( $delivery_start_time ); ?>" id="<?php echo intval( $index ); ?>" class="fmp_time_picker fmp_delivery_start_time_<?php echo intval( $index ); ?> fmp_delivery_weekly_schedule_start_time fmp_delivery_weekly_schedule_start_time_<?php echo intval( $index ); ?> fmp-input-field <?php echo empty( $delivery_start_time ) ? 'fmp_field_error' : ''; ?>" placeholder="<?php echo esc_attr__( 'Start Time', 'food-menu-pro' ); ?>" />
									<?php if ( empty( $delivery_start_time ) ) { ?>
										<span class="fmp_field_error_msg"><?php echo esc_html__( 'This field should be filled up', 'food-menu-pro' ); ?></span>
									<?php } ?>
								</div>
								<div class="fmp_delivery_weekly_end_wrap">
									<input type="text" name="fmp_delivery_weekly_schedule_end_time[]" value="<?php echo esc_attr( $delivery_end_time ); ?>" id="<?php echo intval( $index ); ?>" class="fmp_time_picker fmp_delivery_end_time_<?php echo intval( $index ); ?> fmp_delivery_weekly_schedule_end_time fmp_delivery_weekly_schedule_end_time_<?php echo intval( $index ); ?> fmp-input-field <?php echo empty( $delivery_end_time ) ? 'fmp_field_error' : ''; ?>" placeholder="<?php echo esc_attr__( 'End time', 'food-menu-pro' ); ?>" />
									<?php if ( empty( $delivery_end_time ) ) { ?>
										<span class="fmp_field_error_msg"><?php echo esc_html__( 'This field should be filled up', 'food-menu-pro' ); ?></span>
									<?php } ?>
								</div>
								<div class="fmp_delivery_weekly_clear" id="<?php echo intval( $index ); ?>">
									<span class="dashicons dashicons-update-alt" data-title="<?php echo esc_attr__( 'Reset Fields', 'food-menu-pro' ); ?>">
									</span>
								</div>
							</div>
							<div class="fmp-default-guest-message delivery_valid_message_<?php echo intval( $index ); ?>"></div>
							<?php if ( $index != 0 ) { ?>
								<span class="fmp-btn-close dashicons dashicons-no-alt remove_delivery_block pl-1"></span>
							<?php } ?>
						</div>
						<?php
					}
				} else {
					?>
					<div class="delivery_schedule_block delivery_weekly_block delivery_weekly_block_0" data-id="<?php echo esc_attr( 0 ); ?>">
						<div class="fmp-weekly-schedule-list">
							<?php foreach ( $week_days as $key => $value ) { ?>
								<input type="checkbox" name="fmp_delivery_weekly_schedule[0][<?php echo esc_html( $value ); ?>]" class="<?php echo esc_html( strtolower( $value ) ); ?>" id="weekly_delivery_<?php echo esc_html( strtolower( $value ) ) . '0'; ?>" /><label for="weekly_delivery_<?php echo esc_html( strtolower( $value ) ) . '0'; ?>"><?php echo esc_html( $value ); ?></label>
							<?php } ?>
						</div>
						<div class="fmp-schedule-field">
							<div class="fmp_delivery_weekly_start_wrap">
								<input type="text" name="fmp_delivery_weekly_schedule_start_time[]" disabled id="0" class="fmp_time_picker fmp_delivery_start_time_0 fmp_delivery_weekly_schedule_start_time fmp_delivery_weekly_schedule_start_time_0 fmp-input-field" placeholder="<?php echo esc_attr__( 'Start Time', 'food-menu-pro' ); ?>" />
							</div>
							<div class="fmp_delivery_weekly_end_wrap">
								<input type="text" name="fmp_delivery_weekly_schedule_end_time[]" disabled id="0" class="fmp_time_picker fmp_delivery_end_time_0 fmp_delivery_weekly_schedule_end_time fmp_delivery_weekly_schedule_end_time_0 fmp-input-field" placeholder="<?php echo esc_attr__( 'End Time', 'food-menu-pro' ); ?>" />
							</div>

							<div class="fmp_delivery_weekly_clear" id="0" style="display: none;">
								<span class="dashicons dashicons-update-alt" data-title="<?php echo esc_attr__( 'Reset Fields', 'food-menu-pro' ); ?>"></span>
							</div>

						</div>
						<div class="fmp-default-guest-message delivery_valid_message_0"></div>
					</div>
					<?php
				}
				?>
			</div>
			<div class="fmp_flex_reverse fmp-weekly-schedule-btn">
				<span class="add_delivery_weekly_block fmp-btn-text" data-clear_text="<?php echo esc_attr__( 'Reset Fields', 'food-menu-pro' ); ?>" data-remove_text="<?php echo esc_attr__( 'Remove Fields', 'food-menu-pro' ); ?>" data-clear_text="<?php echo esc_attr__( 'Reset Fields', 'food-menu-pro' ); ?>" data-remove_text="<?php echo esc_attr__( 'Remove Fields', 'food-menu-pro' ); ?>" data-title="<?php echo esc_attr__( 'Add more weekly schedule', 'food-menu-pro' ); ?>" data-start_time="<?php echo esc_attr__( 'Start Time', 'food-menu-pro' ); ?>" data-end_time="<?php echo esc_html__( 'End Time', 'food-menu-pro' ); ?>">
				<?php echo esc_html__( 'Add', 'food-menu-pro' ); ?>
				</span>
			</div>
		</div>

	</div>

	<div class="rt-field-wrapper" id="delivery_weekly_holiday">
		<div class="rt-label">
			<label><?php echo esc_html__( 'Delivery Weekly Holiday', 'food-menu-pro' ); ?></label>
		</div>

		<div class="rt-field">
			<?php
			$delivery_holiday = $fmp_settings['fmp_delivery_weekly_holiday'] ?? [];
			$holidays         = [ 'Sun','Mon','Tue','Wed','Thu','Fri','Sat' ];
			if ( is_array( $delivery_holiday ) && count( $delivery_holiday ) > 0 ) {
				foreach ( $holidays as $key => $value ) {
					?>
					<input type="checkbox" name="fmp_delivery_weekly_holiday[<?php echo intval( $key ); ?>]" <?php echo isset( $delivery_holiday[ $key ] ) ? 'checked' : ''; ?>
						   id="fmp_delivery_weekly_holiday_<?php echo esc_html( strtolower( $value ) ); ?>" />
					<label for="fmp_delivery_weekly_holiday_<?php echo esc_html( strtolower( $value ) ); ?>"><?php echo esc_html( $value ); ?></label>
					<?php
				}
			} else {
				foreach ( $holidays as $key => $value ) {
					?>
					<input type="checkbox" name="fmp_delivery_weekly_holiday[<?php echo intval( $key ); ?>]" id="fmp_delivery_weekly_holiday_<?php echo esc_html( strtolower( $value ) ); ?>" />
					<label for="fmp_delivery_weekly_holiday_<?php echo esc_html( strtolower( $value ) ); ?>"><?php echo esc_html( $value ); ?></label>
					<?php
				}
			}
			?>
		</div>
	</div>

</div>
