<?php
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\Reservation\ReservationFns;

$week_days = [
	'Sat',
	'Sun',
	'Mon',
	'Tue',
	'Wed',
	'Thu',
	'Fri',
];

$fmp_settings = get_option( TLPFoodMenu()->options['settings'] );

?>

<div class="fmp-reservation-settings-wrap">
	<div class="fmp-sub-setting-container">

		<ul class="fmp-sub-setting-nav">
			<li>
				<a href="#general_setting" class="fmp-sub-nav active">
					<?php esc_html_e( 'General', 'food-menu-pro' ); ?>
				</a>
			</li>
			<li>
				<a href="#email_setting" class="fmp-sub-nav">
					<?php esc_html_e( 'Email Setting', 'food-menu-pro' ); ?>
				</a>
			</li>
		</ul>

		<div id="general_setting" class="fmp-sub-tab-content">
			<?php echo Fns::rtFieldGenerator( ReservationFns::schedule_settings_fields() ); //phpcs:ignore ?>

			<div class="rt-field-wrapper" id="resi_weekly_schedule_holder">

				<div class="rt-label">
					<label><?php echo esc_html__( 'Weekly Schedule', 'food-menu-pro' ); ?></label>
				</div>

				<div class="rt-field">

					<div class="fmp-weekly-schedule-main-wrap resi_schedule_main_block">
						<p class="description"><?php echo esc_html__( 'Customize a weekly reservation schedule to accommodate single or multiple days.', 'food-menu-pro' ); ?></p>
						<?php
						$fmp_schedule['fmp_resi_weekly_schedule']            = $fmp_settings['fmp_resi_weekly_schedule'] ?? [];
						$fmp_schedule['fmp_resi_weekly_schedule_start_time'] = $fmp_settings['fmp_resi_weekly_schedule_start_time'] ?? [];
						$fmp_schedule['fmp_resi_weekly_schedule_end_time']   = $fmp_settings['fmp_resi_weekly_schedule_end_time'] ?? [];

						if ( is_array( $fmp_schedule['fmp_resi_weekly_schedule'] ) && count( $fmp_schedule['fmp_resi_weekly_schedule'] ) > 0 ) {
							for ( $index = 0; $index < count( $fmp_schedule['fmp_resi_weekly_schedule'] ); $index++ ) {
								?>
								<div class="resi_schedule_block resi_weekly_block resi_weekly_block_<?php echo esc_attr( $index ); ?>" data-id="<?php echo esc_attr( $index ); ?>">
									<div class="fmp-weekly-schedule-list">
										<?php foreach ( $week_days as $key => $value ) { ?>
											<input type="checkbox" name="fmp_resi_weekly_schedule[<?php echo intval( $index ); ?>][<?php echo esc_attr( $value ); ?>]"
												   class="<?php echo esc_attr( strtolower( $value ) ); ?>"
												   id="weekly_resi_<?php echo esc_attr( strtolower( $value ) . $index ); ?>" <?php echo isset( $fmp_schedule['fmp_resi_weekly_schedule'][ $index ][ $value ] ) ? 'checked' : ''; ?> />
											<label for="weekly_resi_<?php echo esc_html( strtolower( $value ) . $index ); ?>">
												<?php echo esc_html( $value ); ?>
											</label>
										<?php } ?>
									</div>

									<div class="fmp-schedule-field multi_schedule_wrap">
										<p class="fmp-desc fmp-input-field"><?php echo esc_html__( 'Start Time', 'food-menu-pro' ); ?></p>
										<p class="fmp-desc fmp-input-field"><?php echo esc_html__( 'End Time', 'food-menu-pro' ); ?></p>
									</div>

									<div class="fmp-schedule-field">
										<?php
										$resi_start_time = $fmp_schedule['fmp_resi_weekly_schedule_start_time'][ $index ] ?? '';
										$resi_end_time   = $fmp_schedule['fmp_resi_weekly_schedule_end_time'][ $index ] ?? '';
										?>
										<div class="fmp_resi_weekly_start_wrap">
											<input type="text" name="fmp_resi_weekly_schedule_start_time[]" value="<?php echo esc_html( $resi_start_time ); ?>" id="<?php echo intval( $index ); ?>" class="fmp_time_picker fmp_resi_start_time_<?php echo intval( $index ); ?> fmp_resi_weekly_schedule_start_time fmp_resi_weekly_schedule_start_time_<?php echo intval( $index ); ?> fmp-input-field <?php echo empty( $resi_start_time ) ? 'fmp_field_error' : ''; ?>" placeholder="<?php echo esc_attr__( 'Start Time', 'food-menu-pro' ); ?>" />
											<?php if ( empty( $resi_start_time ) ) { ?>
												<span class="fmp_field_error_msg"><?php echo esc_html__( 'This field should be filled up', 'food-menu-pro' ); ?></span>
											<?php } ?>
										</div>
										<div class="fmp_resi_weekly_end_wrap">
											<input type="text" name="fmp_resi_weekly_schedule_end_time[]" value="<?php echo esc_attr( $resi_end_time ); ?>" id="<?php echo intval( $index ); ?>" class="fmp_time_picker fmp_resi_end_time_<?php echo intval( $index ); ?> fmp_resi_weekly_schedule_end_time fmp_resi_weekly_schedule_end_time_<?php echo intval( $index ); ?> fmp-input-field <?php echo empty( $resi_end_time ) ? 'fmp_field_error' : ''; ?>" placeholder="<?php echo esc_attr__( 'End time', 'food-menu-pro' ); ?>" />
											<?php if ( empty( $resi_end_time ) ) { ?>
												<span class="fmp_field_error_msg"><?php echo esc_html__( 'This field should be filled up', 'food-menu-pro' ); ?></span>
											<?php } ?>
										</div>
										<div class="fmp_resi_weekly_clear" id="<?php echo intval( $index ); ?>">
											<span class="dashicons dashicons-update-alt" data-title="<?php echo esc_attr__( 'Reset Fields', 'food-menu-pro' ); ?>"></span>
										</div>
									</div>
									<div class="fmp-default-guest-message resi_valid_message_<?php echo intval( $index ); ?>"></div>

									<?php if ( $index != 0 ) { ?>
										<span class="fmp-btn-close dashicons dashicons-no-alt remove_resi_block"></span>
									<?php } ?>
								</div>
								<?php
							}
						} else {
							?>
							<div class="resi_schedule_block resi_weekly_block resi_weekly_block_0" data-id="<?php echo esc_attr( 0 ); ?>">
								<div class="fmp-weekly-schedule-list">
									<?php foreach ( $week_days as $key => $value ) { ?>
										<input type="checkbox" name="fmp_resi_weekly_schedule[0][<?php echo esc_html( $value ); ?>]" class="<?php echo esc_html( strtolower( $value ) ); ?>" id="weekly_resi_<?php echo esc_html( strtolower( $value ) ) . '0'; ?>" /><label for="weekly_resi_<?php echo esc_html( strtolower( $value ) ) . '0'; ?>"><?php echo esc_html( $value ); ?></label>
									<?php } ?>
								</div>
								<div class="fmp-schedule-field">
									<div class="fmp_resi_weekly_start_wrap">
										<input type="text" name="fmp_resi_weekly_schedule_start_time[]" disabled id="0" class="fmp_time_picker fmp_resi_start_time_0 fmp_resi_weekly_schedule_start_time fmp_resi_weekly_schedule_start_time_0 fmp-input-field" placeholder="<?php echo esc_attr__( 'Start Time', 'food-menu-pro' ); ?>" />
									</div>
									<div class="fmp_resi_weekly_end_wrap">
										<input type="text" name="fmp_resi_weekly_schedule_end_time[]" disabled id="0" class="fmp_time_picker fmp_resi_end_time_0 fmp_resi_weekly_schedule_end_time fmp_resi_weekly_schedule_end_time_0 fmp-input-field" placeholder="<?php echo esc_attr__( 'End Time', 'food-menu-pro' ); ?>" />
									</div>
									<div class="fmp_resi_weekly_clear" id="0" style="display: none;">
										<span class="dashicons dashicons-update-alt" data-title="<?php echo esc_attr__( 'Reset Fields', 'food-menu-pro' ); ?>"></span>
									</div>
								</div>
								<div class="fmp-default-guest-message resi_valid_message_0"></div>
							</div>
							<?php
						}
						?>
					</div>
					<div class="fmp_flex_reverse fmp-weekly-schedule-btn">
				<span class="add_resi_weekly_block fmp-btn-text" data-clear_text="<?php echo esc_attr__( 'Reset Fields', 'food-menu-pro' ); ?>" data-remove_text="<?php echo esc_attr__( 'Remove Fields', 'food-menu-pro' ); ?>" data-clear_text="<?php echo esc_attr__( 'Reset Fields', 'food-menu-pro' ); ?>" data-remove_text="<?php echo esc_attr__( 'Remove Fields', 'food-menu-pro' ); ?>" data-title="<?php echo esc_attr__( 'Add more weekly schedule', 'food-menu-pro' ); ?>" data-start_time="<?php echo esc_attr__( 'Start Time', 'food-menu-pro' ); ?>" data-end_time="<?php echo esc_html__( 'End Time', 'food-menu-pro' ); ?>">
				<?php echo esc_html__( 'Add', 'food-menu-pro' ); ?>
				</span>
					</div>
				</div>
			</div>

			<div class="rt-field-wrapper" id="resi_weekly_holiday">
				<div class="rt-label">
					<label><?php echo esc_html__( 'Weekly Holiday', 'food-menu-pro' ); ?></label>
				</div>

				<div class="rt-field">
					<?php
					$resi_holiday = $fmp_settings['fmp_resi_weekly_holiday'] ?? [];
					$holidays     = [ 'Sun','Mon','Tue','Wed','Thu','Fri','Sat' ];
					if ( is_array( $resi_holiday ) && count( $resi_holiday ) > 0 ) {
						foreach ( $holidays as $key => $value ) {
							?>
							<input type="checkbox" name="fmp_resi_weekly_holiday[<?php echo intval( $key ); ?>]" <?php echo isset( $resi_holiday[ $key ] ) ? 'checked' : ''; ?>
								   id="fmp_resi_weekly_holiday_<?php echo esc_html( strtolower( $value ) ); ?>" />
							<label for="fmp_resi_weekly_holiday_<?php echo esc_html( strtolower( $value ) ); ?>"><?php echo esc_html( $value ); ?></label>
							<?php
						}
					} else {
						foreach ( $holidays as $key => $value ) {
							?>
							<input type="checkbox" name="fmp_resi_weekly_holiday[<?php echo intval( $key ); ?>]" id="fmp_resi_weekly_holiday_<?php echo esc_html( strtolower( $value ) ); ?>" />
							<label for="fmp_resi_weekly_holiday_<?php echo esc_html( strtolower( $value ) ); ?>"><?php echo esc_html( $value ); ?></label>
							<?php
						}
					}
					?>

					<p class="description"><?php echo esc_html__( 'Choose weekly holiday.', 'food-menu-pro' ); ?></p>

				</div>
			</div>

			<?php echo Fns::rtFieldGenerator( ReservationFns::general_settings_fields() ); //phpcs:ignore ?>
		</div>

		<div id="email_setting" class="fmp-sub-tab-content">
			<?php echo Fns::rtFieldGenerator( ReservationFns::email_settings_fields() ); //phpcs:ignore ?>
		</div>

	</div>
</div>
