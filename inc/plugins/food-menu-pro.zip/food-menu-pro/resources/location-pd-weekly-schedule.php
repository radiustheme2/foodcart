<?php
/**
 * Per-location Pickup/Delivery weekly schedule (new format — per-day, multi-slot, max order).
 *
 * Design mirrors the React WeeklySchedule component from the settings page.
 *
 * Variables available via extract():
 *   $prefix  - 'pickup', 'delivery' or 'dinein'
 *   $term_id - term ID (0 for add form)
 *
 * Stores data in term meta: fmp_loc_new_{$prefix}_weekly_schedule
 *
 * @package RT_FoodMenuPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$meta_key          = "fmp_loc_new_{$prefix}_weekly_schedule";
$slot_limits_on    = ! empty( $slot_limits_enabled );
$schedule          = [];
if ( $term_id > 0 ) {
	$schedule = get_term_meta( $term_id, $meta_key, true ) ?: [];
}

$days = [
	'monday'    => 'Monday',
	'tuesday'   => 'Tuesday',
	'wednesday' => 'Wednesday',
	'thursday'  => 'Thursday',
	'friday'    => 'Friday',
	'saturday'  => 'Saturday',
	'sunday'    => 'Sunday',
];

$default_slot = [ 'start' => '', 'end' => '', 'max_order' => '' ];
// 'dinein' would read as "Dinein" through ucfirst(), so label it explicitly.
$labels = [
	'pickup'   => __( 'Pickup', 'food-menu-pro' ),
	'delivery' => __( 'Delivery', 'food-menu-pro' ),
	'dinein'   => __( 'Dine In', 'food-menu-pro' ),
];
$label  = $labels[ $prefix ] ?? ucfirst( $prefix );
?>

<div class="fmp-loc-weekly-wrap" data-meta-key="<?php echo esc_attr( $meta_key ); ?>" style="margin-top:16px;">
	<div class="fmp-loc-weekly-header">
		<span class="fmp-loc-weekly-header-label"><?php echo esc_html( sprintf( __( '%s Weekly Schedule', 'food-menu-pro' ), $label ) ); ?></span>
	</div>

	<table class="fmp-loc-weekly-tbl">
		<thead>
			<tr>
				<th class="fmp-wt-col-day"><?php esc_html_e( 'Day', 'food-menu-pro' ); ?></th>
				<th><?php echo $slot_limits_on ? esc_html__( 'Time Slots: Start to End — Max Orders', 'food-menu-pro' ) : esc_html__( 'Time Slots: Start to End', 'food-menu-pro' ); ?></th>
				<th></th>
				<th class="fmp-wt-col-holiday"><?php esc_html_e( 'Holiday', 'food-menu-pro' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( $days as $day_key => $day_label ) :
			$day_data     = $schedule[ $day_key ] ?? [ 'is_open' => 'yes', 'slots' => [ $default_slot ] ];
			$is_open      = ( $day_data['is_open'] ?? 'yes' ) === 'yes';
			$slots        = ! empty( $day_data['slots'] ) && is_array( $day_data['slots'] ) ? $day_data['slots'] : [ $default_slot ];
			$closed_class = $is_open ? '' : 'fmp-wt-day-closed';
			$input_class  = $is_open ? '' : 'fmp-wt-disabled';
			?>
			<tr class="<?php echo esc_attr( $closed_class ); ?>" data-day="<?php echo esc_attr( $day_key ); ?>">
				<td class="fmp-wt-col-day">
					<span class="fmp-wt-day-name <?php echo $is_open ? '' : 'fmp-wt-day-off'; ?>"><?php echo esc_html( $day_label ); ?></span>
				</td>
				<td class="fmp-wt-col-slots">
					<div class="fmp-wt-slots">
						<?php foreach ( $slots as $si => $slot ) : ?>
							<div class="fmp-wt-slot" data-slot-index="<?php echo intval( $si ); ?>">
								<input type="text"
									   name="<?php echo esc_attr( $meta_key ); ?>[<?php echo esc_attr( $day_key ); ?>][slots][<?php echo intval( $si ); ?>][start]"
									   value="<?php echo esc_attr( $slot['start'] ?? '' ); ?>"
									   class="fmp_time_picker fmp-wt-time-input <?php echo esc_attr( $input_class ); ?>"
									   placeholder="<?php esc_attr_e( 'Start', 'food-menu-pro' ); ?>"
									   <?php echo $is_open ? '' : 'disabled'; ?> />
								<span class="fmp-wt-sep"> - </span>
								<input type="text"
									   name="<?php echo esc_attr( $meta_key ); ?>[<?php echo esc_attr( $day_key ); ?>][slots][<?php echo intval( $si ); ?>][end]"
									   value="<?php echo esc_attr( $slot['end'] ?? '' ); ?>"
									   class="fmp_time_picker fmp-wt-time-input <?php echo esc_attr( $input_class ); ?>"
									   placeholder="<?php esc_attr_e( 'End', 'food-menu-pro' ); ?>"
									   <?php echo $is_open ? '' : 'disabled'; ?> />
								<?php if ( $slot_limits_on ) : ?>
								<span class="fmp-wt-sep"></span>
								<input type="number"
									   name="<?php echo esc_attr( $meta_key ); ?>[<?php echo esc_attr( $day_key ); ?>][slots][<?php echo intval( $si ); ?>][max_order]"
									   value="<?php echo esc_attr( $slot['max_order'] ?? '' ); ?>"
									   class="fmp-wt-max-input <?php echo esc_attr( $input_class ); ?>"
									   placeholder="<?php esc_attr_e( 'Max Orders', 'food-menu-pro' ); ?>"
									   min="0"
									   <?php echo $is_open ? '' : 'disabled'; ?> />
								<?php endif; ?>
								<?php if ( $is_open && count( $slots ) > 1 ) : ?>
									<button type="button" class="fmp-wt-slot-remove" title="<?php esc_attr_e( 'Remove slot', 'food-menu-pro' ); ?>">
										<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/></svg>
									</button>
								<?php endif; ?>
								<?php if ( $is_open && $si === count( $slots ) - 1 ) : ?>
									<button type="button" class="fmp-wt-slot-add" data-day="<?php echo esc_attr( $day_key ); ?>" title="<?php esc_attr_e( 'Add slot', 'food-menu-pro' ); ?>">
										<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/></svg>
									</button>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				</td>
				<td class="fmp-wt-col-apply">
					<?php if ( $is_open ) : ?>
						<button type="button" class="fmp-wt-apply-all" data-day="<?php echo esc_attr( $day_key ); ?>"><?php esc_html_e( 'Apply to all', 'food-menu-pro' ); ?></button>
					<?php endif; ?>
				</td>
				<td class="fmp-wt-col-holiday">
					<label class="fmp-wt-toggle">
						<input type="checkbox"
							   class="fmp-wt-holiday-check"
							   data-day="<?php echo esc_attr( $day_key ); ?>"
							   <?php checked( ! $is_open ); ?> />
						<span class="fmp-wt-toggle-slider"></span>
					</label>
					<input type="hidden"
						   name="<?php echo esc_attr( $meta_key ); ?>[<?php echo esc_attr( $day_key ); ?>][is_open]"
						   value="<?php echo $is_open ? 'yes' : 'no'; ?>"
						   class="fmp-wt-is-open" />
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php if ( $slot_limits_on ) : ?>
	<p class="description" style="margin-top:8px; padding:10px;border-top:1px solid #e8e8e8;max-width:100%; font-style:italic; color:#646970;"><?php esc_html_e( 'Leave "Max Orders" empty to use the location\'s or global max-orders-per-slot setting.', 'food-menu-pro' ); ?></p>
	<?php endif; ?>
</div>
