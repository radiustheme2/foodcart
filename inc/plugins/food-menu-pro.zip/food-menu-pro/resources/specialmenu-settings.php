<?php

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\SpecialMenu\SpecialMenuFns;

$fmp_menu_settings = FnsPro::get_settings_option();

?>

<?php do_action( 'fmp_before_special_menu_settings' ); ?>
	<div class="fmp-menu-settings-wrap">
		<?php echo Fns::rtFieldGenerator( SpecialMenuFns::settings_fields() ); //phpcs:ignore ?>
	</div>
<?php
do_action( 'fmp_after_special_menu_settings' );
