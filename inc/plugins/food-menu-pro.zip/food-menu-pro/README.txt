=== Food Menu Pro ===
Contributors: techlabpro1
Donate link:
Tags: food, food menu, menu, cafe, coffee, cuisine, dining, drink, restaurant, restaurant menu, tlp food menu.
Requires at least: 6.5
Tested up to: 7.0
Stable tag: 6.0.7

== Changelog ==

<h4>Version 6.0.7.1 [UNRELEASED]</h4>
<pre>
Fixed: "Select Options" button on category layout links to the product again
</pre>

<h4>Version 6.0.7 ( Nov 9, 2026 )</h4>
<pre>
New: Option to hide the Kitchen Monitor Pause Orders button from staff
New: CSV import/export includes sale price, stock, tags, gallery, ingredients and nutrition
New: Settings export/import also carries custom order statuses
New: Ingredients and Nutrition Facts on WooCommerce products, also available via the Store API
Improved: Kitchen Monitor refreshes on tab return and restarts the alarm for new orders
Improved: Kitchen Monitor shows a notice when the browser blocks the alert sound
Fixed: Kitchen Monitor alert sound now plays reliably on tablets, kiosks and failed custom sounds
Fixed: Kitchen Monitor search box showed a double border with some themes
Security: Customers could edit order items, variation or addon prices, or delete posts
Security: Customers could list all orders, deactivate the license or pause orders
Security: Visitors could overwrite the reservation table layout
Security: Dashboard staff are now limited to their assigned menus and locations
Security: Checkout slot and table limits can't be skipped, prices can't be negative
Security: Elementor pagination and quick view could expose unpublished posts or plugin files
Security: Extra permission checks and safer escaping on sorting, attributes, imports and lists
</pre>

<h4>Version 6.0.5 ( Sep 8, 2026 )</h4>
<pre>
New: Show or hide the "Free" badge on addon options, site-wide or per addon group
New: Report settings page to exclude order statuses from dashboard report totals
New: Set how many days the dashboard reports cover on first load
Improved: Even spacing between addon options in radio and checkbox groups
Improved: Role Manager users are collapsed by default, with an arrow to expand each one
Improved: Deleted users are flagged "Invalid user" in Role Manager instead of showing a bare ID
Improved: Moved "Statuses That Count As Sales" from Inventory to the new Report page
Improved: Cancelled, Failed, Refunded and Pending payment can no longer be removed from report exclusions
Improved: Order Timeline now shows the exact time of each status change
Improved: Order Timeline is now on by default, so order history is recorded from day one
Fixed: Order Timeline times followed the viewer's timezone instead of the store's
Fixed: Time slot order limits counted orders from every slot on older WooCommerce order storage
Fixed: Location filter and new-order counts ignored on older WooCommerce order storage
Fixed: Addon and grand totals stuck at zero when an option price was left non-numeric
</pre>

<h4>Version 6.0.4 ( Aug 18, 2026 )</h4>
<pre>
New: Choose which order statuses count as sales in the inventory reports
Improved: AJAX add to cart now works for every product type, without a page reload
Improved: Sales Amount card now shows the gross total including tax
Improved: Inventory popups now show the product name, regular price and sale price
New: Edit product and View product links in the inventory popups, opening in new tabs
Added: Sales report status setting under Front-End Dashboard settings (Pro)
Fixed: Unit cost price could be saved higher than the product selling price
Fixed: Excluded product types still appeared in the dashboard reports and inventory figures
Fixed: Dashboard and reports showed the wrong currency symbol and decimals
Fixed: On-hold orders were left out of sales reports, under-reporting revenue
Fixed: Report date picker calendar was unusable on mobile screens
Fixed: Variable and add-on products redirected to the product page for logged-out visitors
Fixed: Add to cart could pick up fields from another product's form
</pre>

<h4>Version 6.0.3 ( Aug 16, 2026 )</h4>
<pre>
New: Dine In order type with table selection, weekly schedule, time slots and slot limits
New: Dine In settings tab with a table list, optionally scoped per location
New: Order type, location, date and time fields on the Create Order screen
Improved: Dine In details on the orders list, quick view, order panel, POS slips, Kitchen Monitor and customer order page
Improved: New WhatsApp and SMS placeholders — {order_type}, {order_schedule}, {table_number}
Improved: Added food item check-off functionality to the Kitchen Monitor
Improved: Added customizable alarm settings for the Kitchen Monitor
</pre>

<h4>Version 6.0.2 ( Aug 11, 2026 )</h4>
<pre>
New: Shift Reports — Day and Night shift filter on reports
Improved: Report times follow the site Time Format setting
Improved: Reports tabs and filters redesigned into separate, clearer sections
Fixed: Inventory log recorded a different reason and note for each item of the same order
Fixed: Inventory log was not recorded for orders created from the Frontend Order Dashboard
</pre>

=  6.0.1 ( Jul 15, 2026 ) =
Improved: POS Printing system improved
Added: New Receipt slip added in POS Printing
Updated: Isotope layout improved

=  6.0.0 ( Jun 24, 2026 ) =
New: QR Code Table Ordering — dine-in QR scan → table session → order meta
New: Minimal Checkout for QR Orders — stripped-down checkout for dine-in
New: Timed Products — per-product availability schedules
New: Custom Order Statuses — WhatsApp, messages and email notifications per status
New: Order Timeline — visual status journey on admin order page
New: Order Tracking — public customer tracking page (ID + email lookup)
New: Order Bumps — checkout cross-sell suggestions in the minicart
New: Custom Checkout with multi-step flow, configurable sections, and flexible layout options.
New: Order Custom Fields — define extra checkout fields (select and text) without code
New: POS Printing — 4 slip types (order confirmation, kitchen, packing, delivery driver)
New: SMS & WhatsApp — order + status messages via WhatsApp and mobile message
New: Frontend Order Dashboard — staff-facing order/inventory UI outside wp-admin
New: Inventory Management — stock tracking, wastage, reports, activity logs
New: Kitchen Monitor — live order board, order managed, audio alerts, status toggle
New: Role Manager — for role-based access to orders, inventory, and Kitchen Monitor management.
Integration: WooCommerce Blocks Cart + Checkout integration (Pickup/Delivery, Tip, Custom Checkout)
Integration: AJAX review submission in quick-view popup (no full page reload)
Improved: Pickup/Delivery: preorder days limit, schedule + holidays, full details on order-received page
Improved: Elementor widgets: stock visibility, low-stock badge, QR-aware add-to-cart
Improved: Product Addons — Improved functionality and Server-side validation
Improved: Security: nonce + capability checks on all REST + AJAX endpoints
Added: Special Menu — Added new 3 style and Exclude Pages option
Added: Order Meta — Food Menu order meta section added in order edit page

= 5.3.1 ( August 28, 2025 ) =
* Fixed: Elementor Activation Error

= 5.3.0 ( August 19, 2025 ) =
* Add: Add Elementor Widgets Grid Layouts, Slider Layouts, Isotope Layouts

= 5.2.2 ( Jul 11, 2025 ) =
* Fixed: Addon price calculation error (NaN)

= 5.2.1 ( Jul 10, 2025 ) =
* Fixed: Reservation bug fixed and export issue fixed
* Fixed: Reservation redesign and mail functional
* Fixed: Pickup and Delivery start time should be grater than the current
* Fixed: Product addon bug fixed
* Fixed: Pickup and delivery time not working js error
* Fixed: Isotope layout responsive issue fixed
* Fixed: A Thousand and decimal separator doesn't work with product addon
* Fixed: Popup layout gallery for woo not working
* Fixed: Isotope Filter order not working
* Fixed: Woocommerce isotope popup not working

= 5.2.0 ( Apr 6, 2025 ) =
* Added: Visual Table Reservation feature with drag-and-drop table builder and frontend table selection support.
* Fixed: Product addon not showing properly.

= 5.1.3 ( Feb 28, 2025 ) =
* Fixed: Multiple Product Addons don't work properly.

= 5.1.2 ( Feb 7, 2025 ) =
* Fixed: Delivery and pickup time now display correctly in quick preview
* Fixed: Resolved issue where delivery and pickup times were not appearing
* Fixed: Delivery settings now save properly
* Fixed: License information now displays correctly
* Fixed: Tip not showing anywhere

= 5.1.1 ( Jan 30, 2025 ) =
* Fixed: Food Review Title escaping issue
* Fixed: Error through from pro plugin

= 5.1.0 ( Jan 29, 2025 ) =
* Security Updated: Sanitize all inputs, and added nonce and user permission for admin ajax
* Modify: Settings Modify
* Release: Reservation Beta release
* Fixed: Ingredient and Nutrition drag and drop (editor) issue fixed
* Fixed: Ingredient and Nutrition Units not showing until saving the post
* Fixed: Old category remove after activate the por plugin
* Fixed: Popup primary color doesn't work

= 5.0.5 ( Aug 19, 2024 ) =
* Fixed: Food List drag and drop order not working
* Fixed: Food Category drag and drop order not working

= 5.0.4 ( Aug 8, 2024 ) =
* Fixed: Category not saved if pro exist
* Fixed: Ingredient and Nutrition front-end issue fixed
* Added: Hide Empty option for category
* Fixed: Load duplicate post in isotope Load More button

= 5.0.3 ( May 31, 2024 ) =
* Added: Some layout product stock status display options
* Fixed: Design css issues

= 5.0.2 ( May 31, 2024 ) =
* Added: Product addon is required show select options
* Fixed: isotope layout two select option set popup
* Fixed: Design css issues

= 5.0.1 ( April 23, 2024 ) =
* Added: Ajax single product add to cart
* Fixed: Design css issues
* Fixed: Product addon frontend mini cart price update

= 5.0.0 ( April 16, 2024 ) =
* Added: Product Addons
* Added: Tipping
* Added: Delivery & Pickup
* Added: Food Location Product Taxonomy address & google map
* Added: Discount
* Added: Special Menu
* Improved: Admin settings panel design improve
* Fixed: Design css issues fixed