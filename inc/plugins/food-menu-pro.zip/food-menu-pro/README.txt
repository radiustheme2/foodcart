=== Food Menu Pro ===
Contributors: techlabpro1
Donate link:
Tags: food, food menu, menu, cafe, coffee, cuisine, dining, drink, restaurant, restaurant menu, tlp food menu.
Requires at least: 4.5
Tested up to: 6.7
Stable tag: 5.2.2

== Changelog ==

= 5.3.1 ( August 28, 2025 ) =
* Fixed: Elementor Activation Error

= 5.3.0 ( August 19, 2025 ) =
* Add: Add Elementor Widgets Grid Layouts, Slider Layouts, Isotope Layouts

= 5.2.2 ( Jul 11, 2025 ) =
* Fixed: Addon price calculation error (NaN)

= 5.2.1 ( Jul 10, 2025 ) =
* Fixed: Reservation bug fixed and export issue fixed
* Fixed: Reservation redesign and mail functional
* Fixed: Pickup and Delivery start time should be grater than the current
* Fixed: Product addon bug fixed
* Fixed: Pickup and delivery time not working js error
* Fixed: Isotope layout responsive issue fixed
* Fixed: A Thousand and decimal separator doesn't work with product addon
* Fixed: Popup layout gallery for woo not working
* Fixed: Isotope Filter order not working
* Fixed: Woocommerce isotope popup not working

= 5.2.0 ( Apr 6, 2025 ) =
* Added: Visual Table Reservation feature with drag-and-drop table builder and frontend table selection support.
* Fixed: Product addon not showing properly.

= 5.1.3 ( Feb 28, 2025 ) =
* Fixed: Multiple Product Addons don't work properly.

= 5.1.2 ( Feb 7, 2025 ) =
* Fixed: Delivery and pickup time now display correctly in quick preview
* Fixed: Resolved issue where delivery and pickup times were not appearing
* Fixed: Delivery settings now save properly
* Fixed: License information now displays correctly
* Fixed: Tip not showing anywhere

= 5.1.1 ( Jan 30, 2025 ) =
* Fixed: Food Review Title escaping issue
* Fixed: Error through from pro plugin

= 5.1.0 ( Jan 29, 2025 ) =
* Security Updated: Sanitize all inputs, and added nonce and user permission for admin ajax
* Modify: Settings Modify
* Release: Reservation Beta release
* Fixed: Ingredient and Nutrition drag and drop (editor) issue fixed
* Fixed: Ingredient and Nutrition Units not showing until saving the post
* Fixed: Old category remove after activate the por plugin
* Fixed: Popup primary color doesn't work

= 5.0.5 ( Aug 19, 2024 ) =
* Fixed: Food List drag and drop order not working
* Fixed: Food Category drag and drop order not working

= 5.0.4 ( Aug 8, 2024 ) =
* Fixed: Category not saved if pro exist
* Fixed: Ingredient and Nutrition front-end issue fixed
* Added: Hide Empty option for category
* Fixed: Load duplicate post in isotope Load More button

= 5.0.3 ( May 31, 2024 ) =
* Added: Some layout product stock status display options
* Fixed: Design css issues

= 5.0.2 ( May 31, 2024 ) =
* Added: Product addon is required show select options
* Fixed: isotope layout two select option set popup
* Fixed: Design css issues

= 5.0.1 ( April 23, 2024 ) =
* Added: Ajax single product add to cart
* Fixed: Design css issues
* Fixed: Product addon frontend mini cart price update

= 5.0.0 ( April 16, 2024 ) =
* Added: Product Addons
* Added: Tipping
* Added: Delivery & Pickup
* Added: Food Location Product Taxonomy address & google map
* Added: Discount
* Added: Special Menu
* Improved: Admin settings panel design improve
* Fixed: Design css issues fixed