<?php
/**
 * Purchase Orders Database Table.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;

class PurchaseOrdersTable {

	use SingletonTrait;

	protected function init() {
		add_action( 'admin_init', [ $this, 'maybe_create_tables' ], 5 );
		add_action( 'rest_api_init', [ $this, 'maybe_create_tables' ], 5 );
	}

	public function maybe_create_tables() {
		$current_version = get_option( 'fmp_po_db_version', '0' );
		if ( version_compare( $current_version, FMP_PO_DB_VERSION, '<' ) ) {
			$this->create_tables();
			update_option( 'fmp_po_db_version', FMP_PO_DB_VERSION );
		}
	}

	protected function create_tables(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate   = $wpdb->get_charset_collate();
		$suppliers_table   = "{$wpdb->prefix}fm_suppliers";
		$po_table          = "{$wpdb->prefix}fm_purchase_orders";
		$po_items_table    = "{$wpdb->prefix}fm_purchase_order_items";
		$alerts_table      = "{$wpdb->prefix}fm_stock_alert_log";

		dbDelta( "
			CREATE TABLE {$suppliers_table} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				name VARCHAR(200) NOT NULL,
				email VARCHAR(100) DEFAULT NULL,
				phone VARCHAR(50) DEFAULT NULL,
				address TEXT DEFAULT NULL,
				notes TEXT DEFAULT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY status (status),
				KEY name (name)
			) {$charset_collate};
		" );

		dbDelta( "
			CREATE TABLE {$po_table} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				po_number VARCHAR(50) NOT NULL,
				supplier_name VARCHAR(200) NOT NULL,
				supplier_email VARCHAR(100) DEFAULT NULL,
				supplier_phone VARCHAR(50) DEFAULT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'draft',
				notes TEXT DEFAULT NULL,
				expected_date DATE DEFAULT NULL,
				received_date DATETIME DEFAULT NULL,
				total_cost DECIMAL(12,2) DEFAULT 0,
				created_by BIGINT UNSIGNED DEFAULT NULL,
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				UNIQUE KEY po_number (po_number),
				KEY status (status),
				KEY created_at (created_at)
			) {$charset_collate};
		" );

		dbDelta( "
			CREATE TABLE {$po_items_table} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				po_id BIGINT UNSIGNED NOT NULL,
				product_id BIGINT UNSIGNED NOT NULL,
				quantity_ordered INT UNSIGNED NOT NULL,
				quantity_received INT UNSIGNED DEFAULT 0,
				cost_price DECIMAL(10,2) DEFAULT NULL,
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY po_id (po_id),
				KEY product_id (product_id)
			) {$charset_collate};
		" );

		dbDelta( "
			CREATE TABLE {$alerts_table} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				product_id BIGINT UNSIGNED NOT NULL,
				alert_type VARCHAR(30) NOT NULL,
				stock_level INT NOT NULL,
				threshold INT NOT NULL,
				notified_to VARCHAR(255) DEFAULT NULL,
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY product_id (product_id),
				KEY alert_type (alert_type),
				KEY created_at (created_at)
			) {$charset_collate};
		" );
	}
}
