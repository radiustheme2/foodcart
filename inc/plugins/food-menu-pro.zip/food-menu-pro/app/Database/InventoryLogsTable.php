<?php
/**
 * Widget Controller Class.
 *
 * @package RT_FoodMenu
 */

namespace RT\FoodMenuPro\Database;

use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;

/**
 * Widget Controller Class.
 */
class InventoryLogsTable {

	use SingletonTrait;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'admin_init', array( $this, 'inventory_table' ), 5 );
	}

	public function inventory_table() {
		$current_version = get_option( 'fmp_inventory_db_version' );
		if ( $current_version < FMP_INVENTORY_DB_VERSION ) {
			$this->migration();
		}
	}

	public function migration(): void {
		// Update the installed version.
		$this->add_version();

		// Register and create tables.
		$this->create_tables();
		flush_rewrite_rules();
	}

	public function add_version(): void {
		update_option( 'fmp_inventory_db_version', FMP_INVENTORY_DB_VERSION );
	}


	protected function create_tables(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		//$inventory = "{$wpdb->prefix}fm_inventory";
		$inventory_logs_table      = "{$wpdb->prefix}fm_inventory_logs";

		/*	dbDelta("
			CREATE TABLE $inventory (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				product_id BIGINT UNSIGNED NOT NULL,
				stock_quantity DECIMAL(10,2) NOT NULL DEFAULT 0,
				unit VARCHAR(50) NOT NULL,
				last_updated DATETIME NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY product_id (product_id)
			) $charset_collate;
		");
		old change_type was = //'reduce','restore'
		*/

		dbDelta("
        CREATE TABLE $inventory_logs_table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		    product_id BIGINT UNSIGNED NOT NULL,
		    variation_id BIGINT UNSIGNED DEFAULT NULL,
		    change_type VARCHAR(20) NOT NULL,
		    quantity INT UNSIGNED NOT NULL,
		    reason VARCHAR(100) DEFAULT NULL,
		    note VARCHAR(255) DEFAULT NULL,
		    reference_id BIGINT DEFAULT NULL,
		    created_by BIGINT UNSIGNED DEFAULT NULL,
		    supplier_name VARCHAR(100) DEFAULT NULL,
		    cost_price DECIMAL(10,2) DEFAULT NULL,
		    location_id BIGINT UNSIGNED DEFAULT 0,
		    occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
		    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
		    PRIMARY KEY (id),
		    KEY product_id (product_id),
		    KEY change_type (change_type),
		    KEY reason (reason),
		    KEY reference_id (reference_id),
		    KEY occurred_at (occurred_at),
		    KEY created_at (created_at),
		    KEY product_type_date (product_id, change_type, occurred_at, created_at),
		    KEY product_ref (product_id, change_type, reference_id)
        ) $charset_collate;
    ");

		update_option( 'fmp_inventory_db_version', FMP_INVENTORY_DB_VERSION );
	}

}
