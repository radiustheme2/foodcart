<?php
/**
 * Order Timeline Database Table.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Database;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;

/**
 * Creates and migrates the fm_order_status_history table.
 */
class OrderTimelineTable {

	use SingletonTrait;

	/**
	 * Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'admin_init', [ $this, 'maybe_create_table' ], 5 );
		add_action( 'rest_api_init', [ $this, 'maybe_create_table' ], 5 );
	}

	/**
	 * Check version and run migration if needed.
	 *
	 * @return void
	 */
	public function maybe_create_table() {
		$current_version = get_option( 'fmp_timeline_db_version', '0' );

		if ( version_compare( $current_version, FMP_TIMELINE_DB_VERSION, '<' ) ) {
			$this->create_table();
			update_option( 'fmp_timeline_db_version', FMP_TIMELINE_DB_VERSION );
		}
	}

	/**
	 * Create the order status history table.
	 *
	 * @return void
	 */
	private function create_table() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$table_name      = "{$wpdb->prefix}fm_order_status_history";

		dbDelta( "
			CREATE TABLE $table_name (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				order_id BIGINT UNSIGNED NOT NULL,
				status VARCHAR(50) NOT NULL,
				status_label VARCHAR(100) NOT NULL,
				note TEXT DEFAULT NULL,
				updated_by BIGINT UNSIGNED DEFAULT NULL,
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY order_id (order_id),
				KEY order_status_time (order_id, status, created_at)
			) $charset_collate;
		" );
	}
}
