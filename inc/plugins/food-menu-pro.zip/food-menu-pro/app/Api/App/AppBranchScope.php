<?php
/**
 * Scoping the Store API to one branch, for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Query;

/**
 * Makes `X-FMP-Branch` mean something to the Store API.
 *
 * **The gap this closes.** The free plugin scopes the menu to the chosen
 * branch in two places — `FoodLocation::filterByLocation()` for shortcodes and
 * `filterShopByLocation()` on `woocommerce_product_query` for the shop page —
 * and both read the branch from a **`fmp_location_id` cookie**. The Store API
 * fires neither hook and a mobile client has no cookie, so a headless client
 * asking for the menu was given every dish from every branch. It could then
 * order something its branch does not serve.
 *
 * **A header, not a query parameter.** The app sets it once in an interceptor
 * and every Store API call carries it — products, search, collection counts
 * and the cart — where a parameter would have to be threaded through each
 * call site and would be forgotten on one of them. `?branch=` is still read as
 * a fallback, so the route stays testable from a browser.
 *
 * **The rule is the free plugin's own**, including the part that matters most:
 * a dish with no location at all is sold **everywhere**, so a store that files
 * only some of its menu by branch does not lose the rest.
 *
 * **It also stamps the branch onto the order.** The free plugin records
 * `fmp_location_name` from a posted field or the cookie, and an app order has
 * neither — so an app order was filed under no branch at all, and the slot
 * counting, which matches orders on that meta, never counted it. Same header,
 * same branch, written server-side from the term so the name can never be a
 * stale one the client sent.
 */
class AppBranchScope {

	use SingletonTrait;

	/**
	 * The header the app sends.
	 *
	 * @var string
	 */
	const HEADER = 'x-fmp-branch';

	/**
	 * The route of the REST request being served, if any.
	 *
	 * @var string
	 */
	private $route = '';

	/**
	 * The branch asked for on this request, -1 until worked out.
	 *
	 * @var int
	 */
	private $branch = -1;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		// Captures the route and the header from the request object itself,
		// which is exact where sniffing `$_SERVER['REQUEST_URI']` is a guess.
		add_filter( 'rest_pre_dispatch', [ $this, 'capture_request' ], 10, 3 );
		add_action( 'pre_get_posts', [ $this, 'scope_query' ], 20 );

		// After the free plugin's own `location_update_meta` at 10, so a site
		// that did manage to post a location keeps it and this only fills the
		// gap the app leaves.
		add_action(
			'woocommerce_store_api_checkout_update_order_from_request',
			[ $this, 'stamp_order_branch' ],
			20,
			2
		);

		// The Store API's own cart validation. It runs on checkout, where the
		// error refuses the order with a 409, and again behind
		// `get_cart_errors()`, where it lands in the cart response's `errors`
		// instead — so the same hook both warns on the cart screen and stops
		// the order, with no second implementation to keep in step.
		add_action( 'woocommerce_store_api_cart_errors', [ $this, 'check_cart_branch' ], 10, 2 );
	}

	/**
	 * Refuse a cart holding a dish the chosen branch does not serve.
	 *
	 * Reachable only from the app: the website drops those lines on the next
	 * cart load (`FoodLocation::validateCartLocation()`), but that pass is
	 * registered off the `fmp_location_id` **cookie**, which a mobile client
	 * never sends. Without this, a customer could fill a cart at one branch,
	 * switch to another, and have the order stamped with — and sent to — a
	 * branch that cannot make it.
	 *
	 * The app asks before it switches and drops the lines itself, so this is
	 * the backstop rather than the normal path: a cart that gets here has
	 * been carried across some way the app did not see.
	 *
	 * @param \WP_Error $errors Errors to add to.
	 * @param \WC_Cart  $cart   Cart being validated.
	 * @return void
	 */
	public function check_cart_branch( $errors, $cart ) {
		if ( ! $this->applies() || ! $cart instanceof \WC_Cart ) {
			return;
		}

		$by_product = [];

		foreach ( $cart->get_cart() as $cart_item ) {
			$product = $cart_item['data'] ?? null;

			if ( ! $product instanceof \WC_Product ) {
				continue;
			}

			$by_product[ $product->get_id() ] = $product->get_name();
		}

		$unserved = self::unserved( array_keys( $by_product ), $this->branch );

		if ( ! $unserved ) {
			return;
		}

		$names = [];

		foreach ( $unserved as $product_id ) {
			$names[] = $by_product[ $product_id ];
		}

		$errors->add(
			'fmp_cart_item_branch',
			sprintf(
				/* translators: 1: comma-separated dish names, 2: branch name. */
				_n(
					'%1$s is not available at %2$s. Remove it to continue.',
					'%1$s are not available at %2$s. Remove them to continue.',
					count( $names ),
					'food-menu-pro'
				),
				implode( ', ', $names ),
				$this->branch_name()
			),
			[
				'branch_id'   => $this->branch,
				'product_ids' => array_values( $unserved ),
			]
		);
	}

	/**
	 * The chosen branch's own name, for a message that has to name it.
	 *
	 * @return string
	 */
	private function branch_name() {
		$term = get_term( $this->branch, AppSchedules::BRANCH_TAXONOMY );

		return $term instanceof \WP_Term ? $term->name : __( 'this branch', 'food-menu-pro' );
	}

	/**
	 * Remember what is being served.
	 *
	 * @param mixed            $result  Dispatch result, untouched.
	 * @param \WP_REST_Server  $server  Server.
	 * @param \WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function capture_request( $result, $server, $request ) {
		$this->route = (string) $request->get_route();

		$header = $request->get_header( self::HEADER );

		if ( null === $header || '' === $header ) {
			$header = $request->get_param( 'branch' );
		}

		$this->branch = absint( $header );

		return $result;
	}

	/**
	 * Limit a Store API product query to the chosen branch.
	 *
	 * @param WP_Query $query Query about to run.
	 * @return void
	 */
	public function scope_query( $query ) {
		if ( ! $this->applies() ) {
			return;
		}

		if ( ! $this->is_product_query( $query ) ) {
			return;
		}

		$branch = $this->branch;

		// A branch that no longer exists scopes nothing rather than hiding the
		// whole menu — the customer gets the full list, which is the same
		// thing they would see with no branch chosen at all.
		if ( ! term_exists( $branch, AppSchedules::BRANCH_TAXONOMY ) ) {
			return;
		}

		$branch_query = [
			'relation' => 'OR',
			[
				'taxonomy' => AppSchedules::BRANCH_TAXONOMY,
				'field'    => 'term_id',
				'terms'    => [ $branch ],
			],
			// **A dish filed under no branch is sold everywhere.** Without
			// this arm a store that only files some of its menu by location
			// would lose the rest of it, which is the free plugin's rule and
			// not ours to change.
			[
				'taxonomy' => AppSchedules::BRANCH_TAXONOMY,
				'operator' => 'NOT EXISTS',
			],
		];

		$existing = $query->get( 'tax_query' );

		// Merged under AND rather than appended, so a category filter and the
		// branch both hold instead of the later one replacing the first.
		$query->set(
			'tax_query', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			empty( $existing )
				? [ $branch_query ]
				: [
					'relation' => 'AND',
					$existing,
					$branch_query,
				]
		);
	}

	/**
	 * Which of these dishes the given branch does not serve.
	 *
	 * The per-product form of the rule `scope_query()` expresses as a
	 * `tax_query`, for the two places that have products in hand rather than a
	 * query to filter: the app asking what a branch switch would cost it, and
	 * the cart guard that refuses an order the branch cannot make.
	 *
	 * **A dish filed under no branch is sold everywhere**, exactly as in the
	 * query — the free plugin's rule, repeated here because the two have to
	 * agree or the menu will offer what the cart then refuses.
	 *
	 * Answers an empty list for branch 0, for a branch that no longer exists
	 * and with multi-location off, each for the same reason `scope_query()`
	 * declines to scope: nothing is out of area when there are no areas.
	 *
	 * @param int[] $product_ids Product or variation ids.
	 * @param int   $branch_id   Branch term id.
	 * @return int[] The ids not served, in the order given.
	 */
	public static function unserved( array $product_ids, $branch_id ) {
		$branch_id = absint( $branch_id );

		if ( $branch_id < 1 ) {
			return [];
		}

		$settings = (array) FnsPro::get_settings_option();

		if ( empty( $settings['fmp_food_location_popup'] )
			|| ! taxonomy_exists( AppSchedules::BRANCH_TAXONOMY )
			|| ! term_exists( $branch_id, AppSchedules::BRANCH_TAXONOMY ) ) {
			return [];
		}

		$out = [];

		foreach ( $product_ids as $product_id ) {
			$product_id = absint( $product_id );

			if ( $product_id > 0 && ! self::serves( $product_id, $branch_id ) ) {
				$out[] = $product_id;
			}
		}

		return $out;
	}

	/**
	 * Whether one branch serves one dish.
	 *
	 * @param int $product_id Product or variation id.
	 * @param int $branch_id  Branch term id.
	 * @return bool
	 */
	private static function serves( $product_id, $branch_id ) {
		// Locations are filed against the parent product: the taxonomy is
		// registered for `product` and never for `product_variation`, so a
		// variation asked about itself has no terms and would look like a
		// dish sold everywhere.
		$product = wc_get_product( $product_id );

		if ( $product instanceof \WC_Product && $product->is_type( 'variation' ) ) {
			$product_id = $product->get_parent_id();
		}

		$terms = get_the_terms( $product_id, AppSchedules::BRANCH_TAXONOMY );

		// Includes the `WP_Error` a missing post gives back: a dish nobody can
		// find is not a dish this branch refuses to make.
		if ( ! is_array( $terms ) || ! $terms ) {
			return true;
		}

		foreach ( $terms as $term ) {
			if ( (int) $term->term_id === $branch_id ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Record the chosen branch on an order placed through the Store API.
	 *
	 * Writes the free plugin's own two keys, because everything downstream
	 * already reads them: the slot counting matches `fmp_location_name`, and
	 * the admin's order screens, the kitchen monitor and POS printing all
	 * read one or the other.
	 *
	 * @param \WC_Order        $order   Order being created.
	 * @param \WP_REST_Request $request Checkout request, unused.
	 * @return void
	 */
	public function stamp_order_branch( $order, $request ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Signature is WooCommerce's.
		if ( ! $this->applies() ) {
			return;
		}

		// Somebody already said which branch this is — the classic checkout's
		// posted field, or the cookie. Theirs wins; this is only the fallback
		// for a client that has neither.
		if ( '' !== (string) $order->get_meta( 'fmp_location_name' ) ) {
			return;
		}

		$term = get_term( $this->branch, AppSchedules::BRANCH_TAXONOMY );

		// A branch that no longer exists files the order under none, which is
		// what a store with no branches does anyway.
		if ( ! $term || is_wp_error( $term ) ) {
			return;
		}

		$order->update_meta_data( 'fmp_location_name', $term->name );
		$order->update_meta_data( 'fmp_location_id', $term->term_id );
	}

	/**
	 * Whether this request asked for a branch at all, on a route that has one.
	 *
	 * @return bool
	 */
	private function applies() {
		if ( $this->branch < 1 ) {
			return false;
		}

		// Store API only. The same header on `wc/v3` or on a staff route would
		// silently change what an admin screen lists.
		if ( ! str_starts_with( $this->route, '/wc/store/' ) ) {
			return false;
		}

		$settings = (array) FnsPro::get_settings_option();

		// With multi-location off the taxonomy is not even registered, so a
		// branch means nothing and scoping by it would hide everything.
		return ! empty( $settings['fmp_food_location_popup'] )
			&& taxonomy_exists( AppSchedules::BRANCH_TAXONOMY );
	}

	/**
	 * Whether this query is for products.
	 *
	 * @param WP_Query $query Query.
	 * @return bool
	 */
	private function is_product_query( WP_Query $query ) {
		$post_type = $query->get( 'post_type' );

		if ( is_array( $post_type ) ) {
			return in_array( 'product', $post_type, true );
		}

		return 'product' === $post_type;
	}
}
