<?php
/**
 * Shared helpers for the `fmp/v1/app` routes.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use WP_Error;
use WP_User;

/**
 * Helpers shared by every app route.
 */
class AppApiFns {

	/**
	 * The REST namespace every app route lives under.
	 *
	 * @var string
	 */
	const REST_NAMESPACE = 'fmp/v1';

	/**
	 * Route prefix, keeping the app's token-only routes clear of the
	 * nonce-gated staff routes in the same namespace.
	 *
	 * @var string
	 */
	const PREFIX = '/app';

	/**
	 * The customer fields the app is given.
	 *
	 * Deliberately small: anything the app does not render is a field we would
	 * have to keep sanitising for no reason. Profile and addresses arrive in
	 * their own endpoint.
	 *
	 * @param WP_User $user User.
	 * @return array
	 */
	public static function user_payload( WP_User $user ) {
		return [
			'id'           => (int) $user->ID,
			'email'        => $user->user_email,
			'username'     => $user->user_login,
			'first_name'   => $user->first_name,
			'last_name'    => $user->last_name,
			'display_name' => $user->display_name,
			'phone'        => (string) get_user_meta( $user->ID, 'billing_phone', true ),
			'avatar_url'   => get_avatar_url( $user->ID, [ 'size' => 160 ] ),
		];
	}

	/**
	 * "ASAP", with the store's own estimate when it has set one.
	 *
	 * Pickup quotes a single preparation time, delivery a range, which is how
	 * the design shows them. A store that has set nothing is quoted nothing
	 * rather than a made-up number.
	 *
	 * Shared because two routes render it: `/app/slots` offers it as a choice
	 * and `/app/orders/{id}` reports it back on an order that took it. Two
	 * renderings of one estimate would drift.
	 *
	 * @param string $type     Order type.
	 * @param array  $settings Store settings.
	 * @return string
	 */
	public static function asap_label( $type, array $settings ) {
		$asap = __( 'ASAP', 'food-menu-pro' );

		if ( 'pickup' === $type ) {
			$minutes = absint( $settings['pickup_prep_minutes'] ?? 0 );

			return $minutes > 0
				? sprintf(
					/* translators: 1: "ASAP", 2: minutes */
					_x( '%1$s (%2$d min)', 'asap with an estimate', 'food-menu-pro' ),
					$asap,
					$minutes
				)
				: $asap;
		}

		$min = absint( $settings['delivery_eta_min_minutes'] ?? 0 );
		$max = absint( $settings['delivery_eta_max_minutes'] ?? 0 );

		if ( $min < 1 && $max < 1 ) {
			return $asap;
		}

		// Either bound on its own is a single figure, and a reversed pair is
		// read in the order the store meant rather than printed backwards.
		if ( $min > 0 && $max > 0 && $min !== $max ) {
			return sprintf(
				/* translators: 1: "ASAP", 2: lowest minutes, 3: highest minutes */
				_x( '%1$s (%2$d–%3$d min)', 'asap with an estimate range', 'food-menu-pro' ),
				$asap,
				min( $min, $max ),
				max( $min, $max )
			);
		}

		return sprintf(
			/* translators: 1: "ASAP", 2: minutes */
			_x( '%1$s (%2$d min)', 'asap with an estimate', 'food-menu-pro' ),
			$asap,
			max( $min, $max )
		);
	}

	/**
	 * The store's currency, in the Store API's own key names.
	 *
	 * @return array
	 */
	public static function currency() {
		$code     = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
		$symbol   = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol( $code ) : '';
		$position = get_option( 'woocommerce_currency_pos' );
		$decimals = function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2;
		$prefix   = in_array( $position, [ 'left', 'left_space' ], true ) ? $symbol : '';
		$suffix   = '' === $prefix ? $symbol : '';

		return [
			'currency_code'               => $code,
			'currency_symbol'             => html_entity_decode( (string) $symbol ),
			'currency_minor_unit'         => $decimals,
			'currency_decimal_separator'  => function_exists( 'wc_get_price_decimal_separator' ) ? wc_get_price_decimal_separator() : '.',
			'currency_thousand_separator' => function_exists( 'wc_get_price_thousand_separator' ) ? wc_get_price_thousand_separator() : ',',
			'currency_prefix'             => html_entity_decode( $prefix ),
			'currency_suffix'             => html_entity_decode( $suffix ),
		];
	}

	/**
	 * An amount in minor units, as a string, the way the Store API sends
	 * every price.
	 *
	 * **Never a float.** The app parses prices as integers against
	 * `currency_minor_unit`, and a decimal here would be read as cents.
	 *
	 * @param mixed $amount Decimal amount.
	 * @return string
	 */
	public static function minor_units( $amount ) {
		$decimals = function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2;

		return (string) (int) round( (float) $amount * ( 10 ** $decimals ) );
	}

	/**
	 * Refuse password traffic over plain HTTP on a site that has HTTPS.
	 *
	 * Only sites whose own home URL is HTTPS are held to this, so a plain-HTTP
	 * development site still works while a real install cannot be downgraded
	 * into leaking credentials.
	 *
	 * @return WP_Error|null
	 */
	public static function check_transport() {
		$site_is_https = 'https' === wp_parse_url( home_url(), PHP_URL_SCHEME );

		if ( ! apply_filters( 'fmp_app_require_ssl', $site_is_https ) ) {
			return null;
		}

		if ( is_ssl() ) {
			return null;
		}

		return new WP_Error(
			'fmp_app_insecure_transport',
			__( 'This endpoint requires HTTPS.', 'food-menu-pro' ),
			[ 'status' => 403 ]
		);
	}

	/**
	 * Mark a response as private so no cache layer stores a token.
	 *
	 * @param \WP_REST_Response $response Response.
	 * @return \WP_REST_Response
	 */
	public static function no_store( $response ) {
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
		$response->header( 'Pragma', 'no-cache' );

		return $response;
	}
}
