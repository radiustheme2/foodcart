<?php
/**
 * Account security REST API for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;
use WP_User;

/**
 * `POST fmp/v1/app/auth/{forgot-password,reset-password,change-password,change-email}`.
 *
 * The group that was missing from task 3.1. A customer who forgot their
 * password had no route back into the app at all, and one who wanted to
 * change their email or password had to use the website.
 *
 * Two are public and gated by rate limiting; two require the current password
 * on top of a valid token, because a stolen phone should not be enough to take
 * an account over.
 */
class AccountSecurityApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		$namespace = AppApiFns::REST_NAMESPACE;
		$prefix    = AppApiFns::PREFIX . '/auth';

		register_rest_route(
			$namespace,
			$prefix . '/forgot-password',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'forgot_password' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'email' => [
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
				],
			]
		);

		register_rest_route(
			$namespace,
			$prefix . '/reset-password',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'reset_password' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'email'    => [
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'code'     => [
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'password' => [
						'required' => true,
						'type'     => 'string',
					],
					'device'   => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
				],
			]
		);

		register_rest_route(
			$namespace,
			$prefix . '/change-password',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'change_password' ],
				'permission_callback' => [ $this, 'signed_in' ],
				'args'                => [
					'current_password' => [
						'required' => true,
						'type'     => 'string',
					],
					'new_password'     => [
						'required' => true,
						'type'     => 'string',
					],
					'device'           => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
				],
			]
		);

		register_rest_route(
			$namespace,
			$prefix . '/change-email',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'change_email' ],
				'permission_callback' => [ $this, 'signed_in' ],
				'args'                => [
					'password' => [
						'required' => true,
						'type'     => 'string',
					],
					'email'    => [
						'required'          => true,
						'type'              => 'string',
						'format'            => 'email',
						'sanitize_callback' => 'sanitize_email',
					],
					'device'   => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
				],
			]
		);
	}

	/**
	 * @return bool|WP_Error
	 */
	public function signed_in() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'fmp_app_not_authenticated',
				__( 'You must be signed in to do that.', 'food-menu-pro' ),
				[ 'status' => 401 ]
			);
		}

		return true;
	}

	/**
	 * `POST /app/auth/forgot-password`.
	 *
	 * **Always answers the same way.** Whether the address has an account is
	 * exactly what an attacker wants to learn, and this route would otherwise
	 * answer it for every address they tried.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function forgot_password( $request ) {
		$insecure = AppApiFns::check_transport();

		if ( $insecure ) {
			return $insecure;
		}

		$email = trim( (string) $request['email'] );
		$ip    = AppRateLimit::client_ip();

		// Per IP, so one machine cannot walk an address list; per account, so
		// a known customer's inbox cannot be flooded from many machines.
		$limited = AppRateLimit::check( 'forgot_ip', $ip, 5, HOUR_IN_SECONDS );

		if ( $limited ) {
			return $limited;
		}

		$limited = AppRateLimit::check( 'forgot_account', strtolower( $email ), 5, HOUR_IN_SECONDS );

		if ( $limited ) {
			return $limited;
		}

		$user = $this->find_user( $email );

		if ( $user ) {
			$code = AppPasswordReset::issue( $user );
			AppPasswordReset::send( $user, $code );

			/**
			 * Fires after a reset code is issued and sent.
			 *
			 * @param WP_User $user The customer.
			 */
			do_action( 'fmp_app_reset_requested', $user );
		}

		return AppApiFns::no_store(
			new WP_REST_Response(
				[
					'sent'    => true,
					'message' => __(
						'If that address has an account, a reset code is on its way.',
						'food-menu-pro'
					),
				],
				200
			)
		);
	}

	/**
	 * `POST /app/auth/reset-password`.
	 *
	 * Signs the customer in on success, as register and login do. A correct
	 * code is the same bar as a correct password, and making them type the
	 * new one again straight away is friction for no gain.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function reset_password( $request ) {
		$insecure = AppApiFns::check_transport();

		if ( $insecure ) {
			return $insecure;
		}

		$limited = AppRateLimit::check(
			'reset_ip',
			AppRateLimit::client_ip(),
			10,
			15 * MINUTE_IN_SECONDS
		);

		if ( $limited ) {
			return $limited;
		}

		$email    = trim( (string) $request['email'] );
		$password = (string) $request['password'];
		$user     = $this->find_user( $email );

		// An unknown address answers exactly as a wrong code does. Telling
		// them apart would turn this into the account oracle that
		// `forgot-password` is careful not to be.
		if ( ! $user ) {
			return $this->invalid_reset_code();
		}

		// **Before** the code is checked, because `verify` consumes it on
		// success: a password that fails these rules would otherwise cost the
		// customer their code and send them back to their inbox for a new
		// one. Nothing here depends on the code being valid.
		$weak = $this->validate_password( $password, $user->user_email );

		if ( $weak ) {
			return $weak;
		}

		if ( ! AppPasswordReset::verify( $user, (string) $request['code'] ) ) {
			return $this->invalid_reset_code();
		}

		reset_password( $user, $password );

		// Every existing session, on every device, is now based on a password
		// the customer may have been resetting *because* somebody else knew
		// it.
		AppTokens::revoke_all( $user->ID );

		do_action( 'fmp_app_password_reset', $user );

		return $this->session_for( $user->ID, (string) $request['device'] );
	}

	/**
	 * The one answer every failed reset gives.
	 *
	 * @return WP_Error
	 */
	private function invalid_reset_code() {
		return new WP_Error(
			'fmp_app_invalid_reset_code',
			__( 'That code is not valid, or it has expired. Please request a new one.', 'food-menu-pro' ),
			[ 'status' => 400 ]
		);
	}

	/**
	 * `POST /app/auth/change-password`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function change_password( $request ) {
		$insecure = AppApiFns::check_transport();

		if ( $insecure ) {
			return $insecure;
		}

		$user = wp_get_current_user();
		$new  = (string) $request['new_password'];

		$wrong = $this->require_current_password( $user, (string) $request['current_password'] );

		if ( $wrong ) {
			return $wrong;
		}

		$weak = $this->validate_password( $new, $user->user_email );

		if ( $weak ) {
			return $weak;
		}

		if ( wp_check_password( $new, $user->user_pass, $user->ID ) ) {
			return new WP_Error(
				'fmp_app_password_unchanged',
				__( 'That is already your password. Please choose a different one.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		wp_set_password( $new, $user->ID );

		// Including this device's. Re-issuing below hands it a working
		// session back, so the customer is not signed out of the app they are
		// standing in — but anything else holding a token is.
		AppTokens::revoke_all( $user->ID );

		do_action( 'fmp_app_password_changed', $user );

		return $this->session_for( $user->ID, (string) $request['device'] );
	}

	/**
	 * `POST /app/auth/change-email`.
	 *
	 * **No confirmation is sent to the new address**, so a typo locks the
	 * customer out of the address they can no longer prove they own. The
	 * current password is the bar instead. Confirming the new address is the
	 * obvious next step if this becomes a real support cost.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function change_email( $request ) {
		$insecure = AppApiFns::check_transport();

		if ( $insecure ) {
			return $insecure;
		}

		$user  = wp_get_current_user();
		$email = sanitize_email( (string) $request['email'] );

		$wrong = $this->require_current_password( $user, (string) $request['password'] );

		if ( $wrong ) {
			return $wrong;
		}

		if ( ! is_email( $email ) ) {
			return new WP_Error(
				'fmp_app_invalid_email',
				__( 'That does not look like an email address.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		if ( 0 === strcasecmp( $email, $user->user_email ) ) {
			return new WP_Error(
				'fmp_app_email_unchanged',
				__( 'That is already your email address.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		$owner = email_exists( $email );

		if ( $owner && (int) $owner !== (int) $user->ID ) {
			return new WP_Error(
				'fmp_app_email_exists',
				__( 'That email address is already in use.', 'food-menu-pro' ),
				[ 'status' => 409 ]
			);
		}

		$was     = $user->user_email;
		$updated = wp_update_user(
			[
				'ID'         => $user->ID,
				'user_email' => $email,
			]
		);

		if ( is_wp_error( $updated ) ) {
			return $this->as_rest_error( $updated );
		}

		$this->sync_billing_email( $user->ID, $was, $email );

		AppTokens::revoke_all( $user->ID );

		do_action( 'fmp_app_email_changed', $user->ID, $was, $email );

		return $this->session_for( $user->ID, (string) $request['device'] );
	}

	/**
	 * Keep WooCommerce's billing email in step, when it was ours to move.
	 *
	 * Only when it was empty or equal to the old account address — the same
	 * rule the address book uses for `display_name`. A customer who
	 * deliberately set a different billing address on the web keeps it.
	 *
	 * @param int    $user_id User ID.
	 * @param string $was     Previous account email.
	 * @param string $email   New account email.
	 * @return void
	 */
	private function sync_billing_email( $user_id, $was, $email ) {
		$billing = (string) get_user_meta( $user_id, 'billing_email', true );

		if ( '' === $billing || 0 === strcasecmp( $billing, $was ) ) {
			update_user_meta( $user_id, 'billing_email', $email );
		}
	}

	/**
	 * Refuse unless the caller knows the account's current password.
	 *
	 * A valid token is not enough for these two: it proves the phone, not the
	 * person.
	 *
	 * @param WP_User $user     Current user.
	 * @param string  $password Submitted password.
	 * @return WP_Error|null
	 */
	private function require_current_password( WP_User $user, $password ) {
		if ( '' === $password || ! wp_check_password( $password, $user->user_pass, $user->ID ) ) {
			return new WP_Error(
				'fmp_app_incorrect_password',
				__( 'That is not your current password.', 'food-menu-pro' ),
				[ 'status' => 403 ]
			);
		}

		return null;
	}

	/**
	 * A user by email, or by login for a store whose customers use one.
	 *
	 * @param string $email Submitted address.
	 * @return WP_User|null
	 */
	private function find_user( $email ) {
		if ( '' === $email ) {
			return null;
		}

		$user = is_email( $email ) ? get_user_by( 'email', $email ) : get_user_by( 'login', $email );

		return $user ? $user : null;
	}

	/**
	 * Issue a fresh session, the way the auth routes do.
	 *
	 * @param int    $user_id User ID.
	 * @param string $device  Device label.
	 * @return WP_REST_Response
	 */
	private function session_for( $user_id, $device ) {
		$user         = get_userdata( $user_id );
		$body         = AppTokens::issue( $user_id, $device );
		$body['user'] = AppApiFns::user_payload( $user );

		return AppApiFns::no_store( new WP_REST_Response( $body, 200 ) );
	}

	/**
	 * The same password rules the register route applies.
	 *
	 * Duplicated deliberately rather than shared: `AuthApi::validate_password`
	 * is private, and widening it to be reused from here would make a rule
	 * that only registration owns look like a shared contract. If a third
	 * caller appears, extract it then.
	 *
	 * @param string $password Candidate.
	 * @param string $email    The account's address.
	 * @return WP_Error|null
	 */
	private function validate_password( $password, $email ) {
		$min = (int) apply_filters( 'fmp_app_min_password_length', 8 );

		if ( mb_strlen( $password ) < $min ) {
			return new WP_Error(
				'fmp_app_weak_password',
				sprintf(
					/* translators: %d: minimum number of characters. */
					_n(
						'Please choose a password of at least %d character.',
						'Please choose a password of at least %d characters.',
						$min,
						'food-menu-pro'
					),
					$min
				),
				[ 'status' => 400 ]
			);
		}

		if ( strlen( $password ) > 4096 ) {
			return new WP_Error(
				'fmp_app_password_too_long',
				__( 'That password is too long.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		if ( 0 === strcasecmp( trim( $password ), trim( $email ) ) ) {
			return new WP_Error(
				'fmp_app_weak_password',
				__( 'Please choose a password that is not your email address.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		return null;
	}

	/**
	 * Give a status-less WP_Error one, so it is not rendered as a 500.
	 *
	 * @param WP_Error $error Error.
	 * @return WP_Error
	 */
	private function as_rest_error( WP_Error $error ) {
		$data = $error->get_error_data();

		if ( is_array( $data ) && isset( $data['status'] ) ) {
			return $error;
		}

		$error->add_data( [ 'status' => 400 ], $error->get_error_code() );

		return $error;
	}
}
