<?php
/**
 * The customer's wishlist storage.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use WP_Error;

/**
 * Favourite dishes, stored against the customer's WordPress user.
 *
 * **One meta row per favourite, not one serialized list.** A list would mean a
 * read-modify-write on every tap, and the heart is tapped fast: two hearts
 * 200ms apart are two requests that both read the old list and the second
 * write silently discards the first favourite. One row per favourite makes
 * adding a single INSERT and removing a single DELETE, so there is no lost
 * update to guard against — no compare-and-swap, no lock, no retry. WordPress
 * offers no atomic way to amend a serialized meta value: `update_user_meta()`
 * ignores its `$prev_value` argument when the previous value is empty, which
 * is exactly the first-favourite case.
 *
 * The row's `umeta_id` is monotonic, so insertion order comes free and no
 * timestamp is stored. `get_user_meta()` returns the rows in that order, which
 * is reversed on read to put the newest favourite first.
 *
 * Product IDs are stored bare so `delete_user_meta()` can match on the value.
 * That also makes removal self-healing: it deletes *every* matching row, so a
 * duplicate left by two simultaneous adds of the same dish disappears on the
 * next unfavourite, and `all()` collapses duplicates meanwhile.
 */
class AppWishlist {

	/**
	 * User meta key. Repeated — one row per favourited product.
	 *
	 * @var string
	 */
	const META_KEY = '_fmp_app_wishlist';

	/**
	 * Most favourites one customer may keep.
	 *
	 * 100 matches the Store API's `per_page` ceiling, so a full wishlist still
	 * hydrates in a single products request.
	 *
	 * @var int
	 */
	const MAX_ITEMS = 100;

	/**
	 * A customer's favourited product IDs, newest first.
	 *
	 * Rows whose product no longer exists at all are pruned here. Rows whose
	 * product merely is not currently visible are kept — a dish pulled from
	 * the menu for an afternoon should not cost the customer their favourite.
	 *
	 * @param int $user_id User ID.
	 * @return int[]
	 */
	public static function all( $user_id ) {
		$user_id = (int) $user_id;
		$stored  = get_user_meta( $user_id, self::META_KEY, false );

		if ( ! is_array( $stored ) || ! $stored ) {
			return [];
		}

		$ids = array_values( array_unique( array_filter( array_map( 'absint', $stored ) ) ) );

		foreach ( $ids as $index => $id ) {
			if ( 'product' !== get_post_type( $id ) ) {
				// Gone for good: deleted, or never a product. Nothing will
				// bring this row back, so stop carrying it.
				delete_user_meta( $user_id, self::META_KEY, $id );
				unset( $ids[ $index ] );
			}
		}

		// Newest first: `get_user_meta()` hands rows back in `umeta_id` order.
		return array_reverse( array_values( $ids ) );
	}

	/**
	 * Whether a product is in the customer's wishlist.
	 *
	 * @param int $user_id    User ID.
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	public static function contains( $user_id, $product_id ) {
		$stored = get_user_meta( (int) $user_id, self::META_KEY, false );

		if ( ! is_array( $stored ) ) {
			return false;
		}

		return in_array( (int) $product_id, array_map( 'absint', $stored ), true );
	}

	/**
	 * Add a product to the wishlist.
	 *
	 * Idempotent: favouriting a dish twice is a success that changed nothing,
	 * because a client replaying a tap should not be handed an error.
	 *
	 * @param int $user_id    User ID.
	 * @param int $product_id Product ID.
	 * @return bool|WP_Error True when a favourite was added, false when it was
	 *                       already there.
	 */
	public static function add( $user_id, $product_id ) {
		$user_id    = (int) $user_id;
		$product_id = (int) $product_id;

		if ( self::contains( $user_id, $product_id ) ) {
			return false;
		}

		$max = (int) apply_filters( 'fmp_app_wishlist_max_items', self::MAX_ITEMS );

		if ( count( self::all( $user_id ) ) >= $max ) {
			return new WP_Error(
				'fmp_app_wishlist_full',
				sprintf(
					/* translators: %d: maximum number of wishlist items. */
					__( 'Your wishlist is full. You can save up to %d dishes.', 'food-menu-pro' ),
					$max
				),
				[ 'status' => 409 ]
			);
		}

		add_user_meta( $user_id, self::META_KEY, $product_id );

		/**
		 * Fires after a dish is added to a customer's wishlist.
		 *
		 * @param int $user_id    User ID.
		 * @param int $product_id Product ID.
		 */
		do_action( 'fmp_app_wishlist_added', $user_id, $product_id );

		return true;
	}

	/**
	 * Remove a product from the wishlist.
	 *
	 * Idempotent, for the same reason as `add()`.
	 *
	 * @param int $user_id    User ID.
	 * @param int $product_id Product ID.
	 * @return bool True when a favourite was removed.
	 */
	public static function remove( $user_id, $product_id ) {
		$user_id    = (int) $user_id;
		$product_id = (int) $product_id;

		// Deletes every row with this value, so duplicates cannot survive an
		// unfavourite.
		$removed = delete_user_meta( $user_id, self::META_KEY, $product_id );

		if ( $removed ) {
			/**
			 * Fires after a dish is removed from a customer's wishlist.
			 *
			 * @param int $user_id    User ID.
			 * @param int $product_id Product ID.
			 */
			do_action( 'fmp_app_wishlist_removed', $user_id, $product_id );
		}

		return (bool) $removed;
	}

	/**
	 * Whether a product may be favourited.
	 *
	 * Mirrors what the app can draw a heart on, which is the menu's own
	 * `catalog_visibility=catalog` query: published products that are not
	 * hidden from the catalogue. **Out of stock is deliberately allowed** —
	 * saving a dish that has sold out is the point of a wishlist.
	 *
	 * @param int $product_id Product ID.
	 * @return true|WP_Error
	 */
	public static function check_product( $product_id ) {
		$product_id = (int) $product_id;
		$post_type  = get_post_type( $product_id );

		if ( 'product_variation' === $post_type ) {
			return new WP_Error(
				'fmp_app_wishlist_variation',
				__( 'Save the dish itself, not one of its options.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		if ( 'product' !== $post_type ) {
			return new WP_Error(
				'fmp_app_product_not_found',
				__( 'That dish does not exist.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return new WP_Error(
				'fmp_app_product_not_found',
				__( 'That dish does not exist.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		$visible = 'publish' === $product->get_status()
			&& in_array( $product->get_catalog_visibility(), [ 'visible', 'catalog' ], true );

		if ( ! $visible ) {
			return new WP_Error(
				'fmp_app_product_unavailable',
				__( 'That dish is not on the menu.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		return true;
	}

	/**
	 * Clear a customer's wishlist.
	 *
	 * Not exposed as a route; here so account erasure has one call to make.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	public static function clear( $user_id ) {
		delete_user_meta( (int) $user_id, self::META_KEY );
	}
}
