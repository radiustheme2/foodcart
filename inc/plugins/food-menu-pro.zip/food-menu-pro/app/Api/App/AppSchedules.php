<?php
/**
 * How the app routes read a store's pickup and delivery schedule.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;
use WP_Error;

/**
 * Shared by `/app/order-types` and `/app/slots`.
 *
 * Both answer questions about the same stored schedule, and they have to agree:
 * a day the first route calls open must be a day the second can generate times
 * for. Reading the settings twice, in two places, is how they stop agreeing.
 *
 * Every reading here is the website's own, taken from
 * `PickupDelivery::pickup_delivery_data_obj()` and its slot-limit helpers
 * rather than reinvented.
 */
class AppSchedules {

	/**
	 * The order types the app can render.
	 *
	 * Dine-in exists in the plugin and the app has no screen for it. One entry
	 * here changes that.
	 *
	 * @var string[]
	 */
	const TYPES = [ 'pickup', 'delivery' ];

	/**
	 * The taxonomy branches are terms of. Registered only while the plugin's
	 * multi-location feature is switched on.
	 *
	 * @var string
	 */
	const BRANCH_TAXONOMY = 'tpl-food-location';

	/**
	 * Settle which branch a request is really about.
	 *
	 * An **unknown** branch is refused. Falling back would hand a deleted
	 * branch's customer the store's generic hours as though they were that
	 * branch's, and they would go and stand outside a closed door. A store not
	 * running branches at all is answered store-wide, with 0 back, so the
	 * client can see its parameter was not honoured.
	 *
	 * @param int $branch Requested location term id.
	 * @return int|WP_Error
	 */
	public static function resolve_branch( $branch ) {
		$branch = absint( $branch );

		if ( $branch < 1 ) {
			return 0;
		}

		if ( ! taxonomy_exists( self::BRANCH_TAXONOMY ) ) {
			return 0;
		}

		if ( ! term_exists( $branch, self::BRANCH_TAXONOMY ) ) {
			return new WP_Error(
				'fmp_app_branch_not_found',
				__( 'That branch does not exist.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		return $branch;
	}

	/**
	 * A branch's own schedule data, or null when it has none.
	 *
	 * @param int $branch Location term id, 0 for store-wide.
	 * @return array|null
	 */
	public static function location_data( $branch ) {
		return $branch > 0 ? FnsPro::get_location_schedule_data( $branch ) : null;
	}

	/**
	 * The weekly schedule that applies, branch first.
	 *
	 * A location can have "custom schedule" switched on while leaving one of
	 * the types unconfigured, and overwriting the store-wide schedule with an
	 * empty one would leave the type with no hours at all. The `has_*` flags
	 * are the same guard `pickup_delivery_data_obj()` uses.
	 *
	 * @param string     $type     Order type.
	 * @param array|null $location Per-location data.
	 * @return array
	 */
	public static function schedule_for( $type, $location ) {
		if ( is_array( $location ) && ! empty( $location[ "has_{$type}_schedule" ] ) ) {
			return (array) ( $location[ "new_{$type}_weekly_schedule" ] ?? [] );
		}

		return (array) FnsPro::get_setting( "new_fmp_{$type}_weekly_schedule", [] );
	}

	/**
	 * Minutes between one selectable time and the next.
	 *
	 * @param string     $type     Order type.
	 * @param array      $settings Store settings.
	 * @param array|null $location Per-location data.
	 * @return int
	 */
	public static function interval( $type, array $settings, $location ) {
		if ( is_array( $location ) && ! empty( $location[ "has_{$type}_schedule" ] ) ) {
			$interval = absint( $location[ "fmp_loc_{$type}_time_interval" ] ?? 0 );
			if ( $interval > 0 ) {
				return $interval;
			}
		}

		return absint( $settings[ "{$type}_time_interval" ] ?? 0 ) ?: 15;
	}

	/**
	 * Orders allowed in one slot, branch overriding the store when it sets one.
	 *
	 * @param string     $type     Order type.
	 * @param array      $settings Store settings.
	 * @param array|null $location Per-location data.
	 * @return int
	 */
	public static function slot_cap( $type, array $settings, $location ) {
		if ( is_array( $location ) ) {
			$cap = absint( $location[ "fmp_loc_{$type}_max_orders_per_slot" ] ?? 0 );
			if ( $cap > 0 ) {
				return $cap;
			}
		}

		return absint( $settings[ "{$type}_max_orders_per_slot" ] ?? 0 );
	}

	/**
	 * Days of preparation before this type can be fulfilled.
	 *
	 * Pickup is always same-day; only delivery has the setting, which is how
	 * `pickup_delivery_data_obj()` reads it too.
	 *
	 * @param string $type     Order type.
	 * @param array  $settings Store settings.
	 * @return int
	 */
	public static function lead_days( $type, array $settings ) {
		if ( 'delivery' !== $type ) {
			return 0;
		}

		return absint( $settings['delivery_preparation_day'] ?? 0 );
	}

	/**
	 * Whether the store offers this type at all.
	 *
	 * **Absent means on**, which is how the website reads these: a store that
	 * has never opened the settings screen offers both.
	 *
	 * @param string $type     Order type.
	 * @param array  $settings Store settings.
	 * @return bool
	 */
	public static function is_enabled( $type, array $settings ) {
		return 'on' === ( $settings[ "enable_{$type}" ] ?? 'on' );
	}

	/**
	 * Whether the customer picks a date and time for this type.
	 *
	 * When false they pick neither and the order is simply as soon as
	 * possible — so a client must skip the slot list rather than draw an
	 * empty one.
	 *
	 * @param string $type     Order type.
	 * @param array  $settings Store settings.
	 * @return bool
	 */
	public static function is_time_required( $type, array $settings ) {
		return 'on' === ( $settings[ "enable_{$type}_time" ] ?? 'on' );
	}

	/**
	 * The order type's own name, translated.
	 *
	 * @param string $type Order type.
	 * @return string
	 */
	public static function label( $type ) {
		return 'pickup' === $type
			? __( 'Pickup', 'food-menu-pro' )
			: __( 'Delivery', 'food-menu-pro' );
	}

	/**
	 * Day indexes the store is closed on.
	 *
	 * Asked rather than rederived: this is the same reading of "open" the
	 * checkout uses, including its rule that a day whose only slots are
	 * malformed counts as closed.
	 *
	 * @param array $schedule Stored weekly schedule.
	 * @return int[]
	 */
	public static function closed_days( array $schedule ) {
		return array_map( 'absint', (array) FnsPro::get_offday_schedule( $schedule ) );
	}

	/**
	 * One day's opening windows, by day index.
	 *
	 * A slot missing either end is dropped: a window with no closing time is
	 * not something a client can draw, and the website does not count it
	 * either. An **open day with no windows** is not a contradiction — it is a
	 * day the store set no hours for, which the website treats as no
	 * restriction.
	 *
	 * @param array $schedule Stored weekly schedule.
	 * @param int   $day      Day index, 0 for Sunday.
	 * @return array[] Each `{ start, end, max_order }`.
	 */
	public static function windows( array $schedule, $day ) {
		$names = array_flip( Fns::day_map_index() );
		$key   = $names[ (int) $day ] ?? '';
		$slots = $key ? ( $schedule[ $key ]['slots'] ?? [] ) : [];
		$out   = [];

		foreach ( (array) $slots as $slot ) {
			$start = trim( (string) ( $slot['start'] ?? '' ) );
			$end   = trim( (string) ( $slot['end'] ?? '' ) );

			if ( '' === $start || '' === $end ) {
				continue;
			}

			$out[] = [
				'start'     => $start,
				'end'       => $end,
				'max_order' => absint( $slot['max_order'] ?? 0 ),
			];
		}

		return $out;
	}

	/**
	 * Minutes since midnight.
	 *
	 * Both formats are accepted because both are stored: the admin schedule
	 * screen writes 24-hour values, while the checkout submits the site's own
	 * `time_format`, which is 12-hour on a default install. The same
	 * two-format reading is in `PickupDelivery::time_to_minutes()`.
	 *
	 * @param string $time Time string, 24h or 12h.
	 * @return int|null Null when it is not a time at all.
	 */
	public static function time_to_minutes( $time ) {
		$time = trim( (string) $time );

		if ( '' === $time ) {
			return null;
		}

		if ( preg_match( '/^(\d{1,2}):(\d{2})$/', $time, $m ) ) {
			return (int) $m[1] * 60 + (int) $m[2];
		}

		if ( preg_match( '/^(\d{1,2}):(\d{2})\s*(am|pm)$/i', $time, $m ) ) {
			$hour = (int) $m[1];

			if ( 'pm' === strtolower( $m[3] ) && 12 !== $hour ) {
				$hour += 12;
			} elseif ( 'am' === strtolower( $m[3] ) && 12 === $hour ) {
				$hour = 0;
			}

			return $hour * 60 + (int) $m[2];
		}

		return null;
	}
}
