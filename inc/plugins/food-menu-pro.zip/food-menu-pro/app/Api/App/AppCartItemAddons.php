<?php
/**
 * Chosen add-ons and their price effect on Store API cart items.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Controllers\ProductAddons\Frontend\FrontendCartAction;
use RT\FoodMenuPro\Traits\SingletonTrait;

/**
 * Adds a cart item's add-ons to the Store API under the plugin's own
 * `food-menu-pro` extension namespace.
 *
 * Task 4.2 got selections **into** the cart. Nothing came back **out**: a
 * cart item carried `item_data` — the same name/value strings the website
 * prints on its cart page, with the quantity baked into the text as `x2` —
 * and `extensions: {}`. So the app could not tell which group a line
 * belonged to, which option was chosen, what the option cost, or what the
 * dish itself cost before any of it. Measured against the dev store before
 * this was written.
 *
 * Three things are published, and the reasons they are separate matter:
 *
 * - **`addons`** — one entry per chosen option, carrying the ids
 *   `AddonsApi` publishes, so the app can reopen its own add-on sheet with
 *   the line's selections already ticked. The `price` on each is the stored
 *   delta, which is also what the order line item records.
 * - **`addons_total`** — those deltas added up. This is the number the
 *   website itself labels "Addons price".
 * - **`base_price`** and **`addons_total_charged`** — the line's unit price
 *   split into the dish part and the add-on part, **as actually charged**.
 *
 * The last pair exists because the first two do not necessarily add up to
 * `prices.price`. The plugin's own discount can take a percentage off the
 * dish, and off the add-ons as well when `fmp_applicable_discount` is
 * `addon_total`, so a cart line is not always `base + sum of deltas`.
 * Rather than reimplement that arithmetic, this asks the website's own
 * `price_calculate()` what the line would cost **with its add-ons removed**,
 * and takes the add-on part as the remainder of what the cart charged.
 * `base_price + addons_total_charged === prices.price` therefore holds by
 * construction, whatever pricing rules are in play, and any rounding
 * residue lands on the add-on side rather than silently breaking the sum.
 */
class AppCartItemAddons {

	use SingletonTrait;

	/**
	 * The plugin's Store API extension key, shared with the checkout
	 * extension and with `AppCartAddons`.
	 *
	 * @var string
	 */
	const NAMESPACE_ID = 'food-menu-pro';

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		// `woocommerce_blocks_loaded` may already have fired by the time Pro
		// boots, so register immediately in that case — the same pattern
		// AppProductStoreApi and PickupDelivery use.
		if ( did_action( 'woocommerce_blocks_loaded' ) ) {
			$this->register();
		} else {
			add_action( 'woocommerce_blocks_loaded', [ $this, 'register' ] );
		}
	}

	/**
	 * Register the schema and data callbacks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			return;
		}

		if ( ! class_exists( '\Automattic\WooCommerce\StoreApi\Schemas\V1\CartItemSchema' ) ) {
			return;
		}

		woocommerce_store_api_register_endpoint_data(
			[
				'endpoint'        => \Automattic\WooCommerce\StoreApi\Schemas\V1\CartItemSchema::IDENTIFIER,
				'namespace'       => self::NAMESPACE_ID,
				'data_callback'   => [ $this, 'data' ],
				'schema_callback' => [ $this, 'schema' ],
				'schema_type'     => ARRAY_A,
			]
		);
	}

	/**
	 * Per-cart-item payload.
	 *
	 * @param array $cart_item Cart item.
	 * @return array
	 */
	public function data( $cart_item ) {
		$cart_item = (array) $cart_item;
		$product   = $cart_item['data'] ?? null;

		if ( ! $product instanceof \WC_Product ) {
			return $this->payload( [], '0', '0', '0' );
		}

		// The cart item's own product object has already had the add-on
		// prices folded into it by `update_product_price()`, so this is the
		// unit price the Store API is about to report as `prices.price`.
		$line = $this->money( $this->displayed_price( $product ) );
		$rows = (array) ( $cart_item['fmp_addons'] ?? [] );

		if ( ! $rows ) {
			// No add-ons, so the whole line is the dish. Said explicitly
			// rather than left out, so the app has one shape to read.
			return $this->payload( [], '0', '0', $line );
		}

		$addons = $this->shape_rows( $cart_item, $rows );
		$total  = 0;

		foreach ( $addons as $addon ) {
			$total += (int) $addon['price'];
		}

		$base    = $this->base_price( $cart_item, $product );
		$charged = (string) ( (int) $line - (int) $base );

		return $this->payload( $addons, (string) $total, $charged, $base );
	}

	/**
	 * One entry per stored add-on row, with its ids resolved.
	 *
	 * A stored row keeps only what the website needs to print it — the group
	 * title as `name`, the chosen label or typed text as `value`, a price, a
	 * `field_name` and the field type. The ids the app works in are not in
	 * there, so they are recovered: the `field_name` identifies the group,
	 * and the row's `value` identifies the option within it.
	 *
	 * @param array $cart_item Cart item.
	 * @param array $rows      Stored `fmp_addons` rows.
	 * @return array[]
	 */
	private function shape_rows( array $cart_item, array $rows ) {
		$product_id = (int) ( $cart_item['product_id'] ?? 0 );
		$groups     = AppAddonGroups::by_field_name( $product_id );
		$out        = [];

		foreach ( $rows as $row ) {
			$row = (array) $row;

			if ( ! isset( $row['value'] ) ) {
				continue;
			}

			$field_name = (string) ( $row['field_name'] ?? '' );
			$entry      = $groups[ $field_name ] ?? null;
			$type       = (string) ( $row['field_type'] ?? '' );
			$value      = (string) $row['value'];
			$qty        = max( 1, (int) ( $row['qty'] ?? 1 ) );
			$price      = $this->money( $row['price'] ?? 0 );

			$option    = $entry ? $this->match_option( (array) $entry['group'], $type, $value ) : null;
			$per_option = null !== $option
				? $this->money( $option['price'] ?? 0 )
				// Without the option in hand the per-one price has to come
				// back out of the row, which already has the quantity
				// multiplied in.
				: (string) (int) round( (int) $price / $qty );

			$out[] = [
				// Null, not a guess, when the group can no longer be found —
				// a title reworded after this line went into the cart leaves
				// nothing to match on. The price effect below is still real,
				// so the row is reported rather than dropped.
				'group_id'     => $entry ? $entry['id'] : null,
				'group_title'  => (string) ( $row['name'] ?? '' ),
				'field_type'   => $type,
				'option_id'    => null !== $option ? $option['id'] : null,
				'value'        => $value,
				'quantity'     => $qty,
				'price_type'   => (string) ( $row['price_type'] ?? '' ),
				'price'        => $price,
				'price_single' => $per_option,
			];
		}

		return $out;
	}

	/**
	 * The option a stored row refers to, by its label.
	 *
	 * `text` and `textarea` have no option to point at — the row's value is
	 * whatever the customer typed — so they resolve to the group's first
	 * option, which is where the website keeps their price.
	 *
	 * @param array  $group Stored group.
	 * @param string $type  Field type.
	 * @param string $value Stored row value.
	 * @return array|null `id` and the stored option, or null.
	 */
	private function match_option( array $group, $type, $value ) {
		$options = array_values( (array) ( $group['options'] ?? [] ) );

		if ( in_array( $type, [ 'text', 'textarea' ], true ) ) {
			return isset( $options[0] )
				? [ 'id' => '0' ] + (array) $options[0]
				: null;
		}

		foreach ( $options as $index => $option ) {
			$label = (string) ( ( (array) $option )['label'] ?? '' );

			// `AddonFields` stores the label raw, so a direct comparison is
			// the one that should hit. The escaped and decoded forms are
			// tried as well because a label carrying an entity — `Medium
			// 12"` — is written one way by the admin screen and another by
			// the form that posted it, and the same mismatch that made task
			// 4.2 charge a base price would make this report no option id.
			if ( $value === $label
				|| $value === esc_html( $label )
				|| $value === html_entity_decode( $label, ENT_QUOTES ) ) {
				return [ 'id' => (string) $index ] + (array) $option;
			}
		}

		return null;
	}

	/**
	 * What this line's unit price would be with its add-ons taken off.
	 *
	 * Asked of the website's own calculator rather than worked out here, so
	 * the plugin's discount — which can apply to the dish only, or to the
	 * dish and its add-ons — is accounted for exactly once, by the code that
	 * owns the rule.
	 *
	 * @param array       $cart_item Cart item.
	 * @param \WC_Product $product   The cart item's product, already carrying
	 *                               the add-on prices.
	 * @return string Minor units.
	 */
	private function base_price( array $cart_item, \WC_Product $product ) {
		$without = $cart_item;

		$without['fmp_addons'] = [];

		$prices = [
			'price'         => $this->raw_price( $cart_item ),
			'regular_price' => $this->raw_price( $cart_item ),
			'sale_price'    => $this->raw_price( $cart_item ),
		];

		$calculated = FrontendCartAction::get_instance()->price_calculate( $without, $prices );
		$base       = (float) ( $calculated['price'] ?? $prices['price'] );

		// Run the dish-only amount through the same tax and rounding the
		// Store API applies to the line, by asking a copy of the product
		// about it. Doing the tax step by hand would be a second reading of
		// the store's tax settings, and the two would drift.
		$clone = clone $product;
		$clone->set_price( $base );

		return $this->money( $this->displayed_price( $clone ) );
	}

	/**
	 * The product's own price, before `update_product_price()` folded the
	 * add-ons in.
	 *
	 * Read from a freshly loaded product rather than from the cart item,
	 * whose product object has already been written to.
	 *
	 * @param array $cart_item Cart item.
	 * @return float
	 */
	private function raw_price( array $cart_item ) {
		$id      = (int) ( $cart_item['variation_id'] ?? 0 );
		$id      = $id > 0 ? $id : (int) ( $cart_item['product_id'] ?? 0 );
		$product = $id ? wc_get_product( $id ) : null;

		return $product instanceof \WC_Product ? (float) $product->get_price( 'edit' ) : 0.0;
	}

	/**
	 * A product's price in the same tax mode the cart response uses.
	 *
	 * @param \WC_Product $product Product.
	 * @return float
	 */
	private function displayed_price( \WC_Product $product ) {
		$mode = get_option( 'woocommerce_tax_display_cart' );

		return 'incl' === $mode
			? (float) wc_get_price_including_tax( $product )
			: (float) wc_get_price_excluding_tax( $product );
	}

	/**
	 * An amount as minor units, the way the Store API's own money formatter
	 * does it.
	 *
	 * @param mixed $amount Amount.
	 * @return string
	 */
	private function money( $amount ) {
		$amount   = is_numeric( $amount ) ? (float) $amount : 0.0;
		$decimals = function_exists( 'wc_get_price_decimals' ) ? absint( wc_get_price_decimals() ) : 2;
		$scaled   = round( $amount * pow( 10, $decimals ), 0, PHP_ROUND_HALF_UP );

		return (string) wc_format_decimal( $scaled, 0, true );
	}

	/**
	 * The payload, with the currency block every money-bearing Store API
	 * object carries.
	 *
	 * @param array[] $addons  Shaped add-on rows.
	 * @param string  $total   Sum of the stored deltas.
	 * @param string  $charged The add-on part of the line price.
	 * @param string  $base    The dish part of the line price.
	 * @return array
	 */
	private function payload( array $addons, $total, $charged, $base ) {
		return array_merge(
			[
				'addons'               => $addons,
				'addons_total'         => (string) $total,
				'addons_total_charged' => (string) $charged,
				'base_price'           => (string) $base,
			],
			$this->currency()
		);
	}

	/**
	 * The store's currency, in the Store API's own key names.
	 *
	 * @return array
	 */
	private function currency() {
		$code     = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
		$symbol   = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol( $code ) : '';
		$position = get_option( 'woocommerce_currency_pos' );
		$prefix   = in_array( $position, [ 'left', 'left_space' ], true ) ? $symbol : '';
		$suffix   = '' === $prefix ? $symbol : '';

		return [
			'currency_code'               => $code,
			'currency_symbol'             => html_entity_decode( (string) $symbol ),
			'currency_minor_unit'         => function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2,
			'currency_decimal_separator'  => function_exists( 'wc_get_price_decimal_separator' ) ? wc_get_price_decimal_separator() : '.',
			'currency_thousand_separator' => function_exists( 'wc_get_price_thousand_separator' ) ? wc_get_price_thousand_separator() : ',',
			'currency_prefix'             => html_entity_decode( (string) $prefix ),
			'currency_suffix'             => html_entity_decode( (string) $suffix ),
		];
	}

	/**
	 * Schema for the payload above.
	 *
	 * @return array
	 */
	public function schema() {
		return [
			'addons'               => [
				'description' => __( 'Add-ons chosen for this cart item.', 'food-menu-pro' ),
				'type'        => 'array',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
				'items'       => [
					'type'       => 'object',
					'properties' => self::addon_schema(),
				],
			],
			'addons_total'         => [
				'description' => __( 'Sum of the add-on prices, in minor units.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'addons_total_charged' => [
				'description' => __( 'The add-on part of the unit price actually charged, in minor units. Differs from addons_total when a discount applies to add-ons.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'base_price'           => [
				'description' => __( 'The dish part of the unit price actually charged, in minor units. With addons_total_charged it sums to prices.price.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
		] + self::currency_schema();
	}

	/**
	 * Shape of one add-on entry.
	 *
	 * @return array
	 */
	private static function addon_schema() {
		return [
			'group_id'     => [
				'description' => __( 'The add-on group id, as GET /fmp/v1/app/products/{id}/addons publishes it. Null when the group can no longer be matched.', 'food-menu-pro' ),
				'type'        => [ 'string', 'null' ],
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'group_title'  => [
				'description' => __( 'The group title stored with the cart item.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'field_type'   => [
				'description' => __( 'Group type: dropdown, checkbox, radio, text or textarea.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'option_id'    => [
				'description' => __( 'The chosen option id within the group. Null for text and textarea, and when the option can no longer be matched.', 'food-menu-pro' ),
				'type'        => [ 'string', 'null' ],
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'value'        => [
				'description' => __( 'The chosen option label, or the text the customer typed.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'quantity'     => [
				'description' => __( 'How many of this option, for groups with a per-option quantity.', 'food-menu-pro' ),
				'type'        => 'integer',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'price_type'   => [
				'description' => __( 'The option price type as stored.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'price'        => [
				'description' => __( 'What this add-on adds, in minor units, with its quantity included.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'price_single' => [
				'description' => __( 'What one of this option adds, in minor units.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
		];
	}

	/**
	 * Schema for the currency keys.
	 *
	 * @return array
	 */
	private static function currency_schema() {
		$out = [];

		$strings = [
			'currency_code'               => __( 'Currency code.', 'food-menu-pro' ),
			'currency_symbol'             => __( 'Currency symbol.', 'food-menu-pro' ),
			'currency_decimal_separator'  => __( 'Decimal separator.', 'food-menu-pro' ),
			'currency_thousand_separator' => __( 'Thousand separator.', 'food-menu-pro' ),
			'currency_prefix'             => __( 'Price prefix.', 'food-menu-pro' ),
			'currency_suffix'             => __( 'Price suffix.', 'food-menu-pro' ),
		];

		foreach ( $strings as $key => $description ) {
			$out[ $key ] = [
				'description' => $description,
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			];
		}

		$out['currency_minor_unit'] = [
			'description' => __( 'Decimal precision of the amounts above.', 'food-menu-pro' ),
			'type'        => 'integer',
			'context'     => [ 'view', 'edit' ],
			'readonly'    => true,
		];

		return $out;
	}
}
