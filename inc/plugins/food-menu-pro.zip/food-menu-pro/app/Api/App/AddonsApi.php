<?php
/**
 * Product add-on REST API for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Controllers\ProductAddons\Frontend\FrontendPAddon;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;

/**
 * `GET fmp/v1/app/products/{id}/addons` — a dish's add-on groups.
 *
 * Add-ons are the one part of a dish the Store API knows nothing about. They
 * live in `_fmp_product_addons` product meta, or in the global add-on setting,
 * and the website renders them with its own PHP templates — so a headless
 * client had no way to even know a dish was customisable.
 *
 * **Public, unlike the rest of `fmp/v1/app/*`.** The menu is public and the
 * dish detail screen is reachable before sign-in, so a token-gated route here
 * would hide the add-ons from exactly the customer deciding whether to
 * create an account. Nothing in the response is customer data.
 */
class AddonsApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/products/(?P<id>\d+)/addons',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_addons' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'id' => [
						'required'          => true,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					],
				],
			]
		);
	}

	/**
	 * `GET /app/products/{id}/addons`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_addons( $request ) {
		$product_id = (int) $request['id'];
		$product    = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;

		if ( ! $product || 'product' !== get_post_type( $product_id ) ) {
			return new WP_Error(
				'fmp_app_product_not_found',
				__( 'That dish does not exist.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		// **Asked, not reimplemented.** Whether a dish uses its own add-ons or
		// the matching global ones is an either/or decided by the
		// `_fmp_pa_global_override` meta, and the website already owns that
		// rule. Calling it is what keeps the app and the web page from ever
		// disagreeing about what a dish offers.
		$groups = FrontendPAddon::get_instance()->addon_lists( $product_id );
		$groups = is_array( $groups ) ? array_filter( $groups ) : [];

		$payload = [];

		foreach ( $groups as $key => $group ) {
			$shaped = $this->shape_group( (string) $key, (array) $group );

			if ( $shaped ) {
				$payload[] = $shaped;
			}
		}

		// `position` is what the admin screen orders by, and the website
		// honours it. Groups without one keep their stored order.
		usort(
			$payload,
			function ( $a, $b ) {
				return $a['position'] <=> $b['position'];
			}
		);

		return new WP_REST_Response(
			[
				'product_id' => $product_id,
				'currency'   => $this->currency(),
				'groups'     => $payload,
			],
			200
		);
	}

	/**
	 * One add-on group, in the shape the app consumes.
	 *
	 * @param string $key   Stored key, used as the group's stable id.
	 * @param array  $group Stored group.
	 * @return array|null Null when the group has no usable title or type.
	 */
	private function shape_group( $key, array $group ) {
		$title = trim( (string) ( $group['title'] ?? '' ) );
		$type  = (string) ( $group['type'] ?? '' );

		// A group with no title or an unknown type cannot be drawn, and
		// guessing one would put a nameless control on the dish screen.
		if ( '' === $title || ! in_array( $type, self::TYPES, true ) ) {
			return null;
		}

		$options = [];

		foreach ( (array) ( $group['options'] ?? [] ) as $index => $option ) {
			$shaped = $this->shape_option( (string) $index, (array) $option );

			if ( $shaped ) {
				$options[] = $shaped;
			}
		}

		return [
			'id'          => $key,
			'title'       => $title,
			'description' => (string) ( $group['description'] ?? '' ),
			'type'        => $type,
			'required'    => ! empty( $group['required'] ),
			'position'    => (int) ( $group['position'] ?? 0 ),
			// Zero means "no limit" on both, which is how the admin screen
			// and the website read them.
			'min_selection' => (int) ( $group['min_selection'] ?? 0 ),
			'max_selection' => (int) ( $group['max_selection'] ?? 0 ),
			// Whether each option carries its own quantity stepper.
			'option_quantity' => ! empty( $group['option_qty'] ),
			'placeholder'     => (string) ( $group['placeholder'] ?? '' ),
			'char_limit'      => (int) ( $group['char_limit'] ?? 0 ),
			'free_label'      => $this->shows_free_label( $group ),
			'options'         => $options,
		];
	}

	/**
	 * One option of a group.
	 *
	 * @param string $index Position, used as the option's stable id.
	 * @param array  $option Stored option.
	 * @return array|null
	 */
	private function shape_option( $index, array $option ) {
		$label = trim( (string) ( $option['label'] ?? '' ) );

		if ( '' === $label ) {
			return null;
		}

		return [
			'id'          => $index,
			'label'       => $label,
			'description' => (string) ( $option['description'] ?? '' ),
			'image'       => $this->image_url( $option['image'] ?? '' ),
			// Minor units as a string, exactly as the Store API sends money,
			// so the app parses it with the model it already has.
			'price'       => $this->minor_units( $option['price'] ?? '' ),
			'price_type'  => (string) ( $option['price_type'] ?? 'quantity_based' ),
			'is_default'  => ! empty( $option['default'] ),
		];
	}

	/**
	 * A stored price as minor units.
	 *
	 * The admin screen stores the price as **free text**, so it can hold "-",
	 * "N/A" or an empty string, all of which mean no charge. Anything
	 * non-numeric is zero here, which is the same reading `AddonHelper` takes
	 * when it renders the website.
	 *
	 * @param mixed $price Stored price.
	 * @return string
	 */
	private function minor_units( $price ) {
		$amount = is_numeric( $price ) ? (float) $price : 0.0;
		$digits = function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2;

		return (string) (int) round( $amount * pow( 10, $digits ) );
	}

	/**
	 * Whether zero-priced options in this group show a "Free" badge.
	 *
	 * Resolved here rather than sent as the raw per-group setting, because
	 * the answer depends on a global option the app cannot see.
	 *
	 * @param array $group Stored group.
	 * @return bool
	 */
	private function shows_free_label( array $group ) {
		return \RT\FoodMenuPro\Controllers\ProductAddons\Frontend\AddonHelper::show_free_label( $group );
	}

	/**
	 * An attachment id or URL, resolved to a URL.
	 *
	 * @param mixed $image Stored value.
	 * @return string
	 */
	private function image_url( $image ) {
		if ( is_numeric( $image ) && (int) $image > 0 ) {
			return (string) wp_get_attachment_image_url( (int) $image, 'thumbnail' );
		}

		return esc_url_raw( (string) $image );
	}

	/**
	 * The store's currency, in the Store API's own key names.
	 *
	 * Lives in {@see AppApiFns::currency()}, shared with the order route.
	 *
	 * @return array
	 */
	private function currency() {
		return AppApiFns::currency();
	}

	/**
	 * The field types the website can render, and therefore the only ones the
	 * app is told about.
	 *
	 * @var string[]
	 */
	const TYPES = [ 'dropdown', 'checkbox', 'radio', 'text', 'textarea' ];
}
