<?php
/**
 * Order types and their weekly schedules, for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;

/**
 * `GET fmp/v1/app/order-types` — can this store be ordered from for pickup or
 * for delivery, and when.
 *
 * The **write** path for an order type already existed: Pro registers a
 * `food-menu-pro` Store API checkout extension carrying `fmp_order_time_type`
 * and the pickup/delivery dates and times. Only the read path was missing —
 * the app had no way to know which of the two a store offers, let alone which
 * days it is open.
 *
 * **Public, like the add-ons route.** The design puts the delivery/pickup
 * choice in the header of the very first screen, before sign-in, and nothing
 * in the answer is customer data — it is the store's own opening hours.
 *
 * This route answers the **week**; `/app/slots` answers one day of it. Both
 * read the schedule through `AppSchedules`, because a day this route calls
 * open has to be a day that one can generate times for.
 */
class OrderTypesApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/order-types',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_order_types' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'branch' => [
						'required'          => false,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
						'description'       => 'Location term id. Omit for the store-wide schedule.',
					],
				],
			]
		);
	}

	/**
	 * `GET /app/order-types`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_order_types( $request ) {
		$branch = AppSchedules::resolve_branch( $request['branch'] ?? 0 );

		if ( is_wp_error( $branch ) ) {
			return $branch;
		}

		$settings = (array) FnsPro::get_settings_option();
		$location = AppSchedules::location_data( $branch );
		$now      = current_datetime();

		$types = [];

		foreach ( AppSchedules::TYPES as $type ) {
			$types[] = $this->shape_type( $type, $settings, $location );
		}

		return new WP_REST_Response(
			[
				'branch'              => $branch,
				'timezone'            => wp_timezone_string(),
				'now'                 => $now->format( 'c' ),
				'today'               => $now->format( TLP_FOOD_MENU_DEFAULT_DATE_FORMAT ),
				// How far ahead a customer may order. Zero means today only,
				// which is the default and not an omission.
				'preorder_max_days'   => absint( $settings['fmp_preorder_max_days'] ?? 0 ),
				// Whether the store caps orders per slot at all. When false,
				// `max_orders_per_slot` below is not enforced whatever it says.
				'slot_limits_enabled' => ! empty( $settings['fmp_enable_order_slot_limits'] ),
				'types'               => $types,
			],
			200
		);
	}

	/**
	 * One order type, with its weekly schedule.
	 *
	 * @param string     $type     `pickup` or `delivery`.
	 * @param array      $settings Store settings.
	 * @param array|null $location Per-location schedule data, when a branch
	 *                             was asked for and has its own.
	 * @return array
	 */
	private function shape_type( $type, array $settings, $location ) {
		$schedule = AppSchedules::schedule_for( $type, $location );
		$lead     = AppSchedules::lead_days( $type, $settings );
		$first    = FnsPro::preparing_date( $lead );
		$max_days = absint( $settings['fmp_preorder_max_days'] ?? 0 );

		return [
			'type'                => $type,
			'label'               => AppSchedules::label( $type ),
			// Absent means **on**, which is how the website reads these: a
			// store that has never opened the settings screen offers both.
			'enabled'             => AppSchedules::is_enabled( $type, $settings ),
			// When false the customer picks no date or time at all and the
			// order is simply as soon as possible — so the app must skip the
			// slot list rather than show an empty one.
			'time_required'       => AppSchedules::is_time_required( $type, $settings ),
			'time_interval'       => AppSchedules::interval( $type, $settings, $location ),
			// Days the kitchen needs before it can take this type. Pickup is
			// always same-day; only delivery has the setting, which is how
			// `pickup_delivery_data_obj()` reads it too.
			'lead_days'           => $lead,
			'first_date'          => $first,
			// Null means no upper bound, not "today".
			'last_date'           => $max_days > 0
				? FnsPro::preparing_date( $lead + $max_days )
				: null,
			// Zero means no cap for this type. Only meaningful when
			// `slot_limits_enabled` is true.
			'max_orders_per_slot' => AppSchedules::slot_cap( $type, $settings, $location ),
			'days'                => $this->days( $schedule ),
		];
	}

	/**
	 * The week, one entry per day, in the store's own day order.
	 *
	 * `windows` being empty on an **open** day is not a contradiction and not
	 * an omission: it is a day the store has set no hours for, which the
	 * website treats as no restriction. A closed day is `open: false`, and
	 * that is the only thing that means closed.
	 *
	 * @param array $schedule Stored weekly schedule.
	 * @return array[]
	 */
	private function days( array $schedule ) {
		$closed = AppSchedules::closed_days( $schedule );
		$out    = [];

		foreach ( Fns::day_map_index() as $index ) {
			$windows = [];

			// Per-window `max_order` is deliberately left out here: this route
			// describes opening hours, and a cap only means anything against a
			// date, which is `/app/slots`.
			foreach ( AppSchedules::windows( $schedule, $index ) as $window ) {
				$windows[] = [
					'start' => $window['start'],
					'end'   => $window['end'],
				];
			}

			$out[] = [
				'day'     => $index,
				'name'    => $this->day_name( $index ),
				'open'    => ! in_array( $index, $closed, true ),
				'windows' => $windows,
			];
		}

		return $out;
	}

	/**
	 * The weekday name in the store's language.
	 *
	 * @param int $index 0 for Sunday.
	 * @return string
	 */
	private function day_name( $index ) {
		global $wp_locale;

		return $wp_locale instanceof \WP_Locale
			? $wp_locale->get_weekday( $index )
			: '';
	}
}
