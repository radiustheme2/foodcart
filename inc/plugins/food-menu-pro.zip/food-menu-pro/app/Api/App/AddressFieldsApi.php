<?php
/**
 * Address field metadata REST API for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;

/**
 * `GET fmp/v1/app/address-fields` — how to draw an address form.
 *
 * `AppAddresses` validates per country, out of
 * `WC()->countries->get_address_fields()`: the US needs a state and a ZIP, the
 * UAE needs neither, the UK needs a postcode but no state, and WooCommerce
 * even renames the fields ("ZIP Code", "District", "Province"). None of that
 * is knowable by a mobile client, so without this route a form can only guess
 * and then react to a rejection.
 *
 * This hands over WooCommerce's own answer — which fields, in which order,
 * required or not, under which label, with which options — so the app draws
 * the right form the first time instead of discovering the rules one failed
 * save at a time.
 *
 * **One country per request.** Returning every country's states at once would
 * be a payload of tens of thousands of entries for a form that shows one
 * country at a time.
 */
class AddressFieldsApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/address-fields',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_fields' ],
				'permission_callback' => [ $this, 'permission' ],
				'args'                => [
					'country' => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'Country code. Defaults to the store\'s base country.',
					],
				],
			]
		);
	}

	/**
	 * Signed in, like every other app route but the auth ones.
	 *
	 * Nothing here is private — it is the same schema a guest checkout page
	 * shows — but v1 requires an account before ordering, so there is no
	 * caller that is not signed in. Relaxing it is one line if guest checkout
	 * ever arrives.
	 *
	 * @return bool|WP_Error
	 */
	public function permission() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'fmp_app_not_authenticated',
				__( 'You must be signed in to do that.', 'food-menu-pro' ),
				[ 'status' => 401 ]
			);
		}

		return true;
	}

	/**
	 * `GET /app/address-fields`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_fields( $request ) {
		$countries = function_exists( 'WC' ) && WC() ? WC()->countries : null;

		if ( ! $countries ) {
			return new WP_Error(
				'fmp_app_woocommerce_missing',
				__( 'Addresses are unavailable because WooCommerce is not active.', 'food-menu-pro' ),
				[ 'status' => 503 ]
			);
		}

		$allowed = $countries->get_allowed_countries();
		$allowed = $allowed ? $allowed : $countries->get_countries();
		$default = $countries->get_base_country();

		// A base country the store does not sell to would hand the app a
		// default it cannot pick, so fall back to the first one it can.
		if ( ! isset( $allowed[ $default ] ) ) {
			$default = (string) array_key_first( $allowed );
		}

		$country = strtoupper( (string) $request['country'] );

		if ( '' === $country ) {
			$country = $default;
		}

		if ( ! isset( $allowed[ $country ] ) ) {
			return new WP_Error(
				'fmp_app_country_not_allowed',
				__( 'We do not deliver to that country.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		// Deliberately no `Cache-Control`. This answer is static per country
		// and would cache well, but WordPress forces `no-store` onto every
		// authenticated REST response, so a header set here never survives.
		// The client holds it for the session instead.
		return new WP_REST_Response(
			[
				'default_country' => $default,
				'countries'       => array_map( 'wp_strip_all_tags', $allowed ),
				'country'         => $country,
				'fields'          => $this->fields_for( $country ),
			],
			200
		);
	}

	/**
	 * WooCommerce's address fields for one country, in our vocabulary.
	 *
	 * Intersected with the fields the address book actually stores, so the app
	 * is never told to collect something that would be dropped on save.
	 * Returned as an ordered list rather than a map, because WooCommerce
	 * orders fields differently per country and that order is the point.
	 *
	 * @param string $country Country code.
	 * @return array
	 */
	private function fields_for( $country ) {
		$countries = WC()->countries;
		$raw       = $countries->get_address_fields( $country, '' );
		$states    = $countries->get_states( $country );
		$states    = is_array( $states ) ? $states : [];
		$out       = [];

		foreach ( AppAddresses::FIELDS as $key ) {
			// WooCommerce drops fields a country does not use — `company` is
			// absent in most locales, `state` where there is no state list.
			// An absent field is the answer, so it is not padded back in.
			if ( ! isset( $raw[ $key ] ) ) {
				continue;
			}

			$field = $raw[ $key ];

			$entry = [
				'key'      => $key,
				'label'    => wp_strip_all_tags( (string) ( $field['label'] ?? $key ) ),
				'required' => ! empty( $field['required'] ),
				'priority' => (int) ( $field['priority'] ?? 0 ),
				'type'     => (string) ( $field['type'] ?? 'text' ),
			];

			if ( 'state' === $key && $states ) {
				$entry['options'] = array_map( 'wp_strip_all_tags', $states );
			}

			$out[] = $entry;
		}

		usort(
			$out,
			function ( $a, $b ) {
				return $a['priority'] <=> $b['priority'];
			}
		);

		return $out;
	}
}
