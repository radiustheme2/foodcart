<?php
/**
 * Password reset codes for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use WP_User;

/**
 * A short numeric code, emailed to the customer and verified by the app.
 *
 * **Not WordPress's own reset link.** `retrieve_password()` emails a URL to
 * `wp-login.php`, which drops a mobile customer onto a web page mid-flow and
 * leaves them to find their way back. Completing the reset in the app needs
 * something typeable, which a 40-character key is not.
 *
 * The trade is that a 6-digit code has only a million values, so the defences
 * are time and attempts rather than length: it lives for
 * [self::TTL] (15 minutes), allows [self::MAX_ATTEMPTS] guesses, is destroyed
 * by either limit, and both routes that touch it are rate limited per IP and
 * per account on top.
 *
 * Only an HMAC of the code is stored. That is worth less here than it is for
 * an access token — a leaked row could be brute-forced offline in a million
 * hashes — but it keeps the plaintext out of the database for the quarter of
 * an hour it exists, and costs nothing.
 */
class AppPasswordReset {

	/**
	 * User meta key holding the pending code.
	 *
	 * @var string
	 */
	const META_KEY = '_fmp_app_reset_code';

	/**
	 * How long a code is good for, in seconds.
	 *
	 * @var int
	 */
	const TTL = 900;

	/**
	 * Wrong guesses before the code is destroyed.
	 *
	 * @var int
	 */
	const MAX_ATTEMPTS = 5;

	/**
	 * Issue a code for a user, replacing any pending one.
	 *
	 * Replacing rather than reusing, so asking again always works — a
	 * customer who did not receive the first email should not be told to wait
	 * for a code they cannot see.
	 *
	 * @param WP_User $user User.
	 * @return string The plain code, to be emailed and then forgotten.
	 */
	public static function issue( WP_User $user ) {
		$code = str_pad( (string) random_int( 0, 999999 ), 6, '0', STR_PAD_LEFT );

		update_user_meta(
			$user->ID,
			self::META_KEY,
			[
				'hash' => self::hash( $code ),
				// Absolute, because the row may be read days later and a
				// stored lifetime would say nothing about whether it is spent.
				'expires'  => time() + (int) apply_filters( 'fmp_app_reset_code_ttl', self::TTL ),
				'attempts' => 0,
			]
		);

		return $code;
	}

	/**
	 * Check a code, consuming it on success.
	 *
	 * @param WP_User $user User.
	 * @param string  $code Submitted code.
	 * @return bool
	 */
	public static function verify( WP_User $user, $code ) {
		$stored = get_user_meta( $user->ID, self::META_KEY, true );

		if ( ! is_array( $stored ) || empty( $stored['hash'] ) ) {
			return false;
		}

		if ( time() > (int) ( $stored['expires'] ?? 0 ) ) {
			self::clear( $user );
			return false;
		}

		$attempts = (int) ( $stored['attempts'] ?? 0 );
		$max      = (int) apply_filters( 'fmp_app_reset_code_attempts', self::MAX_ATTEMPTS );

		if ( $attempts >= $max ) {
			self::clear( $user );
			return false;
		}

		// `hash_equals`, not `===`: the comparison is against a secret, and a
		// timing difference would leak it a character at a time.
		if ( ! hash_equals( (string) $stored['hash'], self::hash( (string) $code ) ) ) {
			$stored['attempts'] = $attempts + 1;
			update_user_meta( $user->ID, self::META_KEY, $stored );
			return false;
		}

		// One use only. A code that still worked after a reset would be a
		// second password.
		self::clear( $user );

		return true;
	}

	/**
	 * Drop any pending code.
	 *
	 * @param WP_User $user User.
	 * @return void
	 */
	public static function clear( WP_User $user ) {
		delete_user_meta( $user->ID, self::META_KEY );
	}

	/**
	 * Email the code.
	 *
	 * Failure is deliberately not reported to the caller: the route it serves
	 * answers identically whether or not the account exists, and saying "we
	 * could not send that" would give that away.
	 *
	 * @param WP_User $user User.
	 * @param string  $code Plain code.
	 * @return void
	 */
	public static function send( WP_User $user, $code ) {
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

		$subject = sprintf(
			/* translators: %s: site name. */
			__( 'Your %s password reset code', 'food-menu-pro' ),
			$site
		);

		$minutes = (int) round( (int) apply_filters( 'fmp_app_reset_code_ttl', self::TTL ) / 60 );

		$message = sprintf(
			/* translators: 1: user display name, 2: the reset code, 3: minutes until it expires, 4: site name. */
			__(
				"Hi %1\$s,\n\nYour password reset code is %2\$s.\n\nEnter it in the app within %3\$d minutes to choose a new password.\n\nIf you did not ask to reset your password you can ignore this email — nothing has changed.\n\n%4\$s",
				'food-menu-pro'
			),
			$user->display_name ? $user->display_name : $user->user_login,
			$code,
			$minutes,
			$site
		);

		/**
		 * Filters the password reset email before it is sent.
		 *
		 * @param array   $email Subject, message and headers.
		 * @param WP_User $user  The customer.
		 * @param string  $code  The plain code.
		 */
		$email = apply_filters(
			'fmp_app_reset_email',
			[
				'subject' => $subject,
				'message' => $message,
				'headers' => [],
			],
			$user,
			$code
		);

		wp_mail(
			$user->user_email,
			$email['subject'],
			$email['message'],
			$email['headers']
		);
	}

	/**
	 * Keyed hash of a code.
	 *
	 * @param string $code Plain code.
	 * @return string
	 */
	private static function hash( $code ) {
		return hash_hmac( 'sha256', $code, wp_salt( 'auth' ) );
	}
}
