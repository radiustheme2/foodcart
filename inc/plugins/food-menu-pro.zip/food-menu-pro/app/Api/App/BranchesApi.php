<?php
/**
 * The store's branches, for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

/**
 * `GET fmp/v1/app/branches` — where this store can be ordered from.
 *
 * The third and last read route Phase 5 needs: `/app/order-types` answers the
 * week, `/app/slots` answers one day of it, and this answers *which* branch
 * those two should be asked about.
 *
 * **Why it is here and not in the free plugin.** Locations are a free-plugin
 * feature — the `tpl-food-location` taxonomy is registered in
 * `PostTypesController` and the term carries only what WordPress gives it.
 * Every *rule* that hangs off a branch is Pro's: the schedules, the intervals
 * and the slot caps are all `fmp_loc_*` term meta written by Pro's
 * `TaxMeta`, and the whole `fmp/v1/app` namespace is Pro's too. Free cannot
 * reference either, and Pro already depends on free, so this is the direction
 * the dependency has to run.
 *
 * **There is always at least one entry.** A store with no branches still has
 * somewhere a customer collects their food from, and the design's header says
 * "Pick up from" on the very first screen. So a store with no location terms
 * is answered with a single entry built from **WooCommerce's own store
 * address**, carrying `id: 0` — which is already what `branch=0` means to the
 * other two routes. The app never has to special-case an empty list.
 */
class BranchesApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/branches',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_branches' ],
				'permission_callback' => '__return_true',
			]
		);

		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/branches/(?P<id>\d+)/unserved',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_unserved' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'id'       => [
						'required'          => true,
						'sanitize_callback' => 'absint',
					],
					'products' => [
						'required'    => true,
						'description' => __( 'Comma-separated product or variation ids.', 'food-menu-pro' ),
					],
				],
			]
		);
	}

	/**
	 * `GET /app/branches/{id}/unserved?products=11,14,25`.
	 *
	 * Which of these dishes the branch does not serve, so the app can ask
	 * before a branch switch takes something out of the customer's cart
	 * rather than after.
	 *
	 * Takes ids rather than reading the cart, because the question is asked
	 * about a branch the customer has **not** switched to yet — there is no
	 * request that would carry it as `X-FMP-Branch`, and the answer is the
	 * same whether those ids are in a cart or not.
	 *
	 * Public, like `/branches` itself: it tells a caller nothing the menu does
	 * not already, since asking the menu for branch N lists exactly the dishes
	 * this route would call served.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function get_unserved( $request ) {
		$branch_id = absint( $request['id'] );

		$ids = array_filter(
			array_map( 'absint', explode( ',', (string) $request->get_param( 'products' ) ) )
		);

		// Deduplicated, because a cart can hold the same dish on two lines
		// with different add-ons and the customer should be told once.
		$unserved = AppBranchScope::unserved( array_values( array_unique( $ids ) ), $branch_id );
		$out      = [];

		foreach ( $unserved as $product_id ) {
			$product = wc_get_product( $product_id );

			$out[] = [
				'id'   => $product_id,
				'name' => $product instanceof \WC_Product ? $product->get_name() : '',
			];
		}

		return new WP_REST_Response(
			[
				'branch_id' => $branch_id,
				'unserved'  => $out,
			],
			200
		);
	}

	/**
	 * `GET /app/branches`.
	 *
	 * @return WP_REST_Response
	 */
	public function get_branches() {
		$settings = (array) FnsPro::get_settings_option();
		$multi    = ! empty( $settings['fmp_food_location_popup'] );
		$terms    = [];

		// The taxonomy is only registered while the multi-location switch is
		// on, so asking for its terms with the feature off is not a smaller
		// answer — it is a `WP_Error`.
		if ( $multi && taxonomy_exists( AppSchedules::BRANCH_TAXONOMY ) ) {
			$found = get_terms(
				[
					'taxonomy'   => AppSchedules::BRANCH_TAXONOMY,
					'hide_empty' => false,
					'orderby'    => 'name',
				]
			);

			if ( ! is_wp_error( $found ) ) {
				$terms = $found;
			}
		}

		$branches = [];

		foreach ( $terms as $term ) {
			$branches[] = $this->shape_branch( $term, $settings );
		}

		if ( empty( $branches ) ) {
			$branches[] = $this->shape_store( $settings );
		}

		return new WP_REST_Response(
			[
				// Whether the customer gets a choice at all. False means the
				// one entry below is the store itself, so show it rather than
				// a picker.
				'multi_location' => $multi,
				'timezone'       => wp_timezone_string(),
				'now'            => current_datetime()->format( 'c' ),
				'branches'       => $branches,
			],
			200
		);
	}

	/**
	 * One branch.
	 *
	 * @param \WP_Term $term     Location term.
	 * @param array    $settings Store settings.
	 * @return array
	 */
	private function shape_branch( $term, array $settings ) {
		$location = AppSchedules::location_data( (int) $term->term_id );

		return [
			'id'            => (int) $term->term_id,
			'name'          => $term->name,
			'slug'          => $term->slug,
			// The taxonomy is hierarchical, so a store can file branches
			// under a city. 0 means top level.
			'parent'        => (int) $term->parent,
			'description'   => $term->description,
			// The taxonomy is attached to `product` and nothing else, so the
			// term's own count is a dish count and safe to pass on.
			'product_count' => (int) $term->count,
			'address'       => $this->term_address( (int) $term->term_id ),
			'coordinates'   => $this->coordinates( (int) $term->term_id ),
			'is_store'      => false,
			'types'         => $this->types( $settings, $location ),
		];
	}

	/**
	 * The store itself, for a site with no branches.
	 *
	 * @param array $settings Store settings.
	 * @return array
	 */
	private function shape_store( array $settings ) {
		return [
			'id'            => 0,
			'name'          => get_bloginfo( 'name' ),
			'slug'          => '',
			'parent'        => 0,
			'description'   => '',
			'product_count' => 0,
			'address'       => $this->store_address(),
			// WooCommerce stores no coordinates for the shop itself, and
			// guessing them from the address would need a geocoder.
			'coordinates'   => null,
			// Says "this is not a branch you chose, it is the shop" — the app
			// shows it without a picker and keeps sending `branch=0`.
			'is_store'      => true,
			'types'         => $this->types( $settings, null ),
		];
	}

	/**
	 * Per-order-type rules for one branch.
	 *
	 * The **week** is deliberately not inlined: `/app/order-types?branch=<id>`
	 * already answers it, and repeating seven days times two types times every
	 * branch would make the picker's payload grow with the store. What is here
	 * is what a picker draws — whether the type is offered, whether this
	 * branch overrides the store, and whether it is open right now.
	 *
	 * @param array      $settings Store settings.
	 * @param array|null $location Per-location schedule data.
	 * @return array[]
	 */
	private function types( array $settings, $location ) {
		$out = [];

		foreach ( AppSchedules::TYPES as $type ) {
			$schedule = AppSchedules::schedule_for( $type, $location );
			$day      = (int) wp_date( 'w' );
			$open     = ! in_array( $day, AppSchedules::closed_days( $schedule ), true );
			$windows  = AppSchedules::windows( $schedule, $day );

			$out[] = [
				'type'                => $type,
				'label'               => AppSchedules::label( $type ),
				'enabled'             => AppSchedules::is_enabled( $type, $settings ),
				'time_required'       => AppSchedules::is_time_required( $type, $settings ),
				// Whether this branch sets its own hours for this type. False
				// means it follows the store's, which is a thing a picker may
				// want to say out loud.
				'has_custom_schedule' => is_array( $location )
					&& ! empty( $location[ "has_{$type}_schedule" ] ),
				'time_interval'       => AppSchedules::interval( $type, $settings, $location ),
				'max_orders_per_slot' => AppSchedules::slot_cap( $type, $settings, $location ),
				'lead_days'           => AppSchedules::lead_days( $type, $settings ),
				'open_today'          => $open,
				'open_now'            => $open && $this->open_now( $windows ),
				'today'               => [
					'day'     => $day,
					'windows' => array_map(
						static function ( $window ) {
							return [
								'start' => $window['start'],
								'end'   => $window['end'],
							];
						},
						$windows
					),
				],
			];
		}

		return $out;
	}

	/**
	 * Whether now falls inside one of today's windows.
	 *
	 * **No windows means open**, not shut: a day the store set no hours for is
	 * a day with no restriction, which is how the website reads it and what
	 * `/app/slots` does with the same case.
	 *
	 * @param array[] $windows Today's windows.
	 * @return bool
	 */
	private function open_now( array $windows ) {
		if ( empty( $windows ) ) {
			return true;
		}

		$now = (int) wp_date( 'G' ) * 60 + (int) wp_date( 'i' );

		foreach ( $windows as $window ) {
			$start = AppSchedules::time_to_minutes( $window['start'] );
			$end   = AppSchedules::time_to_minutes( $window['end'] );

			if ( null !== $start && null !== $end && $now >= $start && $now < $end ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * A branch's address, as the admin typed it.
	 *
	 * One free-text field rather than WooCommerce's structured parts, because
	 * that is what the location screen has always stored. It is returned with
	 * its line breaks intact so the app can render it on one line or several.
	 *
	 * @param int $term_id Location term id.
	 * @return string
	 */
	private function term_address( $term_id ) {
		$address = (string) get_term_meta( $term_id, 'address', true );

		// Historical damage, undone on the way out. The edit screen escaped
		// this field with `esc_attr()` and printed it on its own indented
		// line, so every save round-tripped more leading whitespace and
		// another layer of entity escaping into the stored value. Both are
		// fixed at the source now; this cleans what is already in the
		// database. Bounded, because the escaping could have stacked.
		for ( $pass = 0; $pass < 3; $pass++ ) {
			$decoded = wp_specialchars_decode( $address, ENT_QUOTES );

			if ( $decoded === $address ) {
				break;
			}

			$address = $decoded;
		}

		return trim( $address );
	}

	/**
	 * A branch's coordinates, or null when it has none.
	 *
	 * Null rather than zeroes: `0, 0` is a real place in the Atlantic, and an
	 * app computing a distance to it would quietly tell every customer their
	 * nearest branch is thousands of miles away.
	 *
	 * @param int $term_id Location term id.
	 * @return array|null
	 */
	private function coordinates( $term_id ) {
		$lat = trim( (string) get_term_meta( $term_id, 'location_latitude', true ) );
		$lng = trim( (string) get_term_meta( $term_id, 'location_longitude', true ) );

		if ( '' === $lat || '' === $lng || ! is_numeric( $lat ) || ! is_numeric( $lng ) ) {
			return null;
		}

		$lat = (float) $lat;
		$lng = (float) $lng;

		if ( $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 ) {
			return null;
		}

		return [
			'latitude'  => $lat,
			'longitude' => $lng,
		];
	}

	/**
	 * WooCommerce's own store address, on one line.
	 *
	 * @return string
	 */
	private function store_address() {
		if ( ! function_exists( 'WC' ) || ! WC()->countries ) {
			return '';
		}

		$countries = WC()->countries;

		// `get_formatted_address()` applies the country's own ordering, which
		// is the whole reason to use it rather than concatenating fields.
		$formatted = $countries->get_formatted_address(
			[
				'address_1' => get_option( 'woocommerce_store_address', '' ),
				'address_2' => get_option( 'woocommerce_store_address_2', '' ),
				'city'      => get_option( 'woocommerce_store_city', '' ),
				'state'     => $countries->get_base_state(),
				'postcode'  => get_option( 'woocommerce_store_postcode', '' ),
				'country'   => $countries->get_base_country(),
			]
		);

		// It comes back as HTML with `<br/>` between the lines; stripping the
		// tags without replacing them first runs the lines together.
		return trim( wp_strip_all_tags( str_replace( '<br/>', ', ', $formatted ) ) );
	}
}
