<?php
/**
 * Bearer token authentication for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;

/**
 * Resolves `Authorization: Bearer fmpa_…` to the WordPress current user.
 *
 * This is what makes the rest of the app API possible: once the current user is
 * set, ordinary capability checks, WooCommerce customer sessions and
 * `get_current_user_id()` all behave as they do for a logged-in browser, with
 * no cookie and no nonce anywhere.
 */
class AppAuthentication {

	use SingletonTrait;

	/**
	 * Resolved user ID for this request, or null before the first lookup.
	 *
	 * `determine_current_user` fires on every `wp_get_current_user()` call, so
	 * without this the token would be re-verified many times per request.
	 *
	 * @var int|null
	 */
	private $resolved = null;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_filter( 'determine_current_user', [ $this, 'determine_current_user' ], 20 );
		add_filter( 'rest_authentication_errors', [ $this, 'rest_authentication_errors' ], 20 );
	}

	/**
	 * Read the bearer token out of the request headers.
	 *
	 * `REDIRECT_HTTP_AUTHORIZATION` is checked too, because Apache under CGI or
	 * FastCGI strips `Authorization` unless it has been explicitly passed
	 * through, and leaves it there instead.
	 *
	 * @return string Raw token, or an empty string.
	 */
	private function get_bearer_token() {
		$header = '';

		foreach ( [ 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION' ] as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$header = trim( sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) );
				break;
			}
		}

		if ( '' === $header || 0 !== stripos( $header, 'bearer ' ) ) {
			return '';
		}

		$token = trim( substr( $header, 7 ) );

		// Only claim tokens that are ours. Other plugins also use bearer
		// tokens, and silently failing their requests would be our fault.
		if ( 0 !== strpos( $token, AppTokens::PREFIX . '_' ) ) {
			return '';
		}

		return $token;
	}

	/**
	 * Resolve the current user from a bearer token.
	 *
	 * @param int|false $user_id User ID determined so far.
	 * @return int|false
	 */
	public function determine_current_user( $user_id ) {
		// A cookie session wins: the plugin's own React dashboards run in an
		// authenticated browser and must keep working untouched.
		if ( ! empty( $user_id ) ) {
			return $user_id;
		}

		if ( null !== $this->resolved ) {
			return $this->resolved > 0 ? $this->resolved : $user_id;
		}

		$token = $this->get_bearer_token();

		if ( '' === $token ) {
			$this->resolved = 0;
			return $user_id;
		}

		$this->resolved = AppTokens::user_id_from_access_token( $token );

		return $this->resolved > 0 ? $this->resolved : $user_id;
	}

	/**
	 * Tell the REST API that a valid bearer token counts as authentication.
	 *
	 * @param \WP_Error|null|true $errors Current authentication result.
	 * @return \WP_Error|null|true
	 */
	public function rest_authentication_errors( $errors ) {
		// Never overturn another handler's decision, in either direction.
		if ( null !== $errors ) {
			return $errors;
		}

		if ( '' === $this->get_bearer_token() ) {
			return $errors;
		}

		return get_current_user_id() > 0 ? true : $errors;
	}

	/**
	 * Whether this request carries an app bearer token.
	 *
	 * @return bool
	 */
	public function has_bearer_token() {
		return '' !== $this->get_bearer_token();
	}

	/**
	 * The raw bearer token on this request, if any.
	 *
	 * @return string
	 */
	public function bearer_token() {
		return $this->get_bearer_token();
	}
}
