<?php
/**
 * Ordering the same thing again, for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;

/**
 * `GET fmp/v1/app/orders/{id}/reorder` — the same order, as a cart would take it.
 *
 * ## Why an order could not be reordered before
 * A line records its add-ons as **display text** — `[Make it a meal] = No
 * thanks` — written by `FrontendCartAction::display_checkout_order_line_item`
 * for the customer, the admin and the kitchen slip to read. There is no group
 * id and no option id anywhere on it, so nothing can rebuild a selection from
 * an order: matching labels back to the store's current groups breaks the
 * moment an option is renamed, and picks the wrong one silently rather than
 * failing.
 *
 * WooCommerce's own `order_again` is no help either. It rebuilds a cart
 * through `woocommerce_order_again_cart_item_data`, which **neither plugin
 * hooks**, so it would drop every choice too.
 *
 * ## What this adds
 * `AppCartAddons` now keeps the selection **as submitted** on the cart item,
 * beside the display rows, and this class carries it onto the order line as
 * `_fmp_addon_selection`. It is the exact payload `cart/add-item` accepts, so
 * a reorder re-submits it unchanged and the server validates it again from
 * scratch — a group that has since become required, an option that has been
 * deleted, a dish that is out of stock all fail the way they would on a first
 * order.
 *
 * **Only orders placed through the app carry it.** The meta is copied from a
 * cart item key that only `woocommerce_store_api_add_to_cart_data` writes, so
 * a website order never has one and nothing about the website changes. The key
 * is underscore-prefixed and added to WooCommerce's hidden list, so it does
 * not appear on the order page, the emails or any slip.
 *
 * ## What it refuses
 * This route **does not add anything to a cart**. It answers what the lines
 * would be, and the app submits them through the Store API's own
 * `cart/add-item` — the path where add-on validation, branch scoping, timed
 * products and stock already work. Doing it here would mean reproducing all
 * four.
 *
 * A line is returned as **not reproducible**, with a reason, rather than
 * silently reduced, when:
 *
 * - the product has been deleted, is no longer purchasable, or is out of stock;
 * - the line has no recorded selection **and** the product has add-on groups
 *   today. An order placed before this existed can still be reordered if
 *   nothing on it took choices — there is nothing to lose in that case.
 */
class AppReorderApi {

	use SingletonTrait;

	/**
	 * Order item meta holding the re-submittable selection.
	 *
	 * @var string
	 */
	const META = '_fmp_addon_selection';

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
		add_action( 'woocommerce_checkout_create_order_line_item', [ $this, 'keep_selection' ], 10, 3 );
		add_filter( 'woocommerce_hidden_order_itemmeta', [ $this, 'hide_selection' ] );
	}

	/**
	 * Carry the submitted selection from the cart item onto the order line.
	 *
	 * Guarded on the cart item's own key rather than on the request: only
	 * `woocommerce_store_api_add_to_cart_data` writes it, so a website order
	 * has nothing to copy and this does nothing at all.
	 *
	 * @param \WC_Order_Item_Product $item     Order line.
	 * @param string                 $cart_key Cart item key.
	 * @param array                  $values   Cart item.
	 * @return void
	 */
	public function keep_selection( $item, $cart_key, $values ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Signature is WooCommerce's.
		if ( ! isset( $values['fmp_addon_selection'] ) || ! is_array( $values['fmp_addon_selection'] ) ) {
			return;
		}

		// Stored even when empty: its presence is the signal that this line's
		// choices were recorded, which is what tells a new order from one
		// placed before any of this existed.
		$item->add_meta_data( self::META, wp_json_encode( $values['fmp_addon_selection'] ), true );
	}

	/**
	 * Keep the selection out of the admin order screen.
	 *
	 * Underscore-prefixed meta is hidden from the customer already; this is
	 * the admin's own list, which shows everything unless told.
	 *
	 * @param string[] $hidden Hidden meta keys.
	 * @return string[]
	 */
	public function hide_selection( $hidden ) {
		$hidden[] = self::META;

		return $hidden;
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/orders/(?P<id>\d+)/reorder',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_reorder' ],
				'permission_callback' => [ $this, 'permission' ],
				'args'                => [
					'id' => [
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					],
				],
			]
		);
	}

	/**
	 * Signed in, and nothing more — whose order it is is decided below.
	 *
	 * @return true|WP_Error
	 */
	public function permission() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'fmp_app_not_authenticated',
				__( 'You must be signed in to do that.', 'food-menu-pro' ),
				[ 'status' => 401 ]
			);
		}

		return true;
	}

	/**
	 * `GET /app/orders/{id}/reorder` — what this order would add to a cart.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_reorder( $request ) {
		$order = wc_get_order( absint( $request['id'] ) );

		// Somebody else's order is answered exactly as a missing one is, for
		// the same reason the other order routes do it.
		if ( ! $order || (int) $order->get_customer_id() !== get_current_user_id() ) {
			return new WP_Error(
				'fmp_app_order_not_found',
				__( 'That order could not be found.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		$lines = [];

		foreach ( $order->get_items() as $item ) {
			if ( $item instanceof \WC_Order_Item_Product ) {
				$lines[] = $this->line( $item );
			}
		}

		$available = array_filter(
			$lines,
			static function ( $line ) {
				return $line['available'];
			}
		);

		return AppApiFns::no_store(
			new WP_REST_Response(
				[
					'order_id' => $order->get_id(),
					'number'   => (string) $order->get_order_number(),
					'lines'    => $lines,
					// What the app needs to decide whether to offer the button
					// at all, without counting the list itself.
					'any'      => ! empty( $available ),
					'all'      => count( $available ) === count( $lines ) && $lines,
				],
				200
			)
		);
	}

	/**
	 * One order line, as the cart would take it back.
	 *
	 * @param \WC_Order_Item_Product $item Order line.
	 * @return array
	 */
	private function line( $item ) {
		// The variation where there is one, since that is what the cart takes.
		$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
		$product    = $product_id ? wc_get_product( $product_id ) : null;

		$line = [
			'product_id' => (int) $product_id,
			'name'       => $item->get_name(),
			'quantity'   => max( 1, (int) $item->get_quantity() ),
			'addons'     => [],
			'available'  => false,
			'reason'     => '',
		];

		if ( ! $product ) {
			$line['reason'] = 'gone';

			return $line;
		}

		$line['name'] = $product->get_name();

		if ( ! $product->is_purchasable() ) {
			$line['reason'] = 'unavailable';

			return $line;
		}

		if ( ! $product->is_in_stock() ) {
			$line['reason'] = 'out_of_stock';

			return $line;
		}

		$recorded = $item->get_meta( self::META, true );

		if ( '' === $recorded || null === $recorded ) {
			// No recorded selection. Reproducible only if the dish takes no
			// choices today — then there was nothing to record and nothing to
			// lose. Add-on groups live on the parent, not the variation.
			$parent = $item->get_product_id() ? (int) $item->get_product_id() : (int) $product_id;

			if ( AppAddonGroups::for_product( $parent ) ) {
				$line['reason'] = 'choices_not_recorded';

				return $line;
			}

			$line['available'] = true;

			return $line;
		}

		$decoded = json_decode( (string) $recorded, true );

		if ( ! is_array( $decoded ) ) {
			$line['reason'] = 'choices_not_recorded';

			return $line;
		}

		// Sanitised again on the way out. It was sanitised going in, but this
		// has been sitting in the database since, and it is about to become a
		// request body.
		$line['addons']    = AppCartAddons::sanitize_selection(
			array_column( $decoded, null, 'group_id' )
		);
		$line['available'] = true;

		return $line;
	}
}
