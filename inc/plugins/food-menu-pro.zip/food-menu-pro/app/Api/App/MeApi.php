<?php
/**
 * Customer profile REST API for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;

/**
 * `GET|PUT fmp/v1/app/me` — profile and saved addresses.
 *
 * Authenticated by the bearer token from `AuthApi`, which resolves into the
 * real WordPress current user, so the permission check here is simply "is
 * somebody signed in".
 */
class MeApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/me',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_me' ],
					'permission_callback' => [ $this, 'permission' ],
				],
				[
					'methods'             => 'PUT',
					'callback'            => [ $this, 'update_me' ],
					'permission_callback' => [ $this, 'permission' ],
					'args'                => [
						'first_name' => [
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						],
						'last_name'  => [
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						],
						'phone'      => [
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						],
						'addresses'  => [
							'type'        => 'array',
							'items'       => [ 'type' => 'object' ],
							'description' => 'Replaces the whole address book.',
						],
					],
				],
			]
		);
	}

	/**
	 * Anyone signed in may read and write their own profile.
	 *
	 * @return bool|WP_Error
	 */
	public function permission() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'fmp_app_not_authenticated',
				__( 'You must be signed in to do that.', 'food-menu-pro' ),
				[ 'status' => 401 ]
			);
		}

		return true;
	}

	/**
	 * `GET /app/me`.
	 *
	 * @return WP_REST_Response
	 */
	public function get_me() {
		return AppApiFns::no_store( new WP_REST_Response( $this->payload( get_current_user_id() ), 200 ) );
	}

	/**
	 * `PUT /app/me`.
	 *
	 * Partial: only the keys actually present in the request body are touched,
	 * so a client editing a phone number cannot wipe the address book by
	 * omitting it.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_me( $request ) {
		$user_id = get_current_user_id();
		$body    = $request->get_json_params();
		$body    = is_array( $body ) ? $body : $request->get_body_params();
		$body    = is_array( $body ) ? $body : [];

		$fields = [];

		foreach ( [ 'first_name', 'last_name' ] as $field ) {
			if ( array_key_exists( $field, $body ) ) {
				$fields[ $field ] = (string) $request[ $field ];
			}
		}

		if ( $fields ) {
			// Snapshotted as plain strings, not as the WP_User: that object's
			// magic getters read through the user meta cache, which
			// `wp_update_user()` refreshes, so holding the object would hand
			// back the *new* values a moment later.
			$was = $this->name_snapshot( $user_id );

			$fields['ID'] = $user_id;
			$updated      = wp_update_user( $fields );

			if ( is_wp_error( $updated ) ) {
				return $this->with_status( $updated );
			}

			// `wp_update_user` leaves display_name alone, so an app that has
			// just changed the customer's name would keep showing the old one.
			$this->sync_display_name( $user_id, $was );
		}

		if ( array_key_exists( 'phone', $body ) ) {
			$phone = trim( (string) $request['phone'] );

			if ( '' === $phone ) {
				delete_user_meta( $user_id, 'billing_phone' );
			} else {
				update_user_meta( $user_id, 'billing_phone', $phone );
			}
		}

		if ( array_key_exists( 'addresses', $body ) ) {
			if ( ! is_array( $body['addresses'] ) ) {
				return new WP_Error(
					'fmp_app_invalid_addresses',
					__( 'Addresses must be a list.', 'food-menu-pro' ),
					[ 'status' => 400 ]
				);
			}

			$saved = AppAddresses::replace( $user_id, $body['addresses'] );

			if ( is_wp_error( $saved ) ) {
				return $saved;
			}
		}

		/**
		 * Fires after the app updates a customer's profile.
		 *
		 * @param int   $user_id User ID.
		 * @param array $body    The submitted body.
		 */
		do_action( 'fmp_app_profile_updated', $user_id, $body );

		return AppApiFns::no_store( new WP_REST_Response( $this->payload( $user_id ), 200 ) );
	}

	/**
	 * Keep `display_name` in step with the customer's first and last name.
	 *
	 * Only when it still looks generated. A customer who deliberately set
	 * something else keeps it — but a name WooCommerce itself derived from the
	 * old first and last name counts as generated, or renaming yourself would
	 * leave the old name on screen forever.
	 *
	 * @param int   $user_id User ID.
	 * @param array $was     Name values from before the update.
	 * @return void
	 */
	private function sync_display_name( $user_id, array $was ) {
		$user = get_userdata( $user_id );

		if ( ! $user || ! $was ) {
			return;
		}

		$full = trim( $user->first_name . ' ' . $user->last_name );

		if ( '' === $full || $full === $user->display_name ) {
			return;
		}

		$generated = [
			'',
			$was['user_login'],
			$was['user_email'],
			$was['nickname'],
			trim( $was['first_name'] . ' ' . $was['last_name'] ),
			trim( $was['last_name'] . ' ' . $was['first_name'] ),
		];

		if ( ! in_array( $user->display_name, $generated, true ) ) {
			return;
		}

		wp_update_user(
			[
				'ID'           => $user_id,
				'display_name' => $full,
			]
		);
	}

	/**
	 * Snapshot the name-ish fields as scalars, before an update.
	 *
	 * @param int $user_id User ID.
	 * @return array
	 */
	private function name_snapshot( $user_id ) {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return [];
		}

		return [
			'user_login'   => (string) $user->user_login,
			'user_email'   => (string) $user->user_email,
			'nickname'     => (string) $user->nickname,
			'first_name'   => (string) $user->first_name,
			'last_name'    => (string) $user->last_name,
			'display_name' => (string) $user->display_name,
		];
	}

	/**
	 * The full `/me` payload.
	 *
	 * @param int $user_id User ID.
	 * @return array
	 */
	private function payload( $user_id ) {
		$user = get_userdata( $user_id );

		return [
			'user'      => AppApiFns::user_payload( $user ),
			'addresses' => AppAddresses::all( $user_id ),
		];
	}

	/**
	 * Give a status-less WP_Error one, so it is not rendered as a 500.
	 *
	 * @param WP_Error $error Error.
	 * @return WP_Error
	 */
	private function with_status( WP_Error $error ) {
		$data = $error->get_error_data();

		if ( is_array( $data ) && isset( $data['status'] ) ) {
			return $error;
		}

		$error->add_data( [ 'status' => 400 ], $error->get_error_code() );

		return $error;
	}
}
