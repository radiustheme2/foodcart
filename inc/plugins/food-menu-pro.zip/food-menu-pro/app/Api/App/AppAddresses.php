<?php
/**
 * The customer's saved address book.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use WC_Customer;
use WP_Error;

/**
 * Labelled, multiple saved addresses per customer.
 *
 * WooCommerce stores exactly one billing and one shipping address per customer,
 * so an address book ("Home", "Work") is not something it models. The book
 * therefore lives in its own user meta, and **the default entry is mirrored
 * into WooCommerce's billing and shipping fields** on every write. Without that
 * mirror the customer's My Account page, their order emails and the admin order
 * screen would all disagree with what the app shows.
 *
 * The mirror is one-way by design: this book is the source of truth for the
 * app, WooCommerce's fields are a derived copy, and nothing reads them back.
 *
 * One field is **not** mirrored: `billing_phone`. That meta is where the
 * account's contact phone lives, so copying an address phone onto it would mean
 * saving an address silently rewrote the customer's contact number. See
 * `mirror_default_to_woo()`.
 */
class AppAddresses {

	/**
	 * User meta key for the address book.
	 *
	 * @var string
	 */
	const META_KEY = '_fmp_app_addresses';

	/**
	 * User meta key holding the default address ID.
	 *
	 * Kept separate from the entries so "exactly one default" is structurally
	 * true rather than something every write has to re-assert.
	 *
	 * @var string
	 */
	const DEFAULT_META_KEY = '_fmp_app_default_address';

	/**
	 * Most addresses one customer may keep.
	 *
	 * @var int
	 */
	const MAX_ADDRESSES = 20;

	/**
	 * The fields an address carries.
	 *
	 * Deliberately WooCommerce's own field names, minus the prefix, so the
	 * mirror is a straight copy and Phase 6's checkout payload needs no
	 * translation layer.
	 *
	 * @var string[]
	 */
	const FIELDS = [
		'first_name',
		'last_name',
		'company',
		'address_1',
		'address_2',
		'city',
		'state',
		'postcode',
		'country',
		'phone',
	];

	/**
	 * Read a customer's address book.
	 *
	 * @param int $user_id User ID.
	 * @return array List of addresses, default first.
	 */
	public static function all( $user_id ) {
		$stored = get_user_meta( (int) $user_id, self::META_KEY, true );

		if ( ! is_array( $stored ) ) {
			return [];
		}

		$default = self::default_id( $user_id );
		$out     = [];

		foreach ( $stored as $id => $address ) {
			if ( ! is_array( $address ) ) {
				continue;
			}

			$out[] = self::shape( (string) $id, $address, (string) $id === $default );
		}

		// Default first, so a client that only needs one can take the head.
		usort(
			$out,
			function ( $a, $b ) {
				return ( $b['is_default'] ? 1 : 0 ) <=> ( $a['is_default'] ? 1 : 0 );
			}
		);

		return $out;
	}

	/**
	 * The default address, or null when the book is empty.
	 *
	 * @param int $user_id User ID.
	 * @return array|null
	 */
	public static function get_default( $user_id ) {
		$all = self::all( $user_id );

		return $all ? $all[0] : null;
	}

	/**
	 * The stored default address ID.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	private static function default_id( $user_id ) {
		return (string) get_user_meta( (int) $user_id, self::DEFAULT_META_KEY, true );
	}

	/**
	 * Shape one address for output.
	 *
	 * @param string $id         Address ID.
	 * @param array  $address    Stored address.
	 * @param bool   $is_default Whether this is the default.
	 * @return array
	 */
	private static function shape( $id, array $address, $is_default ) {
		$out = [
			'id'         => $id,
			'label'      => (string) ( $address['label'] ?? '' ),
			'is_default' => (bool) $is_default,
		];

		foreach ( self::FIELDS as $field ) {
			$out[ $field ] = (string) ( $address[ $field ] ?? '' );
		}

		// The design's address card shows `address_1` as its title and a
		// smaller locality line beneath. That second line needs the state's
		// display name rather than its code ("Delaware", not "DE"), which only
		// the server can resolve, so it is built here.
		$out['locality'] = self::locality( $out );

		return $out;
	}

	/**
	 * "Celina, Delaware 10299" — the card's second line.
	 *
	 * @param array $address Shaped address.
	 * @return string
	 */
	private static function locality( array $address ) {
		$region = $address['state'];

		if ( '' !== $region ) {
			$states = self::states( $address['country'] );
			$region = isset( $states[ $region ] ) ? wp_strip_all_tags( $states[ $region ] ) : $region;
		}

		$left  = implode( ', ', array_filter( [ $address['city'], $region ] ) );
		$parts = array_filter( [ $left, $address['postcode'] ] );

		return implode( ' ', $parts );
	}

	/**
	 * Replace the whole address book.
	 *
	 * Whole-book replace rather than per-address routes: the plan puts this on
	 * `PUT /app/me`, and a mobile client always holds the full list anyway.
	 *
	 * @param int   $user_id   User ID.
	 * @param array $addresses Submitted addresses.
	 * @return array|WP_Error The saved book, or the first validation error.
	 */
	public static function replace( $user_id, array $addresses ) {
		$user_id = (int) $user_id;

		if ( count( $addresses ) > self::MAX_ADDRESSES ) {
			return new WP_Error(
				'fmp_app_too_many_addresses',
				sprintf(
					/* translators: %d: maximum number of saved addresses. */
					__( 'You can save at most %d addresses.', 'food-menu-pro' ),
					self::MAX_ADDRESSES
				),
				[ 'status' => 400 ]
			);
		}

		$existing = get_user_meta( $user_id, self::META_KEY, true );
		$existing = is_array( $existing ) ? $existing : [];
		$book     = [];
		$default  = '';

		foreach ( $addresses as $index => $submitted ) {
			if ( ! is_array( $submitted ) ) {
				return self::field_error( 'address', $index, __( 'Each address must be an object.', 'food-menu-pro' ) );
			}

			$clean = self::validate( $submitted, $index );

			if ( is_wp_error( $clean ) ) {
				return $clean;
			}

			// Keep an existing ID so a client editing an address does not
			// orphan whatever else referenced it.
			$id = isset( $submitted['id'] ) ? (string) $submitted['id'] : '';

			if ( '' === $id || ! isset( $existing[ $id ] ) ) {
				$id = self::new_id( $book, $existing );
			}

			$book[ $id ] = $clean;

			if ( ! empty( $submitted['is_default'] ) && '' === $default ) {
				$default = $id;
			}
		}

		// Exactly one default whenever the book is not empty.
		if ( '' === $default && $book ) {
			$default = (string) array_key_first( $book );
		}

		if ( $book ) {
			update_user_meta( $user_id, self::META_KEY, $book );
			update_user_meta( $user_id, self::DEFAULT_META_KEY, $default );
		} else {
			delete_user_meta( $user_id, self::META_KEY );
			delete_user_meta( $user_id, self::DEFAULT_META_KEY );
		}

		self::mirror_default_to_woo( $user_id );

		return self::all( $user_id );
	}

	/**
	 * Mint an address ID that is not already taken.
	 *
	 * @param array $book     Book being built.
	 * @param array $existing Previously stored book.
	 * @return string
	 */
	private static function new_id( array $book, array $existing ) {
		do {
			$id = bin2hex( random_bytes( 6 ) );
		} while ( isset( $book[ $id ] ) || isset( $existing[ $id ] ) );

		return $id;
	}

	/**
	 * Validate and sanitise one submitted address.
	 *
	 * Requirements come from `WC()->countries->get_address_fields()`, so they
	 * follow the country: the US needs a state and a postcode, the UAE needs
	 * neither, the UK needs a postcode but no state. Hard-coding them would be
	 * wrong in most of the world.
	 *
	 * @param array $submitted Raw address.
	 * @param int   $index     Position in the submitted list, for error paths.
	 * @return array|WP_Error
	 */
	private static function validate( array $submitted, $index ) {
		$countries = self::countries();

		if ( ! $countries ) {
			return new WP_Error(
				'fmp_app_woocommerce_missing',
				__( 'Addresses are unavailable because WooCommerce is not active.', 'food-menu-pro' ),
				[ 'status' => 503 ]
			);
		}

		$clean          = [];
		$clean['label'] = mb_substr( wc_clean( (string) ( $submitted['label'] ?? '' ) ), 0, 40 );

		foreach ( self::FIELDS as $field ) {
			$clean[ $field ] = wc_clean( (string) ( $submitted[ $field ] ?? '' ) );
		}

		// Country first: everything else is validated relative to it.
		$clean['country'] = strtoupper( $clean['country'] );

		if ( '' === $clean['country'] ) {
			$clean['country'] = $countries->get_base_country();
		}

		$allowed = $countries->get_allowed_countries();
		$allowed = $allowed ? $allowed : $countries->get_countries();

		if ( ! isset( $allowed[ $clean['country'] ] ) ) {
			return self::field_error( 'country', $index, __( 'We do not deliver to that country.', 'food-menu-pro' ) );
		}

		$states = self::states( $clean['country'] );

		if ( $states && '' !== $clean['state'] ) {
			$resolved = self::resolve_state( $clean['state'], $states );

			if ( null === $resolved ) {
				return self::field_error( 'state', $index, __( 'That state or region is not valid for the selected country.', 'food-menu-pro' ) );
			}

			$clean['state'] = $resolved;
		} elseif ( ! $states ) {
			// The country has no state list, so a free-text value would never
			// match anything downstream.
			$clean['state'] = '';
		}

		if ( '' !== $clean['postcode'] ) {
			$clean['postcode'] = wc_format_postcode( $clean['postcode'], $clean['country'] );

			if ( class_exists( 'WC_Validation' ) && ! \WC_Validation::is_postcode( $clean['postcode'], $clean['country'] ) ) {
				return self::field_error( 'postcode', $index, __( 'That postcode is not valid for the selected country.', 'food-menu-pro' ) );
			}
		}

		$required = self::required_fields( $clean['country'] );

		foreach ( $required as $field ) {
			if ( '' === $clean[ $field ] ) {
				return self::field_error(
					$field,
					$index,
					sprintf(
						/* translators: %s: address field label. */
						__( '%s is required for the selected country.', 'food-menu-pro' ),
						self::field_label( $field, $clean['country'] )
					)
				);
			}
		}

		return $clean;
	}

	/**
	 * Which of our fields WooCommerce considers required for a country.
	 *
	 * @param string $country Country code.
	 * @return string[]
	 */
	private static function required_fields( $country ) {
		$countries = self::countries();
		$fields    = $countries ? $countries->get_address_fields( $country, '' ) : [];
		$required  = [];

		foreach ( self::FIELDS as $field ) {
			// `email` is in WooCommerce's billing fields but belongs to the
			// account, not to an address, so it is not one of ours.
			if ( ! empty( $fields[ $field ]['required'] ) ) {
				$required[] = $field;
			}
		}

		return $required;
	}

	/**
	 * A human label for a field, in the country's own wording where there is
	 * one — WooCommerce calls a postcode a ZIP in the US.
	 *
	 * @param string $field   Field key.
	 * @param string $country Country code.
	 * @return string
	 */
	private static function field_label( $field, $country ) {
		$countries = self::countries();
		$fields    = $countries ? $countries->get_address_fields( $country, '' ) : [];

		return (string) ( $fields[ $field ]['label'] ?? $field );
	}

	/**
	 * Accept a state code or its full name, and return the code.
	 *
	 * @param string $value  Submitted state.
	 * @param array  $states Valid states for the country.
	 * @return string|null
	 */
	private static function resolve_state( $value, array $states ) {
		if ( isset( $states[ strtoupper( $value ) ] ) ) {
			return strtoupper( $value );
		}

		foreach ( $states as $code => $name ) {
			if ( 0 === strcasecmp( $name, $value ) ) {
				return (string) $code;
			}
		}

		return null;
	}

	/**
	 * States for a country, normalised to an array.
	 *
	 * `get_states()` returns `false` for countries that have no state list, not
	 * an empty array.
	 *
	 * @param string $country Country code.
	 * @return array
	 */
	private static function states( $country ) {
		$countries = self::countries();
		$states    = $countries ? $countries->get_states( $country ) : [];

		return is_array( $states ) ? $states : [];
	}

	/**
	 * WooCommerce's countries object, or null when WooCommerce is inactive.
	 *
	 * @return \WC_Countries|null
	 */
	private static function countries() {
		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->countries ) {
			return null;
		}

		return WC()->countries;
	}

	/**
	 * Build a validation error carrying the offending field and position.
	 *
	 * @param string $field   Field key.
	 * @param int    $index   Position in the submitted list.
	 * @param string $message Message.
	 * @return WP_Error
	 */
	private static function field_error( $field, $index, $message ) {
		return new WP_Error(
			'fmp_app_invalid_address',
			$message,
			[
				'status' => 400,
				'field'  => $field,
				'index'  => (int) $index,
			]
		);
	}

	/**
	 * Copy the default address into WooCommerce's billing and shipping fields.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	public static function mirror_default_to_woo( $user_id ) {
		if ( ! class_exists( 'WC_Customer' ) ) {
			return;
		}

		$default = self::get_default( $user_id );

		if ( ! $default ) {
			return;
		}

		try {
			$customer = new WC_Customer( (int) $user_id );
		} catch ( \Exception $e ) {
			return;
		}

		foreach ( self::FIELDS as $field ) {
			// `phone` is deliberately excluded here. `billing_phone` is where
			// the *account's* contact phone lives — it is what `/me` reads and
			// what the design's checkout "Contact details" block edits — so
			// mirroring an address phone onto it would mean saving an address
			// silently changed the customer's contact number. Postal fields
			// come from the address; the phone does not.
			if ( 'phone' === $field ) {
				continue;
			}

			$value = $default[ $field ];

			foreach ( [ "set_billing_{$field}", "set_shipping_{$field}" ] as $setter ) {
				// Shipping has no email, and older WooCommerce has no shipping
				// phone, so every setter is checked rather than assumed.
				if ( method_exists( $customer, $setter ) ) {
					$customer->{$setter}( $value );
				}
			}
		}

		// Shipping phone is genuinely per-delivery — a doorman, a site
		// contact — so the address owns it, falling back to the account's.
		if ( method_exists( $customer, 'set_shipping_phone' ) ) {
			$shipping_phone = '' !== $default['phone']
				? $default['phone']
				: (string) get_user_meta( (int) $user_id, 'billing_phone', true );

			$customer->set_shipping_phone( $shipping_phone );
		}

		// Billing email is the account's, not the address's.
		$customer->set_billing_email( $customer->get_email() );

		$customer->save();
	}
}
