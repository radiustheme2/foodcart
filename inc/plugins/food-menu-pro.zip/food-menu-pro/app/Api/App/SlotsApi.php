<?php
/**
 * Selectable pickup and delivery slots for one date, for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Controllers\TimedProducts\TimedProducts;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;

/**
 * `GET fmp/v1/app/slots` — the times a customer may actually choose.
 *
 * **Why the server has to do this.** The website never produces a slot list:
 * `pickup-delivery.js` hands the whole weekly schedule to a jQuery timepicker,
 * which builds the times in the browser, and then one AJAX call
 * (`PickupDelivery::check_slot_availability()`) judges the single slot the
 * customer landed on. A mobile client cannot reuse either half — it would have
 * to reimplement the picker's arithmetic and then make one request per slot to
 * find out which are full. So this route generates the list and judges every
 * entry in it, in one answer.
 *
 * `/app/order-types` answers the week — which types exist, which days are open.
 * This answers one day of it, and every reading of the schedule they share is
 * in `AppSchedules`.
 *
 * **`value` is the string to submit, and the app must not build its own.**
 * The checkout stores `fmp_{type}_date` and `fmp_{type}_time` as the *site's
 * own display formats* — `date_format` and `time_format` — because that is
 * what the web checkout's inputs submit, and the Store API extension saves
 * whatever it is given. Slot counting then matches those strings. An app that
 * sent ISO times would place orders that no slot limit counted and that the
 * admin order column rendered differently from every web order.
 *
 * **Public**, like `/app/order-types`: opening hours are the store's, not the
 * customer's, and the design puts this on the checkout before sign-in.
 */
class SlotsApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/slots',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_slots' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'type'   => [
						'required'    => true,
						'type'        => 'string',
						'enum'        => AppSchedules::TYPES,
						'description' => 'Order type the slots are for.',
					],
					'date'   => [
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'Y-m-d. Omit for the earliest date this type can be fulfilled on.',
					],
					'branch' => [
						'required'          => false,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
						'description'       => 'Location term id. Omit for the store-wide schedule.',
					],
					'items'  => [
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'Cart contents as `product_id:qty` pairs, comma separated. Needed for per-product slot limits and timed dishes.',
					],
				],
			]
		);
	}

	/**
	 * `GET /app/slots`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_slots( $request ) {
		$branch = AppSchedules::resolve_branch( $request['branch'] ?? 0 );

		if ( is_wp_error( $branch ) ) {
			return $branch;
		}

		$type     = (string) $request['type'];
		$settings = (array) FnsPro::get_settings_option();
		$location = AppSchedules::location_data( $branch );
		$now      = current_datetime();
		$lead     = AppSchedules::lead_days( $type, $settings );
		$max_days = absint( $settings['fmp_preorder_max_days'] ?? 0 );
		$first    = FnsPro::preparing_date( $lead );
		$last     = $max_days > 0 ? FnsPro::preparing_date( $lead + $max_days ) : null;

		$date = $this->requested_date( $request['date'] ?? '', $first );

		if ( is_wp_error( $date ) ) {
			return $date;
		}

		$cart     = $this->requested_items( $request['items'] ?? '' );
		$schedule = AppSchedules::schedule_for( $type, $location );
		$midnight = $this->midnight( $date );
		$day      = (int) wp_date( 'w', $midnight );

		$payload = [
			'branch'              => $branch,
			'timezone'            => wp_timezone_string(),
			'now'                 => $now->format( 'c' ),
			'type'                => $type,
			'label'               => AppSchedules::label( $type ),
			'enabled'             => AppSchedules::is_enabled( $type, $settings ),
			'time_required'       => AppSchedules::is_time_required( $type, $settings ),
			'date'                => $date,
			// What to send back as `fmp_{type}_date`. See the class note.
			'date_value'          => wp_date( get_option( 'date_format' ), $midnight ),
			'day'                 => $day,
			'first_date'          => $first,
			'last_date'           => $last,
			'interval'            => AppSchedules::interval( $type, $settings, $location ),
			'slot_limits_enabled' => ! empty( $settings['fmp_enable_order_slot_limits'] ),
			'closed_reason'       => null,
			'message'             => null,
			'slots'               => [],
		];

		$closed = $this->closed_reason( $type, $date, $day, $first, $last, $schedule, $settings );

		if ( null !== $closed ) {
			$payload['closed_reason'] = $closed;
			$payload['message']       = $this->closed_message( $closed );

			return new WP_REST_Response( $payload, 200 );
		}

		// A store that asks for no time wants none chosen: the order is simply
		// as soon as possible. That is one choice, not none, so it comes back
		// as the single ASAP entry rather than an empty list — the app still
		// has a row to draw, and `time_required: false` is what tells it to
		// drop the date picker. No slot limit applies because there are no
		// slots to limit, which is also true of the web checkout in this mode.
		if ( ! $payload['time_required'] ) {
			$payload['slots'] = [ $this->asap_entry( $type, $settings ) ];

			return new WP_REST_Response( $payload, 200 );
		}

		$payload['slots'] = $this->build_slots( $type, $date, $day, $schedule, $settings, $location, $branch, $cart );

		if ( empty( $payload['slots'] ) ) {
			$payload['closed_reason'] = 'no_times_left';
			$payload['message']       = $this->closed_message( 'no_times_left' );
		}

		return new WP_REST_Response( $payload, 200 );
	}

	/**
	 * The date being asked about.
	 *
	 * @param string $raw   Requested date.
	 * @param string $first Earliest date this type can be fulfilled on.
	 * @return string|WP_Error
	 */
	private function requested_date( $raw, $first ) {
		$raw = trim( (string) $raw );

		if ( '' === $raw ) {
			return $first;
		}

		$parsed = \DateTime::createFromFormat( 'Y-m-d', $raw );

		// A malformed date is the one thing here that is a client bug rather
		// than a closed shop, so it is the one thing refused.
		if ( ! $parsed || $parsed->format( 'Y-m-d' ) !== $raw ) {
			return new WP_Error(
				'fmp_app_invalid_date',
				__( 'The date must be in Y-m-d form.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		return $raw;
	}

	/**
	 * Cart contents, as `product_id => qty`.
	 *
	 * Passed in rather than read from a session: this route is public and the
	 * app's cart lives behind a Store API `Cart-Token`, which only the Store
	 * API's own routes resolve. The website hands the same list to
	 * `check_slot_availability` from JavaScript for the same reason.
	 *
	 * A **variation id is resolved to its parent**, because a client cannot do
	 * it: a Store API cart item reports the variation's own id and carries no
	 * parent anywhere, while per-product order limits and timed-product rules
	 * are both set on the parent dish. Left unresolved, a cart holding a large
	 * pizza would silently miss the cap set on the pizza.
	 *
	 * @param string $raw `42:2,17:1`.
	 * @return array<int, int>
	 */
	private function requested_items( $raw ) {
		$out = [];

		foreach ( explode( ',', (string) $raw ) as $pair ) {
			if ( ! str_contains( $pair, ':' ) ) {
				continue;
			}

			list( $id, $qty ) = explode( ':', $pair, 2 );

			$id  = $this->parent_product_id( absint( $id ) );
			$qty = absint( $qty );

			if ( $id > 0 && $qty > 0 ) {
				// Summed, not overwritten: two variations of one dish are two
				// cart lines, and they share the parent's cap.
				$out[ $id ] = ( $out[ $id ] ?? 0 ) + $qty;
			}
		}

		return $out;
	}

	/**
	 * The dish a product id belongs to — itself, or its parent if it is a
	 * variation.
	 *
	 * @param int $product_id Product or variation id.
	 * @return int
	 */
	private function parent_product_id( $product_id ) {
		if ( $product_id < 1 || 'product_variation' !== get_post_type( $product_id ) ) {
			return $product_id;
		}

		$parent = wp_get_post_parent_id( $product_id );

		return $parent > 0 ? $parent : $product_id;
	}

	/**
	 * Why there are no slots at all, or null when there may be some.
	 *
	 * @param string      $type     Order type.
	 * @param string      $date     Y-m-d.
	 * @param int         $day      Day index.
	 * @param string      $first    Earliest fulfillable date.
	 * @param string|null $last     Latest, or null for no bound.
	 * @param array       $schedule Weekly schedule.
	 * @param array       $settings Store settings.
	 * @return string|null
	 */
	private function closed_reason( $type, $date, $day, $first, $last, array $schedule, array $settings ) {
		if ( ! AppSchedules::is_enabled( $type, $settings ) ) {
			return 'type_disabled';
		}

		if ( $date < $first ) {
			return 'before_first_date';
		}

		if ( null !== $last && $date > $last ) {
			return 'after_last_date';
		}

		if ( in_array( $day, AppSchedules::closed_days( $schedule ), true ) ) {
			return 'weekly_closed';
		}

		return null;
	}

	/**
	 * The website's own words for each of those.
	 *
	 * Borrowed from `pickup_delivery_data_obj()`'s `i18n` block so the app
	 * says what the web checkout says, in the store's language, rather than
	 * inventing a second set of strings to translate.
	 *
	 * @param string $reason Closed reason.
	 * @return string
	 */
	private function closed_message( $reason ) {
		switch ( $reason ) {
			case 'type_disabled':
				return __( 'This order type is not available.', 'food-menu-pro' );

			case 'before_first_date':
			case 'after_last_date':
				return __( 'We are not taking orders for that date.', 'food-menu-pro' );

			case 'weekly_closed':
				return __( 'We are closed on this day. Please choose another date.', 'food-menu-pro' );
		}

		return __( 'No times are available for this date. Please choose another date.', 'food-menu-pro' );
	}

	/**
	 * The day's slots, judged.
	 *
	 * @param string     $type     Order type.
	 * @param string     $date     Y-m-d.
	 * @param int        $day      Day index.
	 * @param array      $schedule Weekly schedule.
	 * @param array      $settings Store settings.
	 * @param array|null $location Per-location data.
	 * @param int        $branch   Location term id.
	 * @param array      $cart     product_id => qty.
	 * @return array[]
	 */
	private function build_slots( $type, $date, $day, array $schedule, array $settings, $location, $branch, array $cart ) {
		$interval = AppSchedules::interval( $type, $settings, $location );
		$windows  = AppSchedules::windows( $schedule, $day );
		$midnight = $this->midnight( $date );
		$is_today = $date === wp_date( 'Y-m-d' );
		$now_min  = $is_today ? ( (int) wp_date( 'G' ) * 60 + (int) wp_date( 'i' ) ) : -1;

		// **An open day with no windows is not closed.** It is a day the store
		// set no hours for, which the website treats as no restriction — its
		// timepicker falls back to `00:00`–`23:59` for exactly this case. The
		// dev store's default state, so getting it wrong is not hypothetical.
		if ( empty( $windows ) ) {
			$windows = [
				[
					'start'     => '00:00',
					'end'       => '23:59',
					'max_order' => 0,
				],
			];
		}

		$limits_on = ! empty( $settings['fmp_enable_order_slot_limits'] );
		$type_cap  = AppSchedules::slot_cap( $type, $settings, $location );
		$counts    = $limits_on ? $this->slot_counts( $type, $date, $branch, $settings ) : [];
		$caps      = $this->product_caps( array_keys( $cart ), $branch, $settings );
		$sold      = $caps ? $this->product_sales( $date, $branch, $settings, array_keys( $caps ) ) : [];

		$slots = [];

		foreach ( $windows as $window ) {
			$start = AppSchedules::time_to_minutes( $window['start'] );
			$end   = AppSchedules::time_to_minutes( $window['end'] );

			if ( null === $start || null === $end || $end <= $start ) {
				continue;
			}

			for ( $minute = $start; $minute < $end; $minute += $interval ) {
				// Past times are dropped rather than returned as unavailable.
				// A chip the customer can never pick is noise; a full one is
				// information, which is why only this reason is silent.
				if ( $minute <= $now_min ) {
					continue;
				}

				$slots[] = $this->shape_slot(
					$type,
					$midnight,
					$minute,
					min( $minute + $interval, $end ),
					$window['max_order'] > 0 ? $window['max_order'] : $type_cap,
					$limits_on,
					$counts,
					$cart,
					$caps,
					$sold,
					$branch
				);
			}
		}

		usort(
			$slots,
			static function ( $a, $b ) {
				return $a['start_minutes'] <=> $b['start_minutes'];
			}
		);

		$asap = $this->asap_slot( $type, $settings, $slots, $is_today, $cart, $caps, $sold, $branch );

		if ( null !== $asap ) {
			array_unshift( $slots, $asap );
		}

		return $slots;
	}

	/**
	 * One slot.
	 *
	 * @param string $type      Order type.
	 * @param int    $midnight  Timestamp of the date's midnight.
	 * @param int    $minute    Start, minutes since midnight.
	 * @param int    $end       End, minutes since midnight.
	 * @param int    $cap       Orders allowed in this slot, 0 for no cap.
	 * @param bool   $limits_on Whether the store counts slot orders at all.
	 * @param array  $counts    Orders already taken, by start minute.
	 * @param array  $cart      product_id => qty.
	 * @param array  $caps      product_id => per-slot cap.
	 * @param array  $sold      Start minute => product_id => qty sold.
	 * @param int    $branch    Location term id.
	 * @return array
	 */
	private function shape_slot( $type, $midnight, $minute, $end, $cap, $limits_on, array $counts, array $cart, array $caps, array $sold, $branch ) {
		$moment = $midnight + $minute * MINUTE_IN_SECONDS;
		$time   = get_option( 'time_format' );

		$slot = [
			'asap'          => false,
			// Pickup is a moment, delivery a window — the design shows "12:45"
			// for one and "13:00–13:15" for the other, and the stored time is
			// the start either way.
			'label'         => 'delivery' === $type
				? sprintf(
					/* translators: 1: window start time, 2: window end time */
					_x( '%1$s – %2$s', 'delivery time window', 'food-menu-pro' ),
					wp_date( $time, $moment ),
					wp_date( $time, $midnight + $end * MINUTE_IN_SECONDS )
				)
				: wp_date( $time, $moment ),
			'value'         => wp_date( $time, $moment ),
			'start'         => sprintf( '%02d:%02d', intdiv( $minute, 60 ), $minute % 60 ),
			'end'           => sprintf( '%02d:%02d', intdiv( $end, 60 ), $end % 60 ),
			'start_minutes' => $minute,
			'available'     => true,
			'remaining'     => null,
			'reason'        => null,
			'message'       => null,
			'products'      => [],
		];

		if ( $limits_on && $cap > 0 ) {
			$slot['remaining'] = max( 0, $cap - ( $counts[ $minute ] ?? 0 ) );

			if ( 0 === $slot['remaining'] ) {
				$slot['available'] = false;
				$slot['reason']    = 'full';
				$slot['message']   = __( 'This time slot is full.', 'food-menu-pro' );

				return $slot;
			}
		}

		$blocked = $this->blocked_products( $moment, $cart, $caps, $sold[ $minute ] ?? [], $branch );

		if ( ! empty( $blocked ) ) {
			$slot['available'] = false;
			$slot['reason']    = $blocked[0]['reason'];
			$slot['message']   = $blocked[0]['message'];
			$slot['products']  = $blocked;
		}

		return $slot;
	}

	/**
	 * Which cart items stand in the way of this slot.
	 *
	 * Two separate reasons, and they are not the same thing: a **timed** dish
	 * is one the kitchen does not serve at that hour at all, while a dish with
	 * a per-slot order limit has simply been sold out of that slot.
	 *
	 * @param int   $moment The slot's own moment.
	 * @param array $cart   product_id => qty.
	 * @param array $caps   product_id => per-slot cap.
	 * @param array $sold   product_id => qty already sold in this slot.
	 * @param int   $branch Location term id.
	 * @return array[]
	 */
	private function blocked_products( $moment, array $cart, array $caps, array $sold, $branch ) {
		if ( empty( $cart ) ) {
			return [];
		}

		$out   = [];
		$timed = TimedProducts::get_instance()->unavailable_at( array_keys( $cart ), $moment, $branch );

		foreach ( $cart as $id => $qty ) {
			$name = $this->product_name( $id );

			if ( in_array( (int) $id, $timed, true ) ) {
				$out[] = [
					'id'        => (int) $id,
					'name'      => $name,
					'reason'    => 'not_served',
					'remaining' => 0,
					'message'   => sprintf(
						/* translators: %s: product name */
						__( '%s is not served at this time.', 'food-menu-pro' ),
						$name
					),
				];

				continue;
			}

			if ( empty( $caps[ $id ] ) ) {
				continue;
			}

			$left = max( 0, (int) $caps[ $id ] - ( $sold[ $id ] ?? 0 ) );

			if ( $left >= $qty ) {
				continue;
			}

			$out[] = [
				'id'        => (int) $id,
				'name'      => $name,
				'reason'    => 'sold_out',
				'remaining' => $left,
				'message'   => 0 === $left
					? sprintf(
						/* translators: %s: product name */
						__( '%s is sold out for this slot.', 'food-menu-pro' ),
						$name
					)
					: sprintf(
						/* translators: 1: product name, 2: units still available */
						__( 'Only %2$d of %1$s left for this slot.', 'food-menu-pro' ),
						$name,
						$left
					),
			];
		}

		return $out;
	}

	/**
	 * The "as soon as possible" entry, or null when it cannot apply.
	 *
	 * **Its `value` is deliberately empty.** The plugin has no "ASAP" time:
	 * the website expresses it by switching `enable_{type}_time` off, which
	 * submits no date or time at all. So an ASAP order carries no
	 * `fmp_{type}_time`, which also means **no slot limit can count it** —
	 * the counting query matches a time string, and there is none.
	 *
	 * Offered only for today, and only while the **next real slot** is still
	 * open: a kitchen that has stopped taking orders for the day cannot start
	 * one now either, and because no limit can count an ASAP order, offering
	 * it beside a full slot would be a way around the cap rather than a
	 * convenience. It is withheld, not returned unavailable — there is no
	 * time for the customer to read.
	 *
	 * @param string $type     Order type.
	 * @param array  $settings Store settings.
	 * @param array  $slots    The day's timed slots, earliest first.
	 * @param bool   $is_today Whether the date is today.
	 * @param array  $cart     product_id => qty.
	 * @param array  $caps     product_id => per-slot cap.
	 * @param array  $sold     Start minute => product_id => qty sold.
	 * @param int    $branch   Location term id.
	 * @return array|null
	 */
	private function asap_slot( $type, array $settings, array $slots, $is_today, array $cart, array $caps, array $sold, $branch ) {
		if ( ! $is_today || empty( $slots ) ) {
			return null;
		}

		$next = $slots[0];

		if ( empty( $next['available'] ) ) {
			return null;
		}

		// Judged at **now**, not at the next slot: "as soon as possible" is a
		// dish going on the stove now, so a timed dish that stops being served
		// in two minutes stops ASAP being offerable now.
		if ( ! empty( $this->blocked_products( time(), $cart, $caps, $sold[ $next['start_minutes'] ] ?? [], $branch ) ) ) {
			return null;
		}

		return $this->asap_entry( $type, $settings );
	}

	/**
	 * The ASAP entry itself.
	 *
	 * @param string $type     Order type.
	 * @param array  $settings Store settings.
	 * @return array
	 */
	private function asap_entry( $type, array $settings ) {
		return [
			'asap'          => true,
			'label'         => $this->asap_label( $type, $settings ),
			'value'         => '',
			'start'         => null,
			'end'           => null,
			'start_minutes' => -1,
			'available'     => true,
			'remaining'     => null,
			'reason'        => null,
			'message'       => null,
			'products'      => [],
		];
	}

	/**
	 * "ASAP", with the store's own estimate when it has set one.
	 *
	 * Lives in {@see AppApiFns::asap_label()} because `/app/orders/{id}`
	 * reports the same estimate back on an order that took it.
	 *
	 * @param string $type     Order type.
	 * @param array  $settings Store settings.
	 * @return string
	 */
	private function asap_label( $type, array $settings ) {
		return AppApiFns::asap_label( $type, $settings );
	}

	/**
	 * Orders already taken for this type and date, by slot start minute.
	 *
	 * **One query for the day**, not one per slot: a twelve-hour day at a
	 * quarter-hour interval is forty-eight slots, and
	 * `check_slot_availability` costs a `wc_get_orders` each.
	 *
	 * The tally is keyed on **minutes since midnight**, not on the stored
	 * string. The admin schedule screen writes 24-hour times while the
	 * checkout submits the site's `time_format`, so the same slot can be
	 * stored as `13:00` on one order and `1:00 pm` on the next; comparing
	 * strings would count them as two different slots.
	 *
	 * @param string $type     Order type.
	 * @param string $date     Y-m-d.
	 * @param int    $branch   Location term id.
	 * @param array  $settings Store settings.
	 * @return array<int, int>
	 */
	private function slot_counts( $type, $date, $branch, array $settings ) {
		$meta = $this->date_meta_query( $type, $date, $branch, $settings );

		$meta[] = [
			'key'   => 'fmp_order_time_type',
			'value' => $type,
		];

		$counts = [];

		foreach ( $this->find_orders( $meta, $settings ) as $order ) {
			$minute = AppSchedules::time_to_minutes( $order->get_meta( "fmp_{$type}_time" ) );

			if ( null === $minute ) {
				continue;
			}

			$counts[ $minute ] = ( $counts[ $minute ] ?? 0 ) + 1;
		}

		return $counts;
	}

	/**
	 * Per-product units sold on this date, by slot start minute.
	 *
	 * Every order type is counted, matching
	 * `PickupDelivery::get_combined_slot_order_ids()`: a dish consumed by a
	 * dine-in order is no longer available to pickup or delivery in the same
	 * slot.
	 *
	 * @param string $date        Y-m-d.
	 * @param int    $branch      Location term id.
	 * @param array  $settings    Store settings.
	 * @param int[]  $product_ids Products with a per-slot cap.
	 * @return array<int, array<int, int>>
	 */
	private function product_sales( $date, $branch, array $settings, array $product_ids ) {
		$by_minute = [];

		foreach ( [ 'pickup', 'delivery', 'dinein' ] as $type ) {
			$meta = $this->date_meta_query( $type, $date, $branch, $settings );

			$meta[] = [
				'key'   => 'fmp_order_time_type',
				'value' => $type,
			];

			foreach ( $this->find_orders( $meta, $settings ) as $order ) {
				$minute = AppSchedules::time_to_minutes( $order->get_meta( "fmp_{$type}_time" ) );

				if ( null === $minute ) {
					continue;
				}

				foreach ( $order->get_items() as $item ) {
					$product_id = (int) $item->get_product_id();

					if ( ! in_array( $product_id, $product_ids, true ) ) {
						continue;
					}

					$by_minute[ $minute ][ $product_id ] = ( $by_minute[ $minute ][ $product_id ] ?? 0 )
						+ (int) $item->get_quantity();
				}
			}
		}

		return $by_minute;
	}

	/**
	 * The meta conditions every slot query shares.
	 *
	 * The date is matched against **both** the site's display format and
	 * `Y-m-d`. The checkout submits the former, so that is what orders carry;
	 * accepting the latter as well costs nothing and stops a store whose
	 * history holds both from being undercounted.
	 *
	 * @param string $type     Order type.
	 * @param string $date     Y-m-d.
	 * @param int    $branch   Location term id.
	 * @param array  $settings Store settings.
	 * @return array[]
	 */
	private function date_meta_query( $type, $date, $branch, array $settings ) {
		$values = array_unique( [ wp_date( get_option( 'date_format' ), $this->midnight( $date ) ), $date ] );

		$meta = [
			[
				'key'     => "fmp_{$type}_date",
				'value'   => array_values( $values ),
				'compare' => 'IN',
			],
			// Orders placed while slot limits were switched off are marked
			// exempt and must not be counted, exactly as the checkout's own
			// queries do it.
			[
				'key'     => '_fmp_slot_limit_exempt',
				'compare' => 'NOT EXISTS',
			],
		];

		if ( $branch > 0 ) {
			$term = get_term( $branch, AppSchedules::BRANCH_TAXONOMY );

			if ( $term && ! is_wp_error( $term ) ) {
				$meta[] = [
					'key'   => 'fmp_location_name',
					'value' => $term->name,
				];
			}
		}

		return $meta;
	}

	/**
	 * Orders matching those conditions, in the statuses the store counts.
	 *
	 * @param array $meta     Meta conditions.
	 * @param array $settings Store settings.
	 * @return \WC_Order[]
	 */
	private function find_orders( array $meta, array $settings ) {
		$statuses = $settings['fmp_slot_counting_statuses'] ?? [];

		if ( empty( $statuses ) || ! is_array( $statuses ) ) {
			$statuses = [ 'wc-processing', 'wc-on-hold', 'wc-completed' ];
		}

		if ( ! function_exists( 'wc_get_orders' ) ) {
			return [];
		}

		return (array) wc_get_orders(
			FnsPro::order_query_args(
				[
					'status'     => $statuses,
					'limit'      => -1,
					'meta_query' => $meta, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				]
			)
		);
	}

	/**
	 * Per-slot caps for the cart's products, branch overriding the default.
	 *
	 * The same reading as `PickupDelivery::get_product_slot_cap()`, including
	 * that the per-product switch has to be on for the number to mean
	 * anything.
	 *
	 * @param int[] $product_ids Cart product ids.
	 * @param int   $branch      Location term id.
	 * @param array $settings    Store settings.
	 * @return array<int, int>
	 */
	private function product_caps( array $product_ids, $branch, array $settings ) {
		if ( empty( $product_ids ) ) {
			return [];
		}

		$caps = [];

		foreach ( $product_ids as $product_id ) {
			if ( 'on' !== get_post_meta( $product_id, '_fmp_order_limit_enable', true ) ) {
				continue;
			}

			$cap = (int) get_post_meta( $product_id, '_fmp_order_limit_per_slot', true );

			if ( $branch > 0 && ! empty( $settings['fmp_food_location_popup'] ) ) {
				$by_location = get_post_meta( $product_id, '_fmp_order_limit_by_location', true );

				if ( is_array( $by_location ) && isset( $by_location[ $branch ] ) && '' !== $by_location[ $branch ] ) {
					$cap = (int) $by_location[ $branch ];
				}
			}

			if ( $cap > 0 ) {
				$caps[ (int) $product_id ] = $cap;
			}
		}

		return $caps;
	}

	/**
	 * Midnight at the start of a date, **in the store's timezone**.
	 *
	 * Not `strtotime()`: WordPress runs PHP in UTC, so `strtotime()` on a bare
	 * date gives UTC midnight, and `wp_date()` then renders it back in the
	 * site's zone — a few hours earlier, which for anywhere west of Greenwich
	 * is the *previous day*. Every weekday index and every slot time here
	 * hangs off this, so getting it from the site's own zone is not a detail.
	 *
	 * @param string $date Y-m-d.
	 * @return int
	 */
	private function midnight( $date ) {
		return ( new \DateTimeImmutable( $date . ' 00:00:00', wp_timezone() ) )->getTimestamp();
	}

	/**
	 * A product's name, for a message the customer reads.
	 *
	 * @param int $product_id Product id.
	 * @return string
	 */
	private function product_name( $product_id ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;

		return $product ? $product->get_name() : '#' . (int) $product_id;
	}
}
