<?php
/**
 * Access and refresh tokens for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use WP_Error;

/**
 * Issues, verifies and rotates the app's bearer tokens.
 *
 * There is no JWT dependency on purpose: `vendor/` is committed, so adding one
 * would mean committing a library to ship four routes. The tokens are therefore
 * opaque random strings, stored only as keyed hashes, which also means a leaked
 * database row cannot be replayed as a token.
 *
 * Token format: `fmpa_{user_id}_{session_id}_{secret}`. The user id and session
 * id are plain so a token can be resolved with one `get_user_meta()` read
 * instead of a meta query; the secret is the only part that proves anything.
 */
class AppTokens {

	/**
	 * User meta key holding the session list.
	 *
	 * @var string
	 */
	const META_KEY = '_fmp_app_sessions';

	/**
	 * Token prefix. Namespaced so our `determine_current_user` filter can
	 * ignore every other plugin's bearer tokens without parsing them.
	 *
	 * @var string
	 */
	const PREFIX = 'fmpa';

	/**
	 * Most sessions kept per user. Oldest are evicted beyond this.
	 *
	 * @var int
	 */
	const MAX_SESSIONS = 10;

	/**
	 * Access token lifetime in seconds.
	 *
	 * @return int
	 */
	public static function access_ttl() {
		return (int) apply_filters( 'fmp_app_access_token_ttl', HOUR_IN_SECONDS );
	}

	/**
	 * Refresh token lifetime in seconds.
	 *
	 * @return int
	 */
	public static function refresh_ttl() {
		return (int) apply_filters( 'fmp_app_refresh_token_ttl', 30 * DAY_IN_SECONDS );
	}

	/**
	 * Hash a token secret for storage and comparison.
	 *
	 * HMAC-SHA256 rather than `wp_hash_password()`: the secret carries 256 bits
	 * of entropy, so there is nothing to brute force, and the access token is
	 * verified on every authenticated request — a bcrypt cost factor there
	 * would be a self-inflicted denial of service.
	 *
	 * @param string $secret Raw secret.
	 * @return string
	 */
	private static function hash( $secret ) {
		return hash_hmac( 'sha256', $secret, wp_salt( 'auth' ) );
	}

	/**
	 * Generate a random secret.
	 *
	 * @return string 64 hex characters.
	 */
	private static function secret() {
		return bin2hex( random_bytes( 32 ) );
	}

	/**
	 * Read a user's sessions, dropping any whose refresh token has expired.
	 *
	 * @param int $user_id User ID.
	 * @return array
	 */
	private static function get_sessions( $user_id ) {
		$sessions = get_user_meta( $user_id, self::META_KEY, true );

		if ( ! is_array( $sessions ) ) {
			return [];
		}

		$now = time();

		foreach ( $sessions as $sid => $session ) {
			if ( empty( $session['refresh_expires'] ) || $session['refresh_expires'] < $now ) {
				unset( $sessions[ $sid ] );
			}
		}

		return $sessions;
	}

	/**
	 * Persist a user's sessions.
	 *
	 * @param int   $user_id  User ID.
	 * @param array $sessions Sessions.
	 * @return void
	 */
	private static function save_sessions( $user_id, array $sessions ) {
		if ( empty( $sessions ) ) {
			delete_user_meta( $user_id, self::META_KEY );
			return;
		}

		// Newest last, so array_slice() from the end keeps the most recent.
		uasort(
			$sessions,
			function ( $a, $b ) {
				return ( $a['created'] ?? 0 ) <=> ( $b['created'] ?? 0 );
			}
		);

		if ( count( $sessions ) > self::MAX_SESSIONS ) {
			$sessions = array_slice( $sessions, - self::MAX_SESSIONS, null, true );
		}

		update_user_meta( $user_id, self::META_KEY, $sessions );
	}

	/**
	 * Split a token into its parts.
	 *
	 * @param string $token Raw token.
	 * @return array|null [ user_id, session_id, secret ] or null when malformed.
	 */
	private static function parse( $token ) {
		if ( ! is_string( $token ) || '' === $token ) {
			return null;
		}

		$parts = explode( '_', $token );

		if ( 4 !== count( $parts ) || self::PREFIX !== $parts[0] ) {
			return null;
		}

		$user_id = (int) $parts[1];

		if ( $user_id < 1 || ! ctype_xdigit( $parts[2] ) || ! ctype_xdigit( $parts[3] ) ) {
			return null;
		}

		return [ $user_id, $parts[2], $parts[3] ];
	}

	/**
	 * Issue a fresh access/refresh pair as a new session.
	 *
	 * @param int    $user_id User ID.
	 * @param string $device  Optional device label, for the user's own reference.
	 * @return array Token bundle.
	 */
	public static function issue( $user_id, $device = '' ) {
		$user_id  = (int) $user_id;
		$sid      = bin2hex( random_bytes( 6 ) );
		$access   = self::secret();
		$refresh  = self::secret();
		$now      = time();
		$sessions = self::get_sessions( $user_id );

		$sessions[ $sid ] = [
			'access'          => self::hash( $access ),
			'access_expires'  => $now + self::access_ttl(),
			'refresh'         => self::hash( $refresh ),
			'refresh_expires' => $now + self::refresh_ttl(),
			'created'         => $now,
			'last_used'       => $now,
			'device'          => $device,
		];

		self::save_sessions( $user_id, $sessions );

		return self::bundle( $user_id, $sid, $access, $refresh );
	}

	/**
	 * Shape a token bundle for the client.
	 *
	 * @param int    $user_id User ID.
	 * @param string $sid     Session ID.
	 * @param string $access  Raw access secret.
	 * @param string $refresh Raw refresh secret.
	 * @return array
	 */
	private static function bundle( $user_id, $sid, $access, $refresh ) {
		$join = implode( '_', [ self::PREFIX, $user_id, $sid ] );

		return [
			'token_type'         => 'Bearer',
			'access_token'       => $join . '_' . $access,
			'expires_in'         => self::access_ttl(),
			'refresh_token'      => $join . '_' . $refresh,
			'refresh_expires_in' => self::refresh_ttl(),
		];
	}

	/**
	 * Resolve an access token to a user ID.
	 *
	 * @param string $token Raw access token.
	 * @return int User ID, or 0 when the token is unusable.
	 */
	public static function user_id_from_access_token( $token ) {
		$parsed = self::parse( $token );

		if ( null === $parsed ) {
			return 0;
		}

		list( $user_id, $sid, $secret ) = $parsed;

		$sessions = self::get_sessions( $user_id );

		if ( ! isset( $sessions[ $sid ]['access'] ) ) {
			return 0;
		}

		$session = $sessions[ $sid ];

		if ( ! hash_equals( $session['access'], self::hash( $secret ) ) ) {
			return 0;
		}

		if ( empty( $session['access_expires'] ) || $session['access_expires'] < time() ) {
			return 0;
		}

		if ( ! get_userdata( $user_id ) ) {
			return 0;
		}

		self::touch( $user_id, $sid );

		return $user_id;
	}

	/**
	 * Record that a session was used, at most once every five minutes.
	 *
	 * Without the throttle this would be a user meta write on every
	 * authenticated request.
	 *
	 * @param int    $user_id User ID.
	 * @param string $sid     Session ID.
	 * @return void
	 */
	private static function touch( $user_id, $sid ) {
		$sessions = self::get_sessions( $user_id );

		if ( ! isset( $sessions[ $sid ] ) ) {
			return;
		}

		$now = time();

		if ( ( $sessions[ $sid ]['last_used'] ?? 0 ) > $now - 5 * MINUTE_IN_SECONDS ) {
			return;
		}

		$sessions[ $sid ]['last_used'] = $now;

		self::save_sessions( $user_id, $sessions );
	}

	/**
	 * Exchange a refresh token for a new pair, rotating the session.
	 *
	 * Replaying an already-rotated refresh token revokes the whole session, per
	 * OAuth 2.0 security BCP: either the token leaked, or the client raced
	 * itself. Clients must serialise refreshes and treat a 401 here as a
	 * logout.
	 *
	 * @param string $token Raw refresh token.
	 * @return array|WP_Error Token bundle, or an error.
	 */
	public static function rotate( $token ) {
		$parsed = self::parse( $token );

		if ( null === $parsed ) {
			return self::invalid_refresh();
		}

		list( $user_id, $sid, $secret ) = $parsed;

		$sessions = self::get_sessions( $user_id );

		if ( ! isset( $sessions[ $sid ] ) ) {
			return self::invalid_refresh();
		}

		$session = $sessions[ $sid ];
		$hashed  = self::hash( $secret );

		if ( ! hash_equals( $session['refresh'], $hashed ) ) {
			// A match against the previous secret means this token was already
			// spent. Burn the session rather than hand out another pair.
			if ( ! empty( $session['prev_refresh'] ) && hash_equals( $session['prev_refresh'], $hashed ) ) {
				unset( $sessions[ $sid ] );
				self::save_sessions( $user_id, $sessions );

				return new WP_Error(
					'fmp_app_refresh_reused',
					__( 'This session has been signed out. Please sign in again.', 'food-menu-pro' ),
					[ 'status' => 401 ]
				);
			}

			return self::invalid_refresh();
		}

		if ( ! get_userdata( $user_id ) ) {
			unset( $sessions[ $sid ] );
			self::save_sessions( $user_id, $sessions );

			return self::invalid_refresh();
		}

		$access  = self::secret();
		$refresh = self::secret();
		$now     = time();

		$sessions[ $sid ] = array_merge(
			$session,
			[
				'access'          => self::hash( $access ),
				'access_expires'  => $now + self::access_ttl(),
				'prev_refresh'    => $session['refresh'],
				'refresh'         => self::hash( $refresh ),
				'refresh_expires' => $now + self::refresh_ttl(),
				'last_used'       => $now,
			]
		);

		self::save_sessions( $user_id, $sessions );

		return self::bundle( $user_id, $sid, $access, $refresh );
	}

	/**
	 * The one error a bad refresh token produces.
	 *
	 * Deliberately identical for malformed, unknown and expired tokens.
	 *
	 * @return WP_Error
	 */
	private static function invalid_refresh() {
		return new WP_Error(
			'fmp_app_invalid_refresh_token',
			__( 'The refresh token is invalid or has expired.', 'food-menu-pro' ),
			[ 'status' => 401 ]
		);
	}

	/**
	 * Revoke the session a token belongs to.
	 *
	 * @param string $token Raw access or refresh token.
	 * @return bool Whether a session was removed.
	 */
	public static function revoke( $token ) {
		$parsed = self::parse( $token );

		if ( null === $parsed ) {
			return false;
		}

		list( $user_id, $sid, $secret ) = $parsed;

		$sessions = self::get_sessions( $user_id );

		if ( ! isset( $sessions[ $sid ] ) ) {
			return false;
		}

		$session = $sessions[ $sid ];
		$hashed  = self::hash( $secret );
		$matches = ( ! empty( $session['access'] ) && hash_equals( $session['access'], $hashed ) )
			|| ( ! empty( $session['refresh'] ) && hash_equals( $session['refresh'], $hashed ) );

		if ( ! $matches ) {
			return false;
		}

		unset( $sessions[ $sid ] );
		self::save_sessions( $user_id, $sessions );

		return true;
	}

	/**
	 * Revoke every session a user has.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	public static function revoke_all( $user_id ) {
		delete_user_meta( (int) $user_id, self::META_KEY );
	}
}
