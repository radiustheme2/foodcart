<?php
/**
 * Customer authentication REST API for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;
use WP_User;

/**
 * `POST fmp/v1/app/auth/{register,login,refresh,logout}`.
 *
 * These are the only routes in the plugin that issue credentials, so they are
 * public by permission and gated by rate limiting and transport checks
 * instead. Everything else under `fmp/v1/app` authenticates with the access
 * token these routes hand out.
 */
class AuthApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		$namespace = AppApiFns::REST_NAMESPACE;
		$prefix    = AppApiFns::PREFIX . '/auth';

		register_rest_route(
			$namespace,
			$prefix . '/register',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'register_customer' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'email'      => [
						'required'          => true,
						'type'              => 'string',
						'format'            => 'email',
						'sanitize_callback' => 'sanitize_email',
					],
					'password'   => [
						'required' => true,
						'type'     => 'string',
					],
					'first_name' => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'last_name'  => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'phone'      => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'device'     => $this->device_arg(),
				],
			]
		);

		register_rest_route(
			$namespace,
			$prefix . '/login',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'login' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'username' => [
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'password' => [
						'required' => true,
						'type'     => 'string',
					],
					'device'   => $this->device_arg(),
				],
			]
		);

		register_rest_route(
			$namespace,
			$prefix . '/refresh',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'refresh' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'refresh_token' => [
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
				],
			]
		);

		register_rest_route(
			$namespace,
			$prefix . '/logout',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'logout' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'refresh_token' => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'all_devices'   => [
						'type'    => 'boolean',
						'default' => false,
					],
				],
			]
		);
	}

	/**
	 * Shared definition of the optional device label.
	 *
	 * @return array
	 */
	private function device_arg() {
		return [
			'type'              => 'string',
			'sanitize_callback' => function ( $value ) {
				return mb_substr( sanitize_text_field( (string) $value ), 0, 100 );
			},
		];
	}

	/**
	 * `POST /app/auth/register`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function register_customer( $request ) {
		$transport = AppApiFns::check_transport();

		if ( $transport ) {
			return $transport;
		}

		if ( ! $this->registration_enabled() ) {
			return new WP_Error(
				'fmp_app_registration_disabled',
				__( 'Account registration is not available on this store.', 'food-menu-pro' ),
				[ 'status' => 403 ]
			);
		}

		$ip      = AppRateLimit::client_ip();
		$limited = AppRateLimit::check( 'register', $ip, 5, HOUR_IN_SECONDS );

		if ( $limited ) {
			return $limited;
		}

		$email    = (string) $request['email'];
		$password = (string) $request['password'];

		if ( ! is_email( $email ) ) {
			return new WP_Error(
				'fmp_app_invalid_email',
				__( 'Please enter a valid email address.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		if ( email_exists( $email ) ) {
			return new WP_Error(
				'fmp_app_email_exists',
				__( 'An account already exists with that email address. Please sign in instead.', 'food-menu-pro' ),
				[ 'status' => 409 ]
			);
		}

		$password_error = $this->validate_password( $password, $email );

		if ( $password_error ) {
			return $password_error;
		}

		$user_id = $this->create_customer( $email, $password, (string) $request['first_name'], (string) $request['last_name'] );

		if ( is_wp_error( $user_id ) ) {
			return $this->as_rest_error( $user_id );
		}

		$phone = trim( (string) $request['phone'] );

		if ( '' !== $phone ) {
			update_user_meta( $user_id, 'billing_phone', $phone );
		}

		$user = get_userdata( $user_id );

		/**
		 * Fires after the app registers a customer.
		 *
		 * @param int $user_id New user ID.
		 */
		do_action( 'fmp_app_customer_registered', $user_id );

		return $this->token_response( $user, (string) $request['device'], 201 );
	}

	/**
	 * `POST /app/auth/login`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function login( $request ) {
		$transport = AppApiFns::check_transport();

		if ( $transport ) {
			return $transport;
		}

		$username = trim( (string) $request['username'] );
		$password = (string) $request['password'];
		$ip       = AppRateLimit::client_ip();

		// Two buckets: one stops a single account being ground down from many
		// addresses, the other stops one address spraying many accounts.
		$limited = AppRateLimit::check( 'login_ip', $ip, 20, 15 * MINUTE_IN_SECONDS );

		if ( $limited ) {
			return $limited;
		}

		// Looser than the per-address bucket on purpose: this one is keyed by
		// the account being targeted, so a tight limit here would let anyone
		// lock a known customer out by guessing badly on their behalf.
		$limited = AppRateLimit::check( 'login_user', $username, 15, 15 * MINUTE_IN_SECONDS );

		if ( $limited ) {
			return $limited;
		}

		if ( '' === $username || '' === $password ) {
			return $this->invalid_credentials();
		}

		$user = wp_authenticate( $username, $password );

		if ( is_wp_error( $user ) ) {
			// Every failure collapses into one message. `wp_authenticate`
			// distinguishes an unknown user from a wrong password, and passing
			// that through would turn this route into an account enumeration
			// oracle.
			return $this->invalid_credentials();
		}

		AppRateLimit::clear( 'login_user', $username );

		return $this->token_response( $user, (string) $request['device'] );
	}

	/**
	 * `POST /app/auth/refresh`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function refresh( $request ) {
		$transport = AppApiFns::check_transport();

		if ( $transport ) {
			return $transport;
		}

		$limited = AppRateLimit::check( 'refresh', AppRateLimit::client_ip(), 60, 5 * MINUTE_IN_SECONDS );

		if ( $limited ) {
			return $limited;
		}

		$tokens = AppTokens::rotate( (string) $request['refresh_token'] );

		if ( is_wp_error( $tokens ) ) {
			return $this->as_rest_error( $tokens );
		}

		$user_id = $this->user_id_from_token( (string) $request['refresh_token'] );
		$user    = $user_id ? get_userdata( $user_id ) : null;

		$body = $tokens;

		if ( $user instanceof WP_User ) {
			$body['user'] = AppApiFns::user_payload( $user );
		}

		return AppApiFns::no_store( new WP_REST_Response( $body, 200 ) );
	}

	/**
	 * `POST /app/auth/logout`.
	 *
	 * Idempotent: an unknown or already-revoked token still reports success, so
	 * a client that has lost track of its own state can always reach a signed
	 * out state.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function logout( $request ) {
		$token = trim( (string) $request['refresh_token'] );

		if ( '' === $token ) {
			$token = AppAuthentication::get_instance()->bearer_token();
		}

		if ( $request['all_devices'] ) {
			$user_id = get_current_user_id();

			if ( ! $user_id ) {
				$user_id = $this->user_id_from_token( $token );
			}

			if ( $user_id ) {
				AppTokens::revoke_all( $user_id );
			}
		} elseif ( '' !== $token ) {
			AppTokens::revoke( $token );
		}

		return AppApiFns::no_store( new WP_REST_Response( [ 'success' => true ], 200 ) );
	}

	/**
	 * Build the token + user response.
	 *
	 * @param WP_User $user   User.
	 * @param string  $device Device label.
	 * @param int     $status HTTP status.
	 * @return WP_REST_Response
	 */
	private function token_response( WP_User $user, $device = '', $status = 200 ) {
		$body         = AppTokens::issue( $user->ID, $device );
		$body['user'] = AppApiFns::user_payload( $user );

		return AppApiFns::no_store( new WP_REST_Response( $body, $status ) );
	}

	/**
	 * Read the user ID out of a token without verifying it.
	 *
	 * Only ever used to decide which user's payload to attach after the token
	 * has already been verified elsewhere.
	 *
	 * @param string $token Raw token.
	 * @return int
	 */
	private function user_id_from_token( $token ) {
		$parts = explode( '_', (string) $token );

		return ( 4 === count( $parts ) && AppTokens::PREFIX === $parts[0] ) ? (int) $parts[1] : 0;
	}

	/**
	 * Whether this store lets customers create accounts.
	 *
	 * Follows WooCommerce's own My Account registration setting rather than
	 * overriding it — a store that has turned registration off should not find
	 * the app creating users anyway. Absent the option, registration is
	 * allowed, because the app requires accounts to order.
	 *
	 * @return bool
	 */
	private function registration_enabled() {
		$option = get_option( 'woocommerce_enable_myaccount_registration', null );

		if ( null === $option ) {
			$enabled = true;
		} elseif ( function_exists( 'wc_string_to_bool' ) ) {
			$enabled = wc_string_to_bool( $option );
		} else {
			$enabled = in_array( $option, [ 'yes', '1', 1, true ], true );
		}

		return (bool) apply_filters( 'fmp_app_registration_enabled', $enabled );
	}

	/**
	 * Create the WooCommerce customer.
	 *
	 * @param string $email      Email.
	 * @param string $password   Password.
	 * @param string $first_name First name.
	 * @param string $last_name  Last name.
	 * @return int|WP_Error
	 */
	private function create_customer( $email, $password, $first_name, $last_name ) {
		// `wc_create_new_customer` is preferred: it derives a unique username,
		// assigns the `customer` role and fires the new-account email, so an
		// app signup looks identical to a storefront signup.
		if ( function_exists( 'wc_create_new_customer' ) ) {
			return wc_create_new_customer(
				$email,
				'',
				$password,
				[
					'first_name' => $first_name,
					'last_name'  => $last_name,
				]
			);
		}

		$user_id = wp_insert_user(
			[
				'user_login' => $this->unique_login( $email ),
				'user_email' => $email,
				'user_pass'  => $password,
				'first_name' => $first_name,
				'last_name'  => $last_name,
				'role'       => 'customer',
			]
		);

		return $user_id;
	}

	/**
	 * Derive an unused login from an email address.
	 *
	 * Only reached when WooCommerce is inactive, which the app's menu already
	 * depends on, so this is a safety net rather than a supported mode.
	 *
	 * @param string $email Email.
	 * @return string
	 */
	private function unique_login( $email ) {
		$base  = sanitize_user( current( explode( '@', $email ) ), true );
		$base  = '' !== $base ? $base : 'customer';
		$login = $base;
		$i     = 1;

		while ( username_exists( $login ) ) {
			$login = $base . ++$i;
		}

		return $login;
	}

	/**
	 * Validate a submitted password.
	 *
	 * @param string $password Password.
	 * @param string $email    Email, so the password cannot simply repeat it.
	 * @return WP_Error|null
	 */
	private function validate_password( $password, $email ) {
		$min = (int) apply_filters( 'fmp_app_min_password_length', 8 );

		if ( mb_strlen( $password ) < $min ) {
			return new WP_Error(
				'fmp_app_weak_password',
				sprintf(
					/* translators: %d: minimum number of characters. */
					_n(
						'Please choose a password of at least %d character.',
						'Please choose a password of at least %d characters.',
						$min,
						'food-menu-pro'
					),
					$min
				),
				[ 'status' => 400 ]
			);
		}

		// Only a sanity cap. WordPress pre-hashes before bcrypt, so a long
		// password is handled correctly rather than silently truncated.
		if ( strlen( $password ) > 4096 ) {
			return new WP_Error(
				'fmp_app_password_too_long',
				__( 'That password is too long.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		if ( 0 === strcasecmp( trim( $password ), trim( $email ) ) ) {
			return new WP_Error(
				'fmp_app_weak_password',
				__( 'Please choose a password that is not your email address.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		return null;
	}

	/**
	 * The single error every failed sign-in returns.
	 *
	 * @return WP_Error
	 */
	private function invalid_credentials() {
		return new WP_Error(
			'fmp_app_invalid_credentials',
			__( 'That email address and password do not match an account.', 'food-menu-pro' ),
			[ 'status' => 401 ]
		);
	}

	/**
	 * Give a WP_Error an HTTP status the REST API will honour.
	 *
	 * Errors raised by core and WooCommerce carry no status, which the REST
	 * API renders as a 500.
	 *
	 * @param WP_Error $error Error.
	 * @return WP_Error
	 */
	private function as_rest_error( WP_Error $error ) {
		$data = $error->get_error_data();

		if ( is_array( $data ) && isset( $data['status'] ) ) {
			return $error;
		}

		$error->add_data( [ 'status' => 400 ], $error->get_error_code() );

		return $error;
	}
}
