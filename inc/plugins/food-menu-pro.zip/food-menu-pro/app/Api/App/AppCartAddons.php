<?php
/**
 * Add-on selections on Store API add-to-cart.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use Automattic\WooCommerce\StoreApi\Exceptions\RouteException;
use RT\FoodMenuPro\Controllers\ProductAddons\Frontend\AddonFields;
use RT\FoodMenuPro\Traits\SingletonTrait;

/**
 * Lets a headless client send add-on selections with `cart/add-item`.
 *
 * The Store API's add-to-cart takes `id`, `quantity` and `variation` and
 * nothing else, and the website's own handler is driven by `$_POST` fields
 * and gated behind a nonce — so before this, a dish with a **required**
 * add-on group went into the cart with no selections at all, at base price,
 * and the cart item recorded nothing about it.
 *
 * Selections arrive under the plugin's own Store API extension key:
 *
 *     "extensions": { "food-menu-pro": { "addons": [
 *         { "group_id": "0", "option_ids": ["1"] },
 *         { "group_id": "1", "option_ids": ["0"], "quantities": { "0": 2 } },
 *         { "group_id": "2", "text": "No ice please" }
 *     ] } }
 *
 * **The app sends ids, not labels.** The website matches options by their
 * label text, which is display copy — it can carry quotes and entities, and
 * it changes whenever the restaurant rewords a topping. Ids are the ones
 * `AddonsApi` already publishes, so the contract survives a rename.
 *
 * A group's id is its **key** in the stored add-on list, not its position in
 * it, and for global add-ons those differ. `AppAddonGroups` carries both;
 * mixing them up attributes a selection to the wrong group or drops it, with
 * nothing in the response to say so.
 *
 * Those ids are then translated back into the exact `value` / `qty_values`
 * shape the website builds, and handed to its own `AddonFields`. The cart
 * item that comes out is byte-identical to the one the web page produces, so
 * pricing, the cart display, the order line item and the admin screen all
 * keep working with no second code path.
 */
class AppCartAddons {

	use SingletonTrait;

	/**
	 * The plugin's Store API extension key, as Pro already registers it for
	 * checkout.
	 *
	 * @var string
	 */
	const EXTENSION = 'food-menu-pro';

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_filter( 'woocommerce_store_api_add_to_cart_data', [ $this, 'add_to_cart_data' ], 10, 2 );
	}

	/**
	 * Attach validated add-on selections to the cart item.
	 *
	 * @param array            $data    Add-to-cart data.
	 * @param \WP_REST_Request $request Request.
	 * @return array
	 * @throws RouteException When a selection is missing or invalid.
	 */
	public function add_to_cart_data( $data, $request ) {
		$product_id = (int) ( $data['id'] ?? 0 );

		if ( ! $product_id ) {
			return $data;
		}

		$product = wc_get_product( $product_id );

		// The website does not render add-ons on variable products, so a
		// variation must not be held to add-on rules it was never shown.
		if ( ! $product || 'variable' === $product->get_type() ) {
			return $data;
		}

		$groups = AppAddonGroups::for_product( $product_id );

		if ( ! $groups ) {
			return $data;
		}

		$submitted = $this->submitted( $request );
		$addons    = [];

		foreach ( $groups as $entry ) {
			$group = $entry['group'];

			// The website's own field name, built the same way, so the cart
			// entry is indistinguishable from one the web page made.
			$group['field_name'] = $entry['field_name'];

			// Keyed by the **id** the client was given, which for global
			// add-ons is not the group's position — see `AppAddonGroups`.
			$selection = $submitted[ $entry['id'] ] ?? [];
			$built     = $this->build_group( $group, $entry['id'], $selection );

			if ( $built ) {
				$addons = array_merge( $addons, $built );
			}
		}

		if ( $addons ) {
			$data['cart_item_data']['fmp_addons'] = array_merge(
				(array) ( $data['cart_item_data']['fmp_addons'] ?? [] ),
				$addons
			);
		}

		// **The selection, as submitted, beside the display rows.**
		// `fmp_addons` is the website's own cart shape — names, values and
		// prices — which is what the cart and the order line render, and which
		// nothing can be rebuilt from: an option's label is not its id. The
		// array below is the exact payload `cart/add-item` accepts, so a
		// reorder can re-submit it unchanged. Task 7.4.
		//
		// **Always set, even empty**, for a product that has add-on groups at
		// all: its presence is how `AppReorderApi` tells a line whose choices
		// were recorded from one placed before this existed.
		$data['cart_item_data']['fmp_addon_selection'] = self::sanitize_selection( $submitted );

		return $data;
	}

	/**
	 * The submitted selection, reduced to what can be re-submitted.
	 *
	 * Whitelisted key by key rather than stored as it arrived: this goes into
	 * order meta and comes back out as a request body, so nothing travels that
	 * the add-to-cart route would not accept.
	 *
	 * @param array $submitted Selections keyed by group id.
	 * @return array List of `{ group_id, option_ids|text, quantities }`.
	 */
	public static function sanitize_selection( array $submitted ) {
		$out = [];

		foreach ( $submitted as $group_id => $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}

			$row = [ 'group_id' => (string) $group_id ];

			$text = isset( $entry['text'] ) ? trim( (string) $entry['text'] ) : '';

			if ( '' !== $text ) {
				$row['text'] = sanitize_textarea_field( $text );
				$out[]       = $row;
				continue;
			}

			$ids = array_values(
				array_filter(
					array_map( 'sanitize_text_field', (array) ( $entry['option_ids'] ?? [] ) ),
					static function ( $id ) {
						return '' !== $id;
					}
				)
			);

			if ( ! $ids ) {
				continue;
			}

			$row['option_ids'] = $ids;

			$quantities = [];

			foreach ( (array) ( $entry['quantities'] ?? [] ) as $id => $qty ) {
				$qty = absint( $qty );

				if ( $qty > 1 && in_array( (string) $id, $ids, true ) ) {
					$quantities[ (string) $id ] = $qty;
				}
			}

			if ( $quantities ) {
				$row['quantities'] = $quantities;
			}

			$out[] = $row;
		}

		return $out;
	}

	/**
	 * Selections from the request, keyed by group id.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array
	 */
	private function submitted( $request ) {
		$extensions = $request['extensions'] ?? [];
		$ours       = is_array( $extensions ) ? ( $extensions[ self::EXTENSION ] ?? [] ) : [];
		$addons     = is_array( $ours ) ? ( $ours['addons'] ?? [] ) : [];
		$out        = [];

		if ( ! is_array( $addons ) ) {
			return $out;
		}

		foreach ( $addons as $entry ) {
			if ( ! is_array( $entry ) || ! isset( $entry['group_id'] ) ) {
				continue;
			}

			$out[ (string) $entry['group_id'] ] = $entry;
		}

		return $out;
	}

	/**
	 * Validate one group's selection and build its cart entries.
	 *
	 * @param array      $group     Stored group, with `field_name` set.
	 * @param int|string $group_id  The group's id, for error data.
	 * @param array      $selection What the client sent for it.
	 * @return array
	 * @throws RouteException When the selection is missing or invalid.
	 */
	private function build_group( array $group, $group_id, array $selection ) {
		$type    = (string) ( $group['type'] ?? '' );
		$title   = (string) ( $group['title'] ?? '' );
		$options = array_values( (array) ( $group['options'] ?? [] ) );

		if ( in_array( $type, [ 'text', 'textarea' ], true ) ) {
			$text  = trim( (string) ( $selection['text'] ?? '' ) );
			$limit = (int) ( $group['char_limit'] ?? 0 );

			if ( '' === $text ) {
				if ( AppAddonGroups::requires_choice( $group ) ) {
					throw new RouteException(
						'fmp_app_addon_required',
						sprintf(
							/* translators: %s: add-on group title. */
							esc_html__( '%s is required.', 'food-menu-pro' ),
							esc_html( $title )
						),
						400
					);
				}

				return [];
			}

			if ( $limit > 0 && mb_strlen( $text ) > $limit ) {
				throw new RouteException(
					'fmp_app_addon_too_long',
					sprintf(
						/* translators: 1: add-on group title, 2: character limit. */
						esc_html__( '%1$s must be %2$d characters or fewer.', 'food-menu-pro' ),
						esc_html( $title ),
						(int) $limit
					),
					400
				);
			}

			return $this->through_website( $group, $text, [] );
		}

		$chosen = $this->chosen_indexes( $selection, $options, $title );

		// A radio or dropdown is one choice, whatever the client sent.
		if ( in_array( $type, [ 'radio', 'dropdown' ], true ) && count( $chosen ) > 1 ) {
			throw new RouteException(
				'fmp_app_addon_too_many',
				sprintf(
					/* translators: %s: add-on group title. */
					esc_html__( 'Please choose one option for %s.', 'food-menu-pro' ),
					esc_html( $title )
				),
				400
			);
		}

		$min = (int) ( $group['min_selection'] ?? 0 );
		$max = (int) ( $group['max_selection'] ?? 0 );

		if ( ! $chosen ) {
			if ( AppAddonGroups::requires_choice( $group ) ) {
				throw new RouteException(
					'fmp_app_addon_required',
					sprintf(
						/* translators: %s: add-on group title. */
						esc_html__( 'Please choose an option for %s.', 'food-menu-pro' ),
						esc_html( $title )
					),
					400
				);
			}

			return [];
		}

		// Zero means "no limit" on both, which is how the admin screen and the
		// website read them.
		if ( $min > 0 && count( $chosen ) < $min ) {
			throw new RouteException(
				'fmp_app_addon_too_few',
				sprintf(
					/* translators: 1: add-on group title, 2: minimum selections. */
					esc_html__( 'Please choose at least %2$d options for %1$s.', 'food-menu-pro' ),
					esc_html( $title ),
					(int) $min
				),
				400
			);
		}

		if ( $max > 0 && count( $chosen ) > $max ) {
			throw new RouteException(
				'fmp_app_addon_too_many',
				sprintf(
					/* translators: 1: add-on group title, 2: maximum selections. */
					esc_html__( 'Please choose no more than %2$d options for %1$s.', 'food-menu-pro' ),
					esc_html( $title ),
					(int) $max
				),
				400
			);
		}

		// Back into the website's own input shape: a dropdown matches on
		// "label-position", everything else on a list of labels.
		if ( 'dropdown' === $type ) {
			$index = (int) $chosen[0];
			$value = html_entity_decode( (string) $options[ $index ]['label'], ENT_QUOTES ) . '-' . ( $index + 1 );
		} else {
			$value = [];

			foreach ( $chosen as $index ) {
				// `esc_html`, not the raw label: the website matches on
				// `esc_html( $option['label'] )`, and its own form posts the
				// already-escaped text from the rendered HTML. A label with a
				// quote in it — `Medium 12"` — matches as `Medium 12&quot;`
				// and silently fails to match otherwise, adding the dish at
				// base price with the option recorded nowhere.
				$value[] = esc_html( (string) $options[ (int) $index ]['label'] );
			}
		}

		return $this->through_website( $group, $value, $this->quantities( $selection, $chosen ) );
	}

	/**
	 * The option indexes the client chose, checked against the group.
	 *
	 * @param array  $selection Submitted entry.
	 * @param array  $options   The group's options.
	 * @param string $title     Group title, for the error.
	 * @return int[]
	 * @throws RouteException When an id is not one of the group's options.
	 */
	private function chosen_indexes( array $selection, array $options, $title ) {
		$ids    = $selection['option_ids'] ?? [];
		$chosen = [];

		foreach ( (array) $ids as $id ) {
			$index = (int) $id;

			// An unknown id is a client that is out of step with the menu —
			// silently dropping it would charge for something else, or for
			// nothing, without saying so.
			if ( ! isset( $options[ $index ] ) ) {
				throw new RouteException(
					'fmp_app_addon_unknown_option',
					sprintf(
						/* translators: %s: add-on group title. */
						esc_html__( 'That option is no longer available for %s.', 'food-menu-pro' ),
						esc_html( $title )
					),
					400
				);
			}

			$chosen[] = $index;
		}

		return array_values( array_unique( $chosen ) );
	}

	/**
	 * Per-option quantities, keyed by option index as `AddonFields` expects.
	 *
	 * @param array $selection Submitted entry.
	 * @param int[] $chosen    Chosen indexes.
	 * @return array
	 */
	private function quantities( array $selection, array $chosen ) {
		$raw = $selection['quantities'] ?? [];
		$out = [];

		if ( ! is_array( $raw ) ) {
			return $out;
		}

		foreach ( $chosen as $index ) {
			if ( isset( $raw[ (string) $index ] ) ) {
				$out[ $index ] = absint( $raw[ (string) $index ] );
			}
		}

		return $out;
	}

	/**
	 * Hand the translated selection to the website's own builder.
	 *
	 * This is the whole point of translating back into labels: the entries it
	 * returns — name, value, price, field_name, field_type, price_type, qty —
	 * are the same ones the web page produces, including its quantity clamp
	 * and its reading of a non-numeric price.
	 *
	 * @param array        $group      Stored group, with `field_name` set.
	 * @param string|array $value      Value in the website's shape.
	 * @param array        $qty_values Quantities by option index.
	 * @return array
	 */
	private function through_website( array $group, $value, array $qty_values ) {
		$fields = new AddonFields(
			[
				'type'       => $group['type'],
				'value'      => $value,
				'addon'      => $group,
				'qty_values' => $qty_values,
			]
		);

		$built = $fields->get_cart_item_content();

		return ( is_array( $built ) && $built ) ? $built : [];
	}
}
