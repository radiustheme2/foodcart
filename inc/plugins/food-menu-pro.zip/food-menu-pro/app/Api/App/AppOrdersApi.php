<?php
/**
 * The customer's own orders, for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;

/**
 * `GET fmp/v1/app/orders/{id}` — one order, as the customer who placed it.
 *
 * **Why not the Store API's own `wc/store/v1/order/{id}`.** That route exists
 * and answers the items, the totals and the addresses — but nothing else an
 * order *is* here. It carries no order number, no date, no payment title, and
 * none of the plugin's own fields: not the order type, not the pickup or
 * delivery time the customer chose, and not the tracking token, without which
 * the design's "Track order" button has nothing to open. Its `extensions`
 * block comes back empty.
 *
 * So the app reads an order back through here. The checkout's own response
 * cannot be used either: its extension block is the schema's defaults rather
 * than what was saved.
 *
 * **Money is in minor units, as strings**, exactly as the Store API sends it,
 * so one parser in the app serves every price it meets. The staff API next
 * door sends floats; that is for a dashboard, and not a precedent to follow.
 */
class AppOrdersApi {

	use SingletonTrait;

	/**
	 * How many dish thumbnails a history row carries.
	 *
	 * The design draws a handful beside the item count; the rest of an order
	 * is a tap away on `/app/orders/{id}`.
	 */
	const ROW_ITEMS = 4;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/orders',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_orders' ],
				'permission_callback' => [ $this, 'permission' ],
				'args'                => [
					'group'    => [
						'type'    => 'string',
						'default' => 'any',
						'enum'    => [ 'any', 'active', 'past' ],
					],
					'page'     => [
						'type'              => 'integer',
						'default'           => 1,
						'sanitize_callback' => 'absint',
					],
					'per_page' => [
						'type'              => 'integer',
						'default'           => 10,
						'sanitize_callback' => 'absint',
					],
				],
			]
		);

		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/orders/(?P<id>\d+)',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_order' ],
				'permission_callback' => [ $this, 'permission' ],
				'args'                => [
					'id' => [
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					],
				],
			]
		);
	}

	/**
	 * Signed in, and nothing more — whose order it is is decided below.
	 *
	 * @return true|WP_Error
	 */
	public function permission() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'fmp_app_not_authenticated',
				__( 'You must be signed in to do that.', 'food-menu-pro' ),
				[ 'status' => 401 ]
			);
		}

		return true;
	}

	/**
	 * `GET /app/orders` — the customer's own orders, newest first.
	 *
	 * **A summary per order, not the whole thing.** The design's row shows the
	 * number, the date, the order type, the status, a few dish thumbnails, a
	 * count and the total — not the address, the customer or every line's
	 * add-ons. Sending the full payload twenty times over would be most of a
	 * page of JSON nobody renders. Tapping a row reads `/app/orders/{id}`,
	 * which still answers everything.
	 *
	 * **Paged WordPress's way**, as a bare array with `X-WP-Total` and
	 * `X-WP-TotalPages` headers rather than an envelope, because that is the
	 * contract the app's pager already speaks for the menu.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function get_orders( $request ) {
		$page = max( 1, absint( $request['page'] ) );

		// Capped, so `per_page=5000` cannot be used to build every order this
		// customer ever placed in one request.
		$per_page = min( 50, max( 1, absint( $request['per_page'] ) ) );

		$result = wc_get_orders(
			[
				'customer_id' => get_current_user_id(),
				'status'      => self::statuses_for( (string) $request['group'] ),
				'limit'       => $per_page,
				'page'        => $page,
				'paginate'    => true,
				'orderby'     => 'date',
				'order'       => 'DESC',
			]
		);

		$out = [];

		foreach ( $result->orders as $order ) {
			$out[] = $this->summary( $order );
		}

		$response = new WP_REST_Response( $out, 200 );
		$response->header( 'X-WP-Total', (int) $result->total );
		$response->header( 'X-WP-TotalPages', (int) $result->max_num_pages );

		return AppApiFns::no_store( $response );
	}

	/**
	 * Which statuses one tab of the design's screen covers.
	 *
	 * The design splits "Active" from "Past", and the split has to survive a
	 * store that invents its own statuses — which this plugin lets it do. So
	 * it is defined the other way round: a short list of **finished**
	 * statuses, and everything else is still happening. A custom
	 * "Out for delivery" is then active without anyone having to say so.
	 *
	 * The default list is the one `OrderTracking::should_flag_as_new()`
	 * already uses for the staff badge; `fmp_app_finished_order_statuses`
	 * exists for the store whose custom status is an ending.
	 *
	 * `checkout-draft` is in none of them. It is the half-finished order the
	 * block checkout parks while the customer is still typing, and showing it
	 * as an order would be alarming and wrong.
	 *
	 * @param string $group `any`, `active` or `past`.
	 * @return string[] Status slugs, `wc-` prefixed as WooCommerce stores them.
	 */
	private static function statuses_for( $group ) {
		$all = array_keys( wc_get_order_statuses() );
		$all = array_values( array_diff( $all, [ 'wc-checkout-draft' ] ) );

		$finished = self::finished_statuses();

		if ( 'past' === $group ) {
			return array_values( array_intersect( $all, $finished ) );
		}

		if ( 'active' === $group ) {
			return array_values( array_diff( $all, $finished ) );
		}

		return $all;
	}

	/**
	 * The finished statuses, `wc-` prefixed.
	 *
	 * @return string[]
	 */
	private static function finished_statuses() {
		/**
		 * Statuses that mean the order is over, for the app's order history.
		 *
		 * @param string[] $finished Slugs, with or without the `wc-` prefix.
		 */
		$finished = (array) apply_filters(
			'fmp_app_finished_order_statuses',
			[ 'completed', 'cancelled', 'refunded', 'failed' ]
		);

		$out = [];

		foreach ( $finished as $slug ) {
			$slug = (string) $slug;

			if ( '' === $slug ) {
				continue;
			}

			// **Not `ltrim( $slug, 'wc-' )`.** That strips *characters*, so
			// `completed` would come back as `ompleted` and never match.
			$out[] = str_starts_with( $slug, 'wc-' ) ? $slug : 'wc-' . $slug;
		}

		return $out;
	}

	/**
	 * Whether an order is still happening, for the design's Active tab.
	 *
	 * @param string $status Status slug, unprefixed.
	 * @return bool
	 */
	private static function is_active( $status ) {
		return ! in_array( 'wc-' . $status, self::finished_statuses(), true );
	}

	/**
	 * One order as a history row.
	 *
	 * Carries its own `currency` block, which does repeat down the list. The
	 * alternative is an envelope, and that would cost the app's pager — which
	 * reads a bare array and the `X-WP-*` headers — for a few hundred bytes.
	 *
	 * @param \WC_Order $order Order.
	 * @return array
	 */
	private function summary( $order ) {
		$schedule = FnsPro::get_order_schedule( $order );
		$created  = $order->get_date_created();
		$status   = $order->get_status();

		return [
			'id'           => $order->get_id(),
			'number'       => (string) $order->get_order_number(),
			'status'       => $status,
			'status_label' => wc_get_order_status_name( $status ),
			// The store's own colour for the status pill, custom statuses and
			// admin overrides included, so the app never maps a slug to a
			// colour any more than it maps one to words.
			'status_color' => self::status_color( $status ),
			'is_active'    => self::is_active( $status ),
			'date_created' => $created ? $created->format( 'c' ) : '',
			'type'         => $schedule['type'],
			'type_label'   => $schedule['label'],
			'eta'          => $this->eta( $schedule ),
			// How far through its stages the order is, so the row can draw the
			// design's progress strip without a tracking request of its own.
			// Null when there is nothing to draw one from. See AppTrackingApi.
			'progress'     => AppTrackingApi::progress( $order ),
			// Units, not lines: three of one dish reads as three, which is
			// what the design's "3 items" counts.
			'item_count'   => (int) $order->get_item_count(),
			// Enough for the row's thumbnails and no more. `item_count` is
			// the real number; this list is capped.
			'items'        => $this->row_items( $order ),
			'currency'     => AppApiFns::currency(),
			'total_price'  => AppApiFns::minor_units( $order->get_total() ),
		];
	}

	/**
	 * The first few lines, as the row's thumbnails need them.
	 *
	 * Deliberately **not** `items()`: that carries each line's total and its
	 * add-on meta, which a history row never draws. Sending them would be the
	 * same waste this summary exists to avoid, four lines at a time.
	 *
	 * @param \WC_Order $order Order.
	 * @return array
	 */
	private function row_items( $order ) {
		$out = [];

		foreach ( $order->get_items() as $item ) {
			if ( count( $out ) >= self::ROW_ITEMS ) {
				break;
			}

			$product = $item->get_product();

			$out[] = [
				'id'       => $product ? (int) $product->get_id() : 0,
				'name'     => $item->get_name(),
				'quantity' => (int) $item->get_quantity(),
				'image'    => $this->image( $product ),
			];
		}

		return $out;
	}

	/**
	 * The store's colour for a status, or WooCommerce's own default.
	 *
	 * @param string $status Status slug, unprefixed.
	 * @return string
	 */
	private static function status_color( $status ) {
		$meta = FnsPro::get_status_metadata( 'wc-' . $status );

		return is_array( $meta ) ? (string) ( $meta['color'] ?? '' ) : '';
	}

	/**
	 * `GET /app/orders/{id}`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_order( $request ) {
		$order = wc_get_order( absint( $request['id'] ) );

		// Somebody else's order is answered exactly as a missing one is.
		// Telling the two apart would confirm that an order id exists.
		if ( ! $order || (int) $order->get_customer_id() !== get_current_user_id() ) {
			return new WP_Error(
				'fmp_app_order_not_found',
				__( 'That order could not be found.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		return AppApiFns::no_store(
			new WP_REST_Response( $this->payload( $order ), 200 )
		);
	}

	/**
	 * One order, in the shape the app renders.
	 *
	 * @param \WC_Order $order Order.
	 * @return array
	 */
	private function payload( $order ) {
		$schedule = FnsPro::get_order_schedule( $order );
		$created  = $order->get_date_created();

		return [
			'id'                   => $order->get_id(),
			// A string, and not the id: a store running an order-number
			// plugin prints something else entirely on the receipt.
			'number'               => (string) $order->get_order_number(),
			'status'               => $order->get_status(),
			// Translated, and covers the store's own custom statuses — which
			// is why the app never maps a slug to words itself.
			'status_label'         => wc_get_order_status_name( $order->get_status() ),
			// The detail screen draws the same status pill the history row
			// does, so it needs the same two fields to draw it with.
			'status_color'         => self::status_color( $order->get_status() ),
			'is_active'            => self::is_active( $order->get_status() ),
			'date_created'         => $created ? $created->format( 'c' ) : '',
			'type'                 => $schedule['type'],
			'type_label'           => $schedule['label'],
			// The site's display format, as stored at checkout.
			'date'                 => $schedule['date'],
			'time'                 => $schedule['time'],
			// What to put under "Estimated": the chosen time, or the store's
			// own ASAP estimate for an order that asked for no time.
			'eta'                  => $this->eta( $schedule ),
			'location'             => [
				'id'   => (int) $order->get_meta( 'fmp_location_id' ),
				'name' => (string) $order->get_meta( 'fmp_location_name' ),
			],
			'payment_method'       => $order->get_payment_method(),
			'payment_method_title' => $order->get_payment_method_title(),
			'needs_payment'        => $order->needs_payment(),
			'customer_note'        => $order->get_customer_note(),
			'customer'             => [
				'name'  => trim(
					$order->get_billing_first_name() . ' ' . $order->get_billing_last_name()
				),
				'email' => $order->get_billing_email(),
				'phone' => $order->get_billing_phone(),
			],
			'address'              => $this->address( $order ),
			// The public tracking route is keyed on this, and nothing else
			// hands it to the customer. Empty until the first status change
			// writes one.
			'tracking_token'       => (string) $order->get_meta( '_fmp_tracking_token' ),
			'currency'             => AppApiFns::currency(),
			'totals'               => [
				'total_items'    => AppApiFns::minor_units( $order->get_subtotal() ),
				'total_discount' => AppApiFns::minor_units( $order->get_discount_total() ),
				'total_shipping' => AppApiFns::minor_units( $order->get_shipping_total() ),
				'total_fees'     => AppApiFns::minor_units( $this->fees_total( $order ) ),
				'total_tax'      => AppApiFns::minor_units( $order->get_total_tax() ),
				'total_price'    => AppApiFns::minor_units( $order->get_total() ),
			],
			'items'                => $this->items( $order ),
		];
	}

	/**
	 * "Estimated": the time the customer chose, or the store's ASAP estimate.
	 *
	 * An ASAP order stores **no time at all** — the plugin has no "ASAP"
	 * value — so an empty time is the signal, not an omission.
	 *
	 * @param array $schedule Order schedule.
	 * @return string
	 */
	private function eta( array $schedule ) {
		if ( '' !== (string) $schedule['time'] ) {
			return (string) $schedule['time'];
		}

		if ( '' === (string) $schedule['type'] ) {
			return '';
		}

		return AppApiFns::asap_label(
			$schedule['type'],
			(array) FnsPro::get_settings_option()
		);
	}

	/**
	 * Where it goes, in WooCommerce's own field names minus the prefix — the
	 * same shape `/app/me` uses for a saved address.
	 *
	 * Shipping, falling back to billing: a pickup order has no shipping
	 * address, and the billing one is the address the customer gave.
	 *
	 * @param \WC_Order $order Order.
	 * @return array
	 */
	private function address( $order ) {
		$use_shipping = '' !== $order->get_shipping_address_1();

		return [
			'first_name' => $use_shipping ? $order->get_shipping_first_name() : $order->get_billing_first_name(),
			'last_name'  => $use_shipping ? $order->get_shipping_last_name() : $order->get_billing_last_name(),
			'company'    => $use_shipping ? $order->get_shipping_company() : $order->get_billing_company(),
			'address_1'  => $use_shipping ? $order->get_shipping_address_1() : $order->get_billing_address_1(),
			'address_2'  => $use_shipping ? $order->get_shipping_address_2() : $order->get_billing_address_2(),
			'city'       => $use_shipping ? $order->get_shipping_city() : $order->get_billing_city(),
			'state'      => $use_shipping ? $order->get_shipping_state() : $order->get_billing_state(),
			'postcode'   => $use_shipping ? $order->get_shipping_postcode() : $order->get_billing_postcode(),
			'country'    => $use_shipping ? $order->get_shipping_country() : $order->get_billing_country(),
		];
	}

	/**
	 * Fee lines added up, since `WC_Order` exposes no single total for them.
	 *
	 * @param \WC_Order $order Order.
	 * @return float
	 */
	private function fees_total( $order ) {
		$total = 0;

		foreach ( $order->get_fees() as $fee ) {
			$total += (float) $fee->get_total();
		}

		return $total;
	}

	/**
	 * The lines, with the dish image the app already draws elsewhere.
	 *
	 * @param \WC_Order $order Order.
	 * @return array
	 */
	private function items( $order ) {
		$items = [];

		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();

			$items[] = [
				// The product this line was for, so a tap can reopen the
				// dish. Zero for a product since deleted.
				'id'         => $product ? (int) $product->get_id() : 0,
				'name'       => $item->get_name(),
				'quantity'   => (int) $item->get_quantity(),
				'total'      => AppApiFns::minor_units( $item->get_total() ),
				'image'      => $this->image( $product ),
				// The plugin's own display copy for the line, which is where
				// the chosen add-ons are written.
				'meta'       => $this->item_meta( $item ),
			];
		}

		return $items;
	}

	/**
	 * @param \WC_Product|false $product Product.
	 * @return string
	 */
	private function image( $product ) {
		if ( ! $product ) {
			return '';
		}

		$image = wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' );

		return $image ? esc_url_raw( $image ) : '';
	}

	/**
	 * Visible line meta — the add-ons, as the order recorded them.
	 *
	 * @param \WC_Order_Item $item Item.
	 * @return array
	 */
	private function item_meta( $item ) {
		$meta = [];

		foreach ( $item->get_formatted_meta_data( '', true ) as $entry ) {
			$meta[] = [
				'label' => wp_strip_all_tags( (string) $entry->display_key ),
				'value' => wp_strip_all_tags( (string) $entry->display_value ),
			];
		}

		return $meta;
	}
}
