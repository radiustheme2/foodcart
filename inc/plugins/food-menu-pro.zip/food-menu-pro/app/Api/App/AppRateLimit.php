<?php
/**
 * Rate limiting for the mobile app's public routes.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use WP_Error;

/**
 * A fixed-window counter kept in transients.
 *
 * The auth routes are unauthenticated by definition, so they are the one place
 * in the plugin where an attacker can spend our CPU for free. This is not a
 * precise limiter — a fixed window lets a burst straddle the boundary — but it
 * turns unbounded credential stuffing into a slow grind, which is the point.
 */
class AppRateLimit {

	/**
	 * Transient key prefix.
	 *
	 * @var string
	 */
	const PREFIX = 'fmp_app_rl_';

	/**
	 * The requesting client's IP address.
	 *
	 * `REMOTE_ADDR` only. Forwarded-for headers are client-supplied, so
	 * trusting them by default would let anyone bypass every limit here by
	 * sending a new value per request. Sites behind a proxy opt in through the
	 * `fmp_app_client_ip` filter, where they can validate their own proxy.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		return (string) apply_filters( 'fmp_app_client_ip', $ip );
	}

	/**
	 * Count a hit and report whether the caller is over the limit.
	 *
	 * @param string $bucket Logical bucket, e.g. `login`.
	 * @param string $key    What is being limited, e.g. an IP or an IP+email.
	 * @param int    $limit  Allowed hits per window.
	 * @param int    $window Window length in seconds.
	 * @return WP_Error|null Error when the limit is exceeded, null otherwise.
	 */
	public static function check( $bucket, $key, $limit, $window ) {
		if ( ! apply_filters( 'fmp_app_rate_limit_enabled', true, $bucket ) ) {
			return null;
		}

		$transient = self::transient_key( $bucket, $key );
		$window    = max( 1, (int) $window );
		$now       = time();
		$state     = get_transient( $transient );

		// The window start is kept in the value rather than read back from
		// `_transient_timeout_*`, because that option does not exist when an
		// external object cache is handling transients.
		if ( ! is_array( $state ) || empty( $state['start'] ) || $state['start'] + $window <= $now ) {
			$state = [
				'count' => 0,
				'start' => $now,
			];
		}

		$elapsed = $now - (int) $state['start'];
		$left    = max( 1, $window - $elapsed );

		if ( (int) $state['count'] >= $limit ) {
			return new WP_Error(
				'fmp_app_too_many_requests',
				__( 'Too many attempts. Please wait a moment and try again.', 'food-menu-pro' ),
				[
					'status'      => 429,
					'retry_after' => $left,
				]
			);
		}

		++$state['count'];

		// TTL tracks the original window, so a steady stream of requests cannot
		// hold the window open indefinitely.
		set_transient( $transient, $state, $left );

		return null;
	}

	/**
	 * Forget a bucket, e.g. after a successful sign-in.
	 *
	 * @param string $bucket Logical bucket.
	 * @param string $key    What was being limited.
	 * @return void
	 */
	public static function clear( $bucket, $key ) {
		delete_transient( self::transient_key( $bucket, $key ) );
	}

	/**
	 * Build the transient name.
	 *
	 * Hashed because transient names are capped at 172 characters and the key
	 * can contain an arbitrary email address.
	 *
	 * @param string $bucket Logical bucket.
	 * @param string $key    What is being limited.
	 * @return string
	 */
	private static function transient_key( $bucket, $key ) {
		return self::PREFIX . md5( $bucket . '|' . strtolower( $key ) );
	}
}
