<?php
/**
 * Where an order has got to, for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Controllers\OrderTimeline\OrderTimeline;
use RT\FoodMenuPro\Controllers\OrderTimeline\OrderTimelineFns;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Models\OrderTimelineModel;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Response;

/**
 * `GET fmp/v1/app/orders/{id}/tracking` — the stages of one order.
 *
 * **Why not the public `fmp/v1/track/{token}` the website uses.** Two
 * reasons, and the second is the one that decides it.
 *
 * It returns the entries that *happened* and nothing else: every one carries
 * `completed: true`, because the website's tracking page draws a history, not
 * a plan. The app's design draws a progress strip — "Preparing", two of four
 * — which needs the stages still to come as well as the ones gone by, and
 * nothing in either plugin had that notion.
 *
 * And it is **expiring, on purpose**: `fmp_tracking_link_expiry_days` closes
 * a link that was emailed to whoever placed the order, and answers 410 after
 * it. That is right for a shared link and wrong for the customer's own order
 * in their own signed-in app, which should not stop working after a week. So
 * this route is bearer-authed against the order's own customer, like the rest
 * of `/app`, and the expiry does not apply.
 *
 * The website is untouched by any of this. The public route keeps its payload
 * and its expiry, and its own page keeps drawing the history.
 *
 * ## Where the stages come from
 * A store **declares an order** for its custom statuses: the Order Statuses
 * screen drag-sorts them, saves the whole array in that order, and its
 * presets ship as pipelines — Order Received, Prepping, In Oven, Ready. That
 * declared order is the only sequence either plugin has, so it is the one
 * used here.
 *
 * It covers the middle only. WooCommerce's own statuses are protected and
 * cannot be custom ones, so `pending`, `processing` and `completed` sit
 * outside the list. The stages are therefore built as:
 *
 * 1. **What happened** — the timeline, in time order, every entry reached,
 *    each with the store's own formatted time and, where the store allows it,
 *    its note. These are facts and come first.
 * 2. **What is still to come** — the enabled custom statuses, in the
 *    declared order, that have not been recorded *and* fall after the last
 *    recorded one. A step earlier in the pipeline that never happened is not
 *    still coming; it was skipped.
 * 3. **The end** — `fmp_tracking_completed_status`, unless it is already in.
 *
 * A **failed** order stops at step 1. Nothing is still to come for an order
 * that was cancelled or refunded, and drawing the rest greyed out would
 * promise a dinner that is not being cooked.
 *
 * A store with no custom statuses gets two stages — where it is, and
 * completed — rather than the design's four. That is the honest answer for a
 * store that never described a pipeline, and the strip reads it the same way.
 */
class AppTrackingApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/orders/(?P<id>\d+)/tracking',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_tracking' ],
				'permission_callback' => [ $this, 'permission' ],
				'args'                => [
					'id' => [
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					],
				],
			]
		);
	}

	/**
	 * Signed in, and nothing more — whose order it is is decided below.
	 *
	 * @return true|WP_Error
	 */
	public function permission() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'fmp_app_not_authenticated',
				__( 'You must be signed in to do that.', 'food-menu-pro' ),
				[ 'status' => 401 ]
			);
		}

		return true;
	}

	/**
	 * `GET /app/orders/{id}/tracking` — the stages of the customer's order.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_tracking( $request ) {
		$order = wc_get_order( absint( $request['id'] ) );

		// Somebody else's order is answered exactly as a missing one is, for
		// the same reason `/app/orders/{id}` does it: telling the two apart
		// would confirm that an order id exists.
		if ( ! $order || (int) $order->get_customer_id() !== get_current_user_id() ) {
			return new WP_Error(
				'fmp_app_order_not_found',
				__( 'That order could not be found.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		return AppApiFns::no_store(
			new WP_REST_Response( $this->payload( $order ), 200 )
		);
	}

	/**
	 * The tracking payload for one order.
	 *
	 * @param \WC_Order $order Order.
	 * @return array
	 */
	private function payload( $order ) {
		$status    = $order->get_status();
		$enabled   = OrderTimelineFns::is_enabled();
		$stages    = $enabled ? self::stages( $order ) : [];
		$last_done = self::last_reached( $stages );

		return [
			'order_id'     => $order->get_id(),
			'number'       => (string) $order->get_order_number(),
			'status'       => $status,
			'status_label' => wc_get_order_status_name( $status ),
			'status_color' => self::status_color( $status ),
			'is_active'    => ! self::is_finished( $status ),
			// Cancelled, refunded or failed. The design greys the whole strip
			// out for one of these rather than showing progress through it.
			'is_failed'    => self::is_failed( $status ),
			// Index into `stages`, or -1 when there are none. The app does not
			// count the list itself: an order can sit on a status the store
			// recorded but never declared, and that is still where it is.
			'step'         => $last_done,
			'stages'       => $stages,
			// False on a store with the timeline switched off, and on an order
			// placed before it was switched on. `stages` is then empty, and
			// the app says the order has no history rather than drawing one.
			'timeline'     => $enabled && ! empty( $stages ),
		];
	}

	/**
	 * How far through its stages an order is, for a history row.
	 *
	 * The row draws the design's progress strip and has only the summary to
	 * draw it from, so the alternative is a tracking request per row. Null
	 * when there is nothing to draw a strip from — the timeline is off, or
	 * the order predates it.
	 *
	 * @param \WC_Order $order Order.
	 * @return array|null `{ step, stage_count }`.
	 */
	public static function progress( $order ) {
		if ( ! OrderTimelineFns::is_enabled() ) {
			return null;
		}

		$stages = self::stages( $order );

		if ( empty( $stages ) ) {
			return null;
		}

		return [
			'step'        => self::last_reached( $stages ),
			'stage_count' => count( $stages ),
		];
	}

	/**
	 * The index of the last stage reached, or -1.
	 *
	 * @param array[] $stages Stages.
	 * @return int
	 */
	private static function last_reached( array $stages ) {
		$last = -1;

		foreach ( $stages as $index => $stage ) {
			if ( $stage['reached'] ) {
				$last = $index;
			}
		}

		return $last;
	}

	/**
	 * The stages of one order — reached, then still to come.
	 *
	 * See the class note for why the sequence is built this way.
	 *
	 * @param \WC_Order $order Order.
	 * @return array[]
	 */
	public static function stages( $order ) {
		$show_notes = 'on' === FnsPro::get_setting( 'fmp_tracking_show_notes', '' );
		$entries    = OrderTimelineModel::get_timeline( $order->get_id() );

		$stages = [];
		$seen   = [];

		// 1. What happened.
		foreach ( (array) $entries as $entry ) {
			$slug = self::unprefix( (string) ( $entry['status'] ?? '' ) );

			if ( '' === $slug || isset( $seen[ $slug ] ) ) {
				continue;
			}

			$seen[ $slug ] = true;

			$stages[] = [
				'status'  => $slug,
				'label'   => (string) ( $entry['status_label'] ?? OrderTimeline::resolve_status_label( $slug ) ),
				'color'   => self::status_color( $slug ),
				'reached' => true,
				// The restaurant's clock, not the one on the phone — the same
				// reason the website's own timeline preformats it server-side.
				'at'         => OrderTimelineFns::format_datetime( $entry['created_at'] ?? '' ),
				'at_utc'     => ! empty( $entry['created_at'] )
					? get_gmt_from_date( $entry['created_at'], 'Y-m-d\TH:i:s\Z' )
					: '',
				'note'    => $show_notes ? (string) ( $entry['note'] ?? '' ) : '',
			];
		}

		// A finished order has no future stages, whichever way it ended.
		// Cancelled is the obvious case; **completed matters just as much**,
		// because the declared pipeline would otherwise be appended after it
		// and a delivered order would read "2 of 6" with three steps still to
		// come. Nothing is still to come for an order that is over.
		if ( self::is_finished( $order->get_status() ) ) {
			return $stages;
		}

		// 2. What is still to come, from the store's declared order — only the
		// part of the pipeline that falls after the last stage reached.
		$declared = self::declared_pipeline();
		$resume   = 0;

		foreach ( $declared as $index => $slug ) {
			if ( isset( $seen[ $slug ] ) ) {
				$resume = $index + 1;
			}
		}

		foreach ( array_slice( $declared, $resume ) as $slug ) {
			if ( isset( $seen[ $slug ] ) ) {
				continue;
			}

			$seen[ $slug ] = true;
			$stages[]      = self::pending_stage( $slug );
		}

		// 3. The end.
		$completed = self::completed_status();

		if ( '' !== $completed && ! isset( $seen[ $completed ] ) ) {
			$stages[] = self::pending_stage( $completed );
		}

		return $stages;
	}

	/**
	 * A stage the order has not reached.
	 *
	 * @param string $slug Status slug, unprefixed.
	 * @return array
	 */
	private static function pending_stage( $slug ) {
		return [
			'status'  => $slug,
			'label'   => OrderTimeline::resolve_status_label( $slug ),
			'color'   => self::status_color( $slug ),
			'reached' => false,
			'at'      => '',
			'at_utc'  => '',
			'note'    => '',
		];
	}

	/**
	 * The store's own order for its custom statuses, unprefixed.
	 *
	 * The option is a list, and the Order Statuses screen saves it in the
	 * order the admin dragged it into — so its order is the declaration, not
	 * an accident of storage.
	 *
	 * @return string[]
	 */
	private static function declared_pipeline() {
		if ( 'on' !== FnsPro::get_setting( 'fmp_enable_custom_order_statuses', '' ) ) {
			return [];
		}

		$statuses = get_option( 'fmp_custom_order_statuses', [] );

		if ( ! is_array( $statuses ) ) {
			return [];
		}

		$out = [];

		foreach ( $statuses as $status ) {
			if ( empty( $status['enabled'] ) ) {
				continue;
			}

			$slug = self::unprefix( (string) ( $status['slug'] ?? '' ) );

			if ( '' !== $slug ) {
				$out[] = $slug;
			}
		}

		return $out;
	}

	/**
	 * The status that ends an order, unprefixed.
	 *
	 * @return string
	 */
	private static function completed_status() {
		return self::unprefix(
			(string) FnsPro::get_setting( 'fmp_tracking_completed_status', 'wc-completed' )
		);
	}

	/**
	 * One colour per status, the store's own where it set one.
	 *
	 * @param string $status Status slug, unprefixed.
	 * @return string
	 */
	private static function status_color( $status ) {
		$meta = FnsPro::get_status_metadata( 'wc-' . $status );

		return is_array( $meta ) ? (string) ( $meta['color'] ?? '' ) : '';
	}

	/**
	 * Statuses that mean the order is over.
	 *
	 * The same filter `/app/orders` groups its Active and Past tabs by, so a
	 * store that extends one extends both and they cannot disagree.
	 *
	 * @return string[] Unprefixed slugs.
	 */
	private static function finished_statuses() {
		/** This filter is documented in app/Api/App/AppOrdersApi.php. */
		$finished = (array) apply_filters(
			'fmp_app_finished_order_statuses',
			[ 'completed', 'cancelled', 'refunded', 'failed' ]
		);

		$out = [];

		foreach ( $finished as $slug ) {
			$slug = self::unprefix( (string) $slug );

			if ( '' !== $slug ) {
				$out[] = $slug;
			}
		}

		return $out;
	}

	/**
	 * Whether a status ends the order, successfully or not.
	 *
	 * @param string $status Status slug, unprefixed.
	 * @return bool
	 */
	private static function is_finished( $status ) {
		return in_array( $status, self::finished_statuses(), true );
	}

	/**
	 * Whether a status ends the order **without** the food arriving.
	 *
	 * Finished minus the store's own completed status, so a store that renames
	 * "completed" to "Picked up" still has one success and the rest failures.
	 *
	 * @param string $status Status slug, unprefixed.
	 * @return bool
	 */
	private static function is_failed( $status ) {
		if ( ! self::is_finished( $status ) ) {
			return false;
		}

		return $status !== self::completed_status();
	}

	/**
	 * Drop a leading `wc-`.
	 *
	 * **Not `ltrim( $slug, 'wc-' )`.** That strips *characters*, so
	 * `completed` would come back as `ompleted` and never match anything.
	 *
	 * @param string $slug Status slug, with or without the prefix.
	 * @return string
	 */
	private static function unprefix( $slug ) {
		return str_starts_with( $slug, 'wc-' ) ? substr( $slug, 3 ) : $slug;
	}
}
