<?php
/**
 * One reading of a dish's add-on groups, shared by the app's add-on code.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Controllers\ProductAddons\Frontend\FrontendPAddon;

/**
 * A dish's add-on groups, each carrying both of the identities the website
 * gives it.
 *
 * A group has **two** numbers attached to it, and they are not the same one:
 *
 * - its **array key** in what `addon_lists()` returns, which is the id
 *   `AddonsApi` publishes to the app, and
 * - its **position** in that array, which is the counter the website feeds
 *   into the `field_name` every cart entry is stamped with.
 *
 * They agree for a dish with its own add-ons, because that array is a plain
 * list. They **do not** agree for global add-ons: `get_global_addon_data()`
 * filters the stored groups by their targeting and assigns into
 * `$addons[ $key ]`, so a dish matched by the second and fourth global group
 * gets back keys 1 and 3 at positions 0 and 1.
 *
 * Reading them off one object is what stops the app's add-on code from
 * mistaking one for the other, which is a mistake with no visible symptom:
 * the selection is attributed to the wrong group, or dropped.
 */
class AppAddonGroups {

	/**
	 * A dish's add-on groups, in the website's own order.
	 *
	 * @param int $product_id Product id.
	 * @return array[] Each entry: `id`, `position`, `field_name`, `group`.
	 */
	public static function for_product( $product_id ) {
		$product_id = (int) $product_id;
		$groups     = FrontendPAddon::get_instance()->addon_lists( $product_id );

		if ( ! is_array( $groups ) ) {
			return [];
		}

		$out      = [];
		$position = 0;

		foreach ( $groups as $key => $group ) {
			if ( empty( $group ) || ! is_array( $group ) ) {
				continue;
			}

			$out[] = [
				'id'       => (string) $key,
				'position' => $position,
				// The website's own formula, built from the position rather
				// than the key, because that is what `add_data_to_cart()`
				// counts with when it stamps a cart entry.
				'field_name' => sanitize_title( $product_id . '-' . ( $group['title'] ?? '' ) . '-' . $position ),
				'group'      => $group,
			];

			$position++;
		}

		return $out;
	}

	/**
	 * The same list, keyed by the id the app was given.
	 *
	 * @param int $product_id Product id.
	 * @return array[]
	 */
	public static function by_id( $product_id ) {
		$out = [];

		foreach ( self::for_product( $product_id ) as $entry ) {
			$out[ $entry['id'] ] = $entry;
		}

		return $out;
	}

	/**
	 * True when adding this dish with no selections at all would be refused.
	 *
	 * This is the question the mobile app's quick-add `+` has to answer
	 * *before* it fires: WooCommerce's own `has_options` knows about variable
	 * products and nothing about add-ons, so a simple dish carrying a
	 * required group looks one-tap addable and is not.
	 *
	 * @param int $product_id Product id.
	 * @return bool
	 */
	public static function requires_choices( $product_id ) {
		foreach ( self::for_product( $product_id ) as $entry ) {
			if ( self::requires_choice( $entry['group'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * True when one group must be answered for the add to go through.
	 *
	 * The single home for the rule, because `AppCartAddons` enforces it and
	 * `AppProductStoreApi` advertises it: were they to drift, the app would
	 * offer a one-tap add the server then refuses, or route a dish to the
	 * dish screen that needed nothing.
	 *
	 * A free-text group is only mandatory when it says so. A group of options
	 * is also mandatory when it asks for a minimum number of them, which the
	 * admin screen allows without ticking `required`.
	 *
	 * @param array $group Stored group.
	 * @return bool
	 */
	public static function requires_choice( array $group ) {
		$required = ! empty( $group['required'] );

		if ( in_array( (string) ( $group['type'] ?? '' ), [ 'text', 'textarea' ], true ) ) {
			return $required;
		}

		return $required || (int) ( $group['min_selection'] ?? 0 ) > 0;
	}

	/**
	 * The same list, keyed by the `field_name` stored on each cart entry.
	 *
	 * @param int $product_id Product id.
	 * @return array[]
	 */
	public static function by_field_name( $product_id ) {
		$out = [];

		foreach ( self::for_product( $product_id ) as $entry ) {
			$out[ $entry['field_name'] ] = $entry;
		}

		return $out;
	}
}
