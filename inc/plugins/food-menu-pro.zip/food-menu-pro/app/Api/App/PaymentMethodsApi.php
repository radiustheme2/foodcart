<?php
/**
 * The store's payment methods, for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

/**
 * `GET fmp/v1/app/payment-methods` — how this store can be paid.
 *
 * **Why the app cannot work this out for itself.** The Store API's cart
 * already reports which gateway ids are available for *that cart*, which is
 * the right source for availability — but ids only. The words beside the
 * radio button are the merchant's: WooCommerce's own title and description,
 * translated, and renamed often enough that "Cash on delivery" cannot be
 * hard-coded in the client. A store that calls it "Pay the rider" means it.
 *
 * **`supported` is the app's reach, not the store's.** A gateway the app
 * cannot finish — anything that wants a redirect or a native SDK — is still
 * listed, so a store running only Stripe gets an explanation rather than an
 * empty payment section. Cash on delivery is the only one v1 can complete;
 * `fmp_app_supported_gateways` opens that up without a release.
 *
 * Enabled, not available: availability depends on the cart, and the cart is
 * the Store API's business. This list is stable for the session, which is why
 * it is a route of its own rather than more fields on the cart.
 */
class PaymentMethodsApi {

	use SingletonTrait;

	/**
	 * Gateways the app can carry through to a placed order on its own.
	 *
	 * @var string[]
	 */
	const APP_SUPPORTED = [ 'cod' ];

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			AppApiFns::REST_NAMESPACE,
			AppApiFns::PREFIX . '/payment-methods',
			[
				'methods'             => 'GET',
				// Public, like the menu: what a store accepts is not private,
				// and the checkout screen reads it before the customer has
				// committed to anything.
				'callback'            => [ $this, 'get_payment_methods' ],
				'permission_callback' => '__return_true',
			]
		);
	}

	/**
	 * `GET /app/payment-methods`.
	 *
	 * @return WP_REST_Response
	 */
	public function get_payment_methods() {
		$methods   = [];
		$supported = $this->supported_ids();

		foreach ( $this->gateways() as $gateway ) {
			// `enabled` rather than `is_available()`: the latter asks about a
			// cart this request does not have, and would quietly drop a
			// gateway that is perfectly fine for the customer's real cart.
			if ( 'yes' !== $gateway->enabled ) {
				continue;
			}

			$id = (string) $gateway->id;

			$methods[] = [
				'id'          => $id,
				// The merchant's own words, already translated. Rendered as
				// they are; the app never composes a label for a gateway.
				'title'       => (string) $gateway->get_title(),
				'description' => (string) $gateway->get_description(),
				'supported'   => in_array( $id, $supported, true ),
			];
		}

		return new WP_REST_Response(
			[
				'default' => $this->default_id( $methods ),
				'methods' => $methods,
			],
			200
		);
	}

	/**
	 * Every registered gateway, in the order the store sorted them.
	 *
	 * @return \WC_Payment_Gateway[]
	 */
	private function gateways() {
		if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways() ) {
			return [];
		}

		return (array) WC()->payment_gateways()->payment_gateways();
	}

	/**
	 * Which gateway ids the app can complete.
	 *
	 * @return string[]
	 */
	private function supported_ids() {
		return array_map(
			'strval',
			(array) apply_filters( 'fmp_app_supported_gateways', self::APP_SUPPORTED )
		);
	}

	/**
	 * What the app should preselect: the first enabled gateway it can
	 * actually finish, or nothing when there is none.
	 *
	 * @param array $methods Methods payload.
	 * @return string
	 */
	private function default_id( array $methods ) {
		foreach ( $methods as $method ) {
			if ( ! empty( $method['supported'] ) ) {
				return (string) $method['id'];
			}
		}

		return '';
	}
}
