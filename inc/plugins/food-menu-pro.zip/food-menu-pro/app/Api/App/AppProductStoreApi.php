<?php
/**
 * The plugin's own block on WooCommerce Store API product responses.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Controllers\ProductFoodData\ProductFoodDataFns;

/**
 * Adds the `food-menu-pro` extension block to Store API products.
 *
 * Everything the mobile app needs about a dish that WooCommerce does not
 * describe goes here: the ingredient and nutrition rows, and whether the dish
 * can be added to a cart without the customer choosing anything first.
 *
 * **One class per endpoint and namespace, by necessity.** WooCommerce keys
 * registered extensions as `[ endpoint ][ namespace ]`, so a second
 * `woocommerce_store_api_register_endpoint_data()` call naming the product
 * schema and `food-menu-pro` would silently *replace* this one rather than
 * add to it — no warning, just a field quietly gone. Anything new about a
 * product belongs in the payload below, not in a class of its own.
 *
 * Registered under the plugin's own namespace, so it stays additive: existing
 * consumers of the product schema see exactly what they saw before. Mirrors
 * how PickupDelivery already extends the checkout schema.
 */
class AppProductStoreApi {

	use \RT\FoodMenuPro\Traits\SingletonTrait;

	const NAMESPACE_ID = 'food-menu-pro';

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		if ( ! ProductFoodDataFns::is_enabled() ) {
			return;
		}

		// woocommerce_blocks_loaded may already have fired by the time Pro
		// boots, so register immediately in that case — the same pattern
		// PickupDelivery uses.
		if ( did_action( 'woocommerce_blocks_loaded' ) ) {
			$this->register();
		} else {
			add_action( 'woocommerce_blocks_loaded', [ $this, 'register' ] );
		}
	}

	/**
	 * Registers the schema and data callbacks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			return;
		}

		if ( ! class_exists( '\Automattic\WooCommerce\StoreApi\Schemas\V1\ProductSchema' ) ) {
			return;
		}

		woocommerce_store_api_register_endpoint_data(
			[
				'endpoint'        => \Automattic\WooCommerce\StoreApi\Schemas\V1\ProductSchema::IDENTIFIER,
				'namespace'       => self::NAMESPACE_ID,
				'data_callback'   => [ $this, 'data' ],
				'schema_callback' => [ $this, 'schema' ],
				'schema_type'     => ARRAY_A,
			]
		);
	}

	/**
	 * Per-product payload.
	 *
	 * Both food lists are empty for a product that has no food data, which is
	 * the overwhelmingly common case, so the cost on a menu listing is
	 * negligible.
	 *
	 * @param \WC_Product $product Product object.
	 *
	 * @return array
	 */
	public function data( $product ) {
		if ( ! $product instanceof \WC_Product ) {
			return [
				'ingredients'      => [],
				'nutrition'        => [],
				'requires_choices' => false,
			];
		}

		// A variation inherits both from its parent: the food fields are only
		// editable on the parent product screen, and add-on groups are stored
		// against the parent too.
		$post_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();

		return [
			'ingredients'      => ProductFoodDataFns::get_ingredients( $post_id ),
			'nutrition'        => ProductFoodDataFns::get_nutrition( $post_id ),
			'requires_choices' => AppAddonGroups::requires_choices( $post_id ),
		];
	}

	/**
	 * Schema for the payload above.
	 *
	 * @return array
	 */
	public function schema() {
		return [
			'ingredients'      => [
				'description' => __( 'Ingredients for this dish.', 'food-menu-pro' ),
				'type'        => 'array',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
				'items'       => [
					'type'       => 'object',
					'properties' => self::row_schema(),
				],
			],
			'nutrition'        => [
				'description' => __( 'Nutrition facts for this dish.', 'food-menu-pro' ),
				'type'        => 'array',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
				'items'       => [
					'type'       => 'object',
					'properties' => self::row_schema(),
				],
			],
			'requires_choices' => [
				'description' => __( 'Whether an add-on group must be answered before this dish can be added to the cart.', 'food-menu-pro' ),
				'type'        => 'boolean',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
		];
	}

	/**
	 * Shared shape of one ingredient or nutrition row.
	 *
	 * @return array
	 */
	private static function row_schema() {
		return [
			'id'    => [
				'description' => __( 'Term ID.', 'food-menu-pro' ),
				'type'        => 'integer',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'name'  => [
				'description' => __( 'Term name.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'value' => [
				'description' => __( 'Amount, as entered. May be empty.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
			'unit'  => [
				'description' => __( 'Unit label. May be empty.', 'food-menu-pro' ),
				'type'        => 'string',
				'context'     => [ 'view', 'edit' ],
				'readonly'    => true,
			],
		];
	}
}
