<?php
/**
 * Customer wishlist REST API for the mobile app.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\App;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * `GET|POST fmp/v1/app/wishlist` and `DELETE fmp/v1/app/wishlist/{product_id}`.
 *
 * Favourites are stored against the WordPress user, so they follow the
 * customer between devices rather than living in app storage. Authenticated by
 * the bearer token from `AuthApi`, which resolves into the real current user,
 * so the permission check is simply "is somebody signed in".
 *
 * `GET` returns **whole Store API product payloads**, not bare IDs. The app's
 * wishlist screen draws the same dish cards as the menu, so handing back IDs
 * would force a second round trip and give the client a list it cannot render
 * on its own. The payloads are produced by dispatching the Store API's own
 * products route internally, so there is no second product serializer to keep
 * in step — and the `food-menu-pro` extension fields (ingredients, nutrition)
 * come along for free.
 */
class WishlistApi {

	use SingletonTrait;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		$namespace = AppApiFns::REST_NAMESPACE;
		$prefix    = AppApiFns::PREFIX . '/wishlist';

		register_rest_route(
			$namespace,
			$prefix,
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_wishlist' ],
					'permission_callback' => [ $this, 'permission' ],
				],
				[
					'methods'             => 'POST',
					'callback'            => [ $this, 'add_item' ],
					'permission_callback' => [ $this, 'permission' ],
					'args'                => [
						'product_id' => [
							'required'          => true,
							'type'              => 'integer',
							'minimum'           => 1,
							'sanitize_callback' => 'absint',
							'validate_callback' => 'rest_validate_request_arg',
						],
					],
				],
			]
		);

		// The ID is in the path rather than the body: a DELETE body is legal
		// but widely dropped by proxies and HTTP clients.
		register_rest_route(
			$namespace,
			$prefix . '/(?P<product_id>\d+)',
			[
				'methods'             => 'DELETE',
				'callback'            => [ $this, 'remove_item' ],
				'permission_callback' => [ $this, 'permission' ],
				'args'                => [
					'product_id' => [
						'required'          => true,
						'type'              => 'integer',
						'minimum'           => 1,
						'sanitize_callback' => 'absint',
						'validate_callback' => 'rest_validate_request_arg',
					],
				],
			]
		);
	}

	/**
	 * Anyone signed in may read and write their own wishlist.
	 *
	 * @return bool|WP_Error
	 */
	public function permission() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'fmp_app_not_authenticated',
				__( 'You must be signed in to do that.', 'food-menu-pro' ),
				[ 'status' => 401 ]
			);
		}

		return true;
	}

	/**
	 * `GET /app/wishlist`.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_wishlist() {
		$ids = AppWishlist::all( get_current_user_id() );

		if ( ! $ids ) {
			return AppApiFns::no_store(
				new WP_REST_Response(
					[
						'items'       => [],
						'product_ids' => [],
					],
					200
				)
			);
		}

		$items = $this->hydrate( $ids );

		if ( is_wp_error( $items ) ) {
			return $items;
		}

		// `product_ids` is the IDs of what is actually in `items`, not of what
		// is in storage. The two differ when a favourited dish is currently
		// off the menu, and the app uses this list to decide which hearts are
		// filled — so a heart it cannot show must not be in it.
		$present = array_values(
			array_filter(
				array_map(
					function ( $item ) {
						return isset( $item['id'] ) ? (int) $item['id'] : 0;
					},
					$items
				)
			)
		);

		return AppApiFns::no_store(
			new WP_REST_Response(
				[
					'items'       => $items,
					'product_ids' => $present,
				],
				200
			)
		);
	}

	/**
	 * `POST /app/wishlist`.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function add_item( $request ) {
		$product_id = (int) $request['product_id'];
		$checked    = AppWishlist::check_product( $product_id );

		if ( is_wp_error( $checked ) ) {
			return $checked;
		}

		$added = AppWishlist::add( get_current_user_id(), $product_id );

		if ( is_wp_error( $added ) ) {
			return $added;
		}

		return AppApiFns::no_store(
			new WP_REST_Response(
				[
					'product_id'  => $product_id,
					'in_wishlist' => true,
				],
				$added ? 201 : 200
			)
		);
	}

	/**
	 * `DELETE /app/wishlist/{product_id}`.
	 *
	 * Deliberately does not check that the product still exists or is on the
	 * menu: removing a favourite must keep working for a dish that has been
	 * deleted, or the customer could never clear it.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function remove_item( $request ) {
		$product_id = (int) $request['product_id'];

		AppWishlist::remove( get_current_user_id(), $product_id );

		return AppApiFns::no_store(
			new WP_REST_Response(
				[
					'product_id'  => $product_id,
					'in_wishlist' => false,
				],
				200
			)
		);
	}

	/**
	 * Turn product IDs into Store API product payloads, in the given order.
	 *
	 * Dispatched internally rather than serialized here, so the app's wishlist
	 * cards are built from byte-identical payloads to its menu cards.
	 *
	 * @param int[] $ids Product IDs, newest favourite first.
	 * @return array|WP_Error
	 */
	private function hydrate( array $ids ) {
		$items = [];

		// `per_page` tops out at 100, which `AppWishlist::MAX_ITEMS` matches —
		// but the cap is filterable, so do not assume one page is enough.
		foreach ( array_chunk( $ids, 100 ) as $chunk ) {
			$request = new WP_REST_Request( 'GET', '/wc/store/v1/products' );
			$request->set_query_params(
				[
					'include'            => $chunk,
					'per_page'           => count( $chunk ),
					// `post__in` ordering, so the Store API hands the dishes
					// back in wishlist order and nothing needs re-sorting.
					'orderby'            => 'include',
					// The same visibility the menu screens ask for, so the
					// wishlist can never show a dish the menu hides.
					'catalog_visibility' => 'catalog',
				]
			);

			$response = rest_do_request( $request );

			if ( $response->is_error() ) {
				return $response->as_error();
			}

			$data = $response->get_data();

			if ( is_array( $data ) ) {
				$items = array_merge( $items, $data );
			}
		}

		return $items;
	}
}
