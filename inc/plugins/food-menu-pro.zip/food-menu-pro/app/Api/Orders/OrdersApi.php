<?php
/**
 * Orders REST API class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\Orders;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\PickupDelivery\PickupDeliveryFns;
use RT\FoodMenuPro\Hooks\InventoryHooks;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

class OrdersApi {

	use SingletonTrait;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		$namespace = 'fmp/v1';

		// Per-menu gates — the dashboard UI hides menus, these enforce them.
		$read   = FnsPro::menu_permission( [ 'dashboard', 'orders', 'order-read', 'order-edit', 'order-create', 'kitchen-monitor' ] );
		$create = FnsPro::menu_permission( [ 'order-create' ] );
		$edit   = FnsPro::menu_permission( [ 'order-edit', 'order-create' ] ); // A new order gets its items through the edit routes.
		$lookup = FnsPro::menu_permission( FnsPro::DASHBOARD_MENUS ); // Product search / categories / locations serve every screen.

		register_rest_route( $namespace, '/orders', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_orders' ],
			'permission_callback' => $read,
		] );

		register_rest_route( $namespace, '/orders/(?P<id>\d+)', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_order' ],
			'permission_callback' => $read,
		] );

		register_rest_route( $namespace, '/orders', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'create_order' ],
			'permission_callback' => $create,
		] );

		register_rest_route( $namespace, '/orders/(?P<id>\d+)', [
			'methods'             => 'PUT',
			'callback'            => [ $this, 'update_order' ],
			'permission_callback' => $edit,
		] );

		register_rest_route( $namespace, '/orders/(?P<id>\d+)/items', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'add_item' ],
			'permission_callback' => $edit,
		] );

		register_rest_route( $namespace, '/orders/(?P<id>\d+)/items/(?P<item_id>\d+)', [
			'methods'             => 'PUT',
			'callback'            => [ $this, 'update_item' ],
			'permission_callback' => $edit,
		] );

		register_rest_route( $namespace, '/orders/(?P<id>\d+)/items/(?P<item_id>\d+)', [
			'methods'             => 'DELETE',
			'callback'            => [ $this, 'delete_item' ],
			'permission_callback' => $edit,
		] );

		register_rest_route( $namespace, '/orders/(?P<id>\d+)/recalculate', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'recalculate_order' ],
			'permission_callback' => $edit,
		] );

		register_rest_route( $namespace, '/orders/statuses', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_statuses' ],
			'permission_callback' => $read,
		] );

		register_rest_route( $namespace, '/orders/products/search', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'search_products' ],
			'permission_callback' => $lookup,
		] );

		register_rest_route( $namespace, '/orders/products', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_products' ],
			'permission_callback' => $lookup,
		] );

		register_rest_route( $namespace, '/orders/products/(?P<id>\d+)/options', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_product_options' ],
			'permission_callback' => $lookup,
		] );

		register_rest_route( $namespace, '/orders/product-categories', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_product_categories' ],
			'permission_callback' => $lookup,
		] );

		register_rest_route( $namespace, '/orders/locations', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_locations' ],
			'permission_callback' => $lookup,
		] );
	}

	/**
	 * Return the food-location terms available to the current user.
	 *
	 * Users who can manage all locations get the full list and the response
	 * carries `manage_all => true` so the React side can show the
	 * "All Locations" reset option. Scoped users only receive their
	 * assigned terms (plus the descendants needed to render a tree).
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_locations( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$manage_all = FnsPro::user_can_manage_all_locations();
		$allowed    = FnsPro::get_user_allowed_locations();

		$terms = get_terms( [
			'taxonomy'   => 'tpl-food-location',
			'hide_empty' => false,
		] );

		if ( is_wp_error( $terms ) ) {
			$terms = [];
		}

		// Build the visible set of term IDs for scoped users:
		// each allowed term + all of its descendants.
		$visible_ids = null;
		if ( ! $manage_all ) {
			$visible_ids = [];
			foreach ( (array) $allowed as $tid ) {
				$visible_ids = array_merge( $visible_ids, FnsPro::expand_location_with_descendants( $tid ) );
			}
			$visible_ids = array_values( array_unique( $visible_ids ) );
		}

		$items = [];
		foreach ( $terms as $term ) {
			if ( is_array( $visible_ids ) && ! in_array( $term->term_id, $visible_ids, true ) ) {
				continue;
			}

			$items[] = [
				'id'        => (int) $term->term_id,
				'name'      => $term->name,
				'parent'    => (int) $term->parent,
				'has_child' => ! empty( get_term_children( $term->term_id, 'tpl-food-location' ) ),
			];
		}

		return rest_ensure_response( [
			'locations'  => $items,
			'manage_all' => (bool) $manage_all,
		] );
	}

	/**
	 * Verify nonce from request header.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return bool|\WP_Error
	 */
	private function verify_nonce( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}
		return true;
	}

	/**
	 * Reject reads/writes on orders the current user has no permission for.
	 *
	 * Scoped users (one or more `fmp_assigned_locations`) can only touch
	 * orders whose location matches their allow-list. Users who can manage
	 * all locations pass through.
	 *
	 * @param \WC_Order $order Order to gate.
	 *
	 * @return true|\WP_Error
	 */
	private function ensure_order_in_user_scope( $order ) {
		$allowed = FnsPro::get_user_allowed_locations();

		if ( FnsPro::order_matches_allowed_locations( $order, $allowed ) ) {
			return true;
		}

		return new \WP_Error( 'forbidden_location', 'You are not assigned to this order\'s location.', [ 'status' => 403 ] );
	}

	/**
	 * Search for order IDs matching a search term across multiple fields.
	 *
	 * @param string $search Search term.
	 *
	 * @return array Array of matching order IDs.
	 */
	private function search_order_ids( $search ) {
		global $wpdb;

		// Strip leading # (users often type #2233).
		$search    = ltrim( $search, '#' );
		$order_ids = [];
		$uses_hpos = $this->is_hpos_enabled();

		// 1. Order ID match (numeric input) — exact lookup, no SQL LIKE needed.
		if ( is_numeric( $search ) ) {
			$order = wc_get_order( (int) $search );
			if ( $order && $order->get_type() === 'shop_order' ) {
				$order_ids[] = $order->get_id();
			}

			return $order_ids;
		}

		// 2. Search by customer name, email, or phone.
		$like = '%' . $wpdb->esc_like( $search ) . '%';

		if ( $uses_hpos ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$meta_results = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT oa.order_id FROM {$wpdb->prefix}wc_order_addresses oa
					WHERE oa.address_type = 'billing'
					AND (oa.first_name LIKE %s OR oa.last_name LIKE %s OR oa.email LIKE %s OR oa.phone LIKE %s)
					LIMIT 200",
					$like,
					$like,
					$like,
					$like
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$meta_results = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT pm.post_id FROM {$wpdb->postmeta} pm
					INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id AND p.post_type = 'shop_order'
					WHERE pm.meta_key IN ('_billing_first_name', '_billing_last_name', '_billing_email', '_billing_phone')
					AND pm.meta_value LIKE %s
					LIMIT 200",
					$like
				)
			);
		}
		$order_ids = array_merge( $order_ids, array_map( 'intval', $meta_results ) );

		// 3. Full name search (first + last name combination).
		if ( strpos( $search, ' ' ) !== false ) {
			$parts = explode( ' ', $search, 2 );
			$first = '%' . $wpdb->esc_like( trim( $parts[0] ) ) . '%';
			$last  = '%' . $wpdb->esc_like( trim( $parts[1] ) ) . '%';

			if ( $uses_hpos ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$name_results = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT DISTINCT oa.order_id FROM {$wpdb->prefix}wc_order_addresses oa
						WHERE oa.address_type = 'billing'
						AND oa.first_name LIKE %s AND oa.last_name LIKE %s
						LIMIT 200",
						$first,
						$last
					)
				);
			} else {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$name_results = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT DISTINCT fn.post_id FROM {$wpdb->postmeta} fn
						INNER JOIN {$wpdb->postmeta} ln ON fn.post_id = ln.post_id AND ln.meta_key = '_billing_last_name' AND ln.meta_value LIKE %s
						INNER JOIN {$wpdb->posts} p ON p.ID = fn.post_id AND p.post_type = 'shop_order'
						WHERE fn.meta_key = '_billing_first_name' AND fn.meta_value LIKE %s
						LIMIT 200",
						$last,
						$first
					)
				);
			}
			$order_ids = array_merge( $order_ids, array_map( 'intval', $name_results ) );
		}

		return array_unique( $order_ids );
	}

	/**
	 * Check if WooCommerce HPOS (High-Performance Order Storage) is enabled.
	 *
	 * @return bool
	 */
	private function is_hpos_enabled() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class ) ) {
			return \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		}
		return false;
	}

	/**
	 * Format order data for JSON response.
	 *
	 * @param \WC_Order $order
	 * @param bool      $include_items
	 *
	 * @return array
	 */
	private function format_order( $order, $include_items = false ) {
		$qr_table_name = $order->get_meta( 'fmp_qr_table_name' ) ?: '';
		$schedule      = FnsPro::get_order_schedule( $order );

		$data = [
			// Scheduling — the dashboard renders and edits these directly.
			// The `_iso` pair is what the date/time pickers bind to; the plain
			// values stay in the site's display format, which is what checkout
			// stores and what slot counting matches on.
			'order_type_label' => $schedule['label'],
			'order_date'       => $schedule['date'],
			'order_time'       => $schedule['time'],
			'order_date_iso'   => $schedule['date'] ? gmdate( 'Y-m-d', strtotime( $schedule['date'] ) ) : '',
			'order_time_iso'   => $schedule['time'] ? gmdate( 'H:i', strtotime( $schedule['time'] ) ) : '',
			'dinein_table'     => $schedule['table'],
			'location_id'      => (int) $order->get_meta( 'fmp_location_id' ),
			'location_name'    => (string) $order->get_meta( 'fmp_location_name' ),
			'id'             => $order->get_id(),
			'status'         => $order->get_status(),
			'status_label'   => wc_get_order_status_name( $order->get_status() ),
			// WooCommerce's own rule: line items may only be changed while the
			// order is Pending, On hold or a draft. Past that the order has taken
			// stock and money, so the dashboard locks its basket the way wp-admin
			// does rather than letting staff edit a completed order.
			'is_editable'    => $order->is_editable(),
			'is_new'         => 'yes' === $order->get_meta( '_fmp_is_new' ),
			'date_created'   => $order->get_date_created() ? $order->get_date_created()->format( 'Y-m-d H:i:s' ) : '',
			'total'          => (float) $order->get_total(),
			'subtotal'       => 0,
			'currency'       => $order->get_currency(),
			'payment_method' => $order->get_payment_method_title(),
			'customer_note'  => $order->get_customer_note(),
			'items_count'    => $order->get_item_count(),
			'order_type'     => $order->get_meta( 'fmp_order_time_type' ) ?: '',
			// `table_name` stays QR-only so the QR badge keeps its meaning; the
			// dine-in table is exposed separately as `dinein_table`.
			'table_name'     => $qr_table_name,
			'is_qr_order'    => ! empty( $qr_table_name ),
			'customer'       => [
				'first_name' => $order->get_billing_first_name(),
				'last_name'  => $order->get_billing_last_name(),
				'email'      => $order->get_billing_email(),
				'phone'      => $order->get_billing_phone(),
			],
			'billing'        => [
				'address_1' => $order->get_billing_address_1(),
				'address_2' => $order->get_billing_address_2(),
				'city'      => $order->get_billing_city(),
				'state'     => $order->get_billing_state(),
				'postcode'  => $order->get_billing_postcode(),
				'country'   => $order->get_billing_country(),
			],
			'shipping'       => [
				'address_1' => $order->get_shipping_address_1(),
				'address_2' => $order->get_shipping_address_2(),
				'city'      => $order->get_shipping_city(),
				'state'     => $order->get_shipping_state(),
				'postcode'  => $order->get_shipping_postcode(),
				'country'   => $order->get_shipping_country(),
			],
		];

		// Calculate subtotal.
		$items_subtotal = 0;
		foreach ( $order->get_items() as $item ) {
			$items_subtotal += $item->get_subtotal();
		}
		$data['subtotal'] = (float) $items_subtotal;

		// Custom fields.
		$custom_fields = $order->get_meta( '_fmp_custom_fields' );
		$data['custom_fields'] = is_array( $custom_fields ) ? $custom_fields : [];

		if ( $include_items ) {
			$data['items'] = [];
			foreach ( $order->get_items() as $item_id => $item ) {
				$product    = $item->get_product();
				$unit_price = $item->get_quantity() > 0 ? $item->get_total() / $item->get_quantity() : 0;

				$stock_info = 'N/A';
				if ( $product && $product->managing_stock() ) {
					$stock_info = $product->get_stock_quantity();
				} elseif ( $product ) {
					$stock_status_options = wc_get_product_stock_status_options();
					$stock_info           = $stock_status_options[ $product->get_stock_status() ] ?? 'N/A';
				}

				$data['items'][] = [
					'item_id'      => $item_id,
					'product_id'   => $item->get_product_id(),
					'name'         => $item->get_name(),
					'quantity'     => $item->get_quantity(),
					'unit_price'   => (float) $unit_price,
					'total'        => (float) $item->get_total(),
					'stock'        => $stock_info,
					'manage_stock' => $product ? $product->managing_stock() : false,
				];
			}
		}

		return $data;
	}

	/**
	 * Get orders list.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_orders( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$page           = max( 1, (int) $request->get_param( 'page' ) );
		$per_page       = max( 1, (int) $request->get_param( 'per_page' ) ?: 10 );
		$status         = sanitize_text_field( $request->get_param( 'status' ) );
		$search         = sanitize_text_field( $request->get_param( 'search' ) );
		$from           = sanitize_text_field( $request->get_param( 'from' ) );
		$to             = sanitize_text_field( $request->get_param( 'to' ) );
		$payment_method = sanitize_text_field( $request->get_param( 'payment_method' ) );
		$new_only       = '1' === (string) $request->get_param( 'new_only' );
		$include_raw    = $request->get_param( 'include' );
		$include        = [];
		if ( ! empty( $include_raw ) ) {
			$include = array_filter( array_map( 'intval', explode( ',', (string) $include_raw ) ) );
		}

		// Resolve location filter against the user's allow-list.
		$allowed_locations = FnsPro::get_user_allowed_locations();
		$requested_loc     = (int) $request->get_param( 'location_id' );
		$location_filter   = FnsPro::resolve_location_filter( $requested_loc, $allowed_locations );

		// Forbidden — requested a location outside the user's scope, or
		// scoped user with no allowed locations.
		if ( $location_filter === false ) {
			return rest_ensure_response( [
				'orders' => [],
				'meta'   => [ 'total' => 0, 'current' => $page, 'pageSize' => $per_page ],
				'stats'  => [ 'total_orders' => 0, 'new_today' => 0, 'completed_today' => 0, 'new_count' => 0 ],
			] );
		}

		$location_meta_clause = is_array( $location_filter ) ? FnsPro::build_location_meta_query( $location_filter ) : [];

		$args = [
			'type'    => 'shop_order',
			'limit'   => $per_page,
			'offset'  => ( $page - 1 ) * $per_page,
			'return'  => 'objects',
			'order'   => 'DESC',
			'orderby' => 'date',
		];

		$meta_query_parts = [];

		if ( $new_only ) {
			$meta_query_parts[] = [
				'key'   => '_fmp_is_new',
				'value' => 'yes',
			];
		}

		if ( ! empty( $location_meta_clause ) ) {
			$meta_query_parts[] = $location_meta_clause;
		}

		if ( ! empty( $meta_query_parts ) ) {
			$args['meta_query'] = count( $meta_query_parts ) === 1
				? $meta_query_parts
				: array_merge( [ 'relation' => 'AND' ], $meta_query_parts );
		}

		if ( ! empty( $include ) ) {
			// Use direct wc_get_order() lookup for HPOS-compatibility.
			// post__in / include args don't reliably filter under HPOS.
			$matched     = array_filter( array_map( 'wc_get_order', $include ) );
			$matched     = array_filter( $matched, fn( $order ) => $order->get_type() === 'shop_order' );

			// Re-apply the user's location clamp on the include set so a tampered
			// `?include=…` list cannot pull in orders from other branches.
			if ( $location_filter !== null ) {
				$matched = array_filter( $matched, static function ( $order ) use ( $location_filter ) {
					return FnsPro::order_matches_allowed_locations( $order, $location_filter );
				} );
			}

			$matched     = array_values( $matched );
			$total       = count( $matched );
			$items       = [];
			foreach ( $matched as $order ) {
				$items[] = $this->format_order( $order, false );
			}
			return rest_ensure_response( [
				'orders' => $items,
				'meta'   => [
					'total'    => $total,
					'current'  => 1,
					'pageSize' => $total,
				],
			] );
		}

		if ( $status && 'all' !== $status ) {
			$args['status'] = 'wc-' . $status;
		}

		if ( $payment_method ) {
			$args['payment_method'] = $payment_method;
		}

		if ( $from ) {
			$args['date_created'] = '>=' . $from;
		}

		if ( $to ) {
			if ( isset( $args['date_created'] ) ) {
				$args['date_created'] .= '...' . $to . ' 23:59:59';
			} else {
				$args['date_created'] = '<=' . $to . ' 23:59:59';
			}
		}

		if ( $search ) {
			$matched_ids = $this->search_order_ids( $search );
			if ( empty( $matched_ids ) ) {
				return rest_ensure_response( [
					'orders' => [],
					'meta'   => [
						'total'    => 0,
						'current'  => $page,
						'pageSize' => $per_page,
					],
				] );
			}

			// Fetch matched orders and apply remaining filters in PHP.
			$all_matched = array_filter( array_map( 'wc_get_order', $matched_ids ) );
			$all_matched = array_filter( $all_matched, fn( $order ) => $order->get_type() === 'shop_order' );

			// Apply status filter.
			if ( $status && 'all' !== $status ) {
				$all_matched = array_filter( $all_matched, function ( $order ) use ( $status ) {
					return $order->get_status() === $status;
				} );
			}

			// Apply payment method filter.
			if ( $payment_method ) {
				$all_matched = array_filter( $all_matched, function ( $order ) use ( $payment_method ) {
					return $order->get_payment_method() === $payment_method;
				} );
			}

			// Apply date filters.
			if ( $from ) {
				$from_ts     = strtotime( $from );
				$all_matched = array_filter( $all_matched, function ( $order ) use ( $from_ts ) {
					$created = $order->get_date_created();
					return $created && $created->getTimestamp() >= $from_ts;
				} );
			}
			if ( $to ) {
				$to_ts       = strtotime( $to . ' 23:59:59' );
				$all_matched = array_filter( $all_matched, function ( $order ) use ( $to_ts ) {
					$created = $order->get_date_created();
					return $created && $created->getTimestamp() <= $to_ts;
				} );
			}

			// Apply excluded product types (search branch operates on an already-bounded set).
			$search_excluded_types = FnsPro::get_excluded_product_types();
			if ( ! empty( $search_excluded_types ) ) {
				$all_matched = array_filter( $all_matched, static function ( $order ) use ( $search_excluded_types ) {
					return ! FnsPro::order_has_excluded_product_type( $order, $search_excluded_types );
				} );
			}

			// Apply location clamp on the search branch too.
			if ( $location_filter !== null ) {
				$all_matched = array_filter( $all_matched, static function ( $order ) use ( $location_filter ) {
					return FnsPro::order_matches_allowed_locations( $order, $location_filter );
				} );
			}

			$all_matched = array_values( $all_matched );
			$total       = count( $all_matched );
			$orders      = array_slice( $all_matched, ( $page - 1 ) * $per_page, $per_page );
		} else {
			$excluded_types = FnsPro::get_excluded_product_types();
			$orders         = [];
			$total          = 0;

			FnsPro::with_excluded_product_types( $excluded_types, static function () use ( $args, &$orders, &$total ) {
				$orders = wc_get_orders( FnsPro::order_query_args( $args ) );

				$count_args           = $args;
				$count_args['limit']  = -1;
				$count_args['offset'] = 0;
				$count_args['return'] = 'ids';
				$total                = count( wc_get_orders( FnsPro::order_query_args( $count_args ) ) );
			} );
		}

		$excluded_types = FnsPro::get_excluded_product_types();

		$items = [];
		foreach ( $orders as $order ) {
			$items[] = $this->format_order( $order, false );
		}

		// Order stats — filter each set through product type exclusion + the
		// user's location clamp so badges never reveal counts from other branches.
		$today_start = wp_date( 'Y-m-d 00:00:00' );

		$loc_clause = $location_meta_clause;

		$stat_args = static function ( array $base ) use ( $loc_clause ) {
			if ( empty( $loc_clause ) ) {
				return $base;
			}
			if ( ! empty( $base['meta_query'] ) ) {
				$existing             = $base['meta_query'];
				$base['meta_query']   = [ 'relation' => 'AND', $existing, $loc_clause ];
			} else {
				$base['meta_query'] = [ $loc_clause ];
			}
			return $base;
		};

		$all_count             = $this->count_orders_excluding_types( $stat_args( [ 'type' => 'shop_order' ] ), $excluded_types );
		$new_today_count       = $this->count_orders_excluding_types( $stat_args( [ 'type' => 'shop_order', 'date_after' => $today_start ] ), $excluded_types );
		$completed_today_count = $this->count_orders_excluding_types( $stat_args( [ 'type' => 'shop_order', 'status' => [ 'wc-completed' ], 'date_after' => $today_start ] ), $excluded_types );
		$new_count             = $this->count_orders_excluding_types( $stat_args( [
			'type'       => 'shop_order',
			'meta_query' => [ [ 'key' => '_fmp_is_new', 'value' => 'yes' ] ],
		] ), $excluded_types );

		return rest_ensure_response( [
			'orders' => $items,
			'meta'   => [
				'total'    => $total,
				'current'  => $page,
				'pageSize' => $per_page,
			],
			'stats'  => [
				'total_orders'    => $all_count,
				'new_today'       => $new_today_count,
				'completed_today' => $completed_today_count,
				'new_count'       => $new_count,
			],
		] );
	}

	/**
	 * Get single order.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_order( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$order = wc_get_order( (int) $request->get_param( 'id' ) );
		if ( ! $order || $order->get_type() !== 'shop_order' ) {
			return new \WP_Error( 'not_found', 'Order not found', [ 'status' => 404 ] );
		}

		$gate = $this->ensure_order_in_user_scope( $order );
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		return rest_ensure_response( $this->format_order( $order, true ) );
	}

	/**
	 * Create a new order.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function create_order( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$initial_status = sanitize_text_field( $request->get_param( 'status' ) );
		$valid_statuses = wc_get_order_statuses();
		if ( ! $initial_status || ! isset( $valid_statuses[ 'wc-' . $initial_status ] ) ) {
			$initial_status = 'pending';
		}

		$order = wc_create_order( [ 'status' => $initial_status ] );
		if ( is_wp_error( $order ) ) {
			return new \WP_Error( 'create_failed', 'Failed to create order', [ 'status' => 500 ] );
		}

		$this->apply_order_data( $order, $request );

		// Build the line items first so the whole basket can be weighed against
		// stock before anything is committed to the order.
		$items     = $request->get_param( 'items' );
		$new_items = [];

		if ( is_array( $items ) ) {
			foreach ( $items as $item_data ) {
				$item = is_array( $item_data ) ? $this->build_line_item( $item_data ) : null;

				if ( $item ) {
					$new_items[] = $item;
				}
			}
		}

		$stock_error = $this->check_stock( array_map(
			function ( $item ) {
				return [ 'product' => $item->get_product(), 'qty' => $item->get_quantity() ];
			},
			$new_items
		) );

		if ( is_wp_error( $stock_error ) ) {
			// `wc_create_order()` already persisted the shell, so a rejected
			// attempt would otherwise leave an empty order behind.
			$order->delete( true );

			return $stock_error;
		}

		foreach ( $new_items as $item ) {
			$order->add_item( $item );
		}

		$order->calculate_totals();
		$order->save();

		$this->maybe_reduce_stock_after_create( $order );

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Order created successfully', 'food-menu-pro' ),
			'order'   => $this->format_order( $order, true ),
		] );
	}

	/**
	 * Refuse line-item changes on an order WooCommerce considers closed.
	 *
	 * `is_editable()` is true only for Pending, On hold and drafts. Once an order
	 * is Processing, Completed, Cancelled or Refunded its stock and totals have
	 * been settled, and wp-admin removes the item controls entirely. The dashboard
	 * used to allow edits in every status — which is how a Completed order could
	 * quietly gain a dish that no stock movement ever accounted for.
	 *
	 * Status, customer details and notes stay editable throughout, exactly as in
	 * wp-admin; only the basket is locked.
	 *
	 * @param \WC_Order $order Order being changed.
	 *
	 * @return \WP_Error|null
	 */
	private function ensure_order_is_editable( $order ) {
		if ( $order->is_editable() ) {
			return null;
		}

		return new \WP_Error(
			'order_not_editable',
			sprintf(
				/* translators: %s: current order status label. */
				__( 'Items cannot be changed while the order is %s. Move it back to Pending or On hold first.', 'food-menu-pro' ),
				wc_get_order_status_name( $order->get_status() )
			),
			[ 'status' => 409 ]
		);
	}

	/**
	 * Refuse quantities the shelf cannot cover.
	 *
	 * Checkout will not let a customer oversell; the dashboard used to, happily
	 * driving stock negative. Products on backorder, or not managing stock at
	 * all, are only checked for their in-stock flag — same rules the cart uses.
	 *
	 * @param array $lines List of `[ 'product' => WC_Product|false, 'qty' => int|float ]`.
	 *
	 * @return \WP_Error|null Error when something is short, null when all is well.
	 */
	private function check_stock( array $lines ) {
		/**
		 * Allow a store to keep taking orders past its recorded stock — a kitchen
		 * that counts loosely may prefer the old behaviour.
		 *
		 * @param bool  $enforce Whether to block oversold lines. Default true.
		 * @param array $lines   The lines being checked.
		 */
		if ( ! apply_filters( 'fmp_dashboard_enforce_stock', true, $lines ) ) {
			return null;
		}

		// Two lines of the same dish have to be weighed together, or each passes
		// on its own while the pair oversells.
		$wanted   = [];
		$products = [];

		foreach ( $lines as $line ) {
			$product = $line['product'] ?? null;

			if ( ! $product instanceof \WC_Product ) {
				continue;
			}

			$id              = $product->get_id();
			$products[ $id ] = $product;
			$wanted[ $id ]   = ( $wanted[ $id ] ?? 0 ) + (float) $line['qty'];
		}

		$problems = [];

		foreach ( $wanted as $id => $qty ) {
			// Nothing more is being taken off the shelf, so there is nothing to check.
			if ( $qty <= 0 ) {
				continue;
			}

			$product = $products[ $id ];

			if ( ! $product->is_in_stock() ) {
				/* translators: %s: product name. */
				$problems[] = sprintf( __( '"%s" is out of stock.', 'food-menu-pro' ), $product->get_name() );
				continue;
			}

			if ( ! $product->managing_stock() || $product->backorders_allowed() ) {
				continue;
			}

			$available = wc_stock_amount( $product->get_stock_quantity() );

			if ( $qty > $available ) {
				$problems[] = sprintf(
					/* translators: 1: product name, 2: quantity in stock, 3: quantity requested. */
					__( 'Not enough stock for "%1$s" — %2$s left, %3$s requested.', 'food-menu-pro' ),
					$product->get_name(),
					$available,
					$qty
				);
			}
		}

		if ( empty( $problems ) ) {
			return null;
		}

		return new \WP_Error( 'insufficient_stock', implode( ' ', $problems ), [ 'status' => 400 ] );
	}

	/**
	 * How much stock a line still has to take.
	 *
	 * On an order that has already reduced stock, only the difference from what
	 * the line is currently holding will be taken. On one that has not, the whole
	 * quantity will be taken at its next status change.
	 *
	 * @param \WC_Order_Item_Product $item     Line item.
	 * @param \WC_Order              $order    Its order.
	 * @param int|float              $quantity Target quantity.
	 *
	 * @return float
	 */
	private function outstanding_stock_need( $item, $order, $quantity ): float {
		if ( ! $order->get_data_store()->get_stock_reduced( $order->get_id() ) ) {
			return (float) $quantity;
		}

		return (float) $quantity - (float) wc_stock_amount( $item->get_meta( '_reduced_stock', true ) );
	}

	/**
	 * Build a line item from the pieces the dashboard sends.
	 *
	 * The dashboard's product-options modal lets staff pick a variation and any
	 * add-ons, exactly as a customer does at checkout, and posts both back. Both
	 * used to be dropped here: the line was written against the *parent* product,
	 * so it was priced at the cheapest variation and — because stock normally
	 * lives on the variation, not the parent — reduced no stock and produced no
	 * inventory log at all.
	 *
	 * Prices come from the resolved product, never from the request, so the line
	 * total is the store's own figure. Add-on prices are taken as sent (only
	 * order managers reach this endpoint, and they can already set a line price
	 * outright) and are added to the unit price the same way the cart does.
	 *
	 * @param array $data Item payload: `product_id`, `quantity`, and optionally
	 *                    `variation_id`, `variation_attributes`, `addons`.
	 *
	 * @return \WC_Order_Item_Product|null Null when the product no longer exists.
	 */
	private function build_line_item( array $data ) {
		$product_id = (int) ( $data['product_id'] ?? 0 );
		$product    = wc_get_product( $product_id );

		if ( ! $product ) {
			return null;
		}

		$qty          = max( 1, (int) ( $data['quantity'] ?? 1 ) );
		$variation_id = (int) ( $data['variation_id'] ?? 0 );

		// Only honour a variation that really belongs to this product.
		$variation = null;

		if ( $variation_id ) {
			$candidate = wc_get_product( $variation_id );

			if ( $candidate && $candidate->is_type( 'variation' ) && (int) $candidate->get_parent_id() === $product_id ) {
				$variation = $candidate;
			} else {
				$variation_id = 0;
			}
		}

		$line_product = $variation ?: $product;
		$price        = (float) $line_product->get_price();

		$item = new \WC_Order_Item_Product();
		$item->set_product_id( $product_id );
		$item->set_variation_id( $variation_id );
		$item->set_name( $line_product->get_name() );
		$item->set_quantity( $qty );

		// Attributes come off the variation itself rather than the request, so the
		// line always describes the variation it points at. A variation set to
		// "Any" for an attribute stores no value of its own — only there do we
		// fall back to what the staff member actually picked.
		if ( $variation ) {
			$attributes = $variation->get_variation_attributes();
			$posted     = is_array( $data['variation_attributes'] ?? null ) ? $data['variation_attributes'] : [];

			foreach ( $attributes as $key => $value ) {
				if ( '' === $value && ! empty( $posted[ $key ] ) ) {
					$attributes[ $key ] = sanitize_text_field( (string) $posted[ $key ] );
				}
			}

			$item->set_variation( $attributes );
		}

		$price += $this->apply_addon_meta( $item, $data['addons'] ?? [] );

		$item->set_subtotal( $price * $qty );
		$item->set_total( $price * $qty );

		return $item;
	}

	/**
	 * Write add-on selections onto a line item and return their price per unit.
	 *
	 * Mirrors `FrontendCartAction::display_checkout_order_line_item()` so an order
	 * taken on the dashboard reads identically to one placed at checkout.
	 *
	 * @param \WC_Order_Item_Product $item   Line item.
	 * @param mixed                  $addons Add-on rows.
	 *
	 * @return float Total add-on price for a single unit.
	 */
	private function apply_addon_meta( $item, $addons ): float {
		if ( ! is_array( $addons ) || empty( $addons ) ) {
			return 0;
		}

		$total = 0;

		foreach ( $addons as $addon ) {
			if ( empty( $addon['name'] ) || ! isset( $addon['value'] ) ) {
				continue;
			}

			$addon_price = isset( $addon['price'] ) ? max( 0, (float) $addon['price'] ) : 0; // Negative add-ons would discount the order.
			$total      += $addon_price;

			$value = sanitize_text_field( (string) $addon['value'] );

			if ( ! empty( $addon['qty'] ) && (int) $addon['qty'] > 1 ) {
				$value .= ' x' . (int) $addon['qty'];
			}

			if ( $addon_price ) {
				$value .= ' (' . wp_strip_all_tags( wc_price( $addon_price ) ) . ')';
			}

			$item->add_meta_data( sanitize_text_field( (string) $addon['name'] ), $value );
		}

		if ( $total > 0 ) {
			$item->add_meta_data( '_addons_price', $total );
		}

		return $total;
	}

	/**
	 * Reduce stock for an order that was created with a stock-reducing status.
	 *
	 * `wc_create_order()` saves the order — and therefore fires the status
	 * transition — before this endpoint has added any line items. WooCommerce's
	 * `wc_maybe_reduce_stock_levels()` runs at that point against an empty order:
	 * nothing is reduced, yet it still flags the order as stock-reduced. So the
	 * items added afterwards never reduce stock, no `woocommerce_reduce_order_item_stock`
	 * fires, and no inventory log is written.
	 *
	 * Reducing here — once the items exist — mirrors what the wp-admin order screen
	 * does. `wc_reduce_stock_levels()` is used directly rather than the `maybe_`
	 * wrapper because the order-level flag is already set; the per-item
	 * `_reduced_stock` meta inside it keeps this safe to run and prevents any
	 * double reduction.
	 *
	 * @param \WC_Order $order Freshly created order, with items saved.
	 */
	private function maybe_reduce_stock_after_create( $order ) {
		/**
		 * Statuses that reduce stock on order creation. Mirrors the statuses
		 * WooCommerce itself hooks `wc_maybe_reduce_stock_levels()` to.
		 *
		 * @param string[] $statuses Order status slugs, without the `wc-` prefix.
		 * @param \WC_Order $order   The order being created.
		 */
		$statuses = apply_filters(
			'fmp_order_create_stock_reducing_statuses',
			[ 'processing', 'completed', 'on-hold' ],
			$order
		);

		if ( ! in_array( $order->get_status(), $statuses, true ) ) {
			return;
		}

		wc_reduce_stock_levels( $order );

		$order->get_data_store()->set_stock_reduced( $order->get_id(), true );
	}

	/**
	 * Update an existing order.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function update_order( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$order = wc_get_order( (int) $request->get_param( 'id' ) );
		if ( ! $order || 'shop_order' !== $order->get_type() ) { // Not refunds or other order types.
			return new \WP_Error( 'not_found', 'Order not found', [ 'status' => 404 ] );
		}

		$gate = $this->ensure_order_in_user_scope( $order );
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		// Update status.
		$new_status = sanitize_text_field( $request->get_param( 'status' ) );
		if ( $new_status ) {
			$order->update_status( $new_status, __( 'Status updated via Inventory Dashboard', 'food-menu-pro' ) );
		}

		$this->apply_order_data( $order, $request );

		$order->calculate_totals();
		$order->save();

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Order updated successfully', 'food-menu-pro' ),
			'order'   => $this->format_order( $order, true ),
		] );
	}

	/**
	 * Apply customer, billing, shipping, note data to an order.
	 *
	 * @param \WC_Order        $order
	 * @param \WP_REST_Request $request
	 */
	private function apply_order_data( $order, $request ) {
		$customer_fields = [
			'billing_first_name',
			'billing_last_name',
			'billing_email',
			'billing_phone',
			'billing_address_1',
			'billing_address_2',
			'billing_city',
			'billing_state',
			'billing_postcode',
			'billing_country',
			'shipping_address_1',
			'shipping_address_2',
			'shipping_city',
			'shipping_state',
			'shipping_postcode',
			'shipping_country',
			'customer_note',
		];

		foreach ( $customer_fields as $field ) {
			$value = $request->get_param( $field );
			if ( $value !== null ) {
				$order->{"set_$field"}( sanitize_text_field( $value ) );
			}
		}

		// Order type + schedule. Only the fields belonging to the selected type
		// are written, so switching type on an existing order doesn't leave a
		// stale date/time from the previous one in the order meta.
		$order_type = $request->get_param( 'fmp_order_time_type' );

		if ( $order_type !== null ) {
			$order_type = sanitize_key( $order_type );

			if ( ! in_array( $order_type, [ 'pickup', 'delivery', 'dinein' ], true ) ) {
				$order_type = '';
			}

			$order->update_meta_data( 'fmp_order_time_type', $order_type );

			foreach ( [ 'pickup', 'delivery', 'dinein' ] as $type ) {
				if ( $type === $order_type ) {
					continue;
				}

				$order->delete_meta_data( "fmp_{$type}_date" );
				$order->delete_meta_data( "fmp_{$type}_time" );
			}

			if ( $order_type ) {
				// The pickers send unambiguous `Y-m-d` / `H:i`. Convert to the
				// site's display format here so the meta is byte-identical to
				// what checkout writes — slot counting matches these strings
				// exactly, so a different format would silently never match.
				$order_date = $request->get_param( 'order_date' );
				$order_time = $request->get_param( 'order_time' );

				if ( $order_date !== null ) {
					$order_date = sanitize_text_field( $order_date );
					$timestamp  = $order_date ? strtotime( $order_date ) : false;

					$order->update_meta_data(
						"fmp_{$order_type}_date",
						$timestamp ? date_i18n( get_option( 'date_format', 'Y-m-d' ), $timestamp ) : ''
					);
				}

				if ( $order_time !== null ) {
					$order_time = sanitize_text_field( $order_time );
					$timestamp  = $order_time ? strtotime( $order_time ) : false;

					$order->update_meta_data(
						"fmp_{$order_type}_time",
						$timestamp ? date_i18n( get_option( 'time_format', 'H:i' ), $timestamp ) : ''
					);
				}
			}

			if ( 'dinein' === $order_type ) {
				$dinein_table = $request->get_param( 'dinein_table' );

				if ( $dinein_table !== null ) {
					// The picker sends `<location_id>:<name>` so branches with a
					// same-named table stay distinct; store just the name, which
					// is what every display surface reads.
					$order->update_meta_data(
						'fmp_dinein_table',
						sanitize_text_field( PickupDeliveryFns::dinein_table_name_from_key( $dinein_table ) )
					);
				}
			} else {
				$order->delete_meta_data( 'fmp_dinein_table' );
			}
		}

		// Save custom fields.
		$custom_fields = $request->get_param( 'custom_fields' );
		if ( is_array( $custom_fields ) ) {
			$sanitized = [];
			foreach ( $custom_fields as $key => $value ) {
				$safe_key = sanitize_key( $key );
				if ( is_array( $value ) ) {
					$sanitized[ $safe_key ] = array_map( 'sanitize_text_field', $value );
				} else {
					$sanitized[ $safe_key ] = sanitize_text_field( $value );
				}
			}
			$order->update_meta_data( '_fmp_custom_fields', $sanitized );
		}

		// Save location. The client may send fmp_location_id (term ID), and
		// optionally fmp_location_name. For scoped users we force the location
		// into one they own — they cannot create or move orders into a branch
		// they don't manage even by editing the request.
		$location_id = $request->get_param( 'fmp_location_id' );

		if ( $location_id !== null && $location_id !== '' ) {
			$location_id = (int) $location_id;
			$allowed     = FnsPro::get_user_allowed_locations();

			if ( is_array( $allowed ) ) {
				$expanded = [];
				foreach ( $allowed as $tid ) {
					$expanded = array_merge( $expanded, FnsPro::expand_location_with_descendants( $tid ) );
				}
				if ( ! in_array( $location_id, $expanded, true ) ) {
					$location_id = 0;
				}
			}

			if ( $location_id ) {
				$term = get_term( $location_id, 'tpl-food-location' );
				if ( $term && ! is_wp_error( $term ) ) {
					$order->update_meta_data( 'fmp_location_id', $location_id );
					$order->update_meta_data( 'fmp_location_name', $term->name );
				}
			} elseif ( $location_id === 0 && FnsPro::user_can_manage_all_locations() ) {
				// Explicit unset only allowed for unrestricted users.
				$order->delete_meta_data( 'fmp_location_id' );
				$order->delete_meta_data( 'fmp_location_name' );
			}
		}
	}

	/**
	 * Add an item to an order.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function add_item( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$order = wc_get_order( (int) $request->get_param( 'id' ) );
		if ( ! $order ) {
			return new \WP_Error( 'not_found', 'Order not found', [ 'status' => 404 ] );
		}

		$gate = $this->ensure_order_in_user_scope( $order );
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$locked = $this->ensure_order_is_editable( $order );
		if ( is_wp_error( $locked ) ) {
			return $locked;
		}

		$item = $this->build_line_item( [
			'product_id'           => $request->get_param( 'product_id' ),
			'quantity'             => $request->get_param( 'quantity' ),
			'variation_id'         => $request->get_param( 'variation_id' ),
			'variation_attributes' => $request->get_param( 'variation_attributes' ),
			'addons'               => $request->get_param( 'addons' ),
		] );

		if ( ! $item ) {
			return new \WP_Error( 'invalid_product', 'Product not found', [ 'status' => 400 ] );
		}

		$stock_error = $this->check_stock( [
			[
				'product' => $item->get_product(),
				'qty'     => $this->outstanding_stock_need( $item, $order, $item->get_quantity() ),
			],
		] );

		if ( is_wp_error( $stock_error ) ) {
			return $stock_error;
		}

		$order->add_item( $item );
		$order->calculate_totals();
		$item->save();

		// The order may already have reduced its stock, in which case nothing else
		// will ever account for this new line.
		InventoryHooks::get_instance()->sync_order_item_stock( $item, $order );

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Item added successfully', 'food-menu-pro' ),
			'order'   => $this->format_order( wc_get_order( $order->get_id() ), true ),
		] );
	}

	/**
	 * Update an item in an order.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function update_item( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$order = wc_get_order( (int) $request->get_param( 'id' ) );
		if ( ! $order ) {
			return new \WP_Error( 'not_found', 'Order not found', [ 'status' => 404 ] );
		}

		$gate = $this->ensure_order_in_user_scope( $order );
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$locked = $this->ensure_order_is_editable( $order );
		if ( is_wp_error( $locked ) ) {
			return $locked;
		}

		$item_id = (int) $request->get_param( 'item_id' );
		$item    = $order->get_item( $item_id );
		if ( ! $item ) {
			return new \WP_Error( 'invalid_item', 'Item not found', [ 'status' => 400 ] );
		}

		$qty   = $request->get_param( 'quantity' );
		$price = $request->get_param( 'unit_price' );

		// Derive current unit price before changing quantity.
		$old_qty    = $item->get_quantity();
		$unit_price = $price !== null ? max( 0, (float) $price ) : ( $old_qty > 0 ? (float) $item->get_total() / $old_qty : 0 );

		if ( $qty !== null ) {
			$qty = max( 1, (int) $qty );

			// Only an increase can oversell, and only the part not already held
			// by this line has to come off the shelf.
			if ( $qty > $old_qty ) {
				$stock_error = $this->check_stock( [
					[
						'product' => $item->get_product(),
						'qty'     => $this->outstanding_stock_need( $item, $order, $qty ),
					],
				] );

				if ( is_wp_error( $stock_error ) ) {
					return $stock_error;
				}
			}

			$item->set_quantity( $qty );
		}

		$item_qty = $item->get_quantity();
		$item->set_subtotal( $unit_price * $item_qty );
		$item->set_total( $unit_price * $item_qty );

		$item->save();
		$order->calculate_totals();
		$order->save();

		// Quantity moved, so the stock this line is holding has to move with it.
		if ( $qty !== null ) {
			InventoryHooks::get_instance()->sync_order_item_stock( $item, $order );
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Item updated successfully', 'food-menu-pro' ),
			'order'   => $this->format_order( wc_get_order( $order->get_id() ), true ),
		] );
	}

	/**
	 * Delete an item from an order.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function delete_item( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$order = wc_get_order( (int) $request->get_param( 'id' ) );
		if ( ! $order ) {
			return new \WP_Error( 'not_found', 'Order not found', [ 'status' => 404 ] );
		}

		$gate = $this->ensure_order_in_user_scope( $order );
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$locked = $this->ensure_order_is_editable( $order );
		if ( is_wp_error( $locked ) ) {
			return $locked;
		}

		$item_id = (int) $request->get_param( 'item_id' );

		// Give the stock back before the line is gone — once removed there is no
		// item left to read the reduced quantity from.
		$item = $order->get_item( $item_id );

		if ( $item ) {
			InventoryHooks::get_instance()->sync_order_item_stock( $item, $order, 0 );
		}

		$order->remove_item( $item_id );
		$order->calculate_totals();
		$order->save();

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Item removed successfully', 'food-menu-pro' ),
			'order'   => $this->format_order( wc_get_order( $order->get_id() ), true ),
		] );
	}

	/**
	 * Recalculate order totals.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function recalculate_order( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$order = wc_get_order( (int) $request->get_param( 'id' ) );
		if ( ! $order ) {
			return new \WP_Error( 'not_found', 'Order not found', [ 'status' => 404 ] );
		}

		$gate = $this->ensure_order_in_user_scope( $order );
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$order->calculate_totals();
		$order->save();

		return rest_ensure_response( [
			'success' => true,
			'order'   => $this->format_order( $order, true ),
		] );
	}

	/**
	 * Get available order statuses.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return WP_REST_Response
	 */
	public function get_statuses( \WP_REST_Request $request ) {
		$statuses = wc_get_order_statuses();
		$result   = [];

		foreach ( $statuses as $key => $label ) {
			if ( in_array( $key, [ 'wc-failed', 'wc-checkout-draft' ], true ) ) {
				continue;
			}
			$result[] = [
				'value' => str_replace( 'wc-', '', $key ),
				'label' => $label,
			];
		}

		return rest_ensure_response( $result );
	}

	/**
	 * Search products for adding to an order.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function search_products( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$query = sanitize_text_field( $request->get_param( 'q' ) );
		if ( strlen( $query ) < 2 ) {
			return rest_ensure_response( [] );
		}

		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 10,
			's'              => $query,
		];

		$products = get_posts( $args );
		$results  = [];

		foreach ( $products as $product_post ) {
			$product = wc_get_product( $product_post->ID );
			if ( ! $product ) {
				continue;
			}

			$stock = '';
			if ( $product->managing_stock() ) {
				$stock = $product->get_stock_quantity();
			}

			// Same price fields as the inventory list, so a product picked here shows
			// and caps identically to one opened from a row.
			$prices = FnsPro::get_product_price_fields( $product );

			$results[] = [
				'id'            => $product->get_id(),
				'name'          => $product->get_name(),
				'permalink'     => $product->get_permalink(),
				'price'         => $prices['price'],
				'regular_price' => $prices['regular_price'],
				'sale_price'    => $prices['sale_price'],
				'manage_stock'  => $product->managing_stock(),
				'stock'         => $stock,
				'stock_status'  => $product->get_stock_status(),
			];
		}

		return rest_ensure_response( $results );
	}

	/**
	 * Get paginated products with images and categories.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_products( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = max( 1, (int) $request->get_param( 'per_page' ) ?: 10 );
		$search   = sanitize_text_field( $request->get_param( 'search' ) );
		$category = (int) $request->get_param( 'category' );

		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'title',
			'order'          => 'ASC',
		];

		if ( $search ) {
			$args['s'] = $search;
		}

		if ( $category ) {
			$args['tax_query'] = [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				[
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $category,
				],
			];
		}

		$query           = new \WP_Query( $args );
		$results         = [];
		$excluded_types  = FnsPro::get_excluded_product_types();

		foreach ( $query->posts as $post ) {
			$product = wc_get_product( $post->ID );
			if ( ! $product ) {
				continue;
			}

			// Skip excluded product types.
			if ( ! empty( $excluded_types ) && in_array( $product->get_type(), $excluded_types, true ) ) {
				continue;
			}

			$image_id  = $product->get_image_id();
			$image_url = $image_id ? wp_get_attachment_image_url( $image_id ) : '';

			$categories = wp_get_post_terms( $post->ID, 'product_cat', [ 'fields' => 'all' ] );
			$cat_data   = [];
			if ( ! is_wp_error( $categories ) ) {
				foreach ( $categories as $cat ) {
					$cat_data[] = [
						'id'   => $cat->term_id,
						'name' => $cat->name,
					];
				}
			}

			$stock = '';
			if ( $product->managing_stock() ) {
				$stock = $product->get_stock_quantity();
			}

			$has_options = $product->is_type( 'variable' ) || $this->product_has_addons( $post->ID );

			$results[] = [
				'id'           => $product->get_id(),
				'name'         => $product->get_name(),
				'price'        => (float) $product->get_price(),
				'image'        => $image_url,
				'categories'   => $cat_data,
				'manage_stock' => $product->managing_stock(),
				'stock'        => $stock,
				'stock_status' => $product->get_stock_status(),
				'has_options'  => $has_options,
			];
		}

		return rest_ensure_response( [
			'products' => $results,
			'meta'     => [
				'total'      => (int) $query->found_posts,
				'current'    => $page,
				'pageSize'   => $per_page,
				'totalPages' => (int) $query->max_num_pages,
			],
		] );
	}

	/**
	 * Get product categories.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_product_categories( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$terms = get_terms( [
			'taxonomy'   => 'product_cat',
			'hide_empty' => true,
			'orderby'    => 'name',
			'order'      => 'ASC',
		] );

		if ( is_wp_error( $terms ) ) {
			return rest_ensure_response( [] );
		}

		$result = [];
		foreach ( $terms as $term ) {
			$result[] = [
				'id'    => $term->term_id,
				'name'  => $term->name,
				'count' => $term->count,
			];
		}

		return rest_ensure_response( $result );
	}

	/**
	 * Check if a product has addons (product-level or global).
	 *
	 * @param int $product_id Product ID.
	 *
	 * @return bool
	 */
	private function product_has_addons( int $product_id ): bool {
		// Addons only apply to simple products.
		$product = wc_get_product( $product_id );
		if ( ! $product || $product->is_type( 'variable' ) ) {
			return false;
		}

		// Check product-level override first.
		$global_override = get_post_meta( $product_id, '_fmp_pa_global_override', true );

		if ( ! empty( $global_override ) ) {
			$addons = array_filter( (array) get_post_meta( $product_id, '_fmp_product_addons', true ) );
			return ! empty( $addons );
		}

		// Check global addons.
		if ( class_exists( '\RT\FoodMenuPro\Controllers\ProductAddons\Frontend\AddonHelper' ) ) {
			$addons = \RT\FoodMenuPro\Controllers\ProductAddons\Frontend\AddonHelper::get_global_addon_data( $product_id );
			return ! empty( $addons );
		}

		return false;
	}

	/**
	 * Get product options (variations and addons) for the options modal.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|WP_REST_Response
	 */
	public function get_product_options( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$product_id = (int) $request->get_param( 'id' );
		$product    = wc_get_product( $product_id );

		if ( ! $product ) {
			return new \WP_Error( 'not_found', 'Product not found', [ 'status' => 404 ] );
		}

		$currency_symbol = function_exists( 'get_woocommerce_currency_symbol' )
			? html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' )
			: '$';

		$data = [
			'product_type' => $product->get_type(),
			'price'        => (float) $product->get_price(),
			'attributes'   => [],
			'variations'   => [],
			'addons'       => [],
		];

		// Variable product: get attributes and variations.
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_variation_attributes() as $attr_name => $options ) {
				$is_taxonomy = taxonomy_exists( $attr_name );
				$label       = wc_attribute_label( $attr_name, $product );
				// Use the same key format as WooCommerce variation attributes.
				$attr_key    = 'attribute_' . sanitize_title( $attr_name );

				$formatted_options = [];
				foreach ( $options as $opt ) {
					if ( $is_taxonomy ) {
						$term = get_term_by( 'slug', $opt, $attr_name );
						$formatted_options[] = [
							'slug'  => $opt,
							'label' => $term ? $term->name : $opt,
						];
					} else {
						$formatted_options[] = [
							'slug'  => $opt,
							'label' => $opt,
						];
					}
				}

				$data['attributes'][] = [
					'name'    => $attr_name,
					'key'     => $attr_key,
					'label'   => $label,
					'options' => $formatted_options,
				];
			}

			foreach ( $product->get_available_variations() as $variation ) {
				$var_product = wc_get_product( $variation['variation_id'] );
				if ( ! $var_product ) {
					continue;
				}

				$var_price = (float) $var_product->get_price();
				$in_stock  = $var_product->is_in_stock();
				$stock_qty = $var_product->managing_stock() ? $var_product->get_stock_quantity() : null;

				$data['variations'][] = [
					'id'            => $variation['variation_id'],
					'price'         => $var_price,
					'display_price' => $currency_symbol . number_format( $var_price, 2 ),
					'attributes'    => $variation['attributes'],
					'stock'         => $stock_qty ?? '',
					'stock_qty'     => $stock_qty,
					'stock_status'  => $var_product->get_stock_status(),
					'in_stock'      => $in_stock,
					'manage_stock'  => $var_product->managing_stock(),
					'image'         => $variation['image']['url'] ?? '',
				];
			}
		}

		// Product addons — only for simple products (variable products use variations).
		$raw_addons = [];

		if ( ! $product->is_type( 'variable' ) ) {
			$global_override = get_post_meta( $product_id, '_fmp_pa_global_override', true );

			if ( ! empty( $global_override ) ) {
				$raw_addons = array_filter( (array) get_post_meta( $product_id, '_fmp_product_addons', true ) );
			} elseif ( class_exists( '\RT\FoodMenuPro\Controllers\ProductAddons\Frontend\AddonHelper' ) ) {
				$raw_addons = \RT\FoodMenuPro\Controllers\ProductAddons\Frontend\AddonHelper::get_global_addon_data( $product_id );
			}
		}

		if ( ! empty( $raw_addons ) ) {
			foreach ( $raw_addons as $addon_key => $addon ) {
				if ( empty( $addon['type'] ) ) {
					continue;
				}

				$addon_data = [
					'title'         => $addon['title'] ?? '',
					'type'          => $addon['type'],
					'required'      => ! empty( $addon['required'] ),
					'description'   => $addon['description'] ?? '',
					'placeholder'   => $addon['placeholder'] ?? '',
					'field_name'    => $addon['field_name'] ?? ( 'addon_' . $addon_key ),
					'option_qty'    => ! empty( $addon['option_qty'] ),
					'min_selection' => (int) ( $addon['min_selection'] ?? 0 ),
					'max_selection' => (int) ( $addon['max_selection'] ?? 0 ),
					'char_limit'    => (int) ( $addon['char_limit'] ?? 0 ),
					'options'       => [],
				];

				if ( ! empty( $addon['options'] ) && is_array( $addon['options'] ) ) {
					foreach ( $addon['options'] as $option ) {
						$price       = isset( $option['price'] ) ? (float) $option['price'] : 0;
						$price_label = $price > 0 ? ( $currency_symbol . number_format( $price, 2 ) ) : '';

						$opt_image = '';
						if ( ! empty( $option['image'] ) ) {
							$opt_image = is_numeric( $option['image'] )
								? wp_get_attachment_image_url( (int) $option['image'], 'thumbnail' )
								: $option['image'];
						}

						$addon_data['options'][] = [
							'label'       => $option['label'] ?? '',
							'price'       => $price,
							'price_label' => $price_label,
							'image'       => $opt_image ?: '',
							'default'     => ! empty( $option['default'] ),
						];
					}
				}

				$data['addons'][] = $addon_data;
			}
		}

		return rest_ensure_response( $data );
	}

	/**
	 * Count orders matching given args, excluding orders with excluded product types.
	 *
	 * @param array $args           Base wc_get_orders query args.
	 * @param array $excluded_types Excluded product type slugs.
	 *
	 * @return int Filtered count.
	 */
	private function count_orders_excluding_types( $args, $excluded_types ) {
		return (int) FnsPro::with_excluded_product_types( $excluded_types, static function () use ( $args ) {
			$args['limit']  = -1;
			$args['return'] = 'ids';

			return count( wc_get_orders( FnsPro::order_query_args( $args ) ) );
		} );
	}
}
