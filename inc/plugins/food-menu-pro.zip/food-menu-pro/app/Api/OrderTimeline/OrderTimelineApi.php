<?php
/**
 * Order Timeline REST API.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\OrderTimeline;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Models\OrderTimelineModel;
use RT\FoodMenuPro\Controllers\OrderTimeline\OrderTimeline;
use RT\FoodMenuPro\Controllers\OrderTimeline\OrderTimelineFns;
use RT\FoodMenuPro\Helpers\FnsPro;
use WP_REST_Response;
use WP_Error;

/**
 * Order Timeline REST API.
 */
class OrderTimelineApi {

	use SingletonTrait;

	/**
	 * Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		// Admin: Get timeline for an order.
		register_rest_route(
			'fmp/v1',
			'/orders/(?P<id>\d+)/timeline',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_timeline' ],
					'permission_callback' => FnsPro::menu_permission( [ 'dashboard', 'orders', 'order-read', 'order-edit', 'order-create', 'kitchen-monitor' ] ),
				],
				[
					'methods'             => 'POST',
					'callback'            => [ $this, 'add_timeline_entry' ],
					'permission_callback' => FnsPro::menu_permission( [ 'order-edit' ] ),
				],
			]
		);

		// Public: Get timeline by tracking token.
		register_rest_route(
			'fmp/v1',
			'/track/(?P<token>[a-zA-Z0-9]{12,64})',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_public_timeline' ],
					'permission_callback' => '__return_true',
				],
			]
		);
	}

	/**
	 * Admin permission check.
	 *
	 * @return bool
	 */
	public function admin_permission() {
		return FnsPro::has_order_manage_capability();
	}

	/**
	 * GET /orders/{id}/timeline — Full timeline for admin.
	 *
	 * @param \WP_REST_Request $request Request object.
	 *
	 * @return WP_REST_Response
	 */
	public function get_timeline( $request ) {
		$order_id = absint( $request->get_param( 'id' ) );
		$order    = wc_get_order( $order_id );

		if ( ! self::order_in_scope( $order ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Order not found' ], 404 );
		}

		$entries = OrderTimelineModel::get_timeline( $order_id );

		// Enrich entries with user display names.
		$timeline = array_map( function ( $entry ) {
			$user_name = '';

			if ( ! empty( $entry['updated_by'] ) ) {
				$user = get_user_by( 'id', $entry['updated_by'] );
				$user_name = $user ? $user->display_name : __( 'Unknown', 'food-menu-pro' );
			} else {
				$user_name = __( 'System', 'food-menu-pro' );
			}

			return [
				'id'           => (int) $entry['id'],
				'status'       => $entry['status'],
				'status_label' => $entry['status_label'],
				'note'         => $entry['note'],
				'updated_by'   => $user_name,
				'created_at'   => get_gmt_from_date( $entry['created_at'], 'Y-m-d\TH:i:s\Z' ),
				// Preformatted server-side so every viewer sees the site's wall clock,
				// not their own browser's timezone.
				'created_at_display' => OrderTimelineFns::format_datetime( $entry['created_at'] ),
			];
		}, $entries );

		$tracking_url = OrderTimeline::get_tracking_url( $order );

		return rest_ensure_response( [
			'success'      => true,
			'timeline'     => $timeline,
			'tracking_url' => $tracking_url,
		] );
	}

	/**
	 * POST /orders/{id}/timeline — Manual status update with note.
	 *
	 * @param \WP_REST_Request $request Request object.
	 *
	 * @return WP_REST_Response
	 */
	public function add_timeline_entry( $request ) {
		$order_id   = absint( $request->get_param( 'id' ) );
		$new_status = sanitize_text_field( $request->get_param( 'status' ) ?? '' );
		$note       = sanitize_textarea_field( $request->get_param( 'note' ) ?? '' );

		$order = wc_get_order( $order_id );

		if ( ! self::order_in_scope( $order ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Order not found' ], 404 );
		}

		// Only a real order status — this value goes straight into update_status().
		if ( '' !== $new_status && ! array_key_exists( 'wc-' . preg_replace( '/^wc-/', '', $new_status ), wc_get_order_statuses() ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Invalid status' ], 400 );
		}

		// Note-only: update the last timeline entry's note.
		if ( empty( $new_status ) ) {
			if ( empty( $note ) ) {
				return new WP_REST_Response( [ 'success' => false, 'message' => 'Note or status is required' ], 400 );
			}

			OrderTimelineModel::update_last_entry_note( $order->get_id(), $note );

			return rest_ensure_response( [
				'success' => true,
				'message' => __( 'Note added', 'food-menu-pro' ),
			] );
		}

		// Set pending note so the woocommerce_order_status_changed hook picks it up.
		OrderTimeline::$pending_note = $note ?: null;

		// Update order status — this triggers woocommerce_order_status_changed,
		// which in turn calls OrderTimeline::record_status_change().
		$order->update_status( $new_status, $note );

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Timeline updated', 'food-menu-pro' ),
		] );
	}

	/**
	 * A real shop order inside the current user's allowed locations (branch-scoped staff).
	 *
	 * @param \WC_Order|false $order Order.
	 * @return bool
	 */
	private static function order_in_scope( $order ) {
		return $order
			&& 'shop_order' === $order->get_type()
			&& FnsPro::order_matches_allowed_locations( $order, FnsPro::get_user_allowed_locations() );
	}

	/**
	 * GET /track/{token} — Public timeline by tracking token.
	 *
	 * @param \WP_REST_Request $request Request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_public_timeline( $request ) {
		$token = sanitize_text_field( $request->get_param( 'token' ) );

		$entries = OrderTimelineModel::get_by_token( $token );

		if ( empty( $entries ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Order not found' ], 404 );
		}

		$order_id = absint( $entries[0]['order_id'] );
		$order    = wc_get_order( $order_id );

		if ( ! $order ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Order not found' ], 404 );
		}

		// Check expiry.
		if ( OrderTimelineFns::is_token_expired( $order ) ) {
			return new WP_REST_Response( [ 'success' => false, 'message' => 'Tracking link has expired' ], 410 );
		}

		// Get custom status colors/icons.
		$custom_statuses = get_option( 'fmp_custom_order_statuses', [] );
		$status_meta     = [];

		foreach ( $custom_statuses as $cs ) {
			$slug                = str_replace( 'wc-', '', $cs['slug'] ?? '' );
			$status_meta[ $slug ] = [
				'color' => $cs['color'] ?? '#6B7280',
				'icon'  => $cs['icon'] ?? '',
			];
		}

		$current_status = $order->get_status();
		$settings       = get_option( 'tpl_food_menu_settings', [] );
		$show_notes     = ( $settings['fmp_tracking_show_notes'] ?? '' ) === 'on';

		// Build customer-safe timeline.
		$timeline = array_map( function ( $entry ) use ( $status_meta, $current_status, $show_notes ) {
			$slug  = $entry['status'];
			$meta  = $status_meta[ $slug ] ?? [];

			$item = [
				'status'       => $entry['status'],
				'status_label' => $entry['status_label'],
				'color'        => $meta['color'] ?? '#6B7280',
				'icon'         => $meta['icon'] ?? '',
				'completed'    => true,
				'created_at'   => get_gmt_from_date( $entry['created_at'], 'Y-m-d\TH:i:s\Z' ),
				// See the admin timeline above — the customer must be shown the
				// restaurant's clock, not the one on their phone.
				'created_at_display' => OrderTimelineFns::format_datetime( $entry['created_at'] ),
			];

			if ( $show_notes && ! empty( $entry['note'] ) ) {
				$item['note'] = $entry['note'];
			}

			return $item;
		}, $entries );

		return rest_ensure_response( [
			'success'        => true,
			'order_number'   => $order->get_order_number(),
			'status'         => $current_status,
			'status_label'   => OrderTimeline::resolve_status_label( $current_status ),
			'date_created'   => $order->get_date_created() ? $order->get_date_created()->format( 'Y-m-d H:i:s' ) : '',
			'timeline'       => $timeline,
		] );
	}
}
