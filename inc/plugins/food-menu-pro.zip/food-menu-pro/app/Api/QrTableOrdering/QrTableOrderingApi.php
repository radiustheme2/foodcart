<?php
/**
 * QR Table Ordering REST API class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\QrTableOrdering;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

/**
 * QR Table Ordering REST API class.
 */
class QrTableOrderingApi {

	use SingletonTrait;

	/**
	 * Option key for stored QR codes.
	 *
	 * @var string
	 */
	const OPTION_KEY = 'fmp_qr_codes';

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST API routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			'fmp/v1',
			'/qr-codes',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_qr_codes' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
				[
					'methods'             => 'POST',
					'callback'            => [ $this, 'create_qr_code' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
			]
		);

		register_rest_route(
			'fmp/v1',
			'/qr-codes/(?P<id>[a-f0-9-]+)',
			[
				[
					'methods'             => 'PUT',
					'callback'            => [ $this, 'update_qr_code' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
				[
					'methods'             => 'DELETE',
					'callback'            => [ $this, 'delete_qr_code' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
			]
		);
	}

	/**
	 * Permission callback.
	 *
	 * @return bool
	 */
	public function check_permission() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * GET /qr-codes — List all QR codes.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_qr_codes( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$qr_codes = get_option( self::OPTION_KEY, [] );

		if ( ! is_array( $qr_codes ) ) {
			$qr_codes = [];
		}

		return rest_ensure_response( [
			'success'  => true,
			'qr_codes' => $qr_codes,
		] );
	}

	/**
	 * POST /qr-codes — Create a new QR code.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function create_qr_code( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$params     = $request->get_json_params();
		$table_name = sanitize_text_field( wp_unslash( $params['table_name'] ?? '' ) );
		$url        = esc_url_raw( wp_unslash( $params['url'] ?? '' ) );
		$location_id = absint( $params['location_id'] ?? 0 );

		if ( empty( $table_name ) || empty( $url ) ) {
			return rest_ensure_response( [
				'success' => false,
				'error'   => __( 'Table name and URL are required.', 'food-menu-pro' ),
			] );
		}

		$qr_codes = get_option( self::OPTION_KEY, [] );

		if ( ! is_array( $qr_codes ) ) {
			$qr_codes = [];
		}

		if ( $this->is_duplicate_table_name( $qr_codes, $table_name, $location_id ) ) {
			return rest_ensure_response( [
				'success' => false,
				'error'   => __( 'A QR code with this table name already exists for this location.', 'food-menu-pro' ),
			] );
		}

		$new_qr = [
			'id'          => wp_generate_uuid4(),
			'table_name'  => $table_name,
			'url'         => $url,
			'location_id' => $location_id,
			'created_at'  => current_time( 'Y-m-d' ),
		];

		$qr_codes[] = $new_qr;

		update_option( self::OPTION_KEY, $qr_codes );

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'QR code created successfully.', 'food-menu-pro' ),
			'qr_code' => $new_qr,
		] );
	}

	/**
	 * PUT /qr-codes/{id} — Update a QR code.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function update_qr_code( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$id         = sanitize_text_field( $request->get_param( 'id' ) );
		$params     = $request->get_json_params();
		$table_name = sanitize_text_field( wp_unslash( $params['table_name'] ?? '' ) );
		$url        = esc_url_raw( wp_unslash( $params['url'] ?? '' ) );
		$location_id = absint( $params['location_id'] ?? 0 );

		if ( empty( $table_name ) || empty( $url ) ) {
			return rest_ensure_response( [
				'success' => false,
				'error'   => __( 'Table name and URL are required.', 'food-menu-pro' ),
			] );
		}

		$qr_codes = get_option( self::OPTION_KEY, [] );

		if ( ! is_array( $qr_codes ) ) {
			$qr_codes = [];
		}

		if ( $this->is_duplicate_table_name( $qr_codes, $table_name, $location_id, $id ) ) {
			return rest_ensure_response( [
				'success' => false,
				'error'   => __( 'A QR code with this table name already exists for this location.', 'food-menu-pro' ),
			] );
		}

		$found = false;

		foreach ( $qr_codes as &$qr ) {
			if ( $qr['id'] === $id ) {
				$qr['table_name']  = $table_name;
				$qr['url']         = $url;
				$qr['location_id'] = $location_id;
				$found             = true;
				break;
			}
		}
		unset( $qr );

		if ( ! $found ) {
			return new \WP_Error(
				'not_found',
				__( 'QR code not found.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		update_option( self::OPTION_KEY, $qr_codes );

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'QR code updated successfully.', 'food-menu-pro' ),
		] );
	}

	/**
	 * DELETE /qr-codes/{id} — Delete a QR code.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function delete_qr_code( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$id       = sanitize_text_field( $request->get_param( 'id' ) );
		$qr_codes = get_option( self::OPTION_KEY, [] );

		if ( ! is_array( $qr_codes ) ) {
			$qr_codes = [];
		}

		$original_count = count( $qr_codes );
		$qr_codes       = array_values(
			array_filter(
				$qr_codes,
				function ( $qr ) use ( $id ) {
					return $qr['id'] !== $id;
				}
			)
		);

		if ( count( $qr_codes ) === $original_count ) {
			return new \WP_Error(
				'not_found',
				__( 'QR code not found.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		update_option( self::OPTION_KEY, $qr_codes );

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'QR code deleted successfully.', 'food-menu-pro' ),
		] );
	}

	/**
	 * Whether another QR code already uses the given table name + location.
	 *
	 * Compares on the URL-slug form of the name (sanitize_title) so visually
	 * different but slug-identical names — "Table 1" vs "TABLE 1" vs "table-1"
	 * — count as duplicates, since they would collide on the scan URL.
	 *
	 * @param array       $qr_codes    Existing QR records.
	 * @param string      $table_name  Submitted table name.
	 * @param int         $location_id Submitted location ID (0 for none).
	 * @param string|null $exclude_id  QR id to skip (the one being updated).
	 *
	 * @return bool
	 */
	private function is_duplicate_table_name( $qr_codes, $table_name, $location_id, $exclude_id = null ) {
		$slug     = sanitize_title( $table_name );
		$location = (int) $location_id;

		foreach ( $qr_codes as $qr ) {
			if ( null !== $exclude_id && ( $qr['id'] ?? '' ) === $exclude_id ) {
				continue;
			}
			$existing_slug     = sanitize_title( $qr['table_name'] ?? '' );
			$existing_location = (int) ( $qr['location_id'] ?? 0 );
			if ( $existing_slug === $slug && $existing_location === $location ) {
				return true;
			}
		}

		return false;
	}
}
