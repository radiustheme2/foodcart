<?php
/**
 * Timed Products REST API class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\TimedProducts;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

/**
 * Timed Products REST API class.
 */
class TimedProductsApi {

	use SingletonTrait;

	/**
	 * Option key for stored timed product rules.
	 *
	 * @var string
	 */
	const OPTION_KEY = 'fmp_timed_products';

	/**
	 * Allowed timed rule types.
	 *
	 * @var array
	 */
	const ALLOWED_RULE_TYPES = [ 'on_date', 'date_range', 'time_range', 'day_of_week', 'before_date', 'after_date' ];

	/**
	 * Allowed actions.
	 *
	 * @var array
	 */
	const ALLOWED_ACTIONS = [ 'show', 'hide' ];

	/**
	 * Allowed product rule types.
	 *
	 * @var array
	 */
	const ALLOWED_PRODUCT_RULE_TYPES = [ 'specific_products', 'product_categories' ];

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST API routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			'fmp/v1',
			'/timed-products',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_rules' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
				[
					'methods'             => 'POST',
					'callback'            => [ $this, 'create_rule' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
			]
		);

		register_rest_route(
			'fmp/v1',
			'/timed-products/(?P<id>[a-f0-9-]+)',
			[
				[
					'methods'             => 'PUT',
					'callback'            => [ $this, 'update_rule' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
				[
					'methods'             => 'DELETE',
					'callback'            => [ $this, 'delete_rule' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
			]
		);

		register_rest_route(
			'fmp/v1',
			'/timed-products/search-products',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'search_products' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
			]
		);
	}

	/**
	 * Permission callback.
	 *
	 * @return bool
	 */
	public function check_permission() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * GET /timed-products — List all rules.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response|\WP_Error
	 */
	public function get_rules( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', __( 'Authentication failed', 'food-menu-pro' ), [ 'status' => 401 ] );
		}

		$rules = get_option( self::OPTION_KEY, [] );

		if ( ! is_array( $rules ) ) {
			$rules = [];
		}

		// Resolve product/category names for display.
		$rules = $this->resolve_names( $rules );

		return rest_ensure_response( [
			'success' => true,
			'rules'   => $rules,
		] );
	}

	/**
	 * Resolve product and category names for all rules.
	 *
	 * Batch-loads all needed products/categories in two queries,
	 * then maps names onto each rule.
	 *
	 * @param array $rules Rules array.
	 *
	 * @return array Rules with product_names/category_names populated.
	 */
	private function resolve_names( $rules ) {
		$product_ids  = [];
		$category_ids = [];

		foreach ( $rules as $rule ) {
			if ( 'specific_products' === ( $rule['product_rule_type'] ?? '' ) ) {
				$product_ids = array_merge( $product_ids, (array) ( $rule['products'] ?? [] ) );
			} else {
				$category_ids = array_merge( $category_ids, (array) ( $rule['categories'] ?? [] ) );
			}
		}

		// Batch-load product titles.
		$product_map = [];

		if ( ! empty( $product_ids ) ) {
			$product_ids = array_unique( array_map( 'absint', $product_ids ) );
			$posts       = get_posts(
				[
					'post_type'      => 'product',
					'post__in'       => $product_ids,
					'posts_per_page' => count( $product_ids ),
					'fields'         => 'ids',
				]
			);

			foreach ( $posts as $pid ) {
				$product_map[ $pid ] = get_the_title( $pid );
			}
		}

		// Batch-load category names.
		$category_map = [];

		if ( ! empty( $category_ids ) ) {
			$category_ids = array_unique( array_map( 'absint', $category_ids ) );
			$terms        = get_terms(
				[
					'taxonomy'   => 'product_cat',
					'include'    => $category_ids,
					'hide_empty' => false,
				]
			);

			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$category_map[ $term->term_id ] = $term->name;
				}
			}
		}

		// Apply maps to each rule.
		foreach ( $rules as &$rule ) {
			if ( 'specific_products' === ( $rule['product_rule_type'] ?? '' ) ) {
				$names = [];

				foreach ( (array) ( $rule['products'] ?? [] ) as $id ) {
					$names[ $id ] = $product_map[ $id ] ?? '#' . $id;
				}

				$rule['product_names'] = $names;
			} else {
				$names = [];

				foreach ( (array) ( $rule['categories'] ?? [] ) as $id ) {
					$names[ $id ] = $category_map[ $id ] ?? '#' . $id;
				}

				$rule['category_names'] = $names;
			}
		}
		unset( $rule );

		return $rules;
	}

	/**
	 * POST /timed-products — Create a new rule.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response|\WP_Error
	 */
	public function create_rule( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', __( 'Authentication failed', 'food-menu-pro' ), [ 'status' => 401 ] );
		}

		$params = $request->get_json_params();
		$rule   = $this->sanitize_rule( $params );

		if ( is_wp_error( $rule ) ) {
			return $rule;
		}

		$rule['id']         = wp_generate_uuid4();
		$rule['created_at'] = current_time( 'Y-m-d' );

		$rules = get_option( self::OPTION_KEY, [] );

		if ( ! is_array( $rules ) ) {
			$rules = [];
		}

		$rules[] = $rule;

		update_option( self::OPTION_KEY, $rules, false );

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Timed product rule created successfully.', 'food-menu-pro' ),
			'rule'    => $rule,
		] );
	}

	/**
	 * PUT /timed-products/{id} — Update a rule.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response|\WP_Error
	 */
	public function update_rule( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', __( 'Authentication failed', 'food-menu-pro' ), [ 'status' => 401 ] );
		}

		$id     = sanitize_text_field( $request->get_param( 'id' ) );
		$params = $request->get_json_params();
		$data   = $this->sanitize_rule( $params );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$rules = get_option( self::OPTION_KEY, [] );

		if ( ! is_array( $rules ) ) {
			$rules = [];
		}

		$found = false;

		foreach ( $rules as &$rule ) {
			if ( $rule['id'] === $id ) {
				$rule = array_merge( $rule, $data );
				$found = true;
				break;
			}
		}
		unset( $rule );

		if ( ! $found ) {
			return new \WP_Error(
				'not_found',
				__( 'Timed product rule not found.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		update_option( self::OPTION_KEY, $rules, false );


		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Timed product rule updated successfully.', 'food-menu-pro' ),
		] );
	}

	/**
	 * DELETE /timed-products/{id} — Delete a rule.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response|\WP_Error
	 */
	public function delete_rule( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', __( 'Authentication failed', 'food-menu-pro' ), [ 'status' => 401 ] );
		}

		$id    = sanitize_text_field( $request->get_param( 'id' ) );
		$rules = get_option( self::OPTION_KEY, [] );

		if ( ! is_array( $rules ) ) {
			$rules = [];
		}

		$original_count = count( $rules );
		$rules          = array_values(
			array_filter(
				$rules,
				function ( $rule ) use ( $id ) {
					return $rule['id'] !== $id;
				}
			)
		);

		if ( count( $rules ) === $original_count ) {
			return new \WP_Error(
				'not_found',
				__( 'Timed product rule not found.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		update_option( self::OPTION_KEY, $rules, false );


		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Timed product rule deleted successfully.', 'food-menu-pro' ),
		] );
	}

	/**
	 * Sanitize and validate a rule from request params.
	 *
	 * @param array $params Raw params from request.
	 *
	 * @return array|\WP_Error Sanitized rule data or error.
	 */

	/**
	 * GET /timed-products/search-products — Search products with optional location filter.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response|\WP_Error
	 */
	public function search_products( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', __( 'Authentication failed', 'food-menu-pro' ), [ 'status' => 401 ] );
		}

		$search      = sanitize_text_field( $request->get_param( 'search' ) ?? '' );
		$location_id = absint( $request->get_param( 'location' ) ?? 0 );
		$include     = sanitize_text_field( $request->get_param( 'include' ) ?? '' );
		$per_page    = absint( $request->get_param( 'per_page' ) ?? 20 );

		if ( $per_page < 1 || $per_page > 100 ) {
			$per_page = 20;
		}

		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => $per_page,
			'fields'         => 'ids',
		];

		if ( ! empty( $search ) ) {
			$args['s'] = $search;
		}

		if ( ! empty( $include ) ) {
			$args['post__in']       = array_map( 'absint', explode( ',', $include ) );
			$args['posts_per_page'] = count( $args['post__in'] );
		}

		// Filter by location taxonomy if a specific location is selected.
		if ( $location_id > 0 && taxonomy_exists( 'tpl-food-location' ) ) {
			$args['tax_query'] = [ //phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				'relation' => 'OR',
				[
					'taxonomy' => 'tpl-food-location',
					'field'    => 'term_id',
					'terms'    => [ $location_id ],
				],
				[
					'taxonomy' => 'tpl-food-location',
					'operator' => 'NOT EXISTS',
				],
			];
		}

		$product_ids = get_posts( $args );
		$results     = [];

		foreach ( $product_ids as $pid ) {
			$results[] = [
				'value' => $pid,
				'label' => get_the_title( $pid ),
			];
		}

		return rest_ensure_response( $results );
	}

	private function sanitize_rule( $params ) {
		$title = sanitize_text_field( wp_unslash( $params['title'] ?? '' ) );

		if ( empty( $title ) ) {
			return new \WP_Error(
				'missing_title',
				__( 'Title is required.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		$action = sanitize_text_field( $params['action'] ?? 'show' );

		if ( ! in_array( $action, self::ALLOWED_ACTIONS, true ) ) {
			$action = 'show';
		}

		$product_rule_type = sanitize_text_field( $params['product_rule_type'] ?? 'specific_products' );

		if ( ! in_array( $product_rule_type, self::ALLOWED_PRODUCT_RULE_TYPES, true ) ) {
			$product_rule_type = 'specific_products';
		}

		$products   = array_map( 'absint', (array) ( $params['products'] ?? [] ) );
		$categories = array_map( 'absint', (array) ( $params['categories'] ?? [] ) );

		$location_id = absint( $params['location_id'] ?? 0 );
		$enabled     = ! empty( $params['enabled'] );

		$timed_rules = $this->sanitize_timed_rules( (array) ( $params['timed_rules'] ?? [] ) );

		// Only keep the relevant data based on product_rule_type.
		if ( 'specific_products' === $product_rule_type ) {
			$categories     = [];
			$product_names  = array_map( 'sanitize_text_field', (array) ( $params['product_names'] ?? [] ) );
			$category_names = [];
		} else {
			$products       = [];
			$product_names  = [];
			$category_names = array_map( 'sanitize_text_field', (array) ( $params['category_names'] ?? [] ) );
		}

		return [
			'title'             => $title,
			'action'            => $action,
			'product_rule_type' => $product_rule_type,
			'products'          => array_values( array_filter( $products ) ),
			'categories'        => array_values( array_filter( $categories ) ),
			'location_id'       => $location_id,
			'timed_rules'       => $timed_rules,
			'enabled'           => $enabled,
			'product_names'     => $product_names,
			'category_names'    => $category_names,
		];
	}

	/**
	 * Sanitize timed rules array.
	 *
	 * @param array $raw_rules Raw timed rules from request.
	 *
	 * @return array Sanitized timed rules.
	 */
	private function sanitize_timed_rules( $raw_rules ) {
		$sanitized = [];

		foreach ( $raw_rules as $rule ) {
			$type = sanitize_text_field( $rule['type'] ?? '' );

			if ( ! in_array( $type, self::ALLOWED_RULE_TYPES, true ) ) {
				continue;
			}

			$clean = [ 'type' => $type ];

			switch ( $type ) {
				case 'on_date':
				case 'before_date':
				case 'after_date':
					$clean['date'] = sanitize_text_field( $rule['date'] ?? '' );
					break;

				case 'date_range':
					$clean['start'] = sanitize_text_field( $rule['start'] ?? '' );
					$clean['end']   = sanitize_text_field( $rule['end'] ?? '' );
					break;

				case 'time_range':
					$clean['start'] = sanitize_text_field( $rule['start'] ?? '' );
					$clean['end']   = sanitize_text_field( $rule['end'] ?? '' );
					break;

				case 'day_of_week':
					$allowed_days = [ 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' ];
					$days         = array_map( 'sanitize_text_field', (array) ( $rule['days'] ?? [] ) );
					$clean['days'] = array_values( array_intersect( $days, $allowed_days ) );
					break;
			}

			$sanitized[] = $clean;
		}

		return $sanitized;
	}

}
