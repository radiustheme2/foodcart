<?php
/**
 * GetInventoryListApi class.
 *
 * @package RT_FoodMenu
 */

namespace RT\FoodMenuPro\Api\Inventory;

use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Services\InventoryServices;
use WP_REST_Response;

class InventoryListApi {

	use SingletonTrait;

	private $inventory_service;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {

		$this->inventory_service = new InventoryServices();

		add_action( 'rest_api_init', function () {
			register_rest_route( 'fmp/v1', '/inventory', [
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_inventory_list' ],
				'permission_callback' => FnsPro::menu_permission( [ 'dashboard', 'inventory', 'inv-add', 'inv-waste', 'inv-adjust', 'waste', 'reconciliation', 'purchase-orders', 'stock-alerts', 'reports' ] ),
			] );

			register_rest_route( 'fmp/v1', '/add-inventory', [
				'methods'             => 'POST',
				'callback'            => [ $this, 'add_inventory' ],
				'permission_callback' => FnsPro::menu_permission( [ 'inv-add' ] ),
			] );

			register_rest_route( 'fmp/v1', '/add-wastage', [
				'methods'             => 'POST',
				'callback'            => [ $this, 'add_wastage' ],
				'permission_callback' => FnsPro::menu_permission( [ 'inv-waste' ] ),
			] );

			register_rest_route( 'fmp/v1', '/inventory-logs', [
				'methods'             => 'POST',
				'callback'            => [ $this, 'inventory_logs' ],
				'permission_callback' => FnsPro::menu_permission( [ 'dashboard', 'inventory', 'inv-add', 'inv-waste', 'inv-adjust', 'waste', 'reconciliation', 'purchase-orders', 'stock-alerts', 'reports' ] ),
			] );

			register_rest_route( 'fmp/v1', '/inventory-report', [
				'methods'             => 'GET',
				'callback'            => [ $this, 'inventory_reports' ],
				'permission_callback' => FnsPro::menu_permission( [ 'dashboard', 'inventory', 'inv-add', 'inv-waste', 'inv-adjust', 'waste', 'reconciliation', 'purchase-orders', 'stock-alerts', 'reports' ] ),
			] );

			register_rest_route( 'fmp/v1', '/inventory-settings', [
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_inventory_settings' ],
				'permission_callback' => FnsPro::menu_permission( [ 'dashboard', 'inventory', 'inv-add', 'inv-waste', 'inv-adjust', 'waste', 'reconciliation', 'purchase-orders', 'stock-alerts', 'reports' ] ),
			] );

			register_rest_route( 'fmp/v1', '/inventory-settings', [
				'methods'             => 'POST',
				'callback'            => [ $this, 'save_inventory_settings' ],
				'permission_callback' => function () {
					return current_user_can( 'manage_woocommerce' );
				},
			] );

			register_rest_route( 'fmp/v1', '/inventory-undo', [
				'methods'             => 'POST',
				'callback'            => [ $this, 'undo_log' ],
				'permission_callback' => FnsPro::menu_permission( [ 'inv-add', 'inv-waste', 'inv-adjust' ] ),
			] );

			register_rest_route( 'fmp/v1', '/inventory-reconciliation', [
				'methods'             => 'GET',
				'callback'            => [ $this, 'reconciliation' ],
				'permission_callback' => FnsPro::menu_permission( [ 'reconciliation', 'inv-adjust' ] ),
			] );

			register_rest_route( 'fmp/v1', '/inventory-import', [
				'methods'             => 'POST',
				'callback'            => [ $this, 'import_inventory' ],
				'permission_callback' => function () {
					return current_user_can( 'manage_woocommerce' );
				},
			] );

			register_rest_route( 'fmp/v1', '/inventory-valuation', [
				'methods'             => 'GET',
				'callback'            => [ $this, 'valuation' ],
				'permission_callback' => FnsPro::menu_permission( [ 'dashboard', 'inventory', 'inv-add', 'inv-waste', 'inv-adjust', 'waste', 'reconciliation', 'purchase-orders', 'stock-alerts', 'reports' ] ),
			] );
		} );

	}

	public function fmp_exact_product_title_search( $where, $query ) {
		global $wpdb;

		if ( $query->get( 'wc_query' ) !== 'product_query' ) {
			return $where;
		}

		$search = $query->get( 'fmp_exact_title' );

		if ( ! empty( $search ) ) {
			$where .= $wpdb->prepare(
				" AND {$wpdb->posts}.post_title LIKE %s",
				'%' . $wpdb->esc_like( $search ) . '%'
			);
		}

		return $where;
	}

	/**
	 * API Callback
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|\WP_REST_Response
	 */

	public function get_inventory_list( \WP_REST_Request $request ) {

		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		global $wpdb;

		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = max( 1, (int) $request->get_param( 'per_page' ) );
		$search   = sanitize_text_field( $request->get_param( 'search' ) );

		$offset = ( $page - 1 ) * $per_page;

		$from = sanitize_text_field( $request->get_param( 'from' ) ) ?: '1970-01-01';
		$to   = sanitize_text_field( $request->get_param( 'to' ) ) ?: current_time( 'Y-m-d' );

		/* ---------------- Products ---------------- */

		add_filter( 'posts_where', [ $this, 'fmp_exact_product_title_search' ], 10, 2 );

		$args = [
			'limit'           => $per_page,
			'offset'          => $offset,
			//'manage_stock'    => true,
			'status'          => 'publish',
			'wc_query'        => 'product_query',
			'fmp_exact_title' => $search,
		];

		$products = wc_get_products( $args );

		$total_products = wc_get_products( [
			'limit'           => - 1,
			'return'          => 'ids',
			//'manage_stock'    => true,
			'status'          => 'publish',
			'wc_query'        => 'product_query',
			'fmp_exact_title' => $search,
		] );

		remove_filter( 'posts_where', [ $this, 'fmp_exact_product_title_search' ], 10 );

		$total = count( $total_products );

		/* ---------------- Inventory Aggregation ---------------- */

		$table = "{$wpdb->prefix}fm_inventory_logs";

		$sql = $wpdb->prepare(
			"
		SELECT
			product_id,

			SUM(
				CASE WHEN change_type IN ('add', 'opening')
					THEN quantity
				    ELSE 0
				END
			) AS total_inventory,

			SUM(
				CASE 
				    WHEN change_type = 'sale'
					THEN quantity 
				    ELSE 0 
				END
			) -
			SUM(
				CASE WHEN change_type = 'restore'
					THEN quantity 
				    ELSE 0 
				END
			) AS sales,

			SUM(
				CASE WHEN change_type = 'wastage'
					THEN quantity 
				    ELSE 0 
				END
			) AS wastage

		FROM {$table}
		WHERE occurred_at BETWEEN %s AND %s
		GROUP BY product_id
		",
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);

		$log_data = $wpdb->get_results( $sql, ARRAY_A );

		$map = [];
		foreach ( $log_data as $row ) {
			$map[ (int) $row['product_id'] ] = $row;
		}

		/* ---------------- Last Supplier per product ---------------- */
		$supplier_sql = "SELECT product_id, supplier_name
			FROM {$table} t1
			WHERE supplier_name IS NOT NULL AND supplier_name != ''
			AND id = (SELECT MAX(id) FROM {$table} t2 WHERE t2.product_id = t1.product_id AND t2.supplier_name IS NOT NULL AND t2.supplier_name != '')";
		$supplier_rows = $wpdb->get_results( $supplier_sql, ARRAY_A );
		$supplier_map  = [];
		foreach ( $supplier_rows as $row ) {
			$supplier_map[ (int) $row['product_id'] ] = $row['supplier_name'];
		}

		/* ---------------- Expected Stock (all-time, for sync check) ---------------- */
		$expected_sql = "SELECT product_id,
			SUM(CASE WHEN change_type IN ('add','opening','adj_add','restore') THEN quantity ELSE 0 END) -
			SUM(CASE WHEN change_type IN ('sale','wastage','adj_remove') THEN quantity ELSE 0 END) AS expected
			FROM {$table} GROUP BY product_id";
		$expected_rows = $wpdb->get_results( $expected_sql, ARRAY_A );
		$expected_map  = [];
		foreach ( $expected_rows as $row ) {
			$expected_map[ (int) $row['product_id'] ] = (int) $row['expected'];
		}

		/* ---------------- Response Build ---------------- */

		$items = [];

		foreach ( $products as $product ) {

			$pid                 = $product->get_id();
			$remaining           = (int) $product->get_stock_quantity();
			$low_stock_threshold = $product->get_low_stock_amount();
			$status              = $remaining <= 0 ? 'Out' : ( $remaining <= $low_stock_threshold ? 'Low' : 'In Stock' );
			$has_opening         = get_post_meta( $pid, '_fmp_inventory', true );

			$categories = wp_get_post_terms(
				$pid,
				'product_cat',
				[ 'fields' => 'names' ]
			);

			$expected    = $expected_map[ $pid ] ?? null;
			$sync_status = 'unknown';
			if ( $has_opening && $expected !== null ) {
				$sync_status = $remaining === $expected ? 'synced' : 'out_of_sync';
			}

			// Shown in the inventory modals, and the cap for the unit cost price.
			$prices = FnsPro::get_product_price_fields( $product );

			$items[] = [
				'id'            => $pid,
				'name'          => $product->get_name(),
				'permalink'     => $product->get_permalink(),
				'price'         => $prices['price'],
				'regular_price' => $prices['regular_price'],
				'sale_price'    => $prices['sale_price'],
				'category'      => implode( ', ', $categories ),
				'unit'          => get_post_meta( $pid, '_unit', true ),

				'totalInventory' => (int) ( $map[ $pid ]['total_inventory'] ?? 0 ),
				'salesQty'       => max( 0, (int) ( $map[ $pid ]['sales'] ?? 0 ) ),
				'wasteQty'       => (int) ( $map[ $pid ]['wastage'] ?? 0 ),

				'manage_stock' => boolval( $product->managing_stock() ),
				'has_opening'  => boolval( $has_opening ),

				'remaining'   => $remaining,
				'expected'    => $expected,
				'sync_status' => $sync_status,
				'status'      => $status,
				'supplier'    => $supplier_map[ $pid ] ?? '',
			];
		}

		return rest_ensure_response( [
			'items' => $items,
			'meta'  => [
				'total'      => $total,
				'current'    => $page,
				'pageSize'   => $per_page,
				'totalPages' => ceil( $total / $per_page ),
			],
		] );
	}

	/**
	 * Add inventory quantity
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|WP_REST_Response
	 */
	public function add_inventory( \WP_REST_Request $request ) {

		$product_id = (int) $request->get_param( 'id' );
		$qty        = (int) $request->get_param( 'quantity' );
		$note       = (string) sanitize_text_field( $request->get_param( 'note' ) );

		$isOpening            = (boolean) $request->get_param( 'isOpening' );
		$hasOpeningPreviously = (boolean) $request->get_param( 'hasOpeningPreviously' );
		$isAdjustable         = (boolean) $request->get_param( 'isAdjustable' );
		$date                 = (string) $request->get_param( 'date' );

		$success_message = $isOpening ? __( 'Inventory enabled successfully', 'food-menu-pro' ) : __( 'Inventory added successfully', 'food-menu-pro' );

		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error(
				'unauthorized',
				'Authentication failed',
				[ 'status' => 401 ]
			);
		}

		$cost_check = $this->validate_cost_price( $product_id, $request->get_param( 'cost_price' ) );

		if ( is_wp_error( $cost_check ) ) {
			return $cost_check;
		}

		if ( $isOpening ) {
			$result = $this->inventory_service->enable_inventory_with_opening_stock(
				$product_id,
				$qty,
				$note,
				$hasOpeningPreviously,
				$this->get_supplier_cost_params( $request )
			);
		} elseif ( $isAdjustable ) {

			if ( ! current_user_can( 'manage_options' ) ) {
				return new \WP_Error(
					'unauthorized',
					'Authentication failed',
					[ 'status' => 401 ]
				);
			}

			$changeType = sanitize_text_field( $request->get_param( 'changeType' ) );
			$reason     = 'adjustment';
			$result     = $this->inventory_service->add_inventory_qty(
				$product_id,
				$qty,
				$note,
				$changeType,
				$reason,
				$date
			);
		} else {
			$extra = $this->get_supplier_cost_params( $request );

			$result = $this->inventory_service->add_inventory_qty(
				$product_id,
				$qty,
				$note,
				'add',
				'manual_add',
				'',
				$extra
			);
		}


		if ( is_wp_error( $result ) ) {
			return rest_ensure_response( [
				'success' => false,
				'error'   => $result->get_error_message(),
			] );
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => $success_message,
		] );
	}

	/**
	 * Reject a unit cost above the product's selling price.
	 *
	 * Backstop for the same rule the modals enforce. Worth having on the server as
	 * well: this figure is what every margin in the reports is calculated against,
	 * so a cost entered above the sell price quietly turns the product's margin
	 * negative for the whole period — typing the total paid for a delivery into a
	 * field asking for the price of one unit is the mistake it catches.
	 *
	 * A product with no price has no cap — there is nothing to compare against.
	 *
	 * @param int   $product_id Product being stocked.
	 * @param mixed $cost       Submitted cost price (may be absent).
	 *
	 * @return true|\WP_Error
	 */
	private function validate_cost_price( $product_id, $cost ) {
		if ( ! is_numeric( $cost ) ) {
			return true;
		}

		$cost = (float) $cost;

		if ( $cost < 0 ) {
			return new \WP_Error(
				'fmp_invalid_cost_price',
				__( 'Enter a valid unit cost price.', 'food-menu-pro' ),
				[ 'status' => 400 ]
			);
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return true;
		}

		// Same resolution the modals use, so client and server cap at the same figure.
		$price = FnsPro::get_product_price_fields( $product )['price'];

		if ( null === $price || $price <= 0 ) {
			return true;
		}

		if ( $cost > $price ) {
			return new \WP_Error(
				'fmp_cost_above_price',
				sprintf(
					/* translators: %s: product selling price */
					__( 'Unit cost cannot be more than the selling price (%s). Enter the cost of one unit, not the total.', 'food-menu-pro' ),
					wp_strip_all_tags( wc_price( (float) $price ) )
				),
				[ 'status' => 400 ]
			);
		}

		return true;
	}

	/**
	 * Read the optional supplier/cost price params off an inventory request.
	 *
	 * Both are optional everywhere, so only the ones actually sent are returned.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return array
	 */
	private function get_supplier_cost_params( \WP_REST_Request $request ): array {
		$extra    = [];
		$supplier = sanitize_text_field( $request->get_param( 'supplier_name' ) );
		$cost     = $request->get_param( 'cost_price' );

		if ( $supplier ) {
			$extra['supplier_name'] = $supplier;
		}

		if ( is_numeric( $cost ) ) {
			$extra['cost_price'] = (float) $cost;
		}

		return $extra;
	}

	/**
	 * Add wastage quantity with reason and note
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|WP_REST_Response
	 */
	public function add_wastage( \WP_REST_Request $request ) {
		$product_id = (int) $request->get_param( 'id' );
		$qty        = (int) $request->get_param( 'quantity' );
		$note       = (string) $request->get_param( 'note' );
		$reason     = (string) $request->get_param( 'reason' );
		$date       = (string) $request->get_param( 'date' );

		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error(
				'unauthorized',
				'Authentication failed',
				[ 'status' => 401 ]
			);
		}

		$result = $this->inventory_service->add_wastage_qty(
			$product_id,
			$qty,
			$reason,
			$note,
			$date
		);

		if ( is_wp_error( $result ) ) {
			return rest_ensure_response( [
				'success' => false,
				'error'   => $result->get_error_message(),
			] );
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => 'Inventory added successfully',
		] );
	}


	/**
	 * Inventory logs
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|WP_REST_Response
	 */
	public function inventory_logs( \WP_REST_Request $request ) {

		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		global $wpdb;

		$table = "{$wpdb->prefix}fm_inventory_logs";

		// ---------- Params ----------
		$product_id = (int) $request->get_param( 'product_id' );

		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$pageSize = max( 1, (int) $request->get_param( 'pageSize' ) );
		$offset   = ( $page - 1 ) * $pageSize;

		$type    = sanitize_text_field( $request->get_param( 'type' ) );
		$from    = sanitize_text_field( $request->get_param( 'from' ) );
		$to      = sanitize_text_field( $request->get_param( 'to' ) );
		$orderBy = sanitize_text_field( $request->get_param( 'orderBy' ) );
		$order   = sanitize_text_field( $request->get_param( 'order' ) );

		// ---------- WHERE ----------
		$where  = [];
		$params = [];

		if ( $product_id > 0 ) {
			$where[]  = 'product_id = %d';
			$params[] = $product_id;
		}

		if ( $type ) {
			$where[]  = 'change_type = %s';
			$params[] = $type;
		}

		if ( $from && $to ) {
			$where[]  = 'DATE(occurred_at) BETWEEN %s AND %s';
			$params[] = $from;
			$params[] = $to;
		}

		$where_sql = ! empty( $where ) ? 'WHERE ' . implode( ' AND ', $where ) : '';

		// ---------- Total ----------
		if ( ! empty( $params ) ) {
			$total = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} {$where_sql}",
					$params
				)
			);
		} else {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
		}

		// ---------- Data ----------

		$allowed_order_by = [ 'created_at', 'occurred_at' ];

		$orderBy = in_array( $orderBy, $allowed_order_by, true ) ? $orderBy : 'occurred_at';

		$order = strtoupper( $order ) === 'ASC' ? 'ASC' : 'DESC';

//		phpcs:disable
		$sql  = "
		    SELECT
		        id,
		        product_id,
		        change_type,
		        quantity,
		        reason,
		        note,
		        reference_id,
		        created_by,
		        supplier_name,
		        cost_price,
		        occurred_at,
		        created_at
		    FROM {$table}
		    {$where_sql}
		    ORDER BY {$orderBy} {$order}
		    LIMIT %d OFFSET %d
		";
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				$sql,
				array_merge( $params, [ $pageSize, $offset ] )
			),
			ARRAY_A
		);

		// ---------- Normalize ----------
		$logs = array_map( function ( $row ) {

			$positive     = in_array( $row['change_type'], [ 'add', 'opening', 'adj_add', 'restore' ], true );
			$created_by   = ! empty( $row['created_by'] ) ? get_userdata( (int) $row['created_by'] ) : null;
			$product_name = get_the_title( (int) $row['product_id'] );

			$variation_label = '';
			if ( ! empty( $row['variation_id'] ) && (int) $row['variation_id'] > 0 ) {
				$variation = wc_get_product( (int) $row['variation_id'] );
				if ( $variation ) {
					$attrs = $variation->get_variation_attributes();
					$variation_label = implode( ', ', array_filter( array_values( $attrs ) ) );
				}
			}

			return [
				'id'              => (int) $row['id'],
				'product_name'    => $product_name ?: 'Unknown',
				'variation_id'    => (int) ( $row['variation_id'] ?? 0 ),
				'variation_label' => $variation_label,
				'change_type'     => $row['change_type'],
				'quantity'      => (int) $row['quantity'],
				'direction'     => $positive ? '+' : '-',
				'reason'        => $row['reason'],
				'note'          => $row['note'],
				'reference'     => $row['reference_id'] ? (int) $row['reference_id'] : null,
				'created_by'    => $created_by ? $created_by->display_name : '',
				'supplier_name' => $row['supplier_name'] ?? '',
				'cost_price'    => $row['cost_price'] ? (float) $row['cost_price'] : null,
				'occurred_at' => mysql2date(
					get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
					$row['occurred_at']
				),
				'created_at'  => mysql2date(
					get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
					$row['created_at']
				),
			];
		}, $rows );

		// ---------- Response ----------
		return rest_ensure_response( [
			'title'      => $product_id > 0 ? get_the_title( $product_id ) : __( 'All Products', 'food-menu-pro' ),
			'logs'       => $logs,
			'pagination' => [
				'total'    => $total,
				'current'  => $page,
				'pageSize' => $pageSize,
			],
		] );
	}


	/**
	 * Quantities put back on the shelf by a cancelled or refunded order.
	 *
	 * Cancelling an order restores its stock and writes a `restore` log, but the
	 * `sale` log written when the order came in is left untouched — that history is
	 * deliberate. It does mean any chart that simply sums `sale` keeps counting food
	 * that was ultimately never sold, which is what makes a report read high after a
	 * busy night of cancellations.
	 *
	 * Each restore is attributed back to the day of **its own sale**, not the day the
	 * cancellation was processed — the same rule `ReportsApi::get_real_sales()` uses
	 * for refunds. An order taken Monday and cancelled Wednesday corrects Monday, so
	 * a period that has already been reported on is never rewritten by later admin
	 * work, and no day can show a negative "sold".
	 *
	 * Restores with no matching sale (a manual stock restore) fall back to their own
	 * date. Only restores that happened on or after `$from` are scanned — a restore
	 * can never precede the sale it undoes — which keeps this off the full log table.
	 *
	 * @param string $from  Period start, `Y-m-d`.
	 * @param string $to    Period end, `Y-m-d`.
	 * @param string $group `date` to key by sale date, `product` to key by product id.
	 *
	 * @return array<string|int,int> Restored quantity keyed as requested.
	 */
	private function restored_quantities( string $from, string $to, string $group = 'date' ): array {
		global $wpdb;

		$logs_table  = "{$wpdb->prefix}fm_inventory_logs";
		$exclude_sql = FnsPro::build_excluded_products_sql( 'r.product_id' );

		$key_select = 'product' === $group ? 't.product_id' : 't.sale_date';

		$sql = $wpdb->prepare(
			// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- identifiers only.
			"SELECT {$key_select} AS group_key, SUM(t.quantity) AS restored
			FROM (
				SELECT
					r.product_id,
					r.quantity,
					DATE(
						COALESCE(
							(
								SELECT MIN( s.occurred_at )
								FROM {$logs_table} s
								WHERE s.product_id = r.product_id
									AND s.change_type = 'sale'
									AND s.reference_id = r.reference_id
									AND r.reference_id > 0
							),
							r.occurred_at
						)
					) AS sale_date
				FROM {$logs_table} r
				WHERE r.change_type = 'restore'
					AND r.occurred_at >= %s
					{$exclude_sql}
			) t
			WHERE t.sale_date BETWEEN %s AND %s
			GROUP BY group_key",
			// phpcs:enable
			$from . ' 00:00:00',
			$from,
			$to
		);

		$restored = [];

		foreach ( (array) $wpdb->get_results( $sql, ARRAY_A ) as $row ) {
			$key = 'product' === $group ? (int) $row['group_key'] : (string) $row['group_key'];

			$restored[ $key ] = (int) $row['restored'];
		}

		return $restored;
	}

	/**
	 * Inventory Reports
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|WP_REST_Response
	 */
	public function inventory_reports( \WP_REST_Request $request ) {

		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		global $wpdb;

		$logs_table = "{$wpdb->prefix}fm_inventory_logs";

		$from = sanitize_text_field( $request->get_param( 'from' ) );
		$to   = sanitize_text_field( $request->get_param( 'to' ) );

		if ( ! $from || ! $to ) {
			$to   = current_time( 'Y-m-d' );
			$from = date( 'Y-m-d', strtotime( '-' . FnsPro::reports_default_days() . ' days', strtotime( $to ) ) );
		}

		// Excluded product types (Front-End Dashboard → Order Management) must stay
		// out of every chart on this page, not just the orders list.
		$log_exclude_sql  = FnsPro::build_excluded_products_sql( "{$logs_table}.product_id" );
		$post_exclude_sql = FnsPro::build_excluded_products_sql( 'p.ID' );

		/*
		 * Sold vs Waste (Line / Area Chart)
		 * ------------------------------------------------- */
		$sold_vs_waste_sql = $wpdb->prepare(
			"
		SELECT
			DATE(occurred_at) as log_date,
			SUM(CASE WHEN change_type = 'sale' THEN quantity ELSE 0 END) as sold,
			SUM(CASE WHEN change_type = 'wastage' THEN quantity ELSE 0 END) as waste
		FROM {$logs_table}
		WHERE DATE(occurred_at) BETWEEN %s AND %s {$log_exclude_sql}
		GROUP BY DATE(occurred_at)
		ORDER BY log_date ASC
		",
			$from,
			$to
		);

		$sold_vs_waste_rows = $wpdb->get_results( $sold_vs_waste_sql, ARRAY_A );

		// Cancelling an order restores its stock but leaves the original `sale` log
		// in place, so a raw SUM of `sale` keeps counting food that was never sold.
		$restored_by_date = $this->restored_quantities( $from, $to, 'date' );

		$soldVsWasteData = array_map( function ( $row ) use ( $restored_by_date ) {
			$date     = $row['log_date'];
			$restored = isset( $restored_by_date[ $date ] ) ? (int) $restored_by_date[ $date ] : 0;

			return [
				'date'  => $date,
				'sold'  => max( 0, (int) $row['sold'] - $restored ),
				'waste' => (int) $row['waste'],
			];
		}, $sold_vs_waste_rows );

		/*
		 * Remaining by Category (Bar Chart)
		 * Single SQL query instead of loading all products into PHP.
		 * ------------------------------------------------- */
		$cat_sql = "SELECT t.name AS category, SUM(CAST(pm_stock.meta_value AS SIGNED)) AS remaining
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} pm_manage ON pm_manage.post_id = p.ID
				AND pm_manage.meta_key = '_manage_stock' AND pm_manage.meta_value = 'yes'
			INNER JOIN {$wpdb->postmeta} pm_stock ON pm_stock.post_id = p.ID
				AND pm_stock.meta_key = '_stock'
			INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
				AND tt.taxonomy = 'product_cat'
			INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
			WHERE p.post_type = 'product' AND p.post_status = 'publish'
				AND CAST(pm_stock.meta_value AS SIGNED) > 0
				{$post_exclude_sql}
			GROUP BY t.name
			ORDER BY remaining DESC
			LIMIT 15";

		$cat_rows = $wpdb->get_results( $cat_sql, ARRAY_A );
		$remainingByCategoryData = array_map( function ( $row ) {
			return [
				'category'  => $row['category'],
				'remaining' => (int) $row['remaining'],
			];
		}, $cat_rows );

		/*
		 * Most Wasted Foods (Top 10)
		 * ------------------------------------------------- */
		$most_wasted_sql = $wpdb->prepare(
			"
		SELECT
			product_id,
			SUM(quantity) as wasted
		FROM {$logs_table}
		WHERE change_type = 'wastage'
		  AND DATE(occurred_at) BETWEEN %s AND %s
		  {$log_exclude_sql}
		GROUP BY product_id
		ORDER BY wasted DESC
		LIMIT 10
		",
			$from,
			$to
		);

		$most_wasted_rows = $wpdb->get_results( $most_wasted_sql, ARRAY_A );

		$mostWastedFoodsData = [];

		foreach ( $most_wasted_rows as $row ) {
			$product = wc_get_product( (int) $row['product_id'] );
			if ( ! $product ) {
				continue;
			}

			$mostWastedFoodsData[] = [
				'name'   => $product->get_name(),
				'wasted' => (int) $row['wasted'],
			];
		}

		/*
		 * #17 — Stock Movement Velocity
		 * Average daily sales per product + predicted stock-out date.
		 * ------------------------------------------------- */
		$days_in_range = max( 1, ( strtotime( $to ) - strtotime( $from ) ) / 86400 );

		$velocity_sql = $wpdb->prepare(
			"SELECT product_id, SUM(quantity) as total_sold
			FROM {$logs_table}
			WHERE change_type = 'sale' AND DATE(occurred_at) BETWEEN %s AND %s {$log_exclude_sql}
			GROUP BY product_id
			ORDER BY total_sold DESC
			LIMIT 20",
			$from,
			$to
		);

		$velocity_rows = $wpdb->get_results( $velocity_sql, ARRAY_A );

		// Same correction as the Sold vs Waste chart — a cancelled order must not
		// keep inflating a product's daily average.
		$restored_by_product = $this->restored_quantities( $from, $to, 'product' );

		$velocityData = [];

		foreach ( $velocity_rows as $row ) {
			$product_id = (int) $row['product_id'];
			$product    = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}

			$restored   = isset( $restored_by_product[ $product_id ] ) ? (int) $restored_by_product[ $product_id ] : 0;
			$total_sold = max( 0, (int) $row['total_sold'] - $restored );

			// Everything sold was cancelled again — not a moving product at all.
			if ( $total_sold <= 0 ) {
				continue;
			}

			$daily_avg   = round( $total_sold / $days_in_range, 1 );
			$stock       = (int) $product->get_stock_quantity();
			$days_left   = $daily_avg > 0 ? round( $stock / $daily_avg ) : null;

			$velocityData[] = [
				'name'      => $product->get_name(),
				'daily_avg' => $daily_avg,
				'stock'     => $stock,
				'days_left' => $days_left,
			];
		}

		// Netting can reorder the list, so restore the "fastest moving first" order.
		usort(
			$velocityData,
			function ( $a, $b ) {
				return $b['daily_avg'] <=> $a['daily_avg'];
			}
		);

		/*
		 * #18 — Waste Percentage Analysis
		 * Waste as % of total inventory (add + opening) per product.
		 * ------------------------------------------------- */
		$waste_pct_sql = $wpdb->prepare(
			"SELECT
				product_id,
				SUM(CASE WHEN change_type IN ('add','opening','adj_add') THEN quantity ELSE 0 END) as total_in,
				SUM(CASE WHEN change_type = 'wastage' THEN quantity ELSE 0 END) as total_waste
			FROM {$logs_table}
			WHERE DATE(occurred_at) BETWEEN %s AND %s {$log_exclude_sql}
			GROUP BY product_id
			HAVING total_waste > 0
			ORDER BY total_waste DESC
			LIMIT 15",
			$from,
			$to
		);

		$waste_pct_rows = $wpdb->get_results( $waste_pct_sql, ARRAY_A );
		$wastePctData   = [];

		foreach ( $waste_pct_rows as $row ) {
			$product = wc_get_product( (int) $row['product_id'] );
			if ( ! $product ) {
				continue;
			}

			$total_in    = max( 1, (int) $row['total_in'] );
			$total_waste = (int) $row['total_waste'];
			$pct         = round( ( $total_waste / $total_in ) * 100, 1 );

			$wastePctData[] = [
				'name'       => $product->get_name(),
				'total_in'   => $total_in,
				'waste'      => $total_waste,
				'percentage' => $pct,
			];
		}

		/*
		 * #19 — Period Comparison
		 * Compare current period vs previous period of same length.
		 * ------------------------------------------------- */
		$days_count    = (int) $days_in_range;
		$prev_from     = date( 'Y-m-d', strtotime( $from ) - ( $days_count * 86400 ) );
		$prev_to       = date( 'Y-m-d', strtotime( $from ) - 86400 );

		$comparison_sql = $wpdb->prepare(
			"SELECT
				CASE WHEN DATE(occurred_at) BETWEEN %s AND %s THEN 'current' ELSE 'previous' END as period,
				SUM(CASE WHEN change_type = 'sale' THEN quantity ELSE 0 END) as sold,
				SUM(CASE WHEN change_type = 'wastage' THEN quantity ELSE 0 END) as waste,
				SUM(CASE WHEN change_type IN ('add','opening') THEN quantity ELSE 0 END) as added
			FROM {$logs_table}
			WHERE DATE(occurred_at) BETWEEN %s AND %s {$log_exclude_sql}
			GROUP BY period",
			$from,
			$to,
			$prev_from,
			$to
		);

		$comparison_rows = $wpdb->get_results( $comparison_sql, ARRAY_A );
		$comparison      = [ 'current' => null, 'previous' => null ];

		foreach ( $comparison_rows as $row ) {
			$comparison[ $row['period'] ] = [
				'sold'  => (int) $row['sold'],
				'waste' => (int) $row['waste'],
				'added' => (int) $row['added'],
			];
		}

		// Calculate change percentages.
		$comparisonData = [];
		if ( $comparison['current'] && $comparison['previous'] ) {
			foreach ( [ 'sold', 'waste', 'added' ] as $metric ) {
				$curr = $comparison['current'][ $metric ];
				$prev = $comparison['previous'][ $metric ];
				$change = $prev > 0 ? round( ( ( $curr - $prev ) / $prev ) * 100, 1 ) : ( $curr > 0 ? 100 : 0 );

				$comparisonData[] = [
					'metric'   => ucfirst( $metric ),
					'current'  => $curr,
					'previous' => $prev,
					'change'   => $change,
				];
			}
		}

		/* -------------------------------------------------
		 * Response
		 * ------------------------------------------------- */

		return rest_ensure_response( [
			'soldVsWasteData'         => $soldVsWasteData,
			'remainingByCategoryData' => array_values( $remainingByCategoryData ),
			'mostWastedFoodsData'     => $mostWastedFoodsData,
			'velocityData'            => $velocityData,
			'wastePctData'            => $wastePctData,
			'comparisonData'          => $comparisonData,
			'dateRange'               => [ 'from' => $from, 'to' => $to ],
		] );
	}

	/**
	 * Get inventory settings.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|WP_REST_Response
	 */
	public function get_inventory_settings( \WP_REST_Request $request ) {

		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$settings      = get_option( 'fmp_inventory_settings', [] );
		$main_settings = get_option( TLPFoodMenu()->options['settings'], [] );

		$waste_reasons = isset( $main_settings['fmp_waste_reasons'] ) && is_array( $main_settings['fmp_waste_reasons'] )
			? array_values( $main_settings['fmp_waste_reasons'] )
			: ( isset( $settings['waste_reasons'] ) ? (array) $settings['waste_reasons'] : [ 'Expired', 'Damaged', 'Spoiled', 'Broken', 'Returned' ] );

		return rest_ensure_response( [
			'low_stock_threshold' => isset( $settings['low_stock_threshold'] ) ? (int) $settings['low_stock_threshold'] : 10,
			'waste_reasons'       => $waste_reasons,
			'orders_enabled'      => isset( $settings['orders_enabled'] ) ? (bool) $settings['orders_enabled'] : true,
			'orders_per_page'     => isset( $settings['orders_per_page'] ) ? (int) $settings['orders_per_page'] : 10,
		] );
	}

	/**
	 * Save inventory settings.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|WP_REST_Response
	 */
	public function save_inventory_settings( \WP_REST_Request $request ) {

		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$current  = get_option( 'fmp_inventory_settings', [] );
		$settings = [];

		$threshold = $request->get_param( 'low_stock_threshold' );
		if ( $threshold !== null ) {
			$settings['low_stock_threshold'] = max( 0, (int) $threshold );
		}

		$orders_enabled = $request->get_param( 'orders_enabled' );
		if ( $orders_enabled !== null ) {
			$settings['orders_enabled'] = (bool) $orders_enabled;
		}

		$orders_per_page = $request->get_param( 'orders_per_page' );
		if ( $orders_per_page !== null ) {
			$settings['orders_per_page'] = max( 1, (int) $orders_per_page );
		}

		update_option( 'fmp_inventory_settings', array_merge( $current, $settings ) );

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Settings saved successfully', 'food-menu-pro' ),
		] );
	}

	/**
	 * #10 — Undo/reverse a log entry.
	 */
	public function undo_log( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$log_id = (int) $request->get_param( 'log_id' );
		if ( ! $log_id ) {
			return new \WP_Error( 'invalid', 'Log ID is required', [ 'status' => 400 ] );
		}

		$model = new \RT\FoodMenuPro\Models\InventoryModel();
		$log   = $model->get_log_by_id( $log_id );

		if ( ! $log ) {
			return new \WP_Error( 'not_found', 'Log entry not found', [ 'status' => 404 ] );
		}

		if ( $log['change_type'] === 'opening' ) {
			return new \WP_Error( 'forbidden', 'Opening inventory cannot be reversed', [ 'status' => 400 ] );
		}

		if ( $model->has_reversal( $log_id ) ) {
			return new \WP_Error( 'already_reversed', 'This entry has already been reversed', [ 'status' => 400 ] );
		}

		$positive_types = [ 'add', 'opening', 'adj_add', 'restore' ];
		$was_positive   = in_array( $log['change_type'], $positive_types, true );

		// Reverse: if original added stock, we remove; if original removed stock, we add.
		$reverse_type = $was_positive ? 'adj_remove' : 'adj_add';

		$result = $this->inventory_service->add_inventory_qty(
			(int) $log['product_id'],
			(int) $log['quantity'],
			sprintf( 'Reversal of log #%d (%s)', $log_id, $log['change_type'] ),
			$reverse_type,
			'reversal'
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Link the reversal to the original via reference_id.
		global $wpdb;
		$table  = $wpdb->prefix . 'fm_inventory_logs';
		$new_id = $wpdb->get_var( "SELECT MAX(id) FROM {$table}" );
		if ( $new_id ) {
			$wpdb->update( $table, [ 'reference_id' => $log_id, 'reason' => 'reversal' ], [ 'id' => $new_id ] );
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Log entry reversed successfully', 'food-menu-pro' ),
		] );
	}

	/**
	 * #11 — Stock reconciliation report.
	 */
	public function reconciliation( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'fm_inventory_logs';

		// Get expected stock from logs per product.
		$log_data = $wpdb->get_results(
			"SELECT product_id,
				SUM(CASE WHEN change_type IN ('add','opening','adj_add','restore') THEN quantity ELSE 0 END) AS total_in,
				SUM(CASE WHEN change_type IN ('sale','wastage','adj_remove') THEN quantity ELSE 0 END) AS total_out
			FROM {$table}
			GROUP BY product_id",
			ARRAY_A
		);

		$expected_map = [];
		foreach ( $log_data as $row ) {
			$expected_map[ (int) $row['product_id'] ] = (int) $row['total_in'] - (int) $row['total_out'];
		}

		// Get tracked products.
		$product_ids = get_posts( [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'meta_key'       => '_fmp_inventory',
			'meta_value'     => '1',
			'fields'         => 'ids',
			'posts_per_page' => -1,
		] );

		$items = [];
		foreach ( $product_ids as $pid ) {
			$product = wc_get_product( $pid );
			if ( ! $product || ! $product->managing_stock() ) {
				continue;
			}

			$actual     = (int) $product->get_stock_quantity();
			$expected   = $expected_map[ $pid ] ?? 0;
			$discrepancy = $actual - $expected;

			// Prices ride along so the Adjust modal opened from this page identifies
			// the product the same way it does on the Inventory page.
			$prices = FnsPro::get_product_price_fields( $product );

			$items[] = [
				'product_id'    => $pid,
				'name'          => $product->get_name(),
				'permalink'     => $product->get_permalink(),
				'price'         => $prices['price'],
				'regular_price' => $prices['regular_price'],
				'sale_price'    => $prices['sale_price'],
				'expected'      => $expected,
				'actual'        => $actual,
				'discrepancy'   => $discrepancy,
				'status'        => $discrepancy === 0 ? 'match' : ( $discrepancy > 0 ? 'over' : 'under' ),
			];
		}

		return rest_ensure_response( [ 'items' => $items ] );
	}

	/**
	 * #9 — Batch import inventory from CSV.
	 */
	public function import_inventory( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$files = $request->get_file_params();
		if ( empty( $files['file']['tmp_name'] ) ) {
			return new \WP_Error( 'no_file', 'CSV file is required', [ 'status' => 400 ] );
		}

		$handle = fopen( $files['file']['tmp_name'], 'r' );
		if ( ! $handle ) {
			return new \WP_Error( 'read_error', 'Cannot read uploaded file', [ 'status' => 400 ] );
		}

		// Read header row.
		$header = fgetcsv( $handle );
		if ( ! $header ) {
			fclose( $handle );
			return new \WP_Error( 'invalid_csv', 'CSV is empty or malformed', [ 'status' => 400 ] );
		}

		$header = array_map( 'strtolower', array_map( 'trim', $header ) );

		// Find column indexes.
		$sku_col  = array_search( 'sku', $header, true );
		$id_col   = array_search( 'product_id', $header, true );
		$qty_col  = array_search( 'quantity', $header, true );
		$note_col = array_search( 'note', $header, true );
		$cost_col = array_search( 'cost_price', $header, true );
		$sup_col  = array_search( 'supplier', $header, true );

		if ( $qty_col === false ) {
			fclose( $handle );
			return new \WP_Error( 'missing_column', 'CSV must have a "quantity" column', [ 'status' => 400 ] );
		}

		if ( $sku_col === false && $id_col === false ) {
			fclose( $handle );
			return new \WP_Error( 'missing_column', 'CSV must have a "sku" or "product_id" column', [ 'status' => 400 ] );
		}

		$success = 0;
		$skipped = 0;
		$errors  = [];
		$row_num = 1;

		while ( ( $row = fgetcsv( $handle ) ) !== false ) {
			$row_num++;
			$product_id = 0;

			if ( $id_col !== false && ! empty( $row[ $id_col ] ) ) {
				$product_id = (int) $row[ $id_col ];
			} elseif ( $sku_col !== false && ! empty( $row[ $sku_col ] ) ) {
				$product_id = wc_get_product_id_by_sku( trim( $row[ $sku_col ] ) );
			}

			if ( ! $product_id ) {
				$errors[] = [ 'row' => $row_num, 'message' => 'Product not found' ];
				$skipped++;
				continue;
			}

			$qty = (int) ( $row[ $qty_col ] ?? 0 );
			if ( $qty <= 0 ) {
				$errors[] = [ 'row' => $row_num, 'message' => 'Invalid quantity' ];
				$skipped++;
				continue;
			}

			$note          = ( $note_col !== false ) ? sanitize_text_field( $row[ $note_col ] ?? '' ) : 'CSV Import';
			$cost_price    = ( $cost_col !== false && is_numeric( $row[ $cost_col ] ?? '' ) ) ? max( 0, (float) $row[ $cost_col ] ) : null;
			$supplier_name = ( $sup_col !== false ) ? sanitize_text_field( $row[ $sup_col ] ?? '' ) : '';

			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				$errors[] = [ 'row' => $row_num, 'message' => 'Product not found' ];
				$skipped++;
				continue;
			}

			// Enable stock management if not already.
			if ( ! $product->managing_stock() ) {
				$this->inventory_service->enable_inventory_with_opening_stock( $product_id, $qty, $note, false );
			} else {
				$this->inventory_service->add_inventory_qty( $product_id, $qty, $note );
			}

			// Update supplier/cost on the last inserted log.
			if ( $cost_price || $supplier_name ) {
				global $wpdb;
				$log_table = $wpdb->prefix . 'fm_inventory_logs';
				$last_id   = $wpdb->get_var( "SELECT MAX(id) FROM {$log_table} WHERE product_id = {$product_id}" );
				if ( $last_id ) {
					$update = [];
					if ( $supplier_name ) {
						$update['supplier_name'] = $supplier_name;
					}
					if ( $cost_price ) {
						$update['cost_price'] = $cost_price;
					}
					$wpdb->update( $log_table, $update, [ 'id' => $last_id ] );
				}
			}

			$success++;
		}

		fclose( $handle );

		return rest_ensure_response( [
			'success' => true,
			'message' => sprintf( '%d imported, %d skipped', $success, $skipped ),
			'imported' => $success,
			'skipped'  => $skipped,
			'errors'   => array_slice( $errors, 0, 20 ),
		] );
	}

	/**
	 * #14 — Inventory valuation report.
	 */
	public function valuation( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'fm_inventory_logs';

		// Get the latest cost_price per product (from the most recent log that has a cost_price).
		$cost_data = $wpdb->get_results(
			"SELECT l.product_id, l.cost_price
			FROM {$table} l
			INNER JOIN (
				SELECT product_id, MAX(id) AS max_id
				FROM {$table}
				WHERE cost_price IS NOT NULL AND cost_price > 0
				GROUP BY product_id
			) latest ON l.id = latest.max_id",
			ARRAY_A
		);

		$cost_map = [];
		foreach ( $cost_data as $row ) {
			$cost_map[ (int) $row['product_id'] ] = (float) $row['cost_price'];
		}

		$product_ids = get_posts( [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'meta_key'       => '_fmp_inventory',
			'meta_value'     => '1',
			'fields'         => 'ids',
			'posts_per_page' => -1,
		] );

		$items           = [];
		$total_valuation = 0;

		foreach ( $product_ids as $pid ) {
			$product = wc_get_product( $pid );
			if ( ! $product || ! $product->managing_stock() ) {
				continue;
			}

			$stock      = (int) $product->get_stock_quantity();
			$cost_price = $cost_map[ $pid ] ?? 0;
			$value      = $stock * $cost_price;
			$total_valuation += $value;

			$items[] = [
				'product_id'  => $pid,
				'name'        => $product->get_name(),
				'stock'       => $stock,
				'cost_price'  => $cost_price,
				'value'       => round( $value, 2 ),
				'sell_price'  => (float) $product->get_price(),
			];
		}

		return rest_ensure_response( [
			'items'           => $items,
			'total_valuation' => round( $total_valuation, 2 ),
		] );
	}

}
