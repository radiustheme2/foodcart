<?php
/**
 * Supplier REST API.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\Inventory;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

class SupplierApi {

	use SingletonTrait;

	private string $table = 'fm_suppliers';

	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	public function register_routes() {
		$namespace  = 'fmp/v1';
		$permission      = FnsPro::menu_permission( [ 'suppliers' ] );
		$read_permission = FnsPro::menu_permission( [ 'suppliers', 'purchase-orders' ] ); // PO screen's supplier picker.

		register_rest_route( $namespace, '/suppliers', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'list_suppliers' ],
			'permission_callback' => $read_permission,
		] );

		register_rest_route( $namespace, '/suppliers', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'create_supplier' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/suppliers/(?P<id>\d+)', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_supplier' ],
			'permission_callback' => $read_permission,
		] );

		register_rest_route( $namespace, '/suppliers/(?P<id>\d+)', [
			'methods'             => 'PUT',
			'callback'            => [ $this, 'update_supplier' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/suppliers/(?P<id>\d+)', [
			'methods'             => 'DELETE',
			'callback'            => [ $this, 'delete_supplier' ],
			'permission_callback' => $permission,
		] );
	}

	private function verify_nonce( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}
		return true;
	}

	public function list_suppliers( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		global $wpdb;
		$table = $wpdb->prefix . $this->table;

		$search = sanitize_text_field( $request->get_param( 'search' ) );
		$status = sanitize_text_field( $request->get_param( 'status' ) );
		$all    = $request->get_param( 'all' );

		$where  = '1=1';
		$params = [];

		if ( $status ) {
			$where   .= ' AND status = %s';
			$params[] = $status;
		} else {
			// Default: only active suppliers.
			$where .= " AND status = 'active'";
		}

		if ( $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (name LIKE %s OR email LIKE %s OR phone LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		// If 'all' param is set, return all without pagination (for dropdowns).
		if ( $all ) {
			$sql  = "SELECT * FROM {$table} WHERE {$where} ORDER BY name ASC";
			$rows = empty( $params )
				? $wpdb->get_results( $sql, ARRAY_A )
				: $wpdb->get_results( $wpdb->prepare( $sql, ...$params ), ARRAY_A );

			return rest_ensure_response( $rows );
		}

		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = max( 1, (int) $request->get_param( 'per_page' ) ?: 20 );
		$offset   = ( $page - 1 ) * $per_page;

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
		$list_sql  = "SELECT * FROM {$table} WHERE {$where} ORDER BY name ASC LIMIT %d OFFSET %d";

		$params_count = $params;
		$params[]     = $per_page;
		$params[]     = $offset;

		$total = empty( $params_count )
			? (int) $wpdb->get_var( $count_sql )
			: (int) $wpdb->get_var( $wpdb->prepare( $count_sql, ...$params_count ) );

		$rows = $wpdb->get_results( $wpdb->prepare( $list_sql, ...$params ), ARRAY_A );

		return rest_ensure_response( [
			'suppliers' => $rows,
			'meta'      => [
				'total'    => $total,
				'current'  => $page,
				'pageSize' => $per_page,
			],
		] );
	}

	public function create_supplier( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		global $wpdb;

		$name = sanitize_text_field( $request->get_param( 'name' ) );
		if ( empty( $name ) ) {
			return new \WP_Error( 'missing_name', 'Supplier name is required', [ 'status' => 400 ] );
		}

		$result = $wpdb->insert(
			$wpdb->prefix . $this->table,
			[
				'name'       => $name,
				'email'      => sanitize_email( $request->get_param( 'email' ) ) ?: null,
				'phone'      => sanitize_text_field( $request->get_param( 'phone' ) ) ?: null,
				'address'    => sanitize_textarea_field( $request->get_param( 'address' ) ) ?: null,
				'notes'      => sanitize_textarea_field( $request->get_param( 'notes' ) ) ?: null,
				'status'     => 'active',
				'created_at' => current_time( 'mysql' ),
				'updated_at' => current_time( 'mysql' ),
			]
		);

		if ( false === $result ) {
			return new \WP_Error( 'db_error', 'Failed to create supplier: ' . $wpdb->last_error, [ 'status' => 500 ] );
		}

		$id       = (int) $wpdb->insert_id;
		$supplier = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}{$this->table} WHERE id = %d", $id ),
			ARRAY_A
		);

		return rest_ensure_response( [
			'success'  => true,
			'supplier' => $supplier,
		] );
	}

	public function get_supplier( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		global $wpdb;
		$supplier = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}{$this->table} WHERE id = %d", (int) $request->get_param( 'id' ) ),
			ARRAY_A
		);

		if ( ! $supplier ) {
			return new \WP_Error( 'not_found', 'Supplier not found', [ 'status' => 404 ] );
		}

		return rest_ensure_response( $supplier );
	}

	public function update_supplier( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		global $wpdb;
		$id     = (int) $request->get_param( 'id' );
		$update = [];

		foreach ( [ 'name', 'phone', 'status' ] as $field ) {
			$value = $request->get_param( $field );
			if ( $value !== null ) {
				$update[ $field ] = sanitize_text_field( $value );
			}
		}
		$email = $request->get_param( 'email' );
		if ( $email !== null ) {
			$update['email'] = sanitize_email( $email ) ?: null;
		}
		foreach ( [ 'address', 'notes' ] as $field ) {
			$value = $request->get_param( $field );
			if ( $value !== null ) {
				$update[ $field ] = sanitize_textarea_field( $value ) ?: null;
			}
		}

		if ( empty( $update ) ) {
			return new \WP_Error( 'no_changes', 'No data to update', [ 'status' => 400 ] );
		}

		$update['updated_at'] = current_time( 'mysql' );
		$wpdb->update( $wpdb->prefix . $this->table, $update, [ 'id' => $id ] );

		$supplier = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}{$this->table} WHERE id = %d", $id ),
			ARRAY_A
		);

		return rest_ensure_response( [
			'success'  => true,
			'supplier' => $supplier,
		] );
	}

	public function delete_supplier( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		global $wpdb;
		$id = (int) $request->get_param( 'id' );

		// Soft delete: set status to inactive.
		$wpdb->update(
			$wpdb->prefix . $this->table,
			[ 'status' => 'inactive', 'updated_at' => current_time( 'mysql' ) ],
			[ 'id' => $id ]
		);

		return rest_ensure_response( [ 'success' => true ] );
	}
}
