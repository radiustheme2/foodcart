<?php
/**
 * Stock Alert REST API.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\Inventory;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

class StockAlertApi {

	use SingletonTrait;

	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	public function register_routes() {
		$namespace  = 'fmp/v1';
		$permission = FnsPro::menu_permission( [ 'stock-alerts' ] );

		register_rest_route( $namespace, '/stock-alerts', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_alerts' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/stock-alerts/history', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_history' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/stock-alerts/settings', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_settings' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/stock-alerts/settings', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'save_settings' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/stock-alerts/test', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'test_notification' ],
			'permission_callback' => $permission,
		] );
	}

	private function verify_nonce( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}
		return true;
	}

	/**
	 * Get current low/out-of-stock products.
	 */
	public function get_alerts( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$settings  = get_option( 'fmp_inventory_settings', [] );
		$threshold = isset( $settings['low_stock_threshold'] ) ? (int) $settings['low_stock_threshold'] : 10;

		$product_ids = get_posts( [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'meta_key'       => '_fmp_inventory',
			'meta_value'     => '1',
			'fields'         => 'ids',
			'posts_per_page' => -1,
		] );

		$alerts = [];
		foreach ( $product_ids as $pid ) {
			$product = wc_get_product( $pid );
			if ( ! $product || ! $product->managing_stock() ) {
				continue;
			}

			$stock              = (int) $product->get_stock_quantity();
			$product_threshold  = get_post_meta( $pid, '_fmp_low_stock_threshold', true );
			$effective_threshold = is_numeric( $product_threshold ) ? (int) $product_threshold : $threshold;

			if ( $stock <= $effective_threshold ) {
				$last_notified = get_post_meta( $pid, '_fmp_low_stock_notified_qty', true );
				$alerts[]      = [
					'product_id'   => $pid,
					'product_name' => $product->get_name(),
					'stock'        => $stock,
					'threshold'    => $effective_threshold,
					'alert_type'   => $stock <= 0 ? 'out_of_stock' : 'low_stock',
					'notified'     => $last_notified !== '',
				];
			}
		}

		// Sort: out of stock first, then by stock ascending.
		usort( $alerts, function ( $a, $b ) {
			if ( $a['stock'] === $b['stock'] ) {
				return 0;
			}
			return $a['stock'] < $b['stock'] ? -1 : 1;
		} );

		return rest_ensure_response( [
			'alerts'    => $alerts,
			'threshold' => $threshold,
			'total'     => count( $alerts ),
		] );
	}

	/**
	 * Get notification history.
	 */
	public function get_history( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		global $wpdb;
		$table    = $wpdb->prefix . 'fm_stock_alert_log';
		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = max( 1, (int) $request->get_param( 'per_page' ) ?: 20 );
		$offset   = ( $page - 1 ) * $per_page;

		// Check if table exists.
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $table_exists ) {
			return rest_ensure_response( [
				'history' => [],
				'meta'    => [ 'total' => 0, 'current' => 1, 'pageSize' => $per_page ],
			] );
		}

		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY created_at DESC LIMIT %d OFFSET %d",
				$per_page,
				$offset
			),
			ARRAY_A
		);

		foreach ( $rows as &$row ) {
			$product             = wc_get_product( (int) $row['product_id'] );
			$row['product_name'] = $product ? $product->get_name() : 'Deleted Product';
		}

		return rest_ensure_response( [
			'history' => $rows,
			'meta'    => [
				'total'    => $total,
				'current'  => $page,
				'pageSize' => $per_page,
			],
		] );
	}

	/**
	 * Get alert settings.
	 */
	public function get_settings( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$settings = get_option( 'fmp_inventory_settings', [] );

		return rest_ensure_response( [
			'low_stock_email_enabled'    => ! empty( $settings['low_stock_email_enabled'] ),
			'low_stock_threshold'        => isset( $settings['low_stock_threshold'] ) ? (int) $settings['low_stock_threshold'] : 10,
			'low_stock_email_recipients' => $settings['low_stock_email_recipients'] ?? get_option( 'admin_email' ),
			'low_stock_check_frequency'  => $settings['low_stock_check_frequency'] ?? 'daily',
		] );
	}

	/**
	 * Save alert settings.
	 */
	public function save_settings( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$settings = get_option( 'fmp_inventory_settings', [] );

		$fields = [ 'low_stock_email_enabled', 'low_stock_threshold', 'low_stock_email_recipients', 'low_stock_check_frequency' ];

		foreach ( $fields as $field ) {
			$value = $request->get_param( $field );
			if ( $value !== null ) {
				$settings[ $field ] = sanitize_text_field( $value );
			}
		}

		update_option( 'fmp_inventory_settings', $settings );

		// Reschedule cron if frequency changed.
		$frequency = $settings['low_stock_check_frequency'] ?? 'daily';
		$timestamp = wp_next_scheduled( 'fmp_low_stock_check' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'fmp_low_stock_check' );
		}
		wp_schedule_event( time(), $frequency, 'fmp_low_stock_check' );

		return rest_ensure_response( [ 'success' => true ] );
	}

	/**
	 * Send a test notification email.
	 */
	public function test_notification( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$settings   = get_option( 'fmp_inventory_settings', [] );
		$recipients = ! empty( $settings['low_stock_email_recipients'] )
			? $settings['low_stock_email_recipients']
			: get_option( 'admin_email' );

		$site_name = get_bloginfo( 'name' );
		$subject   = sprintf( '[%s] Test Low Stock Alert', $site_name );
		$body      = "This is a test notification from Food Menu Pro.\n\nYour low stock email alerts are working correctly.\n";

		$sent = wp_mail( $recipients, $subject, $body );

		return rest_ensure_response( [
			'success' => $sent,
			'message' => $sent ? 'Test email sent successfully' : 'Failed to send test email',
		] );
	}
}
