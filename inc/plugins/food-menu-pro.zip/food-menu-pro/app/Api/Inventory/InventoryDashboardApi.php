<?php
/**
 * GetInventoryListApi class.
 *
 * @package RT_FoodMenu
 */

namespace RT\FoodMenuPro\Api\Inventory;
;

use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

class InventoryDashboardApi {

	use SingletonTrait;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {

		add_action( 'rest_api_init', function () {
			register_rest_route( 'fmp/v1', '/inventory-dashboard', [
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_inventory_dashboard' ],
				'permission_callback' => FnsPro::menu_permission( [ 'dashboard', 'inventory' ] ),
			] );
		});

	}


	/**
	 * API Callback
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|\WP_REST_Response
	 */

	public function get_inventory_dashboard_old_normal_query( \WP_REST_Request $request ) {

		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		global $wpdb;

		$search = sanitize_text_field( $request->get_param( 'search' ) );

		/* ---------------- Products ---------------- */

		$args = [
			'limit'           => -1,
			'manage_stock'    => true,
			'status'          => 'publish',
			'wc_query'        => 'product_query',
			'fmp_exact_title' => $search,
		];

		$products = wc_get_products( $args );
		$total_items = count( $products );

		/* ---------------- Inventory Aggregation ---------------- */

		$table = "{$wpdb->prefix}fm_inventory_logs";

		$log_totals = $wpdb->get_row(
			"
		SELECT
			SUM(CASE WHEN change_type = 'sale' THEN quantity ELSE 0 END) AS sale_qty,
			SUM(CASE WHEN change_type = 'restore' THEN quantity ELSE 0 END) AS restore_qty,
			SUM(CASE WHEN change_type = 'wastage' THEN quantity ELSE 0 END) AS wastage_qty
		FROM {$table}
		",
			ARRAY_A
		);

		$total_sold = max(
			0,
			(int) ( $log_totals['sale_qty'] ?? 0 ) - (int) ( $log_totals['restore_qty'] ?? 0 )
		);

		$total_waste = (int) ( $log_totals['wastage_qty'] ?? 0 );

		/* ---------------- Remaining Stock ---------------- */

		$total_remaining = 0;
		foreach ( $products as $product ) {
			$qty = (int) $product->get_stock_quantity();
			if ( $qty > 0 ) {
				$total_remaining += $qty;
			}
		}

		/* ---------------- Response ---------------- */

		return rest_ensure_response( [
			'totalItems'     => $total_items,
			'totalSold'      => $total_sold,
			'totalWaste'     => $total_waste,
			'totalRemaining'=> $total_remaining,
		] );
	}
	public function get_inventory_dashboard( \WP_REST_Request $request ) {

		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		global $wpdb;

		// Excluded product types are left out of every figure here, the same way
		// they are on the orders list and the reports.
		$excluded_types   = FnsPro::get_excluded_product_types();
		$post_exclude_sql = FnsPro::build_excluded_products_sql( 'p.ID', $excluded_types );

		$log_table       = "{$wpdb->prefix}fm_inventory_logs";
		$log_exclude_sql = FnsPro::build_excluded_products_sql( "{$log_table}.product_id", $excluded_types );

		// #24 — Cache dashboard stats for 5 minutes. Keyed by the exclusion list so
		// changing the setting is reflected at once instead of after the cache expires.
		$cache_key = FnsPro::dashboard_stats_cache_key();
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		$total_items = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT p.ID)
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
			WHERE p.post_type = 'product'
			  AND p.post_status = 'publish'
			  AND pm.meta_key = '_manage_stock'
			  AND pm.meta_value = 'yes'
			  {$post_exclude_sql}"
		);

		$log_totals = $wpdb->get_row(
			"SELECT
				COALESCE(SUM(CASE WHEN change_type = 'sale' THEN quantity END), 0) AS sale_qty,
				COALESCE(SUM(CASE WHEN change_type = 'restore' THEN quantity END), 0) AS restore_qty,
				COALESCE(SUM(CASE WHEN change_type = 'wastage' THEN quantity END), 0) AS wastage_qty
			FROM {$log_table}
			WHERE 1=1 {$log_exclude_sql}",
			ARRAY_A
		);

		$total_sold  = max( 0, (int) $log_totals['sale_qty'] - (int) $log_totals['restore_qty'] );
		$total_waste = (int) $log_totals['wastage_qty'];

		$total_remaining = (int) $wpdb->get_var(
			"SELECT COALESCE(SUM(CAST(pm_stock.meta_value AS SIGNED)), 0)
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} pm_manage ON pm_manage.post_id = p.ID
				AND pm_manage.meta_key = '_manage_stock' AND pm_manage.meta_value = 'yes'
			INNER JOIN {$wpdb->postmeta} pm_stock ON pm_stock.post_id = p.ID
				AND pm_stock.meta_key = '_stock'
			WHERE p.post_type = 'product' AND p.post_status = 'publish'
				{$post_exclude_sql}"
		);

		$result = [
			'totalItems'     => $total_items,
			'totalSold'      => $total_sold,
			'totalWaste'     => $total_waste,
			'totalRemaining' => $total_remaining,
		];

		set_transient( $cache_key, $result, 5 * MINUTE_IN_SECONDS );

		return rest_ensure_response( $result );
	}

}
