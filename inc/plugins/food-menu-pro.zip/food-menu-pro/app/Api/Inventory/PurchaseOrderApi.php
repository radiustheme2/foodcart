<?php
/**
 * Purchase Order REST API.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\Inventory;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Models\PurchaseOrderModel;
use RT\FoodMenuPro\Services\InventoryServices;
use WP_REST_Response;

class PurchaseOrderApi {

	use SingletonTrait;

	private $model;

	protected function init() {
		$this->model = new PurchaseOrderModel();
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	public function register_routes() {
		$namespace  = 'fmp/v1';
		$permission = FnsPro::menu_permission( [ 'purchase-orders' ] );

		register_rest_route( $namespace, '/purchase-orders', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'list_pos' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/purchase-orders', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'create_po' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/purchase-orders/(?P<id>\d+)', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_po' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/purchase-orders/(?P<id>\d+)', [
			'methods'             => 'PUT',
			'callback'            => [ $this, 'update_po' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/purchase-orders/(?P<id>\d+)', [
			'methods'             => 'DELETE',
			'callback'            => [ $this, 'delete_po' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/purchase-orders/(?P<id>\d+)/receive', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'receive_po' ],
			'permission_callback' => $permission,
		] );
	}

	private function verify_nonce( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}
		return true;
	}

	public function list_pos( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$result = $this->model->get_pos( [
			'page'     => $request->get_param( 'page' ),
			'per_page' => $request->get_param( 'per_page' ),
			'status'   => $request->get_param( 'status' ),
			'search'   => $request->get_param( 'search' ),
		] );

		return rest_ensure_response( $result );
	}

	public function create_po( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$po_id = $this->model->insert_po( [
			'supplier_name'  => $request->get_param( 'supplier_name' ),
			'supplier_email' => $request->get_param( 'supplier_email' ),
			'supplier_phone' => $request->get_param( 'supplier_phone' ),
			'notes'          => $request->get_param( 'notes' ),
			'expected_date'  => $request->get_param( 'expected_date' ),
			'status'         => $request->get_param( 'status' ) ?: 'draft',
		] );

		// Add items.
		$items = $request->get_param( 'items' );
		if ( is_array( $items ) ) {
			foreach ( $items as $item ) {
				$this->model->insert_po_item( [
					'po_id'            => $po_id,
					'product_id'       => (int) $item['product_id'],
					'quantity_ordered' => (int) $item['quantity_ordered'],
					'cost_price'       => $item['cost_price'] ?? null,
				] );
			}
			$this->model->recalculate_total( $po_id );
		}

		return rest_ensure_response( [
			'success' => true,
			'po'      => $this->model->get_po( $po_id ),
		] );
	}

	public function get_po( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$po = $this->model->get_po( (int) $request->get_param( 'id' ) );
		if ( ! $po ) {
			return new \WP_Error( 'not_found', 'Purchase order not found', [ 'status' => 404 ] );
		}

		return rest_ensure_response( $po );
	}

	public function update_po( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$id = (int) $request->get_param( 'id' );
		$po = $this->model->get_po( $id );
		if ( ! $po ) {
			return new \WP_Error( 'not_found', 'Purchase order not found', [ 'status' => 404 ] );
		}

		$this->model->update_po( $id, [
			'supplier_name'  => $request->get_param( 'supplier_name' ),
			'supplier_email' => $request->get_param( 'supplier_email' ),
			'supplier_phone' => $request->get_param( 'supplier_phone' ),
			'notes'          => $request->get_param( 'notes' ),
			'expected_date'  => $request->get_param( 'expected_date' ),
			'status'         => $request->get_param( 'status' ),
		] );

		// Update items if provided.
		$items = $request->get_param( 'items' );
		if ( is_array( $items ) ) {
			// Remove old items and re-insert.
			global $wpdb;
			$wpdb->delete( $wpdb->prefix . 'fm_purchase_order_items', [ 'po_id' => $id ] );

			foreach ( $items as $item ) {
				$this->model->insert_po_item( [
					'po_id'             => $id,
					'product_id'        => (int) $item['product_id'],
					'quantity_ordered'  => (int) $item['quantity_ordered'],
					'quantity_received' => (int) ( $item['quantity_received'] ?? 0 ),
					'cost_price'        => $item['cost_price'] ?? null,
				] );
			}
			$this->model->recalculate_total( $id );
		}

		return rest_ensure_response( [
			'success' => true,
			'po'      => $this->model->get_po( $id ),
		] );
	}

	public function delete_po( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$id = (int) $request->get_param( 'id' );
		$po = $this->model->get_po( $id );
		if ( ! $po ) {
			return new \WP_Error( 'not_found', 'Purchase order not found', [ 'status' => 404 ] );
		}

		if ( ! in_array( $po['status'], [ 'draft', 'cancelled' ], true ) ) {
			return new \WP_Error( 'cannot_delete', 'Only draft or cancelled POs can be deleted', [ 'status' => 400 ] );
		}

		$this->model->delete_po( $id );

		return rest_ensure_response( [ 'success' => true ] );
	}

	public function receive_po( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$id = (int) $request->get_param( 'id' );
		$po = $this->model->get_po( $id );
		if ( ! $po ) {
			return new \WP_Error( 'not_found', 'Purchase order not found', [ 'status' => 404 ] );
		}

		$receive_items = $request->get_param( 'items' );
		if ( ! is_array( $receive_items ) || empty( $receive_items ) ) {
			return new \WP_Error( 'no_items', 'No items to receive', [ 'status' => 400 ] );
		}

		$inventory_service = new InventoryServices();
		$received_count    = 0;
		$fully_received    = true;

		foreach ( $po['items'] as $po_item ) {
			$receive_data = null;
			foreach ( $receive_items as $ri ) {
				if ( (int) $ri['item_id'] === (int) $po_item['id'] ) {
					$receive_data = $ri;
					break;
				}
			}

			if ( ! $receive_data || empty( $receive_data['quantity'] ) ) {
				if ( (int) $po_item['quantity_received'] < (int) $po_item['quantity_ordered'] ) {
					$fully_received = false;
				}
				continue;
			}

			$receive_qty     = (int) $receive_data['quantity'];
			$already_received = (int) $po_item['quantity_received'];
			$max_receivable  = (int) $po_item['quantity_ordered'] - $already_received;

			if ( $receive_qty > $max_receivable ) {
				$receive_qty = $max_receivable;
			}

			if ( $receive_qty <= 0 ) {
				if ( $already_received < (int) $po_item['quantity_ordered'] ) {
					$fully_received = false;
				}
				continue;
			}

			// Update inventory via the existing service.
			$extra = [];
			if ( ! empty( $po_item['cost_price'] ) ) {
				$extra['cost_price']    = $po_item['cost_price'];
				$extra['supplier_name'] = $po['supplier_name'];
			}

			$result = $inventory_service->add_inventory_qty(
				(int) $po_item['product_id'],
				$receive_qty,
				sprintf( 'Received from PO %s', $po['po_number'] ),
				'add',
				'purchase_order',
				'',
				$extra
			);

			if ( ! is_wp_error( $result ) ) {
				$new_received = $already_received + $receive_qty;
				$this->model->update_po_item( (int) $po_item['id'], [
					'quantity_received' => $new_received,
				] );
				$received_count++;

				if ( $new_received < (int) $po_item['quantity_ordered'] ) {
					$fully_received = false;
				}
			} else {
				$fully_received = false;
			}
		}

		// Update PO status.
		$new_status = $fully_received ? 'received' : 'partial';
		$update     = [ 'status' => $new_status ];
		if ( $fully_received ) {
			$update['received_date'] = current_time( 'mysql' );
		}
		$this->model->update_po( $id, $update );

		return rest_ensure_response( [
			'success'        => true,
			'received_count' => $received_count,
			'po'             => $this->model->get_po( $id ),
		] );
	}
}
