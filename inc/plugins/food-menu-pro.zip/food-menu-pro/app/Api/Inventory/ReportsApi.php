<?php
/**
 * Reports REST API.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\Inventory;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

class ReportsApi {

	use SingletonTrait;

	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	public function register_routes() {
		$namespace  = 'fmp/v1';
		$permission = FnsPro::menu_permission( [ 'reports' ] );

		register_rest_route( $namespace, '/reports/valuation', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_valuation' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/reports/profit-margin', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_profit_margin' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/reports/waste-cost', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_waste_cost' ],
			'permission_callback' => $permission,
		] );

		register_rest_route( $namespace, '/reports/stock-turnover', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_stock_turnover' ],
			'permission_callback' => $permission,
		] );
	}

	private function verify_nonce( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}
		return true;
	}

	private function get_date_range( \WP_REST_Request $request ): array {
		$from = sanitize_text_field( $request->get_param( 'from' ) );
		$to   = sanitize_text_field( $request->get_param( 'to' ) );
		if ( ! $from || ! $to ) {
			$to   = current_time( 'Y-m-d' );
			$from = date( 'Y-m-d', strtotime( '-' . FnsPro::reports_default_days() . ' days', strtotime( $to ) ) );
		}
		return [ $from, $to ];
	}

	/**
	 * Optional shift time window, from the `from_time` / `to_time` params (`HH:MM`).
	 *
	 * Returns a pair of empty strings when no usable window was requested, which
	 * keeps every report on its original whole-day behaviour.
	 *
	 * @return array{0:string,1:string} `HH:MM:SS` strings, or empty strings.
	 */
	private function get_shift_range( \WP_REST_Request $request ): array {
		$from_time = $this->sanitize_shift_time( $request->get_param( 'from_time' ) );
		$to_time   = $this->sanitize_shift_time( $request->get_param( 'to_time' ) );

		// Both are required, and an identical pair means the full 24 hours.
		if ( '' === $from_time || '' === $to_time || $from_time === $to_time ) {
			return [ '', '' ];
		}

		return [ $from_time, $to_time ];
	}

	/**
	 * Validate a `HH:MM` time param and expand it to `HH:MM:SS`.
	 *
	 * @param mixed $value Raw request param.
	 *
	 * @return string `HH:MM:SS`, or an empty string when the value is unusable.
	 */
	private function sanitize_shift_time( $value ): string {
		$value = sanitize_text_field( (string) $value );

		if ( ! preg_match( '/^([01][0-9]|2[0-3]):([0-5][0-9])$/', $value ) ) {
			return '';
		}

		return $value . ':00';
	}

	/**
	 * Build a WHERE fragment restricting a datetime expression to a date range
	 * plus an optional shift time window.
	 *
	 * Without a shift window this is a plain whole-day `DATE(...) BETWEEN` check.
	 *
	 * A window whose end time is earlier than its start time (e.g. an 18:00 →
	 * 08:00 night shift) crosses midnight. That shift is attributed to the day it
	 * *starts* on: for each day in the range we take everything from the start
	 * time to midnight, plus everything before the end time on the following day.
	 * Attributing by start day is what makes "how much did the night shift make"
	 * answerable — the alternative (same-day only) would mix two different nights.
	 *
	 * @param string $expr      SQL datetime expression, e.g. `occurred_at`.
	 * @param string $from      Range start, `Y-m-d`.
	 * @param string $to        Range end, `Y-m-d`.
	 * @param string $from_time Shift start, `H:i:s`, or '' for no shift filter.
	 * @param string $to_time   Shift end, `H:i:s`, or '' for no shift filter.
	 *
	 * @return array{0:string,1:array} SQL fragment with placeholders, and its values.
	 */
	private function datetime_clause( string $expr, string $from, string $to, string $from_time, string $to_time ): array {
		if ( '' === $from_time || '' === $to_time ) {
			return [ "DATE({$expr}) BETWEEN %s AND %s", [ $from, $to ] ];
		}

		if ( $from_time < $to_time ) {
			return [
				"( DATE({$expr}) BETWEEN %s AND %s AND TIME({$expr}) >= %s AND TIME({$expr}) < %s )",
				[ $from, $to, $from_time, $to_time ],
			];
		}

		// Overnight shift — the tail of each night lands on the following day.
		$next_from = gmdate( 'Y-m-d', strtotime( '+1 day', strtotime( $from ) ) );
		$next_to   = gmdate( 'Y-m-d', strtotime( '+1 day', strtotime( $to ) ) );

		return [
			"( ( DATE({$expr}) BETWEEN %s AND %s AND TIME({$expr}) >= %s )"
			. " OR ( DATE({$expr}) BETWEEN %s AND %s AND TIME({$expr}) < %s ) )",
			[ $from, $to, $from_time, $next_from, $next_to, $to_time ],
		];
	}

	/**
	 * Backwards-compatible wrapper for inventory-log queries.
	 *
	 * @return array{0:string,1:array} SQL fragment with placeholders, and its values.
	 */
	private function occurred_at_clause( string $from, string $to, string $from_time, string $to_time ): array {
		return $this->datetime_clause( 'occurred_at', $from, $to, $from_time, $to_time );
	}

	/**
	 * SQL expression for the date a row should be grouped under in trend charts.
	 *
	 * For a whole day, or a shift that stays inside one day, that is simply the
	 * row's own date. For an overnight shift the timestamp is pulled back by the
	 * shift end time, which lands every row of one night on the day that night
	 * started — so a night shows up as a single point rather than being split
	 * across two calendar days.
	 *
	 * @return array{0:string,1:array} SQL expression with placeholders, and its values.
	 */
	private function occurred_at_date_expr( string $from_time, string $to_time ): array {
		if ( '' === $from_time || '' === $to_time || $from_time < $to_time ) {
			return [ 'DATE(occurred_at)', [] ];
		}

		return [ 'DATE(DATE_SUB(occurred_at, INTERVAL %s HOUR_SECOND))', [ $to_time ] ];
	}

	/**
	 * Shape the `period` payload, including the shift window when one is active.
	 *
	 * @return array<string,string>
	 */
	private function period_payload( string $from, string $to, string $from_time, string $to_time ): array {
		return [
			'from'      => $from,
			'to'        => $to,
			'from_time' => $from_time ? substr( $from_time, 0, 5 ) : '',
			'to_time'   => $to_time ? substr( $to_time, 0, 5 ) : '',
		];
	}

	/* ---------------------------------------------------------------------
	 * Real sales, read straight from WooCommerce orders.
	 *
	 * Everything money- or quantity-related below comes from actual order line
	 * items — the quantity the customer was charged for and the line total they
	 * actually paid after discounts. Nothing is derived from the product's
	 * current price, so a price change or a coupon never rewrites history.
	 * ------------------------------------------------------------------ */

	/**
	 * Is WooCommerce storing orders in its own tables (HPOS)?
	 */
	private function is_hpos(): bool {
		return class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	}

	/**
	 * Column/table names for the active order storage, plus a SQL expression that
	 * yields the order's creation time in the *site's* timezone.
	 *
	 * HPOS only stores `date_created_gmt`, so the site's GMT offset is applied in
	 * SQL. The legacy posts table already stores local time in `post_date`.
	 *
	 * @param string $alias Table alias used in the query.
	 *
	 * @return array{table:string,id:string,status:string,parent:string,type:string,date:string}
	 */
	private function orders_table( string $alias = 'o' ): array {
		global $wpdb;

		if ( $this->is_hpos() ) {
			$offset = (int) round( (float) get_option( 'gmt_offset', 0 ) * HOUR_IN_SECONDS );

			return [
				'table'  => $wpdb->prefix . 'wc_orders',
				'id'     => "{$alias}.id",
				'status' => "{$alias}.status",
				'parent' => "{$alias}.parent_order_id",
				'type'   => "{$alias}.type",
				'date'   => $offset
					? "DATE_ADD({$alias}.date_created_gmt, INTERVAL {$offset} SECOND)"
					: "{$alias}.date_created_gmt",
			];
		}

		return [
			'table'  => $wpdb->posts,
			'id'     => "{$alias}.ID",
			'status' => "{$alias}.post_status",
			'parent' => "{$alias}.post_parent",
			'type'   => "{$alias}.post_type",
			'date'   => "{$alias}.post_date",
		];
	}

	/**
	 * Statuses that are never a sale, whatever is configured — these are not real
	 * orders at all, so counting them would be meaningless rather than a choice.
	 */
	const NEVER_SALES_STATUSES = [ 'checkout-draft', 'trash', 'auto-draft' ];

	/**
	 * Statuses that are always kept out of the reports.
	 *
	 * Not a starting point the admin can pare back — these are locked in the
	 * settings panel and re-applied server-side by `excluded_statuses()`. See there
	 * for why, and for the filter that can override it.
	 */
	const DEFAULT_EXCLUDED_STATUSES = [ 'cancelled', 'failed', 'refunded', 'pending' ];

	/**
	 * Order statuses that count as a completed sale.
	 *
	 * Uses the admin's own selection from Settings → Front-End Dashboard →
	 * Report when one exists, exactly like the slot limits do, so a kitchen
	 * whose workflow parks paid orders somewhere unusual can fix its own reports
	 * without a code change. An empty selection falls back to
	 * `default_sales_statuses()`.
	 *
	 * `NEVER_SALES_STATUSES` is stripped from an explicit selection, and
	 * `excluded_statuses()` is subtracted from whichever list was resolved — so
	 * ticking e.g. "Cancelled" here does not smuggle it back in.
	 *
	 * @return string[] Status slugs, `wc-` prefixed.
	 */
	private function sales_statuses(): array {
		$configured = FnsPro::get_setting( 'fmp_reports_sales_statuses', [] );
		$configured = is_array( $configured ) ? array_filter( $configured ) : [];

		if ( ! empty( $configured ) ) {
			$statuses = $this->strip_status_prefix( $configured );
			$statuses = array_diff( $statuses, self::NEVER_SALES_STATUSES );
		} else {
			$statuses = $this->default_sales_statuses();
		}

		$statuses = array_diff( $statuses, $this->excluded_statuses() );

		/**
		 * Filter the order statuses counted as sales in the inventory reports.
		 *
		 * @param string[] $statuses Status slugs without the `wc-` prefix.
		 */
		$statuses = apply_filters( 'fmp_reports_sales_statuses', array_values( array_unique( $statuses ) ) );

		return array_map(
			function ( $status ) {
				return 'wc-' . str_replace( 'wc-', '', (string) $status );
			},
			(array) $statuses
		);
	}

	/**
	 * Statuses kept out of every report figure.
	 *
	 * `DEFAULT_EXCLUDED_STATUSES` is always part of the result, whatever is stored.
	 * A cancelled, failed or never-paid-for order is not revenue by any definition,
	 * and a fully refunded one nets to zero through its refund line items anyway, so
	 * there is no configuration in which counting them produces a correct sales
	 * figure. The settings panel renders them as locked chips — but that is only a UI
	 * hint, and the posted value is not trustworthy, so the union is enforced here.
	 *
	 * On top of that sit the admin's own picks from **Settings → Front-End Dashboard
	 * → Report → "Exclude Order Statuses"**. That field exists because a kitchen can
	 * create its own "Cancelled" step through Custom Order Statuses, and
	 * `default_sales_statuses()` counts every enabled custom status as a sale — it
	 * cannot tell a cancellation step from a fulfilment one. Cancelled orders then
	 * kept adding to Sales Amount even though WooCommerce's own `cancelled` was
	 * correctly ignored. This is how the store names that status.
	 *
	 * The `fmp_reports_excluded_statuses` filter is the escape hatch for the rare
	 * setup that genuinely needs one of the four back; it can return fewer.
	 *
	 * @return string[] Slugs without the `wc-` prefix.
	 */
	private function excluded_statuses(): array {
		$configured = FnsPro::get_setting( 'fmp_reports_excluded_statuses', [] );

		// An emptied MultiSelect is posted as '' rather than an empty array.
		$configured = is_array( $configured ) ? array_filter( $configured ) : [];

		$excluded = array_merge(
			self::DEFAULT_EXCLUDED_STATUSES,
			$this->strip_status_prefix( $configured )
		);

		/**
		 * Filter the order statuses kept out of the inventory reports.
		 *
		 * @param string[] $excluded Status slugs without the `wc-` prefix.
		 */
		return (array) apply_filters(
			'fmp_reports_excluded_statuses',
			array_values( array_unique( $excluded ) )
		);
	}

	/**
	 * Default set of sale statuses, used until the admin selects their own.
	 *
	 * WooCommerce's paid statuses (processing/completed), plus **on hold**, plus
	 * any enabled custom status this plugin registered.
	 *
	 * On hold is included deliberately: WooCommerce reduces stock on the on-hold
	 * transition and this plugin writes a `sale` inventory log for it, and the
	 * slot limits count it as a real order too. Leaving it out of the reports —
	 * as earlier versions did — meant the inventory said the food was sold while
	 * the revenue report showed nothing for it, which is exactly what makes a
	 * report look "way off". Bank transfer and cheque orders sit in on hold by
	 * default, so for some kitchens that was most of the trading day.
	 *
	 * Cancelled, failed, refunded and pending are excluded from the *default*;
	 * an admin can still opt into them explicitly.
	 *
	 * @return string[] Status slugs without the `wc-` prefix.
	 */
	private function default_sales_statuses(): array {
		$statuses = function_exists( 'wc_get_is_paid_statuses' )
			? wc_get_is_paid_statuses()
			: [ 'processing', 'completed' ];

		$statuses[] = 'on-hold';

		$custom = get_option( 'fmp_custom_order_statuses', [] );

		if ( is_array( $custom ) ) {
			foreach ( $custom as $cs ) {
				if ( ! empty( $cs['enabled'] ) && ! empty( $cs['slug'] ) ) {
					$statuses[] = $cs['slug'];
				}
			}
		}

		$statuses = $this->strip_status_prefix( $statuses );

		return array_values(
			array_diff(
				$statuses,
				array_merge( self::NEVER_SALES_STATUSES, [ 'pending', 'cancelled', 'failed', 'refunded' ] )
			)
		);
	}

	/**
	 * Normalise a list of status slugs to their unprefixed form.
	 *
	 * @param array $statuses Slugs, with or without the `wc-` prefix.
	 *
	 * @return string[]
	 */
	private function strip_status_prefix( array $statuses ): array {
		return array_map(
			function ( $status ) {
				return str_replace( 'wc-', '', (string) $status );
			},
			$statuses
		);
	}

	/**
	 * Real per-product sales for a period, netted against refunds.
	 *
	 * Refunded line items are attributed back to the date of the order they
	 * belong to, so refunding today never silently rewrites a period that has
	 * already been reported on — it corrects the shift the food was sold in.
	 *
	 * `tax` is reported alongside `revenue` rather than folded into it: profit and
	 * margin must be calculated on the net figure, but a restaurant reconciling
	 * against its till needs the gross one, and being unable to see the tax line
	 * makes a correct report look wrong by exactly the tax rate.
	 *
	 * @return array<int,array{product_id:int,variation_id:int,name:string,qty:float,revenue:float,tax:float}>
	 *         Keyed by "product_id:variation_id".
	 */
	private function get_real_sales( string $from, string $to, string $from_time, string $to_time ): array {
		global $wpdb;

		$statuses = $this->sales_statuses();

		if ( empty( $statuses ) ) {
			return [];
		}

		$o     = $this->orders_table( 'o' );
		$items = $wpdb->prefix . 'woocommerce_order_items';
		$meta  = $wpdb->prefix . 'woocommerce_order_itemmeta';

		[ $date_where, $date_args ] = $this->datetime_clause( $o['date'], $from, $to, $from_time, $to_time );

		$status_ph = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );

		// Drop line items whose product sits in an excluded product type (Front-End
		// Dashboard → Order Management → Exclude Product Types). Filtered per line,
		// not per order, so an order holding a room and a burger still reports the
		// burger.
		$exclude_sql = FnsPro::build_excluded_products_sql( 'CAST(m_prod.meta_value AS UNSIGNED)' );

		// Line-item metas are joined individually rather than pivoted in PHP so the
		// whole period collapses to a single grouped row set in one round trip.
		$select = "SELECT
				CAST(m_prod.meta_value AS UNSIGNED) AS product_id,
				CAST(COALESCE(m_var.meta_value, 0) AS UNSIGNED) AS variation_id,
				MAX(oi.order_item_name) AS item_name,
				SUM(CAST(COALESCE(m_qty.meta_value, 0) AS DECIMAL(18,4))) AS qty,
				SUM(CAST(COALESCE(m_total.meta_value, 0) AS DECIMAL(18,6))) AS revenue,
				SUM(CAST(COALESCE(m_tax.meta_value, 0) AS DECIMAL(18,6))) AS tax
			FROM {$items} oi
				INNER JOIN {$meta} m_prod ON m_prod.order_item_id = oi.order_item_id AND m_prod.meta_key = '_product_id'
				LEFT JOIN {$meta} m_var ON m_var.order_item_id = oi.order_item_id AND m_var.meta_key = '_variation_id'
				LEFT JOIN {$meta} m_qty ON m_qty.order_item_id = oi.order_item_id AND m_qty.meta_key = '_qty'
				LEFT JOIN {$meta} m_total ON m_total.order_item_id = oi.order_item_id AND m_total.meta_key = '_line_total'
				LEFT JOIN {$meta} m_tax ON m_tax.order_item_id = oi.order_item_id AND m_tax.meta_key = '_line_tax'";

		// Sales.
		$sales_sql = $wpdb->prepare(
			// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- identifiers only.
			"{$select}
				INNER JOIN {$o['table']} o ON {$o['id']} = oi.order_id
			WHERE oi.order_item_type = 'line_item'
				AND {$o['type']} = 'shop_order'
				AND {$o['status']} IN ({$status_ph})
				AND {$date_where}
				{$exclude_sql}
			GROUP BY product_id, variation_id",
			// phpcs:enable
			array_merge( $statuses, $date_args )
		);

		// Refunds, filtered and dated by their parent order.
		$r = $this->orders_table( 'r' );

		$refund_sql = $wpdb->prepare(
			// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- identifiers only.
			"{$select}
				INNER JOIN {$r['table']} r ON {$r['id']} = oi.order_id AND {$r['type']} = 'shop_order_refund'
				INNER JOIN {$o['table']} o ON {$o['id']} = {$r['parent']}
			WHERE oi.order_item_type = 'line_item'
				AND {$o['status']} IN ({$status_ph})
				AND {$date_where}
				{$exclude_sql}
			GROUP BY product_id, variation_id",
			// phpcs:enable
			array_merge( $statuses, $date_args )
		);

		$rows = array_merge(
			(array) $wpdb->get_results( $sales_sql, ARRAY_A ),
			(array) $wpdb->get_results( $refund_sql, ARRAY_A )
		);

		$sales = [];

		foreach ( $rows as $row ) {
			$product_id = (int) $row['product_id'];

			if ( ! $product_id ) {
				continue;
			}

			$variation_id = (int) $row['variation_id'];
			$key          = $product_id . ':' . $variation_id;

			if ( ! isset( $sales[ $key ] ) ) {
				$sales[ $key ] = [
					'product_id'   => $product_id,
					'variation_id' => $variation_id,
					// Name stored on the order item, used only when the product has
					// since been deleted — real sales still belong in the report.
					'name'         => (string) $row['item_name'],
					'qty'          => 0.0,
					'revenue'      => 0.0,
					'tax'          => 0.0,
				];
			}

			$sales[ $key ]['qty']     += (float) $row['qty'];
			$sales[ $key ]['revenue'] += (float) $row['revenue'];
			$sales[ $key ]['tax']     += (float) $row['tax'];
		}

		// A fully refunded line nets to zero — drop it rather than showing a 0-sold row.
		return array_filter(
			$sales,
			function ( $sale ) {
				return abs( $sale['qty'] ) > 0.0001 || abs( $sale['revenue'] ) > 0.0001;
			}
		);
	}

	/**
	 * Latest recorded cost price for many products in one query.
	 *
	 * Only real, recorded costs are returned. A product that has never had a cost
	 * price entered is simply absent from the result — the reports show a blank
	 * for it and leave it out of cost totals instead of inventing a figure.
	 *
	 * @param int[] $product_ids
	 *
	 * @return array<int,float> product_id => cost price.
	 */
	private function get_cost_prices( array $product_ids ): array {
		global $wpdb;

		$product_ids = array_values( array_unique( array_filter( array_map( 'intval', $product_ids ) ) ) );

		if ( empty( $product_ids ) ) {
			return [];
		}

		$table = $wpdb->prefix . 'fm_inventory_logs';
		$ph    = implode( ', ', array_fill( 0, count( $product_ids ), '%d' ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- identifiers only.
				"SELECT product_id, cost_price
				FROM {$table}
				WHERE product_id IN ({$ph}) AND cost_price IS NOT NULL AND cost_price > 0
				ORDER BY created_at DESC, id DESC",
				// phpcs:enable
				$product_ids
			),
			ARRAY_A
		);

		$costs = [];

		foreach ( $rows as $row ) {
			$pid = (int) $row['product_id'];

			// Rows are newest-first, so the first one seen per product wins.
			if ( ! isset( $costs[ $pid ] ) ) {
				$costs[ $pid ] = (float) $row['cost_price'];
			}
		}

		return $costs;
	}

	/**
	 * First product category name for many products in one query.
	 *
	 * @param int[] $product_ids
	 *
	 * @return array<int,string>
	 */
	private function get_product_categories( array $product_ids ): array {
		$product_ids = array_values( array_unique( array_filter( array_map( 'intval', $product_ids ) ) ) );

		if ( empty( $product_ids ) ) {
			return [];
		}

		$terms = wp_get_object_terms( $product_ids, 'product_cat', [ 'fields' => 'all_with_object_id' ] );

		if ( is_wp_error( $terms ) ) {
			return [];
		}

		$map = [];

		foreach ( $terms as $term ) {
			if ( ! isset( $map[ $term->object_id ] ) ) {
				$map[ $term->object_id ] = $term->name;
			}
		}

		return $map;
	}

	/**
	 * Inventory valuation report.
	 *
	 * Only products with a recorded cost price can be valued. The rest are listed
	 * with a blank cost and excluded from the total, and the count of those is
	 * returned so the dashboard can say so out loud.
	 */
	public function get_valuation( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'meta_key'       => '_manage_stock',
			'meta_value'     => 'yes',
			'fields'         => 'ids',
			'posts_per_page' => -1,
		];

		// Keep excluded product types (e.g. hotel accommodation) out of stock value.
		$tax_query = FnsPro::excluded_product_types_tax_query();

		if ( ! empty( $tax_query ) ) {
			$args['tax_query'] = $tax_query;
		}

		$product_ids = get_posts( $args );

		if ( empty( $product_ids ) ) {
			return rest_ensure_response( [
				'summary'     => [
					'total_value'          => 0,
					'total_units'          => 0,
					'avg_cost'             => 0,
					'total_products'       => 0,
					'products_without_cost' => 0,
				],
				'products'    => [],
				'by_category' => [],
			] );
		}

		// One pass to warm post/meta/term caches so the loop below issues no queries.
		_prime_post_caches( $product_ids, true, true );

		$costs      = $this->get_cost_prices( $product_ids );
		$categories = $this->get_product_categories( $product_ids );

		$products     = [];
		$by_category  = [];
		$total_value  = 0;
		$total_units  = 0;
		$valued_units = 0;
		$no_cost      = 0;

		foreach ( $product_ids as $pid ) {
			$product = wc_get_product( $pid );
			if ( ! $product || ! $product->managing_stock() ) {
				continue;
			}

			$stock = (int) $product->get_stock_quantity();

			if ( $stock <= 0 ) {
				continue;
			}

			$cost_price = $costs[ $pid ] ?? null;
			$value      = null === $cost_price ? null : $stock * $cost_price;
			$category   = $categories[ $pid ] ?? __( 'Uncategorized', 'food-menu-pro' );

			$products[] = [
				'product_id'   => (int) $pid,
				'product_name' => $product->get_name(),
				'category'     => $category,
				'stock'        => $stock,
				'cost_price'   => null === $cost_price ? null : round( $cost_price, 2 ),
				'total_value'  => null === $value ? null : round( $value, 2 ),
			];

			$total_units += $stock;

			if ( null === $value ) {
				++$no_cost;
				continue;
			}

			$total_value  += $value;
			$valued_units += $stock;

			$by_category[ $category ] = ( $by_category[ $category ] ?? 0 ) + $value;
		}

		// Unvalued products sink to the bottom rather than pretending to be worth 0.
		usort( $products, function ( $a, $b ) {
			return ( $b['total_value'] ?? -1 ) <=> ( $a['total_value'] ?? -1 );
		} );

		$category_data = [];
		foreach ( $by_category as $cat => $val ) {
			$category_data[] = [ 'category' => $cat, 'value' => round( $val, 2 ) ];
		}
		usort( $category_data, function ( $a, $b ) {
			return $b['value'] <=> $a['value'];
		} );

		return rest_ensure_response( [
			'summary'     => [
				'total_value'           => round( $total_value, 2 ),
				'total_units'           => $total_units,
				// Averaged over the units actually valued, so it stays a true average.
				'avg_cost'              => $valued_units > 0 ? round( $total_value / $valued_units, 2 ) : 0,
				'total_products'        => count( $products ),
				'products_without_cost' => $no_cost,
			],
			'products'    => $products,
			'by_category' => $category_data,
		] );
	}

	/**
	 * Sales and profit margin, built from real order line items.
	 */
	public function get_profit_margin( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		[ $from, $to ]           = $this->get_date_range( $request );
		[ $from_time, $to_time ] = $this->get_shift_range( $request );

		$sales = $this->get_real_sales( $from, $to, $from_time, $to_time );

		if ( empty( $sales ) ) {
			return rest_ensure_response( [
				'summary'     => [
					'total_revenue'         => 0,
					'total_tax'             => 0,
					'total_revenue_gross'   => 0,
					'total_cogs'            => 0,
					'total_profit'          => 0,
					'gross_margin'          => 0,
					'total_qty'             => 0,
					'order_count'           => 0,
					'products_without_cost' => 0,
				],
				'products'    => [],
				'by_category' => [],
				'period'      => $this->period_payload( $from, $to, $from_time, $to_time ),
			] );
		}

		$product_ids = array_column( $sales, 'product_id' );

		// Variations are separate posts, so prime them alongside their parents —
		// otherwise every variable-product row costs its own pair of queries.
		$prime_ids = array_filter( array_merge( $product_ids, array_column( $sales, 'variation_id' ) ) );

		_prime_post_caches( array_values( array_unique( $prime_ids ) ), true, true );

		$costs      = $this->get_cost_prices( $product_ids );
		$categories = $this->get_product_categories( $product_ids );

		$products      = [];
		$total_revenue = 0;
		$total_tax     = 0;
		$total_cogs    = 0;
		$total_qty     = 0;
		$no_cost       = 0;

		foreach ( $sales as $sale ) {
			$pid          = $sale['product_id'];
			$variation_id = $sale['variation_id'];
			$product      = wc_get_product( $variation_id ?: $pid );

			$qty_sold = $sale['qty'];
			$revenue  = $sale['revenue'];

			$cost_price = $costs[ $pid ] ?? null;
			$cogs       = null === $cost_price ? null : $qty_sold * $cost_price;
			$profit     = null === $cogs ? null : $revenue - $cogs;
			$margin     = ( null === $profit || $revenue <= 0 ) ? null : ( $profit / $revenue ) * 100;

			$products[] = [
				'product_id'   => $pid,
				'variation_id' => $variation_id,
				// Falls back to the name recorded on the order for deleted products.
				'product_name' => $product ? $product->get_name() : $sale['name'],
				'category'     => $categories[ $pid ] ?? __( 'Uncategorized', 'food-menu-pro' ),
				'qty_sold'     => round( $qty_sold, 2 ) + 0,
				'revenue'      => round( $revenue, 2 ),
				'cogs'         => null === $cogs ? null : round( $cogs, 2 ),
				'profit'       => null === $profit ? null : round( $profit, 2 ),
				'margin'       => null === $margin ? null : round( $margin, 1 ),
			];

			$total_revenue += $revenue;
			$total_tax     += (float) ( $sale['tax'] ?? 0 );
			$total_qty     += $qty_sold;

			if ( null === $cogs ) {
				++$no_cost;
			} else {
				$total_cogs += $cogs;
			}
		}

		usort( $products, function ( $a, $b ) {
			return $b['revenue'] <=> $a['revenue'];
		} );

		// Category rollup. Revenue always counts; cost only where it is known, and
		// the margin for a category is only shown when every line in it has a cost.
		$cat_map = [];
		foreach ( $products as $p ) {
			$cat = $p['category'];

			if ( ! isset( $cat_map[ $cat ] ) ) {
				$cat_map[ $cat ] = [ 'revenue' => 0, 'cogs' => 0, 'qty' => 0, 'missing_cost' => false ];
			}

			$cat_map[ $cat ]['revenue'] += $p['revenue'];
			$cat_map[ $cat ]['qty']     += $p['qty_sold'];

			if ( null === $p['cogs'] ) {
				$cat_map[ $cat ]['missing_cost'] = true;
			} else {
				$cat_map[ $cat ]['cogs'] += $p['cogs'];
			}
		}

		$by_category = [];
		foreach ( $cat_map as $cat => $d ) {
			$has_cost = ! $d['missing_cost'];
			$profit   = $has_cost ? $d['revenue'] - $d['cogs'] : null;

			$by_category[] = [
				'category' => $cat,
				'revenue'  => round( $d['revenue'], 2 ),
				'qty'      => round( $d['qty'], 2 ) + 0,
				'cogs'     => $has_cost ? round( $d['cogs'], 2 ) : null,
				'profit'   => null === $profit ? null : round( $profit, 2 ),
				'margin'   => ( null === $profit || $d['revenue'] <= 0 ) ? null : round( ( $profit / $d['revenue'] ) * 100, 1 ),
			];
		}

		usort( $by_category, function ( $a, $b ) {
			return $b['revenue'] <=> $a['revenue'];
		} );

		// Profit and margin describe only the part of revenue with a known cost,
		// otherwise a store with half its costs filled in would read as 50% margin.
		$costed_revenue = 0;
		foreach ( $products as $p ) {
			if ( null !== $p['cogs'] ) {
				$costed_revenue += $p['revenue'];
			}
		}

		$total_profit = $costed_revenue - $total_cogs;

		return rest_ensure_response( [
			'summary'     => [
				'total_revenue'         => round( $total_revenue, 2 ),
				// Net + tax, so the figure can be reconciled against a till total.
				'total_tax'             => round( $total_tax, 2 ),
				'total_revenue_gross'   => round( $total_revenue + $total_tax, 2 ),
				'total_qty'             => round( $total_qty, 2 ) + 0,
				'total_cogs'            => $no_cost === count( $products ) ? null : round( $total_cogs, 2 ),
				'total_profit'          => $no_cost === count( $products ) ? null : round( $total_profit, 2 ),
				'gross_margin'          => $costed_revenue > 0 ? round( ( $total_profit / $costed_revenue ) * 100, 1 ) : null,
				'order_count'           => $this->count_orders( $from, $to, $from_time, $to_time ),
				'products_without_cost' => $no_cost,
			],
			'products'    => $products,
			'by_category' => $by_category,
			'period'      => $this->period_payload( $from, $to, $from_time, $to_time ),
		] );
	}

	/**
	 * Number of real orders in the period, for the "orders" figure on the report.
	 */
	private function count_orders( string $from, string $to, string $from_time, string $to_time ): int {
		global $wpdb;

		$statuses = $this->sales_statuses();

		if ( empty( $statuses ) ) {
			return 0;
		}

		$o = $this->orders_table( 'o' );

		[ $date_where, $date_args ] = $this->datetime_clause( $o['date'], $from, $to, $from_time, $to_time );

		$status_ph = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );

		// With product types excluded, count only orders that actually contributed a
		// reported line — an order of nothing but rooms is not a food order. Orders
		// mixing both still count once, matching the revenue they contributed.
		$included_items = '';
		$exclude_sql    = FnsPro::build_excluded_products_sql( 'CAST(m_prod_cnt.meta_value AS UNSIGNED)' );

		if ( $exclude_sql ) {
			$items = $wpdb->prefix . 'woocommerce_order_items';
			$meta  = $wpdb->prefix . 'woocommerce_order_itemmeta';

			$included_items = " AND EXISTS (
				SELECT 1
				FROM {$items} oi_cnt
				INNER JOIN {$meta} m_prod_cnt
					ON m_prod_cnt.order_item_id = oi_cnt.order_item_id AND m_prod_cnt.meta_key = '_product_id'
				WHERE oi_cnt.order_id = {$o['id']}
					AND oi_cnt.order_item_type = 'line_item'
					{$exclude_sql}
			)";
		}

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- identifiers only.
				"SELECT COUNT(*) FROM {$o['table']} o
				WHERE {$o['type']} = 'shop_order'
					AND {$o['status']} IN ({$status_ph})
					AND {$date_where}
					{$included_items}",
				// phpcs:enable
				array_merge( $statuses, $date_args )
			)
		);
	}

	/**
	 * Waste cost analysis.
	 *
	 * Wastage is recorded by hand in the inventory screen, so it genuinely lives
	 * in the log table — unlike sales, there is no order to read it from. Cost is
	 * still only applied where a real cost price exists.
	 */
	public function get_waste_cost( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		global $wpdb;
		[ $from, $to ]              = $this->get_date_range( $request );
		[ $from_time, $to_time ]    = $this->get_shift_range( $request );
		[ $date_where, $date_args ] = $this->occurred_at_clause( $from, $to, $from_time, $to_time );
		$logs_table                 = $wpdb->prefix . 'fm_inventory_logs';
		$exclude_sql                = FnsPro::build_excluded_products_sql( "{$logs_table}.product_id" );

		// Waste by product.
		$waste_data = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT product_id, reason, SUM(quantity) as qty
				FROM {$logs_table}
				WHERE change_type = 'wastage' AND {$date_where} {$exclude_sql}
				GROUP BY product_id, reason",
				$date_args
			),
			ARRAY_A
		);

		$product_ids = array_map( 'intval', array_column( $waste_data, 'product_id' ) );

		if ( ! empty( $product_ids ) ) {
			_prime_post_caches( $product_ids, true, true );
		}

		$costs = $this->get_cost_prices( $product_ids );

		$products   = [];
		$by_reason  = [];
		$total_cost = 0;
		$total_qty  = 0;
		$no_cost    = [];

		foreach ( $waste_data as $row ) {
			$pid        = (int) $row['product_id'];
			$qty        = (int) $row['qty'];
			$cost_price = $costs[ $pid ] ?? null;
			$cost       = null === $cost_price ? null : $qty * $cost_price;
			$reason     = $row['reason'] ?: 'Unknown';

			$product = wc_get_product( $pid );
			$name    = $product ? $product->get_name() : __( 'Deleted Product', 'food-menu-pro' );

			if ( ! isset( $products[ $pid ] ) ) {
				$products[ $pid ] = [
					'product_id'   => $pid,
					'product_name' => $name,
					'qty'          => 0,
					'cost_price'   => null === $cost_price ? null : round( $cost_price, 2 ),
					'total_cost'   => null === $cost_price ? null : 0,
				];
			}

			$products[ $pid ]['qty'] += $qty;

			if ( ! isset( $by_reason[ $reason ] ) ) {
				$by_reason[ $reason ] = [ 'qty' => 0, 'cost' => 0 ];
			}
			$by_reason[ $reason ]['qty'] += $qty;

			$total_qty += $qty;

			if ( null === $cost ) {
				$no_cost[ $pid ] = true;
				continue;
			}

			$products[ $pid ]['total_cost'] += $cost;
			$by_reason[ $reason ]['cost']   += $cost;
			$total_cost                     += $cost;
		}

		$products_list = array_values( $products );
		foreach ( $products_list as &$p ) {
			if ( null !== $p['total_cost'] ) {
				$p['total_cost'] = round( $p['total_cost'], 2 );
			}
		}
		unset( $p );

		usort( $products_list, function ( $a, $b ) {
			return ( $b['total_cost'] ?? -1 ) <=> ( $a['total_cost'] ?? -1 );
		} );

		$reason_list = [];
		foreach ( $by_reason as $reason => $d ) {
			$reason_list[] = [
				'reason' => ucfirst( str_replace( '_', ' ', $reason ) ),
				'qty'    => $d['qty'],
				'cost'   => round( $d['cost'], 2 ),
			];
		}
		usort( $reason_list, function ( $a, $b ) {
			return $b['cost'] <=> $a['cost'];
		} );

		// Waste trend by date. Grouped by shift-start date so an overnight shift
		// shows as one point instead of being split across two calendar days.
		[ $date_expr, $expr_args ] = $this->occurred_at_date_expr( $from_time, $to_time );

		$trend = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT {$date_expr} as date, SUM(quantity) as qty
				FROM {$logs_table}
				WHERE change_type = 'wastage' AND {$date_where} {$exclude_sql}
				GROUP BY date ORDER BY date ASC",
				array_merge( $expr_args, $date_args )
			),
			ARRAY_A
		);

		return rest_ensure_response( [
			'summary'    => [
				'total_cost'            => round( $total_cost, 2 ),
				'total_qty'             => $total_qty,
				'top_reason'            => ! empty( $reason_list ) ? $reason_list[0]['reason'] : 'N/A',
				'product_count'         => count( $products_list ),
				'products_without_cost' => count( $no_cost ),
			],
			'products'   => $products_list,
			'by_reason'  => $reason_list,
			'trend'      => $trend,
			'period'     => $this->period_payload( $from, $to, $from_time, $to_time ),
		] );
	}

	/**
	 * Stock turnover analysis.
	 *
	 * Quantities sold come from real orders. Average inventory is reconstructed
	 * from the logged stock movements — opening stock is the current stock wound
	 * back through everything that moved during the period — instead of the
	 * previous `(current + sold) / 2` guess.
	 */
	public function get_stock_turnover( \WP_REST_Request $request ) {
		$check = $this->verify_nonce( $request );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		[ $from, $to ]           = $this->get_date_range( $request );
		[ $from_time, $to_time ] = $this->get_shift_range( $request );

		// Inclusive day count: a single-day range is 1 day, not 0.
		$days = max( 1, (int) round( ( strtotime( $to ) - strtotime( $from ) ) / DAY_IN_SECONDS ) + 1 );

		$sales = $this->get_real_sales( $from, $to, $from_time, $to_time );

		// Turnover is a stock metric — roll variations up into their parent, which
		// is where stock and cost are tracked.
		$by_product = [];
		foreach ( $sales as $sale ) {
			$pid                 = $sale['product_id'];
			$by_product[ $pid ]  = ( $by_product[ $pid ] ?? 0 ) + $sale['qty'];
		}

		if ( empty( $by_product ) ) {
			return rest_ensure_response( [
				'summary'  => [
					'avg_turnover'          => 0,
					'avg_days_supply'       => null,
					'total_cogs'            => 0,
					'product_count'         => 0,
					'products_without_cost' => 0,
				],
				'products' => [],
				'period'   => $this->period_payload( $from, $to, $from_time, $to_time ),
			] );
		}

		$product_ids = array_keys( $by_product );

		_prime_post_caches( $product_ids, true, true );

		$costs    = $this->get_cost_prices( $product_ids );
		$movement = $this->get_stock_movement( $product_ids, $from, $to, $from_time, $to_time );

		$products       = [];
		$total_cogs     = 0;
		$total_turnover = 0;
		$turnover_count = 0;
		$no_cost        = 0;

		foreach ( $by_product as $pid => $qty_sold ) {
			$product = wc_get_product( $pid );
			if ( ! $product || ! $product->managing_stock() ) {
				continue;
			}

			$current_stock = (int) $product->get_stock_quantity();
			$cost_price    = $costs[ $pid ] ?? null;

			// Wind the current stock back through the period's logged movements to
			// recover what was on hand when the period started.
			$net_change    = $movement[ $pid ] ?? 0;
			$opening_stock = max( 0, $current_stock - $net_change );
			$avg_inventory = ( $opening_stock + $current_stock ) / 2;

			$cogs          = null === $cost_price ? null : $qty_sold * $cost_price;
			$avg_inv_value = null === $cost_price ? null : $avg_inventory * $cost_price;

			// Units-based turnover, so it is still meaningful without a cost price.
			$turnover    = $avg_inventory > 0 ? $qty_sold / $avg_inventory : null;
			$daily_sales = $qty_sold / $days;
			$days_supply = $daily_sales > 0 ? (int) round( $current_stock / $daily_sales ) : null;

			$products[] = [
				'product_id'    => (int) $pid,
				'product_name'  => $product->get_name(),
				'qty_sold'      => round( $qty_sold, 2 ) + 0,
				'current_stock' => $current_stock,
				'opening_stock' => $opening_stock,
				'cost_price'    => null === $cost_price ? null : round( $cost_price, 2 ),
				'cogs'          => null === $cogs ? null : round( $cogs, 2 ),
				'avg_inventory' => round( $avg_inventory, 1 ),
				'turnover'      => null === $turnover ? null : round( $turnover, 2 ),
				'days_supply'   => $days_supply,
				'daily_sales'   => round( $daily_sales, 1 ),
			];

			if ( null === $cogs ) {
				++$no_cost;
			} else {
				$total_cogs += $cogs;
			}

			if ( null !== $turnover ) {
				$total_turnover += $turnover;
				++$turnover_count;
			}
		}

		usort( $products, function ( $a, $b ) {
			return ( $b['turnover'] ?? -1 ) <=> ( $a['turnover'] ?? -1 );
		} );

		$avg_turnover = $turnover_count > 0 ? $total_turnover / $turnover_count : 0;

		return rest_ensure_response( [
			'summary'  => [
				'avg_turnover'          => round( $avg_turnover, 2 ),
				'avg_days_supply'       => $avg_turnover > 0 ? (int) round( $days / $avg_turnover ) : null,
				'total_cogs'            => $no_cost === count( $products ) ? null : round( $total_cogs, 2 ),
				'product_count'         => count( $products ),
				'products_without_cost' => $no_cost,
			],
			'products' => $products,
			'period'   => $this->period_payload( $from, $to, $from_time, $to_time ),
		] );
	}

	/**
	 * Net logged stock change per product over the period.
	 *
	 * Positive types add stock, negative types remove it. Used to reconstruct the
	 * opening stock for turnover.
	 *
	 * @param int[] $product_ids
	 *
	 * @return array<int,int> product_id => net change.
	 */
	private function get_stock_movement( array $product_ids, string $from, string $to, string $from_time, string $to_time ): array {
		global $wpdb;

		$product_ids = array_values( array_unique( array_filter( array_map( 'intval', $product_ids ) ) ) );

		if ( empty( $product_ids ) ) {
			return [];
		}

		[ $date_where, $date_args ] = $this->occurred_at_clause( $from, $to, $from_time, $to_time );

		$table = $wpdb->prefix . 'fm_inventory_logs';
		$ph    = implode( ', ', array_fill( 0, count( $product_ids ), '%d' ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- identifiers only.
				"SELECT product_id,
					SUM(CASE WHEN change_type IN ('add','opening','adj_add','restore','purchase') THEN quantity ELSE 0 END)
					- SUM(CASE WHEN change_type IN ('sale','wastage','adj_remove','adj_reduce') THEN quantity ELSE 0 END) AS net_change
				FROM {$table}
				WHERE product_id IN ({$ph}) AND {$date_where}
				GROUP BY product_id",
				// phpcs:enable
				array_merge( $product_ids, $date_args )
			),
			ARRAY_A
		);

		$movement = [];

		foreach ( $rows as $row ) {
			$movement[ (int) $row['product_id'] ] = (int) $row['net_change'];
		}

		return $movement;
	}
}
