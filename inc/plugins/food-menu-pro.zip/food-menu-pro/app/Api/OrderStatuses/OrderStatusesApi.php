<?php
/**
 * Order Statuses REST API class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Api\OrderStatuses;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use WP_REST_Response;

/**
 * Order Statuses REST API class.
 */
class OrderStatusesApi {

	use SingletonTrait;

	/**
	 * Option key for stored statuses.
	 *
	 * @var string
	 */
	const OPTION_KEY = 'fmp_custom_order_statuses';

	/**
	 * Option key for stored default-status overrides.
	 *
	 * @var string
	 */
	const DEFAULTS_OPTION_KEY = 'fmp_default_status_overrides';

	/**
	 * Protected WooCommerce slugs that cannot be overwritten.
	 *
	 * @var array
	 */
	const PROTECTED_SLUGS = [
		'wc-pending',
		'wc-processing',
		'wc-on-hold',
		'wc-completed',
		'wc-cancelled',
		'wc-refunded',
		'wc-failed',
	];

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST API routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			'fmp/v1',
			'/order-statuses',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_statuses' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
				[
					'methods'             => 'POST',
					'callback'            => [ $this, 'save_statuses' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
			]
		);

		register_rest_route(
			'fmp/v1',
			'/order-statuses/presets',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_presets' ],
				'permission_callback' => [ $this, 'check_permission' ],
			]
		);

		register_rest_route(
			'fmp/v1',
			'/order-statuses/presets/(?P<name>[a-z_]+)',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_preset' ],
				'permission_callback' => [ $this, 'check_permission' ],
			]
		);

		register_rest_route(
			'fmp/v1',
			'/order-statuses/order-count/(?P<slug>[a-z0-9-]+)',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_order_count' ],
				'permission_callback' => [ $this, 'check_permission' ],
			]
		);

		register_rest_route(
			'fmp/v1',
			'/order-statuses/defaults',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_default_statuses' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
				[
					'methods'             => 'POST',
					'callback'            => [ $this, 'save_default_statuses' ],
					'permission_callback' => [ $this, 'check_permission' ],
				],
			]
		);
	}

	/**
	 * Permission callback.
	 *
	 * @return bool
	 */
	public function check_permission() {
		// Site-wide statuses + the email/WhatsApp templates sent to every customer — same cap as the
		// wp-admin Order Statuses page that uses these routes, not any dashboard staff member.
		return current_user_can( 'manage_woocommerce' );
	}

	/**
	 * GET /order-statuses — List all custom statuses.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_statuses( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$statuses = get_option( self::OPTION_KEY, [] );

		if ( ! is_array( $statuses ) ) {
			$statuses = [];
		}

		return rest_ensure_response( [
			'success'  => true,
			'statuses' => $statuses,
		] );
	}

	/**
	 * POST /order-statuses — Save all statuses (full array replace).
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function save_statuses( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$raw_statuses = $request->get_json_params();
		$statuses     = $raw_statuses['statuses'] ?? [];

		if ( ! is_array( $statuses ) ) {
			return rest_ensure_response( [
				'success' => false,
				'error'   => __( 'Invalid data format.', 'food-menu-pro' ),
			] );
		}

		$sanitized = [];

		foreach ( $statuses as $index => $status ) {
			$label = sanitize_text_field( wp_unslash( $status['label'] ?? '' ) );

			if ( empty( $label ) ) {
				continue;
			}

			$slug = sanitize_title( $label );
			$slug = substr( $slug, 0, 17 );
			$slug = 'wc-' . $slug;

			// Use the provided slug if it already has wc- prefix and is valid.
			if ( ! empty( $status['slug'] ) && 0 === strpos( $status['slug'], 'wc-' ) ) {
				$slug = sanitize_title( wp_unslash( $status['slug'] ) );
			}

			// Block protected WC slugs.
			if ( in_array( $slug, self::PROTECTED_SLUGS, true ) ) {
				continue;
			}

			$color = sanitize_hex_color( $status['color'] ?? '#999999' );

			if ( empty( $color ) ) {
				$color = '#999999';
			}

			$sanitized[] = [
				'slug'          => $slug,
				'label'         => $label,
				'color'         => $color,
				'icon'          => sanitize_text_field( $status['icon'] ?? 'dashicons-marker' ),
				'email'         => ! empty( $status['email'] ) ? 1 : 0,
				'email_admin'   => ! empty( $status['email_admin'] ) ? 1 : 0,
				'email_subject' => sanitize_text_field( wp_unslash( $status['email_subject'] ?? '' ) ),
				'email_body'    => sanitize_textarea_field( wp_unslash( $status['email_body'] ?? '' ) ),
				'whatsapp_body' => sanitize_textarea_field( wp_unslash( $status['whatsapp_body'] ?? '' ) ),
				'position'      => absint( $index ),
				'enabled'       => ! empty( $status['enabled'] ) ? 1 : 0,
			];
		}

		update_option( self::OPTION_KEY, $sanitized );

		return rest_ensure_response( [
			'success'  => true,
			'message'  => __( 'Order statuses saved successfully.', 'food-menu-pro' ),
			'statuses' => $sanitized,
		] );
	}

	/**
	 * GET /order-statuses/presets — List available preset names.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_presets( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		return rest_ensure_response( [
			'success' => true,
			'presets' => [
				'kitchen'  => __( 'Kitchen Flow', 'food-menu-pro' ),
				'delivery' => __( 'Delivery Flow', 'food-menu-pro' ),
				'dine_in'  => __( 'Dine-in Flow', 'food-menu-pro' ),
			],
		] );
	}

	/**
	 * GET /order-statuses/presets/{name} — Get a specific preset.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_preset( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$name    = sanitize_text_field( $request->get_param( 'name' ) );
		$presets = self::get_preset_data();

		if ( ! isset( $presets[ $name ] ) ) {
			return new \WP_Error(
				'not_found',
				__( 'Preset not found.', 'food-menu-pro' ),
				[ 'status' => 404 ]
			);
		}

		return rest_ensure_response( [
			'success'  => true,
			'statuses' => $presets[ $name ],
		] );
	}

	/**
	 * GET /order-statuses/order-count/{slug} — Count orders with a given status.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_order_count( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$slug = sanitize_title( $request->get_param( 'slug' ) );

		if ( empty( $slug ) ) {
			return rest_ensure_response( [ 'count' => 0 ] );
		}

		$orders = wc_get_orders( [
			'status' => $slug,
			'limit'  => 1,
			'return' => 'ids',
		] );

		$count = count( $orders );

		if ( $count > 0 ) {
			$all_orders = wc_get_orders( [
				'status' => $slug,
				'limit'  => -1,
				'return' => 'ids',
			] );

			$count = count( $all_orders );
		}

		return rest_ensure_response( [
			'success' => true,
			'count'   => $count,
		] );
	}

	/**
	 * GET /order-statuses/defaults — List every WC-registered status (including
	 * core + third-party) with any stored overrides applied. Excludes statuses
	 * already managed in the custom panel and the internal checkout-draft status.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_default_statuses( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$wc_statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : [];

		// Exclude slugs already managed by the custom panel so we don't double-render.
		$custom_statuses = get_option( self::OPTION_KEY, [] );
		$custom_slugs    = [];
		if ( is_array( $custom_statuses ) ) {
			foreach ( $custom_statuses as $cs ) {
				if ( ! empty( $cs['slug'] ) ) {
					$custom_slugs[] = $cs['slug'];
				}
			}
		}

		$overrides = get_option( self::DEFAULTS_OPTION_KEY, [] );
		if ( ! is_array( $overrides ) ) {
			$overrides = [];
		}

		$defaults = [];

		foreach ( $wc_statuses as $slug => $label ) {
			if ( 'wc-checkout-draft' === $slug ) {
				continue;
			}
			if ( in_array( $slug, $custom_slugs, true ) ) {
				continue;
			}

			$ov = isset( $overrides[ $slug ] ) && is_array( $overrides[ $slug ] ) ? $overrides[ $slug ] : [];

			$defaults[] = [
				'slug'          => $slug,
				'label'         => $label,
				'color'         => $ov['color'] ?? \RT\FoodMenuPro\Helpers\FnsPro::default_wc_status_color( $slug ),
				'icon'          => $ov['icon'] ?? '',
				'email_subject' => $ov['email_subject'] ?? '',
				'email_body'    => $ov['email_body'] ?? '',
				'whatsapp_body' => $ov['whatsapp_body'] ?? '',
			];
		}

		return rest_ensure_response( [
			'success'  => true,
			'statuses' => $defaults,
		] );
	}

	/**
	 * POST /order-statuses/defaults — Save overrides for default statuses. Only
	 * editable fields are stored, keyed by slug. Slugs that aren't registered
	 * with WooCommerce are silently dropped.
	 *
	 * @param \WP_REST_Request $request REST request.
	 *
	 * @return WP_REST_Response
	 */
	public function save_default_statuses( \WP_REST_Request $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'unauthorized', 'Authentication failed', [ 'status' => 401 ] );
		}

		$raw   = $request->get_json_params();
		$input = $raw['statuses'] ?? [];

		if ( ! is_array( $input ) ) {
			return rest_ensure_response( [
				'success' => false,
				'error'   => __( 'Invalid data format.', 'food-menu-pro' ),
			] );
		}

		$wc_statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : [];
		$overrides   = [];

		foreach ( $input as $row ) {
			$slug = sanitize_text_field( wp_unslash( $row['slug'] ?? '' ) );

			if ( empty( $slug ) || ! isset( $wc_statuses[ $slug ] ) ) {
				continue;
			}

			$color = sanitize_hex_color( $row['color'] ?? '' );
			if ( empty( $color ) ) {
				$color = \RT\FoodMenuPro\Helpers\FnsPro::default_wc_status_color( $slug );
			}

			$overrides[ $slug ] = [
				'color'         => $color,
				'icon'          => sanitize_text_field( $row['icon'] ?? '' ),
				'email_subject' => sanitize_text_field( wp_unslash( $row['email_subject'] ?? '' ) ),
				'email_body'    => sanitize_textarea_field( wp_unslash( $row['email_body'] ?? '' ) ),
				'whatsapp_body' => sanitize_textarea_field( wp_unslash( $row['whatsapp_body'] ?? '' ) ),
			];
		}

		update_option( self::DEFAULTS_OPTION_KEY, $overrides );

		// Exclude slugs managed by the custom panel (registered with WC via
		// the OrderStatuses controller) so they don't show up twice in the
		// defaults table.
		$custom_statuses = get_option( self::OPTION_KEY, [] );
		$custom_slugs    = [];
		if ( is_array( $custom_statuses ) ) {
			foreach ( $custom_statuses as $cs ) {
				if ( ! empty( $cs['slug'] ) ) {
					$custom_slugs[] = $cs['slug'];
				}
			}
		}

		// Return the same shape the GET endpoint would, so the client can sync.
		$response = [];
		foreach ( $wc_statuses as $slug => $label ) {
			if ( 'wc-checkout-draft' === $slug ) {
				continue;
			}
			if ( in_array( $slug, $custom_slugs, true ) ) {
				continue;
			}
			$ov = $overrides[ $slug ] ?? [];
			$response[] = [
				'slug'          => $slug,
				'label'         => $label,
				'color'         => $ov['color'] ?? \RT\FoodMenuPro\Helpers\FnsPro::default_wc_status_color( $slug ),
				'icon'          => $ov['icon'] ?? '',
				'email_subject' => $ov['email_subject'] ?? '',
				'email_body'    => $ov['email_body'] ?? '',
				'whatsapp_body' => $ov['whatsapp_body'] ?? '',
			];
		}

		return rest_ensure_response( [
			'success'  => true,
			'message'  => __( 'Default status overrides saved.', 'food-menu-pro' ),
			'statuses' => $response,
		] );
	}

	/**
	 * Get preset data arrays.
	 *
	 * @return array
	 */
	private static function get_preset_data() {
		return [
			'kitchen'  => [
				[
					'slug'          => 'wc-received',
					'label'         => __( 'Order Received', 'food-menu-pro' ),
					'color'         => '#3498db',
					'icon'          => 'dashicons-clipboard',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => __( 'Your order has been received', 'food-menu-pro' ),
					'email_body'    => __( 'Hi {customer_name}, your order #{order_number} has been received and is in the queue.', 'food-menu-pro' ),
					'position'      => 0,
					'enabled'       => 1,
				],
				[
					'slug'          => 'wc-prepping',
					'label'         => __( 'Prepping', 'food-menu-pro' ),
					'color'         => '#f39c12',
					'icon'          => 'dashicons-carrot',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => __( 'Your order is being prepared', 'food-menu-pro' ),
					'email_body'    => __( 'Hi {customer_name}, your order #{order_number} is now being prepared.', 'food-menu-pro' ),
					'position'      => 1,
					'enabled'       => 1,
				],
				[
					'slug'          => 'wc-in-oven',
					'label'         => __( 'In Oven', 'food-menu-pro' ),
					'color'         => '#e74c3c',
					'icon'          => 'dashicons-image-filter',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => '',
					'email_body'    => '',
					'position'      => 2,
					'enabled'       => 1,
				],
				[
					'slug'          => 'wc-ready',
					'label'         => __( 'Ready', 'food-menu-pro' ),
					'color'         => '#27ae60',
					'icon'          => 'dashicons-yes-alt',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => __( 'Your order is ready', 'food-menu-pro' ),
					'email_body'    => __( 'Hi {customer_name}, your order #{order_number} is ready for pickup!', 'food-menu-pro' ),
					'position'      => 3,
					'enabled'       => 1,
				],
			],
			'delivery' => [
				[
					'slug'          => 'wc-confirmed',
					'label'         => __( 'Confirmed', 'food-menu-pro' ),
					'color'         => '#3498db',
					'icon'          => 'dashicons-yes',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => __( 'Your order is confirmed', 'food-menu-pro' ),
					'email_body'    => __( 'Hi {customer_name}, your order #{order_number} has been confirmed.', 'food-menu-pro' ),
					'position'      => 0,
					'enabled'       => 1,
				],
				[
					'slug'          => 'wc-preparing',
					'label'         => __( 'Preparing', 'food-menu-pro' ),
					'color'         => '#f39c12',
					'icon'          => 'dashicons-carrot',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => '',
					'email_body'    => '',
					'position'      => 1,
					'enabled'       => 1,
				],
				[
					'slug'          => 'wc-driver-out',
					'label'         => __( 'Driver Out', 'food-menu-pro' ),
					'color'         => '#9b59b6',
					'icon'          => 'dashicons-car',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => __( 'Your order is on the way', 'food-menu-pro' ),
					'email_body'    => __( 'Hi {customer_name}, your order #{order_number} is on its way! Track your order: {order_url}', 'food-menu-pro' ),
					'position'      => 2,
					'enabled'       => 1,
				],
				[
					'slug'          => 'wc-delivered',
					'label'         => __( 'Delivered', 'food-menu-pro' ),
					'color'         => '#27ae60',
					'icon'          => 'dashicons-yes-alt',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => __( 'Your order has been delivered', 'food-menu-pro' ),
					'email_body'    => __( 'Hi {customer_name}, your order #{order_number} has been delivered. Enjoy your meal!', 'food-menu-pro' ),
					'position'      => 3,
					'enabled'       => 1,
				],
			],
			'dine_in'  => [
				[
					'slug'          => 'wc-seated',
					'label'         => __( 'Seated', 'food-menu-pro' ),
					'color'         => '#3498db',
					'icon'          => 'dashicons-admin-users',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => '',
					'email_body'    => '',
					'position'      => 0,
					'enabled'       => 1,
				],
				[
					'slug'          => 'wc-in-kitchen',
					'label'         => __( 'In Kitchen', 'food-menu-pro' ),
					'color'         => '#f39c12',
					'icon'          => 'dashicons-carrot',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => '',
					'email_body'    => '',
					'position'      => 1,
					'enabled'       => 1,
				],
				[
					'slug'          => 'wc-served',
					'label'         => __( 'Served', 'food-menu-pro' ),
					'color'         => '#27ae60',
					'icon'          => 'dashicons-food',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => '',
					'email_body'    => '',
					'position'      => 2,
					'enabled'       => 1,
				],
				[
					'slug'          => 'wc-bill-ready',
					'label'         => __( 'Bill Ready', 'food-menu-pro' ),
					'color'         => '#e67e22',
					'icon'          => 'dashicons-money-alt',
					'email'         => 0,
					'email_admin'   => 0,
					'email_subject' => '',
					'email_body'    => '',
					'position'      => 3,
					'enabled'       => 1,
				],
			],
		];
	}
}
