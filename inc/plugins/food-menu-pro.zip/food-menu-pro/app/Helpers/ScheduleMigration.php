<?php
/**
 * Schedule Migration.
 *
 * Migrates old weekly schedule data (split across 3 keys + holiday key)
 * into the new unified schedule structure.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Helpers;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Schedule Migration Class.
 */
class ScheduleMigration {

	/**
	 * Option key used to track whether migration has run.
	 */
	const MIGRATION_FLAG = 'fmp_schedule_migration_v1';

	/**
	 * Map of abbreviated day names (old) to full lowercase day names (new).
	 *
	 * @var array
	 */
	private static $day_abbr_map = [
		'Sat' => 'saturday',
		'Sun' => 'sunday',
		'Mon' => 'monday',
		'Tue' => 'tuesday',
		'Wed' => 'wednesday',
		'Thu' => 'thursday',
		'Fri' => 'friday',
	];

	/**
	 * Map of JS day index (0=Sun..6=Sat) to full lowercase day name.
	 *
	 * @var array
	 */
	private static $day_index_map = [
		0 => 'sunday',
		1 => 'monday',
		2 => 'tuesday',
		3 => 'wednesday',
		4 => 'thursday',
		5 => 'friday',
		6 => 'saturday',
	];

	/**
	 * All 7 day names in the new format.
	 *
	 * @var array
	 */
	private static $all_days = [
		'sunday',
		'monday',
		'tuesday',
		'wednesday',
		'thursday',
		'friday',
		'saturday',
	];

	/**
	 * Run migration if not already done.
	 *
	 * @return void
	 */
	public static function maybe_migrate() {
		if ( get_option( self::MIGRATION_FLAG ) ) {
			return;
		}

		self::migrate();

		update_option( self::MIGRATION_FLAG, true );
	}

	/**
	 * Perform the migration for all 3 schedule types.
	 *
	 * @return void
	 */
	private static function migrate() {
		$settings = get_option( TLPFoodMenu()->options['settings'], [] );

		if ( ! is_array( $settings ) ) {
			return;
		}

		$changed = false;

		// Pickup schedule migration.
		if ( empty( $settings['new_fmp_pickup_weekly_schedule'] ) ) {
			//Old structure to new structure
			$result = self::convert_schedule(
				$settings['fmp_pickup_weekly_schedule'] ?? [],
				$settings['fmp_pickup_weekly_schedule_start_time'] ?? [],
				$settings['fmp_pickup_weekly_schedule_end_time'] ?? [],
				$settings['fmp_pickup_weekly_holiday'] ?? []
			);

			if ( ! empty( $result ) ) {
				$settings['new_fmp_pickup_weekly_schedule'] = $result;
				$changed                                    = true;
			}
		}

		// Delivery schedule migration.
		if ( empty( $settings['new_fmp_delivery_weekly_schedule'] ) ) {
			//Old structure to new structure
			$result = self::convert_schedule(
				$settings['fmp_delivery_weekly_schedule'] ?? [],
				$settings['fmp_delivery_weekly_schedule_start_time'] ?? [],
				$settings['fmp_delivery_weekly_schedule_end_time'] ?? [],
				$settings['fmp_delivery_weekly_holiday'] ?? []
			);

			if ( ! empty( $result ) ) {
				$settings['new_fmp_delivery_weekly_schedule'] = $result;
				$changed                                      = true;
			}
		}

		// Reservation schedule migration.
		if ( empty( $settings['new_fmp_resi_weekly_schedule'] ) ) {
			//Old structure to new structure
			$result = self::convert_schedule(
				$settings['fmp_resi_weekly_schedule'] ?? [],
				$settings['fmp_resi_weekly_schedule_start_time'] ?? [],
				$settings['fmp_resi_weekly_schedule_end_time'] ?? [],
				$settings['fmp_resi_weekly_holiday'] ?? []
			);

			if ( ! empty( $result ) ) {
				$settings['new_fmp_resi_weekly_schedule'] = $result;
				$changed                                  = true;
			}
		}

		if ( $changed ) {
			update_option( TLPFoodMenu()->options['settings'], $settings );
		}
	}

	/**
	 * Convert old schedule data into the new structure.
	 *
	 * Old structure:
	 *   schedule:    [ [Sat => on, Sun => on], [Tue => on, Wed => on] ]
	 *   start_times: [ 0 => '11:00 AM', 1 => '2:00 PM' ]
	 *   end_times:   [ 0 => '1:00 PM',  1 => '10:00 PM' ]
	 *   holidays:    [ 0 => 'on', 3 => 'on' ] (key = JS day index, 0=Sun..6=Sat)
	 *
	 * New structure:
	 *   [
	 *     'monday' => [ 'is_open' => 'yes', 'slots' => [ ['start' => '10:00', 'end' => '12:00', 'max_order' => ''] ] ],
	 *     ...
	 *   ]
	 *
	 * @param array $schedule Old grouped schedule array.
	 * @param array $start_times Old start times indexed by group.
	 * @param array $end_times Old end times indexed by group.
	 * @param array $holidays Old holiday array (key = JS day index).
	 *
	 * @return array New schedule structure.
	 */
	private static function convert_schedule( $schedule, $start_times, $end_times, $holidays ) {
		// Build the set of holiday day names from the old index-based format.
		$holiday_days = [];

		foreach ( $holidays as $day_index => $value ) {
			if ( isset( self::$day_index_map[ (int) $day_index ] ) ) {
				$holiday_days[] = self::$day_index_map[ (int) $day_index ];
			}
		}

		// Build a map: day_name => array of slots from the old grouped schedule.
		$day_slots = [];

		if ( is_array( $schedule ) ) {
			foreach ( $schedule as $group_index => $group ) {
				if ( ! is_array( $group ) ) {
					continue;
				}

				$start = isset( $start_times[ $group_index ] ) ? self::normalize_time( $start_times[ $group_index ] ) : '';
				$end   = isset( $end_times[ $group_index ] ) ? self::normalize_time( $end_times[ $group_index ] ) : '';

				foreach ( $group as $abbr => $status ) {
					if ( 'on' !== $status || ! isset( self::$day_abbr_map[ $abbr ] ) ) {
						continue;
					}

					$day_name = self::$day_abbr_map[ $abbr ];

					if ( ! isset( $day_slots[ $day_name ] ) ) {
						$day_slots[ $day_name ] = [];
					}

					if ( $start || $end ) {
						$day_slots[ $day_name ][] = [
							'start'     => $start,
							'end'       => $end,
							'max_order' => '',
						];
					}
				}
			}
		}

		// Build the final new structure for all 7 days.
		$new_schedule = [];

		foreach ( self::$all_days as $day ) {
			$is_holiday = in_array( $day, $holiday_days, true );
			$is_open    = $is_holiday ? 'no' : 'yes';
			$slots      = ! empty( $day_slots[ $day ] ) ? $day_slots[ $day ] : [];

			$new_schedule[ $day ] = [
				'is_open' => $is_open,
				'slots'   => $slots,
			];
		}

		return $new_schedule;
	}

	/**
	 * Normalize time string to 24h format (H:i).
	 *
	 * Handles both "2:00 PM" and "14:00" formats.
	 *
	 * @param string $time Time string.
	 *
	 * @return string Normalized time in H:i format, or empty string.
	 */
	private static function normalize_time( $time ) {
		$time = trim( $time );

		if ( empty( $time ) ) {
			return '';
		}

		$timestamp = strtotime( $time );

		if ( false === $timestamp ) {
			return $time;
		}

		return gmdate( 'H:i', $timestamp );
	}
}