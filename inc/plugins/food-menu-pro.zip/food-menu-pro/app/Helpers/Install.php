<?php
/**
 * Activation & Deactivation actions.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Helpers;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Activation & Deactivation actions.
 */
class Install {
	/**
	 * Activation actions.
	 *
	 * @return void
	 */
	public static function activate() {
		flush_rewrite_rules();
//		self::fmp_add_order_manager_role();
		self::fmp_add_kitchen_manager_role();
		self::fmp_migrate_add_order_meta();
	}

	/**
	 * Deactivation actions.
	 *
	 * @return void
	 */
	public static function deactivate() {
		flush_rewrite_rules();
	}

	/**
	 * Migrate add order meta.
	 *
	 * @return void
	 */
	public static function fmp_migrate_add_order_meta() {

		$taxonomy = 'food-menu-cat';

		$terms = get_terms(
			[
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			]
		);

		foreach ( $terms as $term ) {
			$order_meta = get_term_meta( $term->term_id, '_order', true );

			if ( empty( $order_meta ) ) {
				$default_value = 0;
				update_term_meta( $term->term_id, '_order', $default_value );
			}
		}
	}

	public static function fmp_add_order_manager_role() {
		add_role(
			'fm_order_manage',
			__( 'FoodMenu Order Manager', 'food-menu-pro' ),
			array(
				'read' => true,
			)
		);
	}

	public static function fmp_add_kitchen_manager_role() {
		add_role(
			'fm_kitchen_manager',
			__( 'Kitchen Manager', 'food-menu-pro' ),
			array(
				'read' => true,
			)
		);
	}
}