<?php
/**
 * Helpers class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Helpers;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Models\FMPFood;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Helpers class.
 */
class FnsPro {

	/**
	 * All dashboard menu slugs. Add new menus here once.
	 */
	const DASHBOARD_MENUS = [ 'dashboard', 'orders', 'order-read', 'order-edit', 'order-create', 'inventory', 'inv-add', 'inv-waste', 'inv-adjust', 'waste', 'reconciliation', 'purchase-orders', 'suppliers', 'stock-alerts', 'reports', 'kitchen-monitor' ];

	/**
	 * Render view.
	 *
	 * @param string $viewName View name.
	 * @param array $args View args.
	 * @param boolean $return View return.
	 *
	 * @return string|void
	 */
	public static function renderView( $viewName, $args = [], $return = false ) {
		$viewName = str_replace( '.', '/', $viewName );

		if ( ! empty( $args ) && is_array( $args ) ) {
			extract( $args );
		}

		$view_file = FMP()->pro_plugin_path() . '/resources/' . $viewName . '.php';

		if ( ! file_exists( $view_file ) ) {
			_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', esc_html( $view_file ) ), '1.7.0' );

			return;
		}

		if ( $return ) {
			ob_start();
			include $view_file;

			return ob_get_clean();
		} else {
			include $view_file;
		}
	}

	/**
	 * Insert Array.
	 *
	 * @param array $array Array.
	 * @param int $position Position.
	 * @param array $insert_array Insert array.
	 *
	 * @return array
	 */
	public static function array_insert( $array, $position, $insert_array ) {
		$first_array = array_splice( $array, 0, $position + 1 );
		$array       = array_merge( $first_array, $insert_array, $array );

		return $array;
	}

	/**
	 * Food
	 *
	 * @param string $food Food.
	 *
	 * @return void|object
	 */
	public static function food( $food = null ) {
		return new FMPFood( $food );
	}

	/**
	 * Get nutrition list.
	 *
	 * @param int $post_id Post ID.
	 *
	 * @return void|string
	 */
	public static function get_fm_nutrition_list( $post_id = null ) {
		if ( ! $post_id ) {
			global $post;
			$post_id = $post->ID;
		}

		$post_id = absint( $post_id );

		$html      = null;
		$nutrition = get_post_meta( $post_id, '_nutrition' );

		if ( ! empty( $nutrition ) ) {
			$items = '';
			foreach ( $nutrition as $nutrition ) {
				$nut   = ! empty( $nutrition['id'] ) ? get_term( $nutrition['id'], TLPFoodMenu()->taxonomies['nutrition'] ) : null;
				$unit  = ! empty( $nutrition['unit_id'] ) ? get_term( $nutrition['unit_id'], TLPFoodMenu()->taxonomies['unit'] ) : null;
				$value = ! empty( $nutrition['value'] ) ? ' ' . $nutrition['value'] : null;

				if ( is_object( $unit ) && ! empty( $unit->name ) && $value ) {
					$unit = " ( {$unit->name} )";
				} else {
					$unit = null;
				}

				if ( is_object( $nut ) ) {
					$items .= "<li>{$nut->name}{$value}{$unit}</li>";
				}
			}

			if ( $items ) {
				$html = '<ul>' . $items . '</ul>';
			}
		}

		return $html;
	}

	/**
	 * @param null $post_id
	 *
	 * @return null|string
	 */
	public static function get_fm_ingredient_list( $post_id = null ) {
		if ( ! $post_id ) {
			global $post;
			$post_id = $post->ID;
		}

		$post_id = absint( $post_id );

		$html        = null;
		$ingredients = get_post_meta( $post_id, '_ingredient' );

		if ( ! empty( $ingredients ) ) {
			$items = '';
			foreach ( $ingredients as $ingredient ) {
				$ing   = ! empty( $ingredient['id'] ) ? get_term( $ingredient['id'], TLPFoodMenu()->taxonomies['ingredient'] ) : null;
				$unit  = ! empty( $ingredient['unit_id'] ) ? get_term( $ingredient['unit_id'], TLPFoodMenu()->taxonomies['unit'] ) : null;
				$value = ! empty( $ingredient['value'] ) ? ' ' . $ingredient['value'] : null;

				if ( is_object( $unit ) && $unit->name && $value ) {
					$unit = " ( {$unit->name} )";
				} else {
					$unit = null;
				}

				if ( is_object( $ing ) ) {
					$items .= "<li>{$ing->name}{$value}{$unit}</li>";
				}
			}

			if ( $items ) {
				$html = '<ul>' . $items . '</ul>';
			}
		}

		return $html;
	}

	/**
	 * Returns the product tags.
	 *
	 * @param $id
	 * @param $sep
	 * @param $before
	 * @param $after
	 *
	 * @return false|string|\WP_Error|\WP_Term[]
	 */
	public static function get_tags( $id, $sep = ', ', $before = '', $after = '' ) {
		return get_the_term_list( $id, TLPFoodMenu()->taxonomies['tag'], $before, $sep, $after );
	}

	/**
	 * Pagination
	 *
	 * @param string $pages Pages.
	 * @param integer $range Range.
	 * @param boolean $ajax Ajax.
	 * @param string $scID Shortcode ID.
	 *
	 * @return string
	 */
	public static function pagination( $pages = '', $range = 4, $ajax = false, $scID = '' ) {
		$html      = null;
		$showitems = ( $range * 2 ) + 1;

		global $paged;

		if ( is_front_page() ) {
			$paged = ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1;
		} else {
			$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
		}

		if ( empty( $paged ) ) {
			$paged = 1;
		}

		if ( $pages == '' ) {
			global $wp_query;
			$pages = $wp_query->max_num_pages;

			if ( ! $pages ) {
				$pages = 1;
			}
		}

		$ajaxClass = null;
		$dataAttr  = null;

		if ( $ajax ) {
			$ajaxClass = ' fmp-ajax';
			$dataAttr  = "data-sc-id='{$scID}' data-paged='1'";
		}

		if ( 1 != $pages ) {
			$html .= '<div class="fmp-pagination' . $ajaxClass . '" ' . $dataAttr . '>';
			$html .= '<ul class="pagination-list">';

			if ( $paged > 2 && $paged > $range + 1 && $showitems < $pages ) {
				$html .= "<li><a data-paged='1' href='" . get_pagenum_link( 1 ) . "' aria-label='First'>&laquo;</a></li>";
			}

			if ( $paged > 1 && $showitems < $pages ) {
				$p    = $paged - 1;
				$html .= "<li><a data-paged='{$p}' href='" . get_pagenum_link( $p ) . "' aria-label='Previous'>&lsaquo;</a></li>";
			}

			for ( $i = 1; $i <= $pages; $i ++ ) {
				if ( 1 != $pages && ( ! ( $i >= $paged + $range + 1 || $i <= $paged - $range - 1 ) || $pages <= $showitems ) ) {
					$html .= ( $paged == $i ) ? '<li class="active"><span>' . $i . '</span></li>' : "<li><a data-paged='{$i}' href='" . get_pagenum_link( $i ) . "'>" . $i . '</a></li>';
				}
			}

			if ( $paged < $pages && $showitems < $pages ) {
				$p    = $paged + 1;
				$html .= "<li><a data-paged='{$p}' href=\"" . get_pagenum_link( $paged + 1 ) . "\"  aria-label='Next'>&rsaquo;</a></li>";
			}

			if ( $paged < $pages - 1 && $paged + $range - 1 < $pages && $showitems < $pages ) {
				$html .= "<li><a data-paged='{$pages}' href='" . get_pagenum_link( $pages ) . "' aria-label='Last'>&raquo;</a></li>";
			}

			$html .= '</ul>';
			$html .= '</div>';
		}

		return $html;
	}

	public static function getStockStatus( $id = null ) {
		if ( $id ) {
			$id = absint( $id );
		} else {
			$id = get_the_ID();
		}

		$stock     = get_post_meta( $id, '_stock_status', true );
		$stockHtml = null;
		$fmp_type  = get_post_meta( $id, '_fmp_type', true );

		if ( 'variable' === $fmp_type ) {
			$stockHtml = '<span class="na">–</span>';
		} else {
			if ( $stock == 'instock' ) {
				$stockHtml = '<mark class="instock">In stock</mark>';
			} elseif ( $stock == 'outofstock' ) {
				$stockHtml = '<mark class="outofstock">Out of stock</mark>';
			}
		}

		return $stockHtml;
	}

	public static function fmpHtmlPrice( $id = null ) {
		if ( $id ) {
			$id = absint( $id );
		} else {
			global $post;
			$id = $post->ID;
		}

		if(! $id){
			return '';
		}

		$price_html         = null;

		$fmp_type = get_post_meta( $id, '_fmp_type', true );

		if ( 'variable' === $fmp_type ) {
			$vPrices    = [];
			$variations = get_posts(
				[
					'post_type'      => 'fmp_variation',
					'posts_per_page' => - 1,
					'post_status'    => 'any',
					'post_parent'    => $id,
					'order'          => 'ASC',
				]
			);

			if ( ! empty( $variations ) ) {
				foreach ( $variations as $variation ) {
					$vp = get_post_meta( $variation->ID, '_price', true );
					if ( $vp ) {
						$vPrices[] = $vp;
					}
				}

				if ( ! empty( $vPrices ) && count( $vPrices ) > 1 ) {
					$max        = self::getPriceWithSymbol( max( $vPrices ) );
					$min        = self::getPriceWithSymbol( min( $vPrices ) );
					$price_html = $min . ' - ' . $max;
				} elseif ( ! empty( $vPrices ) && count( $vPrices ) == 1 ) {
					$price_html = self::getPriceWithSymbol( max( $vPrices ) );
				} else {
					$price_html = "<span class='na'>–</span>";
				}
			}
		} else {
			$sale_price_html    = null;
			$regular_price_html = null;
			$regular_price      = get_post_meta( $id, '_regular_price', true );
			$sale_price         = get_post_meta( $id, '_sale_price', true );

			if ( ! ( $regular_price || $sale_price ) ) {
				return '';
			}

			if ( $regular_price > 0 ) {
				$fRegularPrice      = self::getPriceWithSymbol( $regular_price );
				$regular_price_html = '<span class="fmp-price-amount amount">' . $fRegularPrice . '</span>';
			}

			if ( $sale_price > 0 ) {
				$fSalePrice      = self::getPriceWithSymbol( $sale_price );
				$sale_price_html = '<span class="fmp-price-amount amount">' . $fSalePrice . '</span>';
			} elseif ( $sale_price == '' ) {
				$sale_price_html = null;
			} elseif ( $sale_price == 0 ) {
				$sale_price_html = '<span class="amount">' . esc_html__( 'Free!', 'food-menu-pro' ) . '</span>';
			}

			if ( $regular_price_html && $sale_price_html ) {
				$price_html = '<del>' . $regular_price_html . '</del>' . '<inc>' . $sale_price_html . '</inc>';
			} elseif ( ! $regular_price_html && $sale_price_html ) {
				$price_html = $sale_price_html;
			} elseif ( $regular_price_html && ! $sale_price_html ) {
				$price_html = $regular_price_html;
			}
		}

		return apply_filters( 'rtfm_food_price_modifier', $price_html, get_the_ID() );
	}

	public static function get_formatted_amount( $amount ) {
		$settings      = get_option( TLPFoodMenu()->options['settings'] );
		$thousands_sep = isset( $settings['price_thousand_sep'] ) ? stripslashes( $settings['price_thousand_sep'] ) : ',';
		$decimal_sep   = isset( $settings['price_decimal_sep'] ) ? stripslashes( $settings['price_decimal_sep'] ) : '.';
		$decimals      = isset( $settings['price_num_decimals'] ) ? absint( $settings['price_num_decimals'] ) : 2;

		$un_formatted_price = $amount;
		$negative           = $amount < 0;
		$amount             = apply_filters( 'fmp_raw_amount', floatval( $negative ? $amount * - 1 : $amount ) );
		$amount             = apply_filters( 'fmp_formatted_amount', number_format( $amount, $decimals, $decimal_sep, $thousands_sep ) );

		if ( apply_filters( 'fmp_price_trim_zeros', false, $decimals ) && $decimals > 0 ) {
			$amount = self::trim_zeros( $amount, $decimal_sep );
		}

		return apply_filters( 'fmp_get_formatted_amount', $amount, $un_formatted_price, $decimals, $decimal_sep, $thousands_sep );
	}

	public static function trim_zeros( $amount, $decimal_sep ) {
		return preg_replace( '/' . preg_quote( $decimal_sep, '/' ) . '0++$/', '', $amount );
	}

	public static function getPriceWithSymbol( $price ) {
		$price     = self::get_formatted_amount( $price );
		$currencyP = Fns::getCurrencyPosition();
		$symbol    = '<span class="fmp-price-currencySymbol">' . Fns::getCurrencySymbol() . '</span>';

		switch ( $currencyP ) {
			case 'left':
				$price = $symbol . $price;
				break;

			case 'right':
				$price = $price . $symbol;
				break;

			case 'left_space':
				$price = $symbol . ' ' . $price;
				break;

			case 'right_space':
				$price = $price . ' ' . $symbol;
				break;

			default:
				break;
		}

		return $price;
	}

	public static function fmp_clean( $var ) {
		if ( is_array( $var ) ) {
			return array_map( [ __CLASS__, 'fmp_clean' ], $var );
		} else {
			return is_scalar( $var ) ? sanitize_text_field( $var ) : $var;
		}
	}

	public static function getAllFmpIsoFilterType() {
		return [
			'default' => esc_html__( 'Layout Default', 'food-menu-pro' ),
			'type-1'  => esc_html__( 'Type 1', 'food-menu-pro' ),
			'type-2'  => esc_html__( 'Type 2', 'food-menu-pro' ),
			'type-3'  => esc_html__( 'Type 3', 'food-menu-pro' ),
		];
	}

	/**
	 * Preparing date function
	 *
	 * @param number $daysToAdd receive day number.
	 *
	 * @return mixed
	 */
	public static function preparing_date( $daysToAdd = 0 ) {
		// Create a new DateTime object for the current date.
		$currentDate = new \DateTime();

		// Add the specified number of days to the current date.
		$currentDate->modify( '+' . $daysToAdd . ' day' );

		// Return the formatted date.
		return $currentDate->format( TLP_FOOD_MENU_DEFAULT_DATE_FORMAT );
	}

	/**
	 * Safely get a singleton instance of a class owned by the free plugin.
	 *
	 * Pro is frequently updated before the free plugin is, and several classes
	 * Pro reaches into (Tip, Reservation, Special Menu, Discount, the order-info
	 * metabox) only exist in newer free versions. Calling them directly throws
	 * "Class not found" on `init`/`wp`, which white-screens the whole site —
	 * front end *and* wp-admin, so the user can't even update the free plugin to
	 * recover. Always resolve free classes through this helper and no-op on null.
	 *
	 * @param string $class Fully-qualified class name.
	 *
	 * @return object|null The singleton, or null when the free plugin is too old.
	 */
	public static function free_instance( $class ) {
		if ( ! class_exists( $class ) || ! method_exists( $class, 'get_instance' ) ) {
			return null;
		}

		return $class::get_instance();
	}

	/**
	 * Human label for an order type slug.
	 *
	 * Unknown/empty slugs return an empty string — callers decide how to render
	 * an order that predates the order-type feature rather than being told it is
	 * something it isn't.
	 *
	 * @param string $type Order type slug ('pickup', 'delivery', 'dinein').
	 *
	 * @return string
	 */
	public static function get_order_type_label( $type ) {
		$labels = [
			'delivery' => esc_html__( 'Delivery', 'food-menu-pro' ),
			'pickup'   => esc_html__( 'Pickup', 'food-menu-pro' ),
			'dinein'   => esc_html__( 'Dine In', 'food-menu-pro' ),
		];

		return $labels[ $type ] ?? '';
	}

	/**
	 * Badge colour for an order type slug.
	 *
	 * @param string $type Order type slug.
	 *
	 * @return string Hex colour.
	 */
	public static function get_order_type_color( $type ) {
		$colors = [
			'delivery' => '#3577c1',
			'pickup'   => '#35c183',
			'dinein'   => '#b8860b',
		];

		return $colors[ $type ] ?? '#6c757d';
	}

	/**
	 * Resolve an order's scheduling info in one shot.
	 *
	 * Every surface that shows "when is this order for" (admin column, quick
	 * view, metabox, POS slips, kitchen monitor, dashboard) needs the same three
	 * pieces, and each one used to re-derive them with its own pickup/delivery
	 * if-else — which silently mislabelled anything that wasn't those two.
	 *
	 * @param \WC_Order $order Order object.
	 *
	 * @return array{type: string, label: string, date: string, time: string, table: string}
	 */
	public static function get_order_schedule( $order ) {
		if ( ! $order instanceof \WC_Order ) {
			return [
				'type'  => '',
				'label' => '',
				'date'  => '',
				'time'  => '',
				'table' => '',
			];
		}

		$type = (string) $order->get_meta( 'fmp_order_time_type' );

		return [
			'type'  => $type,
			'label' => self::get_order_type_label( $type ),
			'date'  => $type ? (string) $order->get_meta( "fmp_{$type}_date" ) : '',
			'time'  => $type ? (string) $order->get_meta( "fmp_{$type}_time" ) : '',
			'table' => (string) $order->get_meta( 'fmp_dinein_table' ),
		];
	}

	/**
	 * Get checkout order time array in desired format
	 */
	public static function get_order_type() {
		return [
			esc_html__( 'Delivery type', 'food-menu-pro' )  => 'fmp_order_time_type',
			esc_html__( 'Delivery date', 'food-menu-pro' )  => 'fmp_delivery_date',
			esc_html__( 'Delivery time', 'food-menu-pro' )  => 'fmp_delivery_time',
			esc_html__( 'Pickup date', 'food-menu-pro' )    => 'fmp_pickup_date',
			esc_html__( 'Pickup time', 'food-menu-pro' )    => 'fmp_pickup_time',
			esc_html__( 'Dine in date', 'food-menu-pro' )   => 'fmp_dinein_date',
			esc_html__( 'Dine in time', 'food-menu-pro' )   => 'fmp_dinein_time',
			esc_html__( 'Dine in table', 'food-menu-pro' )  => 'fmp_dinein_table',
			esc_html__( 'Tip type', 'food-menu-pro' )       => 'fmp_tip_type',
			esc_html__( 'Fixed Tip', 'food-menu-pro' )      => 'fmp_fixed_amount',
			esc_html__( 'Percentage Tip', 'food-menu-pro' ) => 'fmp_percentage_amount',
		];
	}

	/**
	 * Product discount price.
	 *
	 * @param array $args .
	 *
	 * @return array|void
	 */
	public static function discount_price( $args ) {
		return Fns::discount_price( $args );
	}

	/**
	 * Product price by tax.
	 *
	 * @param float $product .
	 *
	 * @return float
	 */
	public static function product_price_by_tax( $product ) {
		return wc_get_price_excluding_tax( $product ) ? wc_get_price_excluding_tax( $product ) : wc_get_price_including_tax( $product );
	}

	/**
	 * Get settings Options.
	 *
	 * @param string $key .
	 *
	 * @return array
	 */
	public static function get_settings_option( $key = null ) {
		$options = TLPFoodMenu()->options;
		$key     = ( null === $key && isset( $options['settings'] ) ) ? $options['settings'] : $key;

		return get_option( $key );
	}

	/**
	 * Resolve display + notification metadata for any order status slug.
	 *
	 * Lookup order:
	 *   1. `fmp_custom_order_statuses` (user-created custom statuses)
	 *   2. WooCommerce core/external statuses, merged with any override stored
	 *      in `fmp_default_status_overrides`.
	 *
	 * Returns null if the slug is not a known status.
	 *
	 * @param string $slug Status slug with the `wc-` prefix.
	 *
	 * @return array|null
	 */
	public static function get_status_metadata( $slug ) {
		if ( empty( $slug ) ) {
			return null;
		}

		$custom_statuses = get_option( 'fmp_custom_order_statuses', [] );
		if ( is_array( $custom_statuses ) ) {
			foreach ( $custom_statuses as $cs ) {
				if ( ( $cs['slug'] ?? '' ) === $slug && ! empty( $cs['enabled'] ) ) {
					return [
						'slug'          => $slug,
						'label'         => $cs['label'] ?? $slug,
						'color'         => $cs['color'] ?? '#6b7280',
						'icon'          => $cs['icon'] ?? '',
						'email_subject' => $cs['email_subject'] ?? '',
						'email_body'    => $cs['email_body'] ?? '',
						'whatsapp_body' => $cs['whatsapp_body'] ?? '',
						'is_default'    => false,
					];
				}
			}
		}

		$wc_statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : [];
		if ( ! isset( $wc_statuses[ $slug ] ) ) {
			return null;
		}

		$overrides = get_option( 'fmp_default_status_overrides', [] );
		$override  = is_array( $overrides ) && isset( $overrides[ $slug ] ) && is_array( $overrides[ $slug ] )
			? $overrides[ $slug ]
			: [];

		return [
			'slug'          => $slug,
			'label'         => $wc_statuses[ $slug ],
			'color'         => $override['color'] ?? self::default_wc_status_color( $slug ),
			'icon'          => $override['icon'] ?? '',
			'email_subject' => $override['email_subject'] ?? '',
			'email_body'    => $override['email_body'] ?? '',
			'whatsapp_body' => $override['whatsapp_body'] ?? '',
			'is_default'    => true,
		];
	}

	/**
	 * Default color palette for WooCommerce core statuses.
	 *
	 * @param string $slug Status slug.
	 *
	 * @return string
	 */
	public static function default_wc_status_color( $slug ) {
		$colors = [
			'wc-pending'    => '#d97706',
			'wc-processing' => '#2563eb',
			'wc-on-hold'    => '#ea580c',
			'wc-completed'  => '#16a34a',
			'wc-cancelled'  => '#dc2626',
			'wc-refunded'   => '#6b7280',
			'wc-failed'     => '#dc2626',
		];

		return $colors[ $slug ] ?? '#6b7280';
	}

	/**
	 * Get Product id and value array
	 *
	 * @param array $post_ids .
	 * @param string $post_type .
	 *
	 * @return array
	 */
	public static function get_product_id_titles( $post_ids, $post_type = 'post' ) {
		$post_titles = [];

		if ( ! empty( $post_ids ) ) {
			foreach ( $post_ids as $post_id ) {
				$post = get_post( $post_id );
				if ( $post && $post->post_type === $post_type ) {
					$post_titles[ $post_id ] = $post->post_title;
				}
			}
		}

		return $post_titles;
	}

	/**
	 * Get term and name array
	 *
	 * @param array $term_ids .
	 * @param string $taxonomy .
	 *
	 * @return array
	 */
	public static function get_term_names( $term_ids, $taxonomy = 'category' ) {
		$term_names = [];

		if ( ! empty( $term_ids ) ) {
			foreach ( $term_ids as $term_id ) {
				$term = get_term( $term_id, $taxonomy );
				if ( $term && ! is_wp_error( $term ) ) {
					$term_names[ $term_id ] = $term->name;
				}
			}
		}

		return $term_names;
	}

	public static function get_setting( $name, $default = '' ) {
		$settings = get_option( TLPFoodMenu()->options['settings'], [] );

		if ( ! is_array( $settings ) ) {
			return $default;
		}

		return array_key_exists( $name, $settings ) ? $settings[ $name ] : $default;
	}

	/**
	 * How many days the dashboard reports cover when no date range has been picked.
	 *
	 * Settings → Front-End Dashboard → Report. Clamped to 1–730: the settings form
	 * stores a cleared number field as `''`, and `(int) ''` is `0`, which would ask
	 * every report for a zero-day window and return an empty page.
	 *
	 * @return int
	 */
	public static function reports_default_days(): int {
		$days = (int) self::get_setting( 'fmp_reports_default_days', 30 );

		if ( $days < 1 ) {
			$days = 30;
		}

		return min( $days, 730 );
	}

	/**
	 * JS Default index for day. Delegates to free Fns.
	 *
	 * @return int[]
	 */
	public static function day_map_index() {
		return method_exists( Fns::class, 'day_map_index' )
			? Fns::day_map_index()
			: [];
	}

	/**
	 * Off-day list for a schedule. Delegates to free Fns.
	 *
	 * @param array $schedule .
	 *
	 * @return array
	 */
	public static function get_offday_schedule( $schedule ) {
		return method_exists( Fns::class, 'get_offday_schedule' )
			? Fns::get_offday_schedule( $schedule )
			: [];
	}

	/**
	 * Per-day schedule boundary times. Delegates to free Fns.
	 *
	 * @param array  $schedule .
	 * @param string $boundary .
	 *
	 * @return array
	 */
	public static function get_schedule_time( $schedule, $boundary = 'start' ) {
		return method_exists( Fns::class, 'get_schedule_time' )
			? Fns::get_schedule_time( $schedule, $boundary )
			: [];
	}

	/**
	 * Per-day slot arrays. Delegates to free Fns.
	 *
	 * @param array $schedule .
	 *
	 * @return array
	 */
	public static function get_schedule_slots( $schedule ) {
		return method_exists( Fns::class, 'get_schedule_slots' )
			? Fns::get_schedule_slots( $schedule )
			: [];
	}

	/**
	 * Whether reservation is enabled. Delegates to free Fns.
	 *
	 * @return boolean
	 */
	public static function enable_reservation() {
		if ( method_exists( Fns::class, 'enable_reservation' ) ) {
			return Fns::enable_reservation();
		}

		// Fallback for older free plugin versions without the helper.
		$settings = self::get_settings_option();
		$settings = is_array( $settings ) ? $settings : [];

		return 'on' === ( $settings['fmp_food_reservation_status'] ?? '' );
	}

	/**
	 * Reservation status list. Delegates to free Fns.
	 *
	 * @return array
	 */
	public static function get_reservation_status() {
		return method_exists( Fns::class, 'get_reservation_status' )
			? Fns::get_reservation_status()
			: [];
	}

	/**
	 * Guest limit list. Delegates to free Fns.
	 *
	 * @return array
	 */
	public static function get_guest_limit() {
		return method_exists( Fns::class, 'get_guest_limit' )
			? Fns::get_guest_limit()
			: [];
	}

	/**
	 * Booking invoice ID generator. Delegates to free Fns.
	 *
	 * @param int $postId .
	 *
	 * @return string
	 */
	public static function generate_invoice_number( $postId ) {
		return method_exists( Fns::class, 'generate_invoice_number' )
			? Fns::generate_invoice_number( $postId )
			: '';
	}

	/**
	 * Reservation email sender. Delegates to free Fns.
	 *
	 * @param array $args .
	 *
	 * @return bool|mixed
	 */
	public static function send_email( $args ) {
		return method_exists( Fns::class, 'send_email' )
			? Fns::send_email( $args )
			: false;
	}

	/**
	 * Reservation fields list. Delegates to free Fns.
	 *
	 * @return string[]
	 */
	public static function reservation_fields_array() {
		return method_exists( Fns::class, 'reservation_fields_array' )
			? Fns::reservation_fields_array()
			: [];
	}

	/**
	 * Admin/user notification dispatcher. Delegates to free Fns.
	 *
	 * @param array $settings .
	 * @param array $args .
	 *
	 * @return void
	 */
	public static function send_email_notify_admin_user( $settings, $args ) {
		if ( method_exists( Fns::class, 'send_email_notify_admin_user' ) ) {
			Fns::send_email_notify_admin_user( $settings, $args );
		}
	}

	/**
	 * Status-change email dispatcher. Delegates to free Fns.
	 *
	 * @param array  $mail_args .
	 * @param string $resi_email .
	 * @param string $invoice_no .
	 * @param string $resi_status .
	 *
	 * @return void
	 */
	public static function send_email_notify( $mail_args, $resi_email, $invoice_no, $resi_status ) {
		if ( method_exists( Fns::class, 'send_email_notify' ) ) {
			Fns::send_email_notify( $mail_args, $resi_email, $invoice_no, $resi_status );
		}
	}

	/**
	 * Reservation email body markup. Delegates to free Fns.
	 *
	 * @param array  $args .
	 * @param string $context .generate_invoice_number
	 *
	 * @return string
	 */
	public static function mail_body_markup( $args, $context = 'client' ) {
		return method_exists( Fns::class, 'mail_body_markup' )
			? Fns::mail_body_markup( $args, $context )
			: '';
	}

	/**
	 * Input field validation for visual table
	 *
	 * @param array $request .
	 * @param array $input_fields .
	 *
	 * @return array
	 */
	public static function input_field_validation( $request, $input_fields ) {
		if ( ! empty( $input_fields ) ) {
			$error_fields = [];

			foreach ( $input_fields as $field ) {
				$name = $field['name'];
				if ( $field['required'] && empty( $request[ $name ] ) ) {
					$error_fields[] = esc_html( ucfirst( str_replace( '_', ' ', $name ) ) . ' is empty' );
				}
			}

			if ( ! empty( $error_fields ) ) {
				$response = [
					'status_code' => 0,
					'messages'    => $error_fields,
				];
			} else {
				$input_data = [];

				foreach ( $input_fields as $field ) {
					$name                = $field['name'];
					$data                = sanitize_text_field( $request[ $name ] );
					$input_data[ $name ] = $data;
				}

				$response = [
					'status_code' => 1,
					'messages'    => [],
					'data'        => $input_data,
				];
			}
		} else {
			$response = [
				'status_code' => 0,
				'messages'    => [
					'empty_input' => esc_html__( 'Input field is empty', 'food-menu-pro' ),
				],
			];
		}

		return $response;
	}

	/**
	 * Get the reservation-system time format.
	 *
	 * Reservations don't follow WordPress's general "time_format" option because admins
	 * can set arbitrary tokens there (e.g. `G\hi` → "12h30") which break time parsing
	 * and comparison. This always returns one of two safe PHP date tokens:
	 *
	 *  - "h:i A" (12-hour, e.g. "12:30 PM")
	 *  - "H:i"   (24-hour, e.g. "12:30")
	 *
	 * Resolution order:
	 *   1. Explicit plugin setting `fmp_resi_time_format` ('12' or '24'), if saved.
	 *   2. Inferred from the WP `time_format` option — if it contains a non-escaped
	 *      `G` or `H` token (24-hour PHP date format characters), treat as 24h.
	 *   3. 12-hour fallback.
	 *
	 * @return string
	 */
	public static function get_resi_time_format() {
		$settings = self::get_settings_option();

		if ( isset( $settings['fmp_resi_time_format'] ) ) {
			$choice = (string) $settings['fmp_resi_time_format'];
			if ( '24' === $choice ) {
				return 'H:i';
			}
			if ( '12' === $choice ) {
				return 'h:i A';
			}
		}

		// No plugin setting saved yet — infer from WP global so existing sites Just Work.
		// Match `G` or `H` (24-hour tokens) only when NOT escaped by a backslash.
		$wp_format = (string) get_option( 'time_format', 'h:i A' );
		$is_24h    = (bool) preg_match( '/(?<!\\\\)[GH]/', $wp_format );

		return $is_24h ? 'H:i' : 'h:i A';
	}

	/**
	 * Format a "seconds since midnight" value into a time string.
	 *
	 * Inverse of self::parse_time_to_seconds(). Useful for normalizing stored
	 * reservation times into the current canonical 12h / 24h representation.
	 *
	 * @param int    $seconds 0-86399. Clamped to a valid range.
	 * @param string $format  PHP date() format. Defaults to the resi-format helper.
	 *
	 * @return string Formatted time string (e.g. "13:30" or "01:30 PM").
	 */
	public static function format_time_from_seconds( $seconds, $format = null ) {
		if ( null === $format ) {
			$format = self::get_resi_time_format();
		}
		$seconds = max( 0, min( 86399, (int) $seconds ) );
		$h       = (int) floor( $seconds / 3600 );
		$m       = (int) floor( ( $seconds % 3600 ) / 60 );

		// gmdate ignores server timezone, so X seconds since the unix epoch maps to the
		// same wall-clock time-of-day every run.
		return gmdate( $format, ( $h * 3600 ) + ( $m * 60 ) );
	}

	/**
	 * Whether a stored reservation time string already matches the current canonical
	 * format (so it doesn't need rewriting during migration).
	 *
	 * @param string $value  The stored meta value, e.g. "12h30" or "1:30 PM" or "13:30".
	 * @param string $format The target canonical PHP format ("H:i" or "h:i A").
	 *
	 * @return bool
	 */
	public static function is_canonical_resi_time( $value, $format ) {
		if ( ! is_string( $value ) || '' === $value ) {
			return false;
		}
		if ( 'H:i' === $format ) {
			// 00:00 – 23:59
			return (bool) preg_match( '/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $value );
		}
		if ( 'h:i A' === $format ) {
			// 01:00 AM – 12:59 PM, leading zero on hours
			return (bool) preg_match( '/^(0[1-9]|1[0-2]):[0-5][0-9] (AM|PM)$/', $value );
		}
		return false;
	}

	/**
	 * One-time migration: rewrite every existing reservation's start/end time meta
	 * to the current canonical format (H:i or h:i A) so the admin UI and stored
	 * values stay consistent after switching away from a WP custom time format
	 * like `G\hi`.
	 *
	 * Safe to call repeatedly — guarded by an option flag, skips already-canonical
	 * values, and only rewrites strings that contain at least one digit (so unparseable
	 * legacy data is left alone rather than zeroed out).
	 *
	 * @return void
	 */
	public static function migrate_resi_time_formats() {
		$flag_key        = 'fmp_resi_time_format_migration';
		$current_version = 1;

		$existing = get_option( $flag_key );
		if ( is_array( $existing ) && isset( $existing['version'] ) && (int) $existing['version'] >= $current_version ) {
			return;
		}

		$target_format = self::get_resi_time_format();
		$reservations  = get_posts( [
			'post_type'   => 'fmp_reservation',
			'numberposts' => -1,
			'post_status' => 'any',
			'fields'      => 'ids',
		] );

		$updated = 0;
		$skipped = 0;

		foreach ( $reservations as $post_id ) {
			foreach ( [ 'fmp_resi_meta_start_time', 'fmp_resi_meta_end_time' ] as $meta_key ) {
				$raw = get_post_meta( $post_id, $meta_key, true );

				if ( ! is_string( $raw ) || '' === $raw ) {
					continue;
				}
				if ( self::is_canonical_resi_time( $raw, $target_format ) ) {
					continue;
				}
				// Bail on values that contain no digits at all — nothing we can safely parse.
				if ( ! preg_match( '/\d/', $raw ) ) {
					$skipped++;
					continue;
				}

				$seconds = self::parse_time_to_seconds( $raw );
				$new     = self::format_time_from_seconds( $seconds, $target_format );

				if ( $new && $new !== $raw ) {
					update_post_meta( $post_id, $meta_key, $new );
					$updated++;
				}
			}
		}

		update_option( $flag_key, [
			'version'       => $current_version,
			'completed_at'  => current_time( 'mysql' ),
			'updated'       => $updated,
			'skipped'       => $skipped,
			'target_format' => $target_format,
			'reservations'  => count( $reservations ),
		] );
	}

	/**
	 * Parse time-string to seconds since midnight. Delegates to free Fns.
	 *
	 * @param string $time_str .
	 *
	 * @return int
	 */
	public static function parse_time_to_seconds( $time_str ) {
		return method_exists( Fns::class, 'parse_time_to_seconds' )
			? Fns::parse_time_to_seconds( $time_str )
			: 0;
	}

	/**
	 * Visual-table booking data for a slot. Delegates to free Fns.
	 *
	 * @param string $selected_date .
	 * @param string $start_time .
	 * @param string $end_time .
	 *
	 * @return array
	 */
	public static function get_booking_data( $selected_date = '', $start_time = '', $end_time = '' ) {
		return method_exists( Fns::class, 'get_booking_data' )
			? Fns::get_booking_data( $selected_date, $start_time, $end_time )
			: [];
	}

	/**
	 * Get booked seats info
	 *
	 * @param number $post_id .
	 *
	 * @return array
	 */
	public static function get_booked_seats_info( $post_id = 0 ) {
		$booked_seats_info = [];
		$booked_ids        = get_post_meta( $post_id, 'fmp_resi_meta_booked_ids', true ); //store all chair ids
		$booked_ids        = maybe_unserialize( $booked_ids );

		// Check if booked_ids empty then return.
		if ( empty( $booked_ids ) && ! is_array( $booked_ids ) ) {
			return $booked_seats_info;
		}

		$obj_names        = get_post_meta( $post_id, 'fmp_resi_meta_obj_names', true ); //total object of the canvas
		$intersected_data = get_post_meta( $post_id, 'fmp_resi_meta_intersected_data', true ); //all chairs under the table

		if ( empty( $obj_names ) ) {
			return $booked_seats_info;
		}

		$obj_names        = json_decode( $obj_names, true );
		$intersected_data = json_decode( $intersected_data, true );

		return self::process_booked_seats_info( $booked_ids, $obj_names, $intersected_data );
	}

	/**
	 * Booked seats info
	 *
	 * @param array $booked_ids .
	 * @param array $obj_names .
	 * @param array $intersected_data .
	 *
	 * @return array
	 */
	private static function process_booked_seats_info( $booked_ids, $obj_names, $intersected_data ) {
		$table_chairs      = [];
		$table_chair_names = [];

		foreach ( $intersected_data as $table_id => $chair_arr ) {
			$table_chairs[ $table_id ] = [];

			// Check if all chairs under a table are booked.
			if ( empty( array_diff( $chair_arr, $booked_ids ) ) ) {
				$booked_ids = array_diff( $booked_ids, $chair_arr );
				//$table_chair_names[] = $obj_names[ $table_id ] . ' / ' . esc_html__( 'All chairs', 'food-menu-pro' ) . ' (' . count( $chair_arr ) . ')';

				$table_chair_names[] = sprintf(
					"<span class='table-name'>%s</span> : <span class='chair-name all-chair-book'>%s</span>",
					esc_html( $obj_names[ $table_id ] ),
					esc_html__( 'All chairs booked', 'food-menu-pro' ) . ' (' . count( $chair_arr ) . ')'
				);
			} else {
				foreach ( $booked_ids as $index => $booked_id ) {
					// Check if the booked chair belongs to the current table.
					if ( in_array( $booked_id, $chair_arr ) ) {
						$table_chairs[ $table_id ][] = $obj_names[ $booked_id ];
						unset( $booked_ids[ $index ] );
					}
				}
			}
		}

		// Format booked chairs for each table.
		foreach ( $table_chairs as $t_id => $t_chairs ) {
			if ( ! empty( $t_chairs ) ) {
				//$table_chair_names[] = $obj_names[ $t_id ] . ' / ' . join( ', ', $t_chairs );

				$table_chair_names[] = sprintf(
					"<span class='table-name'>%s</span> : %s",
					esc_html( $obj_names[ $t_id ] ),
					implode( '<span class="separate">, </span>', array_map( function ( $chair ) {
						return '<span class="chair-name">' . esc_html( $chair ) . '</span>';
					}, $t_chairs ) )
				);
			}
		}

		// Format individually booked chairs.
		foreach ( $booked_ids as $booked_id ) {
			$table_chair_names[] = $obj_names[ $booked_id ];
		}

		return $table_chair_names;
	}

	/**
	 * Get reservation message. Delegates to free Fns.
	 *
	 * @param array  $settings .
	 * @param string $type .
	 * @param string $booking_id .
	 *
	 * @return string
	 */
	public static function get_reservation_message( $settings, $type, $booking_id = '' ) {
		return method_exists( Fns::class, 'get_reservation_message' )
			? Fns::get_reservation_message( $settings, $type, $booking_id )
			: '';
	}

	/**
	 * Get reservation list.
	 *
	 * @return int[]|\WP_Post[]
	 */
	public static function get_reservation_list() {
		return get_posts(
			[
				'post_type'   => 'fmp_reservation',
				'numberposts' => - 1,
				'post_status' => 'publish',
			]
		);
	}

	/**
	 * Clear any cache plugins
	 */
	public static function site_cache_clear() {
		wp_cache_flush();

		$cleared_cache = false;

		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
			$cleared_cache = true;
		}

		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
			$cleared_cache = true;
		}

		if ( function_exists( 'opcache_reset' ) && ! ini_get( 'opcache.restrict_api' ) ) {
			@opcache_reset();
			$cleared_cache = true;
		}

		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
			$cleared_cache = true;
		}

		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
			$cleared_cache = true;
		}

		global $wp_fastest_cache;
		if ( method_exists( 'WpFastestCache', 'deleteCache' ) && ! empty( $wp_fastest_cache ) ) {
			$wp_fastest_cache->deleteCache();
			$cleared_cache = true;
		}

		// If your host has installed APC cache this plugin allows you to clear the cache from within WordPress
		if ( function_exists( 'apc_clear_cache' ) ) {
			apc_clear_cache();
			$cleared_cache = true;
		}

		if ( function_exists( 'fvm_purge_all' ) ) {
			fvm_purge_all();
			$cleared_cache = true;
		}

		if ( class_exists( 'autoptimizeCache' ) ) {
			autoptimizeCache::clearall();
			$cleared_cache = true;
		}

		// WPEngine
		if ( class_exists( 'WpeCommon' ) ) {
			if ( method_exists( 'WpeCommon', 'purge_memcached' ) ) {
				WpeCommon::purge_memcached();
			}
			if ( method_exists( 'WpeCommon', 'clear_maxcdn_cache' ) ) {
				WpeCommon::clear_maxcdn_cache();
			}
			if ( method_exists( 'WpeCommon', 'purge_varnish_cache' ) ) {
				WpeCommon::purge_varnish_cache();
			}

			$cleared_cache = true;
		}

		if ( class_exists( 'Cache_Enabler_Disk' ) && method_exists( 'Cache_Enabler_Disk', 'clear_cache' ) ) {
			Cache_Enabler_Disk::clear_cache();
			$cleared_cache = true;
		}

		// Perfmatters
		if ( class_exists( 'Perfmatters\CSS' ) && method_exists( 'Perfmatters\CSS', 'clear_used_css' ) ) {
			Perfmatters\CSS::clear_used_css();
			$cleared_cache = true;
		}

		if ( defined( 'BREEZE_VERSION' ) ) {
			do_action( 'breeze_clear_all_cache' );
			$cleared_cache = true;
		}

		if ( function_exists( 'sg_cachepress_purge_everything' ) ) {
			sg_cachepress_purge_everything();
			$cleared_cache = true;
		}

		if ( defined( 'FLYING_PRESS_VERSION' ) ) {
			do_action( 'flying_press_purge_everything:before' );

			wp_delete_file( FLYING_PRESS_CACHE_DIR . '/preload.txt' );

			// Delete all files and subdirectories.
			FlyingPress\Purge::purge_everything();

			//phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_mkdir
			@mkdir( FLYING_PRESS_CACHE_DIR, 0755, true );

			do_action( 'flying_press_purge_everything:after' );

			$cleared_cache = true;
		}

		if ( class_exists( '\LiteSpeed\Purge' ) ) {
			\LiteSpeed\Purge::purge_all();
			$cleared_cache = true;
		}

		return $cleared_cache;
	}

	/**
	 * Tip Information generate
	 *
	 * @param $order
	 *
	 * @return array
	 */
	public static function tip_information( $order ) {
		$order_amout           = $order->get_total();
		$fmp_tip_type          = $order->get_meta( 'fmp_tip_type' );
		$fmp_percentage_amount = $order->get_meta( 'fmp_percentage_amount' );
		$fmp_fixed_amount      = $order->get_meta( 'fmp_fixed_amount' );

		if ( 'fixed' === $fmp_tip_type ) {
			$tip_prefix = esc_html__( 'Fixed', 'food-menu-pro' );
			$tip_amount = $fmp_fixed_amount;
		} else {
			$tip_prefix = sprintf( esc_html__( '%s of %s', 'food-menu-pro' ),
				esc_html( $fmp_percentage_amount ) . '%',
				esc_html( $order_amout ),
			);
			$amount     = ( strpos( $fmp_percentage_amount, '.' ) !== false ) ? (float) $fmp_percentage_amount : (int) $fmp_percentage_amount;

			$tip_amount = $order_amout / 100 * $amount;
		}

		return [
			'prefix' => $tip_prefix,
			'amount' => $tip_amount,
		];
	}

	public static function has_order_manage_capability() {
		if ( current_user_can( 'administrator' ) ) {
			return true;
		}

		$user_id     = get_current_user_id();
		$settings    = get_option( TLPFoodMenu()->options['settings'], [] );
		$permissions = isset( $settings['fmp_dashboard_permissions'] ) && is_array( $settings['fmp_dashboard_permissions'] )
			? $settings['fmp_dashboard_permissions']
			: [];

		foreach ( $permissions as $entry ) {
			if ( ! empty( $entry['user_id'] ) && (int) $entry['user_id'] === $user_id && ! empty( $entry['menus'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the current user has at least one of these dashboard menus.
	 * The UI hides menus; this is what actually enforces them on the REST routes.
	 *
	 * @param string[] $menus Menu keys (see DASHBOARD_MENUS).
	 * @return bool
	 */
	public static function can_use_dashboard_menu( array $menus ) {
		if ( current_user_can( 'administrator' ) ) {
			return true;
		}

		return (bool) array_intersect( $menus, self::get_allowed_dashboard_menus() );
	}

	/**
	 * permission_callback for a REST route gated by dashboard menus.
	 *
	 * @param string[] $menus Menu keys — any one of them grants access.
	 * @return callable
	 */
	public static function menu_permission( array $menus ) {
		return static function () use ( $menus ) {
			return self::can_use_dashboard_menu( $menus );
		};
	}

	/**
	 * Build the capability name for a dashboard menu key.
	 *
	 * e.g. 'inv-add' → 'fmp_menu_inv_add', 'kitchen-monitor' → 'fmp_menu_kitchen_monitor'.
	 *
	 * @param string $menu_key Menu key.
	 *
	 * @return string
	 */
	public static function menu_capability( $menu_key ) {
		return 'fmp_menu_' . str_replace( '-', '_', $menu_key );
	}

	/**
	 * Get allowed dashboard menus for the current user.
	 *
	 * Menu access is now a real WP capability (`fmp_menu_*`) stored on each role,
	 * so this just filters DASHBOARD_MENUS by current_user_can().
	 *
	 * @return array
	 */
	public static function get_allowed_dashboard_menus() {
		$all_menus = self::DASHBOARD_MENUS;

		if ( current_user_can( 'administrator' ) ) {
			return $all_menus;
		}

		$user_id     = get_current_user_id();
		$settings    = get_option( TLPFoodMenu()->options['settings'], [] );
		$permissions = isset( $settings['fmp_dashboard_permissions'] ) && is_array( $settings['fmp_dashboard_permissions'] )
			? $settings['fmp_dashboard_permissions']
			: [];

		foreach ( $permissions as $entry ) {
			if ( ! empty( $entry['user_id'] ) && (int) $entry['user_id'] === $user_id ) {
				$selected = ( ! empty( $entry['menus'] ) && is_array( $entry['menus'] ) ) ? $entry['menus'] : [];

				return array_values( array_intersect( $all_menus, $selected ) );
			}
		}

		return [];
	}

	/**
	 * Read the saved dashboard permissions array.
	 *
	 * @return array
	 */
	public static function get_dashboard_permissions() {
		$settings = get_option( TLPFoodMenu()->options['settings'], [] );
		$perms    = $settings['fmp_dashboard_permissions'] ?? [];

		return is_array( $perms ) ? $perms : [];
	}

	/**
	 * Find the permission entry for a given user.
	 *
	 * @param int $user_id User ID. Defaults to current user.
	 *
	 * @return array|null
	 */
	private static function get_user_permission_entry( $user_id = 0 ) {
		$user_id = $user_id ?: get_current_user_id();

		if ( ! $user_id ) {
			return null;
		}

		foreach ( self::get_dashboard_permissions() as $entry ) {
			if ( (int) ( $entry['user_id'] ?? 0 ) === $user_id ) {
				return $entry;
			}
		}

		return null;
	}

	/**
	 * Whether the current (or given) user may see and modify orders from every location.
	 *
	 * Administrators are always treated as managers of all locations.
	 *
	 * @param int $user_id User ID. Defaults to current user.
	 *
	 * @return bool
	 */
	public static function user_can_manage_all_locations( $user_id = 0 ) {
		$user_id = $user_id ?: get_current_user_id();

		if ( ! $user_id ) {
			return false;
		}

		if ( user_can( $user_id, 'administrator' ) ) {
			return true;
		}

		$entry = self::get_user_permission_entry( $user_id );

		$raw = $entry['all_locations'] ?? false;

		// FormData turns boolean `false` into the literal string "false"; treat
		// that (and "0", "") as off. Anything else truthy → manage all.
		return filter_var( $raw, FILTER_VALIDATE_BOOLEAN );
	}

	/**
	 * Get the location term IDs a user is allowed to act on.
	 *
	 * Return values:
	 *  - null  : unrestricted (admins / users with `all_locations` enabled)
	 *  - []    : no access (no permission entry, or entry has no locations)
	 *  - [..]  : explicit allow-list of term IDs
	 *
	 * @param int $user_id User ID. Defaults to current user.
	 *
	 * @return array|null
	 */
	public static function get_user_allowed_locations( $user_id = 0 ) {
		if ( self::user_can_manage_all_locations( $user_id ) ) {
			return null;
		}

		$entry = self::get_user_permission_entry( $user_id );

		if ( ! $entry ) {
			return [];
		}

		$ids = isset( $entry['locations'] ) && is_array( $entry['locations'] )
			? array_values( array_unique( array_map( 'intval', $entry['locations'] ) ) )
			: [];

		return array_filter( $ids );
	}

	/**
	 * Expand a location term ID into itself + all descendant term IDs.
	 *
	 * Used so that picking a parent ("Downtown") matches orders assigned to
	 * any of its child branches.
	 *
	 * @param int $term_id Location term ID.
	 *
	 * @return array
	 */
	public static function expand_location_with_descendants( $term_id ) {
		$term_id = (int) $term_id;
		if ( ! $term_id ) {
			return [];
		}

		$children = get_term_children( $term_id, 'tpl-food-location' );
		$ids      = [ $term_id ];

		if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
			$ids = array_merge( $ids, array_map( 'intval', $children ) );
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Resolve a requested location_id against the user's allow-list.
	 *
	 * @param int        $requested Requested location term ID (0 = no specific selection).
	 * @param array|null $allowed   Allow-list from get_user_allowed_locations().
	 *
	 * @return array|null|false
	 *   - array  : meta_query-ready list of term IDs to match (parent + descendants)
	 *   - null   : "no filter" — show everything the user can see
	 *   - false  : request is forbidden (user tried a location they don't own)
	 */
	public static function resolve_location_filter( $requested, $allowed ) {
		$requested = (int) $requested;

		if ( $requested > 0 ) {
			$expanded = self::expand_location_with_descendants( $requested );

			if ( is_array( $allowed ) ) {
				$intersect = array_values( array_intersect( $expanded, $allowed ) );
				if ( empty( $intersect ) ) {
					return false;
				}
				return $intersect;
			}

			return $expanded;
		}

		// No specific selection — clamp to the user's allow-list if scoped.
		if ( is_array( $allowed ) ) {
			if ( empty( $allowed ) ) {
				return false;
			}

			$expanded_all = [];
			foreach ( $allowed as $tid ) {
				$expanded_all = array_merge( $expanded_all, self::expand_location_with_descendants( $tid ) );
			}
			return array_values( array_unique( $expanded_all ) );
		}

		return null;
	}

	/**
	 * Build a WC meta_query clause that matches orders assigned to one of
	 * the given location term IDs.
	 *
	 * Covers two storage shapes:
	 *  - new orders: `fmp_location_id` meta with a numeric term ID
	 *  - legacy orders: only `fmp_location_name` meta (string), matched against term names
	 *
	 * @param array $term_ids Location term IDs.
	 *
	 * @return array meta_query sub-array suitable for nesting into wc_get_orders args.
	 */
	public static function build_location_meta_query( array $term_ids ) {
		$term_ids = array_values( array_unique( array_map( 'intval', $term_ids ) ) );
		$term_ids = array_filter( $term_ids );

		if ( empty( $term_ids ) ) {
			return [];
		}

		$names = [];
		foreach ( $term_ids as $tid ) {
			$term = get_term( $tid, 'tpl-food-location' );
			if ( $term && ! is_wp_error( $term ) ) {
				$names[] = $term->name;
			}
		}

		$clauses = [
			'relation' => 'OR',
			[
				'key'     => 'fmp_location_id',
				'value'   => $term_ids,
				'compare' => 'IN',
			],
		];

		if ( ! empty( $names ) ) {
			$clauses[] = [
				'key'     => 'fmp_location_name',
				'value'   => $names,
				'compare' => 'IN',
			];
		}

		return $clauses;
	}

	/**
	 * Whether the legacy `meta_query` bridge filter has been registered.
	 *
	 * @var bool
	 */
	private static $legacy_order_meta_query_hooked = false;

	/**
	 * Make `wc_get_orders()` args safe on both HPOS and legacy (post) order storage.
	 *
	 * `meta_query` is an HPOS-only query arg. On legacy storage WooCommerce logs a
	 * `wc_doing_it_wrong()` notice (since 9.2) *and* silently drops the clause in
	 * `WC_Data_Store_WP::get_wp_query_args()` — so every meta filter (location clamp,
	 * `_fmp_is_new`, slot date/time/type) matched nothing and returned unfiltered orders.
	 *
	 * Here the clause is moved to a private query var and re-attached to the WP_Query
	 * args through `woocommerce_order_data_store_cpt_get_orders_query`, which is the
	 * supported way to filter legacy order queries by meta.
	 *
	 * Always wrap order args with this before calling `wc_get_orders()`.
	 *
	 * @param array $args wc_get_orders() args.
	 *
	 * @return array Args safe for the active order datastore.
	 */
	public static function order_query_args( array $args ) {
		if ( empty( $args['meta_query'] ) ) {
			return $args;
		}

		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			return $args;
		}

		if ( ! self::$legacy_order_meta_query_hooked ) {
			self::$legacy_order_meta_query_hooked = true;
			add_filter( 'woocommerce_order_data_store_cpt_get_orders_query', [ __CLASS__, 'apply_legacy_order_meta_query' ], 10, 2 );
		}

		$args['fmp_meta_query'] = $args['meta_query'];
		unset( $args['meta_query'] );

		return $args;
	}

	/**
	 * Re-attach a meta_query moved aside by order_query_args() on legacy order storage.
	 *
	 * @param array $wp_query_args WP_Query args built by the CPT datastore.
	 * @param array $query_vars    Original wc_get_orders() query vars.
	 *
	 * @return array
	 */
	public static function apply_legacy_order_meta_query( $wp_query_args, $query_vars ) {
		unset( $wp_query_args['fmp_meta_query'] );

		if ( empty( $query_vars['fmp_meta_query'] ) ) {
			return $wp_query_args;
		}

		$existing = ! empty( $wp_query_args['meta_query'] ) ? $wp_query_args['meta_query'] : [];

		// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		$wp_query_args['meta_query'] = $existing
			? [ 'relation' => 'AND', $existing, $query_vars['fmp_meta_query'] ]
			: $query_vars['fmp_meta_query'];

		return $wp_query_args;
	}

	/**
	 * Build an `AND <ref> IN (sub)` SQL fragment that clamps a raw query to
	 * orders matching the given location term IDs.
	 *
	 * Mirrors `build_location_meta_query()` but at the SQL level so the
	 * Kitchen Monitor stats raw-SQL can be clamped without loading order
	 * objects into PHP.
	 *
	 * @param string $order_id_ref SQL ref to the orders-table order ID (e.g.
	 *                             "{$wpdb->prefix}wc_orders.id" or "{$wpdb->posts}.ID").
	 * @param array  $term_ids     Allowed location term IDs.
	 * @param bool   $is_hpos      Whether HPOS is in use.
	 *
	 * @return string SQL fragment (with leading space), or empty string when
	 *                no clamp applies.
	 */
	public static function build_location_sql_fragment( $order_id_ref, array $term_ids, $is_hpos ) {
		global $wpdb;

		$term_ids = array_values( array_unique( array_map( 'intval', $term_ids ) ) );
		$term_ids = array_filter( $term_ids );

		if ( empty( $term_ids ) ) {
			return '';
		}

		$names = [];
		foreach ( $term_ids as $tid ) {
			$term = get_term( $tid, 'tpl-food-location' );
			if ( $term && ! is_wp_error( $term ) ) {
				$names[] = $term->name;
			}
		}

		$meta_table  = $is_hpos ? $wpdb->prefix . 'wc_orders_meta' : $wpdb->postmeta;
		$id_col      = $is_hpos ? 'order_id' : 'post_id';

		$id_list_sql = implode( ',', array_map( 'intval', $term_ids ) );

		$name_clause_sql = '';
		if ( ! empty( $names ) ) {
			$escaped = array_map( static function ( $n ) use ( $wpdb ) {
				return "'" . esc_sql( $n ) . "'";
			}, $names );
			$name_list = implode( ',', $escaped );
			$name_clause_sql = " UNION SELECT {$id_col} FROM {$meta_table} WHERE meta_key = 'fmp_location_name' AND meta_value IN ({$name_list})";
		}

		return " AND {$order_id_ref} IN ( SELECT {$id_col} FROM {$meta_table} WHERE meta_key = 'fmp_location_id' AND meta_value IN ({$id_list_sql}){$name_clause_sql} )";
	}

	/**
	 * Whether the given order is within the user's allowed locations.
	 *
	 * Returns true when the user is unrestricted, or when the order's
	 * location matches one of the user's allowed branches (including
	 * descendants). Orders with no location meta are accessible to everyone
	 * unrestricted — but only when the user is unrestricted.
	 *
	 * @param \WC_Order  $order   Order.
	 * @param array|null $allowed Allow-list from get_user_allowed_locations().
	 *
	 * @return bool
	 */
	public static function order_matches_allowed_locations( $order, $allowed ) {
		if ( $allowed === null ) {
			return true;
		}

		if ( empty( $allowed ) ) {
			return false;
		}

		$expanded = [];
		foreach ( $allowed as $tid ) {
			$expanded = array_merge( $expanded, self::expand_location_with_descendants( $tid ) );
		}
		$expanded = array_values( array_unique( $expanded ) );

		$order_loc_id = (int) $order->get_meta( 'fmp_location_id' );
		if ( $order_loc_id && in_array( $order_loc_id, $expanded, true ) ) {
			return true;
		}

		$order_loc_name = (string) $order->get_meta( 'fmp_location_name' );
		if ( $order_loc_name !== '' ) {
			foreach ( $expanded as $tid ) {
				$term = get_term( $tid, 'tpl-food-location' );
				if ( $term && ! is_wp_error( $term ) && $term->name === $order_loc_name ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Generate a role slug from a role label.
	 *
	 * @param string $label Role label.
	 *
	 * @return string
	 */
	public static function dashboard_role_slug( $label ) {
		$slug = sanitize_title( $label );
		$slug = str_replace( '-', '_', $slug );

		// Add prefix if not already a built-in WP/WC role.
		$builtin = [ 'administrator', 'editor', 'author', 'contributor', 'subscriber', 'shop_manager', 'customer' ];
		if ( ! in_array( $slug, $builtin, true ) && strpos( $slug, 'fmp_' ) !== 0 ) {
			$slug = 'fmp_' . $slug;
		}

		return $slug;
	}

	/**
	 * Sync dashboard roles in WordPress when settings are saved.
	 *
	 * @param mixed $old_value Old option value.
	 * @param mixed $new_value New option value.
	 */
	public static function sync_dashboard_roles( $old_value, $new_value ) {
		// Clean up any legacy fmp_ custom roles from the old role-based system.
		$old_permissions = ( is_array( $old_value ) && isset( $old_value['fmp_dashboard_permissions'] ) )
			? $old_value['fmp_dashboard_permissions']
			: [];

		if ( is_array( $old_permissions ) ) {
			foreach ( $old_permissions as $entry ) {
				if ( ! empty( $entry['role'] ) ) {
					$slug = self::dashboard_role_slug( $entry['role'] );
					if ( strpos( $slug, 'fmp_' ) === 0 && get_role( $slug ) ) {
						remove_role( $slug );
					}
				}
			}
		}

		// Permissions are now user-based and read directly from settings
		// in get_allowed_dashboard_menus() and has_order_manage_capability().
		// No WordPress roles need to be created.
	}

	public static function get_frontend_order_page() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return $settings['fmp_frontend_order_page'] ?? '';
	}

	public static function order_header_footer_visibility() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return $settings['fmp_frontend_order_header_footer'] ?? '';
	}

	public static function has_kitchen_monitor_capability() {
		$settings             = get_option( TLPFoodMenu()->options['settings'] );
		$kitchen_monitor_role = $settings['fmp_kitchen_monitor_role'] ?? 'administrator';

		return ( current_user_can( $kitchen_monitor_role ) || current_user_can( 'administrator' ) );
	}

	public static function get_kitchen_monitor_page() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return $settings['fmp_kitchen_monitor_page'] ?? '';
	}

	public static function is_inventory_activate() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return $settings['fmp_enable_frontend_inventory'] ?? '';
	}

	public static function get_available_rooms() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		if ( ! is_array( $settings ) || empty( $settings['fmp_available_rooms'] ) || ! is_string( $settings['fmp_available_rooms'] ) ) {
			return []; // Return empty array if not properly set
		}

		$available_rooms = array_filter( array_map(
			function ( $room ) {
				return str_replace( ' ', '', trim( $room ) );
			},
			explode( ',', $settings['fmp_available_rooms'] )
		) );

		// Convert to key => value
		$rooms_kv = [];
		foreach ( $available_rooms as $room ) {
			$rooms_kv[ $room ] = $room;
		}

		return $rooms_kv;
	}

	public static function update_product_stocks_on_status_change( $order, $old_status, $new_status ) {
		$direction = '';

		//Update refunded or cancelled from Others status
		if ( in_array( $new_status, [ 'refunded', 'cancelled' ] )
		     && ! in_array( $old_status, [ 'refunded', 'cancelled' ] ) ) {
			$direction = 'increase'; // restore stock
		}

		//Update others from refunded or cancelled status
		if ( in_array( $old_status, [ 'refunded', 'cancelled' ] )
		     && ! in_array( $new_status, [ 'refunded', 'cancelled' ] ) ) {
			$direction = 'decrease'; // deduct stock again
		}

		if ( $direction ) {
			//line_items only get products from order
			foreach ( $order->get_items( 'line_item' ) as $item ) {
				$product = $item->get_product();
				if ( $product && $product->managing_stock() ) {
					$qty = $item->get_quantity();
					wc_update_product_stock( $product, $qty, $direction );
				}
			}

			return true;
		}

		return false;
	}

	public static function is_editable_order( $status ) {
		return in_array( $status, [ 'cancelled', 'failed', 'delivered', 'completed', 'refunded' ] );
	}

	/**
	 * Get location-specific schedule data.
	 *
	 * @param int $term_id Location term ID.
	 *
	 * @return array|null Null signals caller to use global schedule.
	 */
	/**
	 * Whether a weekly schedule actually says anything.
	 *
	 * Ticking "custom schedule" on a location saves a row for every day even
	 * when a tab was left blank, so a non-empty array is not proof of intent.
	 * An all-blank schedule marks every day as an off-day downstream, which
	 * disables the whole date picker — callers must fall back to the global
	 * schedule instead. A day explicitly switched off *is* a real choice and
	 * counts as configured.
	 *
	 * @param mixed $schedule Weekly schedule array.
	 *
	 * @return bool
	 */
	public static function schedule_is_configured( $schedule ) {
		if ( empty( $schedule ) || ! is_array( $schedule ) ) {
			return false;
		}

		foreach ( $schedule as $day_data ) {
			if ( ! is_array( $day_data ) ) {
				continue;
			}

			// Deliberately closed on this day.
			if ( 'no' === ( $day_data['is_open'] ?? 'yes' ) ) {
				return true;
			}

			foreach ( (array) ( $day_data['slots'] ?? [] ) as $slot ) {
				if ( ! empty( $slot['start'] ) && ! empty( $slot['end'] ) ) {
					return true;
				}
			}
		}

		return false;
	}

	public static function get_location_schedule_data( $term_id ) {
		$has_custom = get_term_meta( $term_id, 'fmp_location_has_custom_schedule', true );

		if ( 'on' !== $has_custom ) {
			return null;
		}

		$new_delivery = get_term_meta( $term_id, 'fmp_loc_new_delivery_weekly_schedule', true ) ?: [];
		$new_pickup   = get_term_meta( $term_id, 'fmp_loc_new_pickup_weekly_schedule', true ) ?: [];
		$new_dinein   = get_term_meta( $term_id, 'fmp_loc_new_dinein_weekly_schedule', true ) ?: [];

		return [
			'fmp_loc_delivery_weekly_schedule_start_time' => self::get_schedule_time( $new_delivery ),
			'fmp_loc_delivery_weekly_schedule_end_time'   => self::get_schedule_time( $new_delivery, 'end' ),
			'fmp_loc_delivery_weekly_holiday'             => self::get_offday_schedule( $new_delivery ),
			'fmp_loc_delivery_weekly_schedule_slots'      => self::get_schedule_slots( $new_delivery ),
			'fmp_loc_delivery_time_interval'              => get_term_meta( $term_id, 'fmp_loc_delivery_time_interval', true ) ?: 15,
			'new_delivery_weekly_schedule'                => $new_delivery,
			'fmp_loc_pickup_weekly_schedule_start_time'   => self::get_schedule_time( $new_pickup ),
			'fmp_loc_pickup_weekly_schedule_end_time'     => self::get_schedule_time( $new_pickup, 'end' ),
			'fmp_loc_pickup_weekly_holiday'               => self::get_offday_schedule( $new_pickup ),
			'fmp_loc_pickup_weekly_schedule_slots'        => self::get_schedule_slots( $new_pickup ),
			'fmp_loc_pickup_time_interval'                => get_term_meta( $term_id, 'fmp_loc_pickup_time_interval', true ) ?: 15,
			'new_pickup_weekly_schedule'                  => $new_pickup,
			'fmp_loc_pickup_max_orders_per_slot'          => absint( get_term_meta( $term_id, 'fmp_loc_pickup_max_orders_per_slot', true ) ),
			'fmp_loc_delivery_max_orders_per_slot'        => absint( get_term_meta( $term_id, 'fmp_loc_delivery_max_orders_per_slot', true ) ),
			'fmp_loc_dinein_weekly_schedule_start_time'   => self::get_schedule_time( $new_dinein ),
			'fmp_loc_dinein_weekly_schedule_end_time'     => self::get_schedule_time( $new_dinein, 'end' ),
			'fmp_loc_dinein_weekly_holiday'               => self::get_offday_schedule( $new_dinein ),
			'fmp_loc_dinein_weekly_schedule_slots'        => self::get_schedule_slots( $new_dinein ),
			'fmp_loc_dinein_time_interval'                => get_term_meta( $term_id, 'fmp_loc_dinein_time_interval', true ) ?: 15,
			'new_dinein_weekly_schedule'                  => $new_dinein,
			// A location can have "custom schedule" enabled while leaving one of
			// the three order types unconfigured — always true for dine-in on
			// locations created before it existed. Callers must not overwrite the
			// global schedule with an empty per-location one, or the checkout
			// ends up with no time bounds and no per-slot limits. Check these
			// flags before applying any override.
			'has_dinein_schedule'                         => self::schedule_is_configured( $new_dinein ),
			'has_pickup_schedule'                         => self::schedule_is_configured( $new_pickup ),
			'has_delivery_schedule'                       => self::schedule_is_configured( $new_delivery ),
			'fmp_loc_dinein_max_orders_per_slot'          => absint( get_term_meta( $term_id, 'fmp_loc_dinein_max_orders_per_slot', true ) ),
		];
	}

	/**
	 * Get location-specific reservation data.
	 *
	 * @param int $term_id Location term ID.
	 *
	 * @return array|null Null signals caller to use global reservation settings.
	 */
	public static function get_location_reservation_data( $term_id ) {
		$has_custom = get_term_meta( $term_id, 'fmp_location_has_custom_reservation', true );

		if ( 'on' !== $has_custom ) {
			return null;
		}

		$new_schedule = get_term_meta( $term_id, 'fmp_loc_new_resi_weekly_schedule', true ) ?: [];

		return [
			'seat_capacity'                           => get_term_meta( $term_id, 'fmp_loc_resi_seat_capacity', true ) ?: 30,
			'min_guest'                               => get_term_meta( $term_id, 'fmp_loc_resi_min_guest', true ) ?: 1,
			'max_guest'                               => get_term_meta( $term_id, 'fmp_loc_resi_max_guest', true ) ?: 10,
			'time_interval'                           => get_term_meta( $term_id, 'fmp_loc_resi_time_interval', true ) ?: 30,
			'fmp_loc_resi_weekly_schedule_start_time' => self::get_schedule_time( $new_schedule ),
			'fmp_loc_resi_weekly_schedule_end_time'   => self::get_schedule_time( $new_schedule, 'end' ),
			'fmp_loc_resi_weekly_holiday'             => self::get_offday_schedule( $new_schedule ),
			'fmp_loc_resi_weekly_schedule_slots'      => self::get_schedule_slots( $new_schedule ),
			'new_resi_weekly_schedule'                => $new_schedule,
		];
	}

	/**
	 * Darken a hex color by a given percentage.
	 *
	 * @param string $hex     Hex color (e.g. #e60000).
	 * @param float  $percent Percentage to darken (0–100). Default 15.
	 *
	 * @return string Darkened hex color.
	 */
	public static function darken_color( $hex, $percent = 15 ) {
		$hex    = ltrim( $hex, '#' );
		$factor = 1 - ( $percent / 100 );
		$r      = max( 0, (int) round( hexdec( substr( $hex, 0, 2 ) ) * $factor ) );
		$g      = max( 0, (int) round( hexdec( substr( $hex, 2, 2 ) ) * $factor ) );
		$b      = max( 0, (int) round( hexdec( substr( $hex, 4, 2 ) ) * $factor ) );

		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}

	/**
	 * Lighten a hex color by mixing it with white.
	 *
	 * @param string $hex     Hex color (e.g. #e60000).
	 * @param float  $percent Lightness percentage (0 = original, 100 = white). Default 90.
	 *
	 * @return string Lightened hex color.
	 */
	public static function lighten_color( $hex, $percent = 90 ) {
		$hex    = ltrim( $hex, '#' );
		$factor = $percent / 100;
		$r      = (int) round( hexdec( substr( $hex, 0, 2 ) ) + ( 255 - hexdec( substr( $hex, 0, 2 ) ) ) * $factor );
		$g      = (int) round( hexdec( substr( $hex, 2, 2 ) ) + ( 255 - hexdec( substr( $hex, 2, 2 ) ) ) * $factor );
		$b      = (int) round( hexdec( substr( $hex, 4, 2 ) ) + ( 255 - hexdec( substr( $hex, 4, 2 ) ) ) * $factor );

		return sprintf( '#%02x%02x%02x', min( 255, $r ), min( 255, $g ), min( 255, $b ) );
	}

	/**
	 * Get the excluded product types from settings.
	 *
	 * @return array
	 */
	public static function get_excluded_product_types() {
		$settings = get_option( TLPFoodMenu()->options['settings'], [] );

		if ( ! is_array( $settings ) || empty( $settings['fmp_order_exclude_product_types'] ) || ! is_array( $settings['fmp_order_exclude_product_types'] ) ) {
			return [];
		}

		return array_map( 'sanitize_text_field', $settings['fmp_order_exclude_product_types'] );
	}

	/**
	 * Check if an order contains any excluded product types.
	 *
	 * @param \WC_Order $order WooCommerce order.
	 * @param array     $excluded_types Excluded product types.
	 *
	 * @return bool True if order has an excluded product type.
	 */
	public static function order_has_excluded_product_type( $order, $excluded_types ) {
		if ( empty( $excluded_types ) ) {
			return false;
		}

		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			if ( ! $product ) {
				continue;
			}

			$type = $product->get_type();

			// For variations, also check the parent product type.
			if ( 'variation' === $type ) {
				$parent = wc_get_product( $product->get_parent_id() );
				if ( $parent ) {
					$type = $parent->get_type();
				}
			}

			if ( in_array( $type, $excluded_types, true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Resolve excluded product type slugs to their term IDs (cached per-request).
	 *
	 * @param array $excluded_types Product type slugs.
	 *
	 * @return array Term IDs.
	 */
	public static function get_excluded_product_type_term_ids( $excluded_types ) {
		if ( empty( $excluded_types ) ) {
			return [];
		}

		static $cache = [];
		$key = md5( wp_json_encode( $excluded_types ) );

		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}

		$term_ids = [];
		foreach ( $excluded_types as $slug ) {
			$term = get_term_by( 'slug', $slug, 'product_type' );
			if ( $term && ! is_wp_error( $term ) ) {
				$term_ids[] = (int) $term->term_id;
			}
		}

		$cache[ $key ] = $term_ids;

		return $term_ids;
	}

	/**
	 * Build a NOT EXISTS SQL fragment that excludes orders containing any line
	 * item whose product is assigned an excluded product type.
	 *
	 * Returned string begins with " AND " so it can be appended to a WHERE clause.
	 *
	 * @param string $order_id_ref SQL reference for the order id column (e.g. "{$wpdb->prefix}wc_orders.id").
	 * @param array  $term_ids     Excluded product type term IDs.
	 *
	 * @return string SQL fragment or empty string when nothing to exclude.
	 */
	public static function build_excluded_product_types_sql( $order_id_ref, $term_ids ) {
		global $wpdb;

		if ( empty( $term_ids ) ) {
			return '';
		}

		// Guard the column reference (defense in depth — callers should pass trusted refs).
		if ( ! preg_match( '/^[A-Za-z0-9_.${}\\\\]+$/', $order_id_ref ) ) {
			return '';
		}

		$term_ids = array_map( 'intval', $term_ids );
		$term_in  = implode( ',', $term_ids );

		return " AND NOT EXISTS (
			SELECT 1
			FROM {$wpdb->prefix}woocommerce_order_items fmp_oi_excl
			INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta fmp_oim_excl
				ON fmp_oim_excl.order_item_id = fmp_oi_excl.order_item_id
				AND fmp_oim_excl.meta_key = '_product_id'
			INNER JOIN {$wpdb->term_relationships} fmp_tr_excl
				ON fmp_tr_excl.object_id = CAST(fmp_oim_excl.meta_value AS UNSIGNED)
			INNER JOIN {$wpdb->term_taxonomy} fmp_tt_excl
				ON fmp_tt_excl.term_taxonomy_id = fmp_tr_excl.term_taxonomy_id
			WHERE fmp_oi_excl.order_id = {$order_id_ref}
			  AND fmp_oi_excl.order_item_type = 'line_item'
			  AND fmp_tt_excl.taxonomy = 'product_type'
			  AND fmp_tt_excl.term_id IN ({$term_in})
		)";
	}

	/**
	 * Add filters that push excluded-product-type filtering into the SQL of
	 * wc_get_orders() / WP_Query shop_order queries.
	 *
	 * Works for both HPOS (`woocommerce_orders_table_query_clauses`) and the
	 * legacy posts table (`posts_where`).
	 *
	 * Returns a cleanup callable; the caller MUST invoke it to remove the
	 * filters (use try/finally).
	 *
	 * @param array $excluded_types Product type slugs to exclude.
	 *
	 * @return callable Cleanup callable.
	 */
	public static function add_excluded_product_types_query_filter( $excluded_types ) {
		$term_ids = self::get_excluded_product_type_term_ids( $excluded_types );

		if ( empty( $term_ids ) ) {
			return static function () {
				// No-op when nothing to exclude.
			};
		}

		$hpos_filter = static function ( $clauses ) use ( $term_ids ) {
			global $wpdb;
			$sql = self::build_excluded_product_types_sql( "{$wpdb->prefix}wc_orders.id", $term_ids );

			if ( $sql ) {
				$clauses['where'] = ( $clauses['where'] ?? '' ) . $sql;
			}

			return $clauses;
		};
		add_filter( 'woocommerce_orders_table_query_clauses', $hpos_filter, 10, 1 );

		$posts_filter = static function ( $where, $query ) use ( $term_ids ) {
			if ( ! ( $query instanceof \WP_Query ) ) {
				return $where;
			}

			$post_type = $query->get( 'post_type' );
			$is_order  = ( 'shop_order' === $post_type )
				|| ( is_array( $post_type ) && in_array( 'shop_order', $post_type, true ) );

			if ( ! $is_order ) {
				return $where;
			}

			global $wpdb;
			return $where . self::build_excluded_product_types_sql( "{$wpdb->posts}.ID", $term_ids );
		};
		add_filter( 'posts_where', $posts_filter, 10, 2 );

		return static function () use ( $hpos_filter, $posts_filter ) {
			remove_filter( 'woocommerce_orders_table_query_clauses', $hpos_filter, 10 );
			remove_filter( 'posts_where', $posts_filter, 10 );
		};
	}

	/**
	 * Run a callback with the excluded-product-types SQL filters temporarily applied.
	 *
	 * @param array    $excluded_types Product type slugs.
	 * @param callable $callback       Callback to invoke.
	 *
	 * @return mixed The callback's return value.
	 */
	public static function with_excluded_product_types( $excluded_types, callable $callback ) {
		$cleanup = self::add_excluded_product_types_query_filter( $excluded_types );

		try {
			return $callback();
		} finally {
			$cleanup();
		}
	}

	/**
	 * Build a NOT EXISTS SQL fragment that drops rows whose *product* is assigned
	 * an excluded product type.
	 *
	 * This is the row-level counterpart to build_excluded_product_types_sql(), and
	 * the two are NOT interchangeable:
	 *
	 * - build_excluded_product_types_sql() removes the whole **order** when it
	 *   contains any excluded item. Right for the orders list and Kitchen Monitor,
	 *   where an order is either shown or it is not.
	 * - This one removes only the **line/log row** for the excluded product. Right
	 *   for reports, where an order holding a room and a burger must still count
	 *   the burger's revenue.
	 *
	 * Returned string begins with " AND " so it can be appended to a WHERE clause,
	 * and is empty when nothing is excluded.
	 *
	 * @param string $product_id_ref SQL expression yielding a product ID
	 *                               (e.g. "log.product_id", "CAST(m.meta_value AS UNSIGNED)").
	 * @param array  $excluded_types Optional product type slugs; read from settings when omitted.
	 *
	 * @return string SQL fragment, or '' when nothing to exclude.
	 */
	public static function build_excluded_products_sql( $product_id_ref, $excluded_types = null ) {
		global $wpdb;

		if ( null === $excluded_types ) {
			$excluded_types = self::get_excluded_product_types();
		}

		$term_ids = self::get_excluded_product_type_term_ids( $excluded_types );

		if ( empty( $term_ids ) ) {
			return '';
		}

		// Guard the expression (defense in depth — callers should pass trusted refs).
		// Allows identifiers plus the CAST(... AS UNSIGNED) form used for meta values.
		if ( ! preg_match( '/^[A-Za-z0-9_.${}()\\\\ ]+$/', $product_id_ref ) ) {
			return '';
		}

		$term_in = implode( ',', array_map( 'intval', $term_ids ) );

		return " AND NOT EXISTS (
			SELECT 1
			FROM {$wpdb->term_relationships} fmp_tr_pex
			INNER JOIN {$wpdb->term_taxonomy} fmp_tt_pex
				ON fmp_tt_pex.term_taxonomy_id = fmp_tr_pex.term_taxonomy_id
			WHERE fmp_tr_pex.object_id = {$product_id_ref}
			  AND fmp_tt_pex.taxonomy = 'product_type'
			  AND fmp_tt_pex.term_id IN ({$term_in})
		)";
	}

	/**
	 * Selling price fields for a product, as numbers for the dashboard.
	 *
	 * `price` is the effective selling price — the sale price while a product is on
	 * sale — which is what the reports earn revenue at, and therefore the cap the
	 * inventory modals measure a unit cost against. `regular_price` / `sale_price`
	 * are returned alongside it so the UI can show the struck-through original
	 * exactly like the WooCommerce products list does.
	 *
	 * Values are `null` rather than `0` when unset: a missing price means "no cap"
	 * and renders blank, whereas a zero would read as a real, free product.
	 *
	 * @param \WC_Product $product Product object.
	 *
	 * @return array{price:?float,regular_price:?float,sale_price:?float}
	 */
	public static function get_product_price_fields( $product ) {
		$empty = [
			'price'         => null,
			'regular_price' => null,
			'sale_price'    => null,
		];

		if ( ! $product instanceof \WC_Product ) {
			return $empty;
		}

		$to_number = static function ( $value ) {
			return ( '' === $value || null === $value || ! is_numeric( $value ) ) ? null : (float) $value;
		};

		$price   = $to_number( $product->get_price() );
		$regular = $to_number( $product->get_regular_price() );
		$sale    = $to_number( $product->get_sale_price() );

		// A variable product carries no price of its own — its range lives on the
		// variations — so fall back to the cheapest variation price WooCommerce
		// already caches for the catalogue.
		if ( null === $price && $product->is_type( 'variable' ) ) {
			$price = $to_number( $product->get_variation_price( 'min', true ) );
		}

		if ( null === $price ) {
			$price = $regular;
		}

		// Only report a sale when it really is one, so the UI never strikes through
		// a regular price that equals (or undercuts) the "sale".
		if ( null === $sale || null === $regular || $sale >= $regular ) {
			$sale = null;
		}

		return [
			'price'         => $price,
			'regular_price' => $regular,
			'sale_price'    => $sale,
		];
	}

	/**
	 * Transient key for the inventory dashboard stat cards.
	 *
	 * Keyed by the excluded product types so switching that setting is reflected
	 * at once rather than after the cache expires. Every reader AND every
	 * invalidator must go through here — a hardcoded 'fmp_dashboard_stats' delete
	 * silently stops clearing the cache as soon as an exclusion is configured.
	 *
	 * @return string
	 */
	public static function dashboard_stats_cache_key() {
		$excluded_types = self::get_excluded_product_types();

		if ( empty( $excluded_types ) ) {
			return 'fmp_dashboard_stats';
		}

		return 'fmp_dashboard_stats_' . substr( md5( wp_json_encode( $excluded_types ) ), 0, 8 );
	}

	/**
	 * tax_query clause that keeps excluded product types out of a product query.
	 *
	 * For WP_Query/get_posts callers, where build_excluded_products_sql() cannot
	 * be spliced in.
	 *
	 * @param array $excluded_types Optional product type slugs; read from settings when omitted.
	 *
	 * @return array tax_query array (empty when nothing to exclude).
	 */
	public static function excluded_product_types_tax_query( $excluded_types = null ) {
		if ( null === $excluded_types ) {
			$excluded_types = self::get_excluded_product_types();
		}

		if ( empty( $excluded_types ) ) {
			return [];
		}

		return [
			[
				'taxonomy' => 'product_type',
				'field'    => 'slug',
				'terms'    => $excluded_types,
				'operator' => 'NOT IN',
			],
		];
	}

	/**
	 * Get the list of unique table names from the saved QR codes.
	 *
	 * Used to populate the table dropdown on the admin order edit screen so
	 * staff pick from existing QR-coded tables instead of free-typing.
	 *
	 * @return string[] Unique, non-empty table names in QR-code order.
	 */
	public static function get_qr_table_names() {
		$qr_codes = get_option( 'fmp_qr_codes', [] );

		if ( ! is_array( $qr_codes ) ) {
			return [];
		}

		$names = [];
		foreach ( $qr_codes as $qr ) {
			$name = isset( $qr['table_name'] ) && is_scalar( $qr['table_name'] )
				? trim( (string) $qr['table_name'] )
				: '';
			if ( '' !== $name && ! in_array( $name, $names, true ) ) {
				$names[] = $name;
			}
		}

		return $names;
	}

	/**
	 * Translate a PHP date format into the equivalent Day.js format.
	 *
	 * Lets React pickers display times in whatever the site picked under
	 * Settings → General → Time Format, including a Custom value, while the
	 * values they send around stay in a fixed machine format.
	 *
	 * Only time tokens are mapped — this is meant for the `time_format` option.
	 * Unmapped letters are emitted as Day.js literals (`[x]`) so they show up
	 * as-is instead of being read as format tokens.
	 *
	 * @param string $php_format PHP date format, e.g. `g:i A`.
	 *
	 * @return string Day.js format, e.g. `h:mm A`.
	 */
	/**
	 * Convert a PHP *date* format (e.g. the `date_format` option) into a Day.js
	 * format, so React pickers display dates the way the rest of the site does.
	 *
	 * Display only — stored values are formatted server-side so they stay
	 * byte-identical to what checkout writes.
	 *
	 * @param string $php_format PHP date format.
	 *
	 * @return string
	 */
	public static function php_to_dayjs_date_format( string $php_format ): string {
		$map = [
			'd' => 'DD',    // Day, leading zero.
			'j' => 'D',     // Day, no leading zero.
			'D' => 'ddd',   // Mon.
			'l' => 'dddd',  // Monday.
			'N' => 'E',
			'w' => 'd',
			'F' => 'MMMM',  // August.
			'M' => 'MMM',   // Aug.
			'm' => 'MM',
			'n' => 'M',
			'Y' => 'YYYY',
			'y' => 'YY',
		];

		$out    = '';
		$length = strlen( $php_format );

		for ( $i = 0; $i < $length; $i++ ) {
			$char = $php_format[ $i ];

			// A backslash escapes the next character in PHP date formats.
			if ( '\\' === $char && $i + 1 < $length ) {
				$i++;
				$out .= '[' . $php_format[ $i ] . ']';
				continue;
			}

			// `jS` / `dS` (ordinal suffix) maps to Day.js `Do` as a unit —
			// Day.js has no standalone suffix token.
			if ( ( 'j' === $char || 'd' === $char ) && isset( $php_format[ $i + 1 ] ) && 'S' === $php_format[ $i + 1 ] ) {
				$out .= 'Do';
				$i++;
				continue;
			}

			if ( isset( $map[ $char ] ) ) {
				$out .= $map[ $char ];
			} elseif ( ctype_alpha( $char ) ) {
				$out .= '[' . $char . ']';
			} else {
				$out .= $char;
			}
		}

		return $out;
	}

	public static function php_to_dayjs_time_format( string $php_format ): string {
		$map = [
			'g' => 'h',   // 12-hour, no leading zero.
			'G' => 'H',   // 24-hour, no leading zero.
			'h' => 'hh',  // 12-hour, leading zero.
			'H' => 'HH',  // 24-hour, leading zero.
			'i' => 'mm',
			's' => 'ss',
			'a' => 'a',   // am / pm.
			'A' => 'A',   // AM / PM.
		];

		$out    = '';
		$length = strlen( $php_format );

		for ( $i = 0; $i < $length; $i++ ) {
			$char = $php_format[ $i ];

			// A backslash escapes the next character in PHP date formats.
			if ( '\\' === $char && $i + 1 < $length ) {
				$i++;
				$out .= '[' . $php_format[ $i ] . ']';
				continue;
			}

			if ( isset( $map[ $char ] ) ) {
				$out .= $map[ $char ];
			} elseif ( ctype_alpha( $char ) ) {
				$out .= '[' . $char . ']';
			} else {
				$out .= $char;
			}
		}

		return $out;
	}

	/**
	 * Whether a Day.js format renders time on a 12-hour clock.
	 *
	 * Bracketed literals are stripped first so a letter that is only ever
	 * displayed as text can't be mistaken for a format token.
	 *
	 * @param string $dayjs_format Day.js format string.
	 */
	public static function dayjs_format_is_12h( string $dayjs_format ): bool {
		$probe = preg_replace( '/\[[^\]]*\]/', '', $dayjs_format );

		return (bool) preg_match( '/[hAa]/', (string) $probe );
	}

	/**
	 * The store's price format, as the pieces JavaScript needs to rebuild it.
	 *
	 * Mirrors what `wc_price()` does server-side: symbol, which side it sits on,
	 * how many decimals the currency uses, and the separators.
	 *
	 * **Every bundle that localizes `fmpInventory` must include this as
	 * `priceFormat`.** `src/js/frontend-dashboard/utils/price.js` falls back to a
	 * hardcoded `$` when it is missing, which is how a CFA store ends up reading
	 * its own takings in dollars. It lives here, rather than privately in one
	 * controller, so a new bundle can't quietly ship without it.
	 *
	 * @return array<string,mixed>
	 */
	public static function get_price_format(): array {
		if ( ! function_exists( 'get_woocommerce_currency_symbol' ) ) {
			return [
				'symbol'      => '$',
				'position'    => 'left',
				'decimals'    => 2,
				'decimalSep'  => '.',
				'thousandSep' => ',',
			];
		}

		return [
			'symbol'      => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ),
			'position'    => get_option( 'woocommerce_currency_pos', 'left' ),
			'decimals'    => wc_get_price_decimals(),
			'decimalSep'  => wc_get_price_decimal_separator(),
			'thousandSep' => wc_get_price_thousand_separator(),
		];
	}

}
