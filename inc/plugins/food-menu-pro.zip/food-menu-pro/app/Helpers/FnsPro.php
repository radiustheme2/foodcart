<?php
/**
 * Helpers class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Helpers;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\Reservation\Reservation;
use RT\FoodMenuPro\Models\FMPFood;
use RT\FoodMenuPro\Controllers\Discount\Discount;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Helpers class.
 */
class FnsPro {

	/**
	 * Render view.
	 *
	 * @param string $viewName View name.
	 * @param array $args View args.
	 * @param boolean $return View return.
	 *
	 * @return string|void
	 */
	public static function renderView( $viewName, $args = [], $return = false ) {
		$viewName = str_replace( '.', '/', $viewName );

		if ( ! empty( $args ) && is_array( $args ) ) {
			extract( $args );
		}

		$view_file = FMP()->pro_plugin_path() . '/resources/' . $viewName . '.php';

		if ( ! file_exists( $view_file ) ) {
			_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', esc_html( $view_file ) ), '1.7.0' );

			return;
		}

		if ( $return ) {
			ob_start();
			include $view_file;

			return ob_get_clean();
		} else {
			include $view_file;
		}
	}

	/**
	 * Insert Array.
	 *
	 * @param array $array Array.
	 * @param int $position Position.
	 * @param array $insert_array Insert array.
	 *
	 * @return array
	 */
	public static function array_insert( $array, $position, $insert_array ) {
		$first_array = array_splice( $array, 0, $position + 1 );
		$array       = array_merge( $first_array, $insert_array, $array );

		return $array;
	}

	/**
	 * Food
	 *
	 * @param string $food Food.
	 *
	 * @return void|object
	 */
	public static function food( $food = null ) {
		return new FMPFood( $food );
	}

	/**
	 * Get nutrition list.
	 *
	 * @param int $post_id Post ID.
	 *
	 * @return void|string
	 */
	public static function get_fm_nutrition_list( $post_id = null ) {
		if ( ! $post_id ) {
			global $post;
			$post_id = $post->ID;
		}

		$post_id = absint( $post_id );

		$html      = null;
		$nutrition = get_post_meta( $post_id, '_nutrition' );

		if ( ! empty( $nutrition ) ) {
			$html .= '<ul>';
			foreach ( $nutrition as $nutrition ) {
				$nut   = ! empty( $nutrition['id'] ) ? get_term( $nutrition['id'], TLPFoodMenu()->taxonomies['nutrition'] ) : null;
				$unit  = ! empty( $nutrition['unit_id'] ) ? get_term( $nutrition['unit_id'], TLPFoodMenu()->taxonomies['unit'] ) : null;
				$value = ! empty( $nutrition['value'] ) ? ' ' . $nutrition['value'] : null;

				if ( is_object( $unit ) && ! empty( $unit->name ) && $value ) {
					$unit = " ( {$unit->name} )";
				} else {
					$unit = null;
				}

				if ( is_object( $nut ) ) {
					$html .= "<li>{$nut->name}{$value}{$unit}</li>";
				}
			}
			$html .= '</ul>';
		}

		return $html;
	}

	/**
	 * @param null $post_id
	 *
	 * @return null|string
	 */
	public static function get_fm_ingredient_list( $post_id = null ) {
		if ( ! $post_id ) {
			global $post;
			$post_id = $post->ID;
		}

		$post_id = absint( $post_id );

		$html        = null;
		$ingredients = get_post_meta( $post_id, '_ingredient' );

		if ( ! empty( $ingredients ) ) {
			$html .= '<ul>';
			foreach ( $ingredients as $ingredient ) {
				$ing   = ! empty( $ingredient['id'] ) ? get_term( $ingredient['id'], TLPFoodMenu()->taxonomies['ingredient'] ) : null;
				$unit  = ! empty( $ingredient['unit_id'] ) ? get_term( $ingredient['unit_id'], TLPFoodMenu()->taxonomies['unit'] ) : null;
				$value = ! empty( $ingredient['value'] ) ? ' ' . $ingredient['value'] : null;

				if ( is_object( $unit ) && $unit->name && $value ) {
					$unit = " ( {$unit->name} )";
				} else {
					$unit = null;
				}

				if ( is_object( $ing ) ) {
					$html .= "<li>{$ing->name}{$value}{$unit}</li>";
				}
			}
			$html .= '</ul>';
		}

		return $html;
	}

	/**
	 * Returns the product tags.
	 *
	 * @param $id
	 * @param $sep
	 * @param $before
	 * @param $after
	 *
	 * @return false|string|\WP_Error|\WP_Term[]
	 */
	public static function get_tags( $id, $sep = ', ', $before = '', $after = '' ) {
		return get_the_term_list( $id, TLPFoodMenu()->taxonomies['tag'], $before, $sep, $after );
	}

	/**
	 * Pagination
	 *
	 * @param string $pages Pages.
	 * @param integer $range Range.
	 * @param boolean $ajax Ajax.
	 * @param string $scID Shortcode ID.
	 *
	 * @return string
	 */
	public static function pagination( $pages = '', $range = 4, $ajax = false, $scID = '' ) {
		$html      = null;
		$showitems = ( $range * 2 ) + 1;

		global $paged;

		if ( is_front_page() ) {
			$paged = ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1;
		} else {
			$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
		}

		if ( empty( $paged ) ) {
			$paged = 1;
		}

		if ( $pages == '' ) {
			global $wp_query;
			$pages = $wp_query->max_num_pages;

			if ( ! $pages ) {
				$pages = 1;
			}
		}

		$ajaxClass = null;
		$dataAttr  = null;

		if ( $ajax ) {
			$ajaxClass = ' fmp-ajax';
			$dataAttr  = "data-sc-id='{$scID}' data-paged='1'";
		}

		if ( 1 != $pages ) {
			$html .= '<div class="fmp-pagination' . $ajaxClass . '" ' . $dataAttr . '>';
			$html .= '<ul class="pagination-list">';

			if ( $paged > 2 && $paged > $range + 1 && $showitems < $pages ) {
				$html .= "<li><a data-paged='1' href='" . get_pagenum_link( 1 ) . "' aria-label='First'>&laquo;</a></li>";
			}

			if ( $paged > 1 && $showitems < $pages ) {
				$p    = $paged - 1;
				$html .= "<li><a data-paged='{$p}' href='" . get_pagenum_link( $p ) . "' aria-label='Previous'>&lsaquo;</a></li>";
			}

			for ( $i = 1; $i <= $pages; $i ++ ) {
				if ( 1 != $pages && ( ! ( $i >= $paged + $range + 1 || $i <= $paged - $range - 1 ) || $pages <= $showitems ) ) {
					$html .= ( $paged == $i ) ? '<li class="active"><span>' . $i . '</span></li>' : "<li><a data-paged='{$i}' href='" . get_pagenum_link( $i ) . "'>" . $i . '</a></li>';
				}
			}

			if ( $paged < $pages && $showitems < $pages ) {
				$p    = $paged + 1;
				$html .= "<li><a data-paged='{$p}' href=\"" . get_pagenum_link( $paged + 1 ) . "\"  aria-label='Next'>&rsaquo;</a></li>";
			}

			if ( $paged < $pages - 1 && $paged + $range - 1 < $pages && $showitems < $pages ) {
				$html .= "<li><a data-paged='{$pages}' href='" . get_pagenum_link( $pages ) . "' aria-label='Last'>&raquo;</a></li>";
			}

			$html .= '</ul>';
			$html .= '</div>';
		}

		return $html;
	}

	public static function getStockStatus( $id = null ) {
		if ( $id ) {
			$id = absint( $id );
		} else {
			$id = get_the_ID();
		}

		$stock     = get_post_meta( $id, '_stock_status', true );
		$stockHtml = null;
		$fmp_type  = get_post_meta( $id, '_fmp_type', true );

		if ( 'variable' === $fmp_type ) {
			$stockHtml = '<span class="na">–</span>';
		} else {
			if ( $stock == 'instock' ) {
				$stockHtml = '<mark class="instock">In stock</mark>';
			} elseif ( $stock == 'outofstock' ) {
				$stockHtml = '<mark class="outofstock">Out of stock</mark>';
			}
		}

		return $stockHtml;
	}

	public static function fmpHtmlPrice( $id = null ) {
		if ( $id ) {
			$id = absint( $id );
		} else {
			global $post;
			$id = $post->ID;
		}

		$price_html         = null;
		$sale_price_html    = null;
		$regular_price_html = null;
		$regular_price      = get_post_meta( $id, '_regular_price', true );
		$sale_price         = get_post_meta( $id, '_sale_price', true );

		if ( ! ( $regular_price || $sale_price ) ) {
			return '';
		}

		if ( $regular_price > 0 ) {
			$fRegularPrice      = self::getPriceWithSymbol( $regular_price );
			$regular_price_html = '<span class="fmp-price-amount amount">' . $fRegularPrice . '</span>';
		}

		if ( $sale_price > 0 ) {
			$fSalePrice      = self::getPriceWithSymbol( $sale_price );
			$sale_price_html = '<span class="fmp-price-amount amount">' . $fSalePrice . '</span>';
		} elseif ( $sale_price == '' ) {
			$sale_price_html = null;
		} elseif ( $sale_price == 0 ) {
			$sale_price_html = '<span class="amount">' . esc_html__( 'Free!', 'food-menu-pro' ) . '</span>';
		}

		if ( $regular_price_html && $sale_price_html ) {
			$price_html = '<del>' . $regular_price_html . '</del>' . '<inc>' . $sale_price_html . '</inc>';
		} elseif ( ! $regular_price_html && $sale_price_html ) {
			$price_html = $sale_price_html;
		} elseif ( $regular_price_html && ! $sale_price_html ) {
			$price_html = $regular_price_html;
		}

		$fmp_type = get_post_meta( $id, '_fmp_type', true );

		if ( 'variable' === $fmp_type ) {
			$vPrices    = [];
			$variations = get_posts(
				[
					'post_type'      => 'fmp_variation',
					'posts_per_page' => - 1,
					'post_status'    => 'any',
					'post_parent'    => $id,
					'order'          => 'ASC',
				]
			);

			if ( ! empty( $variations ) ) {
				foreach ( $variations as $variation ) {
					$vp = get_post_meta( $variation->ID, '_price', true );
					if ( $vp ) {
						$vPrices[] = $vp;
					}
				}

				if ( ! empty( $vPrices ) && count( $vPrices ) > 1 ) {
					$max        = self::getPriceWithSymbol( max( $vPrices ) );
					$min        = self::getPriceWithSymbol( min( $vPrices ) );
					$price_html = $min . ' - ' . $max;
				} elseif ( ! empty( $vPrices ) && count( $vPrices ) == 1 ) {
					$price_html = self::getPriceWithSymbol( max( $vPrices ) );
				} else {
					$price_html = "<span class='na'>–</span>";
				}
			}
		}

		return apply_filters( 'rtfm_food_price_modifier', $price_html, get_the_ID() );
	}

	public static function get_formatted_amount( $amount ) {
		$settings      = get_option( TLPFoodMenu()->options['settings'] );
		$thousands_sep = isset( $settings['price_thousand_sep'] ) ? stripslashes( $settings['price_thousand_sep'] ) : ',';
		$decimal_sep   = isset( $settings['price_decimal_sep'] ) ? stripslashes( $settings['price_decimal_sep'] ) : '.';
		$decimals      = isset( $settings['price_num_decimals'] ) ? absint( $settings['price_num_decimals'] ) : 2;

		$un_formatted_price = $amount;
		$negative           = $amount < 0;
		$amount             = apply_filters( 'fmp_raw_amount', floatval( $negative ? $amount * - 1 : $amount ) );
		$amount             = apply_filters( 'fmp_formatted_amount', number_format( $amount, $decimals, $decimal_sep, $thousands_sep ) );

		if ( apply_filters( 'fmp_price_trim_zeros', false, $decimals ) && $decimals > 0 ) {
			$amount = self::trim_zeros( $amount, $decimal_sep );
		}

		return apply_filters( 'fmp_get_formatted_amount', $amount, $un_formatted_price, $decimals, $decimal_sep, $thousands_sep );
	}

	public static function trim_zeros( $amount, $decimal_sep ) {
		return preg_replace( '/' . preg_quote( $decimal_sep, '/' ) . '0++$/', '', $amount );
	}

	public static function getPriceWithSymbol( $price ) {
		$price     = self::get_formatted_amount( $price );
		$currencyP = Fns::getCurrencyPosition();
		$symbol    = '<span class="fmp-price-currencySymbol">' . Fns::getCurrencySymbol() . '</span>';

		switch ( $currencyP ) {
			case 'left':
				$price = $symbol . $price;
				break;

			case 'right':
				$price = $price . $symbol;
				break;

			case 'left_space':
				$price = $symbol . ' ' . $price;
				break;

			case 'right_space':
				$price = $price . ' ' . $symbol;
				break;

			default:
				break;
		}

		return $price;
	}

	public static function fmp_clean( $var ) {
		if ( is_array( $var ) ) {
			return array_map( [ __CLASS__, 'fmp_clean' ], $var );
		} else {
			return is_scalar( $var ) ? sanitize_text_field( $var ) : $var;
		}
	}

	public static function getAllFmpIsoFilterType() {
		return [
			'default' => esc_html__( 'Layout Default', 'food-menu-pro' ),
			'type-1'  => esc_html__( 'Type 1', 'food-menu-pro' ),
			'type-2'  => esc_html__( 'Type 2', 'food-menu-pro' ),
			'type-3'  => esc_html__( 'Type 3', 'food-menu-pro' ),
		];
	}

	/**
	 * Preparing date function
	 *
	 * @param number $daysToAdd receive day number.
	 *
	 * @return mixed
	 */
	public static function preparing_date( $daysToAdd = 0 ) {
		// Create a new DateTime object for the current date.
		$currentDate = new \DateTime();

		// Add the specified number of days to the current date.
		$currentDate->modify( '+' . $daysToAdd . ' day' );

		// Return the formatted date.
		return $currentDate->format( TLP_FOOD_MENU_DEFAULT_DATE_FORMAT );
	}

	/**
	 * Get checkout order time array in desired format
	 */
	public static function get_order_type() {
		return [
			esc_html__( 'Delivery type', 'food-menu-pro' )  => 'fmp_order_time_type',
			esc_html__( 'Delivery date', 'food-menu-pro' )  => 'fmp_delivery_date',
			esc_html__( 'Delivery time', 'food-menu-pro' )  => 'fmp_delivery_time',
			esc_html__( 'Pickup date', 'food-menu-pro' )    => 'fmp_pickup_date',
			esc_html__( 'Pickup time', 'food-menu-pro' )    => 'fmp_pickup_time',
			esc_html__( 'Tip type', 'food-menu-pro' )       => 'fmp_tip_type',
			esc_html__( 'Fixed Tip', 'food-menu-pro' )      => 'fmp_fixed_amount',
			esc_html__( 'Percentage Tip', 'food-menu-pro' ) => 'fmp_percentage_amount',
		];
	}

	/**
	 * Product discount price.
	 *
	 * @param array $args .
	 *
	 * @return array|void
	 */
	public static function discount_price( $args ) {
		$defaults = [
			'product_id'    => null,
			'data'          => '',
			'product_price' => null,
			'addons_price'  => 0,
		];
		$args     = wp_parse_args( $args, $defaults );

		$fmp_check_discount = Discount::get_instance()->check_discount_of_product( $args['product_id'], null );
		if ( is_array( $fmp_check_discount ) && ! empty( $fmp_check_discount['percentage'] ) ) {
			$main_price           = empty( $args['product_price'] ) ? self::product_price_by_tax( wc_get_product( $args['product_id'] ) ) : $args['product_price'];
			$percentage           = $fmp_check_discount['percentage'];
			$price_after_discount = (float) ( $percentage / 100 ) * (float) $main_price;
			$new_price            = (float) $main_price - (float) $price_after_discount;

			// Addon apply discount.
			$addons_new_price     = $args['addons_price'];
			$settings             = self::get_settings_option();
			$discount_apply_addon = ! empty( $settings['fmp_applicable_discount'] ) && 'addon_total' === $settings['fmp_applicable_discount'];
			if ( $args['addons_price'] > 0 && $discount_apply_addon ) {
				$addons_price_discounted = (float) ( $percentage / 100 ) * (float) $args['addons_price'];
				$addons_new_price        = (float) $args['addons_price'] - (float) $addons_price_discounted;
			}

			if ( 'fmp_cart' == $args['data'] || 'fmp_cart_sub_total' == $args['data'] ) {
				// Set the new price.
				return [
					'new_price'           => $new_price,
					'addons_new_price'    => $addons_new_price,
					'discount_percentage' => $percentage,
				];
			} else {
				return [
					'main_price'           => $main_price,
					'new_price'            => $new_price,
					'price_after_discount' => wc_price( $new_price ),
					'discount_percentage'  => $percentage,
					'discount_apply_to'    => $settings['fmp_applicable_discount'] ?? '',
					'addons_new_price'     => $addons_new_price,
				];
			}
		}
	}

	/**
	 * Product price by tax.
	 *
	 * @param float $product .
	 *
	 * @return float
	 */
	public static function product_price_by_tax( $product ) {
		return wc_get_price_excluding_tax( $product ) ? wc_get_price_excluding_tax( $product ) : wc_get_price_including_tax( $product );
	}

	/**
	 * Get settings Options.
	 *
	 * @param string $key .
	 *
	 * @return array
	 */
	public static function get_settings_option( $key = null ) {
		$options = TLPFoodMenu()->options;
		$key     = ( null === $key && isset( $options['settings'] ) ) ? $options['settings'] : $key;

		return get_option( $key );
	}

	/**
	 * Get Product id and value array
	 *
	 * @param array $post_ids .
	 * @param string $post_type .
	 *
	 * @return array
	 */
	public static function get_product_id_titles( $post_ids, $post_type = 'post' ) {
		$post_titles = [];

		if ( ! empty( $post_ids ) ) {
			foreach ( $post_ids as $post_id ) {
				$post = get_post( $post_id );
				if ( $post && $post->post_type === $post_type ) {
					$post_titles[ $post_id ] = $post->post_title;
				}
			}
		}

		return $post_titles;
	}

	/**
	 * Get term and name array
	 *
	 * @param array $term_ids .
	 * @param string $taxonomy .
	 *
	 * @return array
	 */
	public static function get_term_names( $term_ids, $taxonomy = 'category' ) {
		$term_names = [];

		if ( ! empty( $term_ids ) ) {
			foreach ( $term_ids as $term_id ) {
				$term = get_term( $term_id, $taxonomy );
				if ( $term && ! is_wp_error( $term ) ) {
					$term_names[ $term_id ] = $term->name;
				}
			}
		}

		return $term_names;
	}

	/**
	 * Reservation enable or disable function
	 *
	 * @return boolean
	 */
	public static function enable_reservation() {
		$settings       = get_option( TLPFoodMenu()->options['settings'] );
		$food_menu_type = $settings['fmp_food_reservation_status'] ?? '';

		return boolval( $food_menu_type );
	}

	/**
	 * Get reservation status list
	 *
	 * @return array
	 */
	public static function get_reservation_status() {
		return [
			'pending'   => __( 'Pending', 'food-menu-pro' ),
			'confirmed' => __( 'Confirmed', 'food-menu-pro' ),
			'cancelled' => __( 'Cancelled', 'food-menu-pro' ),
			'completed' => __( 'Completed', 'food-menu-pro' ),
		];
	}

	/**
	 * Get guest limit
	 *
	 * @return array
	 */
	public static function get_guest_limit() {
		$guest_limit      = [];
		$settings         = get_option( TLPFoodMenu()->options['settings'] );
		$seat_capacity    = $settings['fmp_resi_seat_capacity'] ?? 30;
		$min_guest_number = ! empty( $settings['fmp_resi_min_guest'] ) ? $settings['fmp_resi_min_guest'] : 1;
		$max_guest_number = ! empty( $settings['fmp_resi_max_guest'] ) ? $settings['fmp_resi_max_guest'] : $seat_capacity;

		for ( $guest_number = $min_guest_number; $guest_number <= $max_guest_number; $guest_number ++ ) {
			$guest_limit[ $guest_number ] = $guest_number;
		}

		return $guest_limit;
	}

	/**
	 * Generate invoice number
	 *
	 * @param $postId
	 *
	 * @return string
	 */
	public static function generate_invoice_number( $postId ) {
		$four_digit_random = wp_rand( 1000, 9999 );
		$prefix            = apply_filters( 'fmp_booking_id_prefix', 'fm' );

		return $prefix . $postId;
	}

	/**
	 * Send email
	 *
	 * @param array $args .
	 *
	 * @return bool|mixed
	 */
	public static function send_email( $args ) {
		$body      = wpautop( html_entity_decode( $args['mail_body'] ) );
		$from_name = html_entity_decode( $args['from_name'] );
		$headers   = [
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $from_name . ' <' . $args['from'] . '>',
		];

		return wp_mail( $args['to'], $args['subject'], $body, $headers );
	}

	/**
	 * Reservation fields array
	 *
	 * @return string[]
	 */
	public static function reservation_fields_array() {
		return [
			'fmp_resi_meta_invoice'    => __( 'Booking ID', 'food-menu-pro' ),
			'fmp_resi_meta_date'       => __( 'Reservation Date', 'food-menu-pro' ),
			'fmp_resi_meta_start_time' => __( 'Start Time', 'food-menu-pro' ),
			'fmp_resi_meta_end_time'   => __( 'End Time', 'food-menu-pro' ),
			'fmp_resi_meta_seat'       => __( 'Seat', 'food-menu-pro' ),
			'fmp_resi_meta_name'       => __( 'Name', 'food-menu-pro' ),
			'fmp_resi_meta_email'      => __( 'Email', 'food-menu-pro' ),
			'fmp_resi_meta_phone'      => __( 'Phone', 'food-menu-pro' ),
			'fmp_resi_meta_message'    => __( 'Message', 'food-menu-pro' ),
			'fmp_resi_meta_status'     => __( 'Status', 'food-menu-pro' ),
		];
	}

	/**
	 * Send email admin & user.
	 *
	 * @param array $settings .
	 * @param array $args .
	 *
	 * @return void
	 */
	public static function send_email_notify_admin_user( $settings, $args ) {
		$sender_mail  = ! empty( $settings['fmp_resi_sender_email'] ) ? $settings['fmp_resi_sender_email'] : get_bloginfo( 'admin_email' );
		$receive_mail = ! empty( $settings['fmp_resi_receive_email'] ) ? $settings['fmp_resi_receive_email'] : $sender_mail;

		if ( ! empty( $args['admin_notify'] ) ) {
			$args['msg'] = sprintf( "Hi Admin, you have a new reservation request from %s.", $args['resi_email'] );

			if ( 'cancelled' === $args['status'] ) {
				$args['msg'] = sprintf( "You have received a reservation cancellation request from %s.", $args['resi_email'] );
			}

			$mail_body = self::mail_body_markup( $args, 'admin' );

			$mail_to        = $receive_mail;
			$mail_from      = ! empty( $settings['fmp_resi_sender_email'] ) ? $settings['fmp_resi_sender_email'] : $receive_mail;
			$mail_subject   = esc_html__( 'New Reservation Request', 'food-menu-pro' );
			$mail_from_name = esc_html__( 'Admin', 'food-menu-pro' );

			$email_args = [
				'to'        => $mail_to,
				'subject'   => $mail_subject,
				'mail_body' => $mail_body,
				'from'      => $mail_from,
				'from_name' => $mail_from_name,
			];
			self::send_email( $email_args );
		}

		if ( ! empty( $args['user_notify'] ) ) {
			$args['msg']    = $args['message'];
			$mail_to        = $args['resi_email'];
			$mail_subject   = esc_html__( 'Hello ', 'food-menu-pro' ) . ' ' . $args['recipient'] ?? '';
			$mail_from      = ! empty( $settings['fmp_resi_sender_email'] ) ? $settings['fmp_resi_sender_email'] : $receive_mail;
			$mail_from_name = $sender_mail;
			$mail_body      = self::mail_body_markup( $args );
			$email_args     = [
				'to'        => $mail_to,
				'subject'   => $mail_subject,
				'mail_body' => $mail_body,
				'from'      => $mail_from,
				'from_name' => $mail_from_name,
			];
			self::send_email( $email_args );
		}
	}

	/**
	 * Send email notification.
	 *
	 * @param array $mail_args .
	 * @param string $resi_email .
	 * @param string $invoice_no .
	 * @param string $resi_status .
	 *
	 * @return void
	 */
	public static function send_email_notify( $mail_args, $resi_email, $invoice_no, $resi_status ) {
		if ( ! empty( $resi_status ) && ! empty( $invoice_no ) ) {
			$settings = self::get_settings_option();

			switch ( $resi_status ) {
				case 'cancelled':
					$message = self::get_reservation_message( $settings, 'cancel' );
					$args    = [
						'recipient'    => get_post_meta( $mail_args['ID'], 'fmp_resi_meta_name', true ),
						'resi_id'      => $mail_args['ID'],
						'booking_date' => $mail_args['booking_date'] ?? '',
						'invoice'      => $invoice_no,
						'resi_email'   => $resi_email,
						'message'      => $message,
						'admin_notify' => $settings['fmp_resi_admin_cancel_notify'] ?? 'on',
						'user_notify'  => $settings['fmp_resi_user_cancel_notify'] ?? 'on',
						'status'       => $resi_status,
					];
					self::send_email_notify_admin_user( $settings, $args );
					break;

				case 'confirmed':
					$message = self::get_reservation_message( $settings, 'confirm' );
					$args    = [
						'recipient'    => get_post_meta( $mail_args['ID'], 'fmp_resi_meta_name', true ),
						'resi_id'      => $mail_args['ID'],
						'booking_date' => $mail_args['booking_date'] ?? '',
						'invoice'      => $invoice_no,
						'resi_email'   => $resi_email,
						'message'      => $message,
						'admin_notify' => $settings['fmp_resi_admin_confirm_notify'] ?? 'on',
						'user_notify'  => $settings['fmp_resi_user_confirm_notify'] ?? 'on',
						'status'       => $resi_status,
					];
					self::send_email_notify_admin_user( $settings, $args );
					break;

				case 'pending':
					$message = self::get_reservation_message( $settings, 'pending' );
					$args    = [
						'recipient'    => get_post_meta( $mail_args['ID'], 'fmp_resi_meta_name', true ),
						'resi_id'      => $mail_args['ID'],
						'booking_date' => $mail_args['booking_date'] ?? '',
						'invoice'      => $invoice_no,
						'resi_email'   => $resi_email,
						'message'      => $message,
						'admin_notify' => $settings['fmp_resi_admin_pending_notify'] ?? 'on',
						'user_notify'  => $settings['fmp_resi_user_pending_notify'] ?? 'on',
						'status'       => $resi_status,
					];
					self::send_email_notify_admin_user( $settings, $args );
					break;
			}
		}
	}

	/**
	 * Return mail body markup
	 *
	 * @param $args
	 *
	 * @return string
	 */
	public static function mail_body_markup( $args, $context = 'client' ) {
		$booked_seats_info = FnsPro::get_booked_seats_info( $args['resi_id'] );
		$total_seat        = join( '<br>', $booked_seats_info );
		$booking_date      = $args['booking_date'] ?? '';
		$rows              = '';

		$color = '';
		if ( ! empty( $args['status'] ) && $status = $args['status'] ) {
			if ( 'confirmed' == $status ) {
				$color = '#28a745';
			} elseif ( 'pending' == $status ) {
				$color = '#F3B604';
			} elseif ( 'cancelled' == $status ) {
				$color = '#6c757d';
			} elseif ( 'completed' == $status ) {
				$color = '#007bff';
			}
		}
		// Reservation ID
		if ( $context === 'admin' && ! empty( $args['recipient'] ) ) {
			$rows .= '
	<tr>
	  <td style="vertical-align: top;padding: 10px 0; border-bottom: 1px solid #eeeeee; font-weight: bold; color: #333333;">Customer Info:</td>
	  <td style="vertical-align: top;padding: 10px 0; border-bottom: 1px solid #eeeeee; color: #555555;">' . esc_html( $args['recipient'] ) . '<br>' . esc_html( $args['resi_email'] ) . '<br>' . esc_html( $args['fmp_phone'] ) . '</td>
	</tr>';
		}

		// Reservation ID
		if ( ! empty( $args['invoice'] ) ) {
			$rows .= '
	<tr>
	  <td style="vertical-align: top;padding: 10px 0; border-bottom: 1px solid #eeeeee; font-weight: bold; color: #333333;">Reservation ID:</td>
	  <td style="vertical-align: top;padding: 10px 0; border-bottom: 1px solid #eeeeee; color: #555555;">' . esc_html( $args['invoice'] ) . '</td>
	</tr>';
		}

		// Booking Date
		if ( ! empty( $booking_date ) ) {
			$rows .= '
	<tr>
	  <td style="vertical-align: top;padding: 10px 0; border-bottom: 1px solid #eeeeee; font-weight: bold; color: #333333;">Booking Date:</td>
	  <td style="vertical-align: top;padding: 10px 0; border-bottom: 1px solid #eeeeee; color: #555555;">' . esc_html( $booking_date ) . '</td>
	</tr>';
		}

		// Seats
		if ( ! empty( $total_seat ) ) {
			$rows .= '
	<tr>
	  <td style="vertical-align: top;padding: 10px 0; border-bottom: 1px solid #eeeeee; font-weight: bold; color: #333333;">Seats:</td>
	  <td style="vertical-align: top;padding: 10px 0; border-bottom: 1px solid #eeeeee; color: #555555;">' . esc_html( $total_seat ) . '</td>
	</tr>';
		}

		$mail_body = '
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Reservation Confirmation</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; margin: 0;">
  <table width="100%" cellpadding="0" cellspacing="0" style="max-width: 600px; margin: auto; background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); overflow: hidden;">
    <tr>
      <td style="vertical-align: top;background-color: ' . $color . '; padding: 20px; color: #ffffff; text-align: center;">
        <h2 style="margin: 0;">Reservation Details</h2>
      </td>
    </tr>
    <tr>
      <td style="vertical-align: top;padding: 20px;">
        <p style="font-size: 16px; color: #555555;">' . nl2br( esc_html( $args['msg'] ) ) . '</p>

        <table cellpadding="0" cellspacing="0" width="100%" style="margin-top: 20px; border-collapse: collapse;">'
		             . $rows .
		             '</table>
      </td>
    </tr>
    <tr>
      <td style="vertical-align: top;padding: 20px; text-align: center; font-size: 12px; color: #888888;">
        &copy; ' . date( 'Y' ) . ' ' . esc_html( get_bloginfo( 'name' ) ) . '. All rights reserved.
      </td>
    </tr>
  </table>
</body>
</html>';

		return $mail_body;
	}

	/**
	 * Input field validation for visual table
	 *
	 * @param array $request .
	 * @param array $input_fields .
	 *
	 * @return array
	 */
	public static function input_field_validation( $request, $input_fields ) {
		if ( ! empty( $input_fields ) ) {
			$error_fields = [];

			foreach ( $input_fields as $field ) {
				$name = $field['name'];
				if ( $field['required'] && empty( $request[ $name ] ) ) {
					$error_fields[] = esc_html( ucfirst( str_replace( '_', ' ', $name ) ) . ' is empty' );
				}
			}

			if ( ! empty( $error_fields ) ) {
				$response = [
					'status_code' => 0,
					'messages'    => $error_fields,
				];
			} else {
				$input_data = [];

				foreach ( $input_fields as $field ) {
					$name                = $field['name'];
					$data                = sanitize_text_field( $request[ $name ] );
					$input_data[ $name ] = $data;
				}

				$response = [
					'status_code' => 1,
					'messages'    => [],
					'data'        => $input_data,
				];
			}
		} else {
			$response = [
				'status_code' => 0,
				'messages'    => [
					'empty_input' => esc_html__( 'Input field is empty', 'food-menu-pro' ),
				],
			];
		}

		return $response;
	}

	/**
	 * Get Booking data
	 *
	 * @param string $selected_date .
	 * @param string $start_time .
	 * @param string $end_time .
	 *
	 * @return array
	 */
	public static function get_booking_data( $selected_date = '', $start_time = '', $end_time = '' ) {
		$booking_data = [
			'booking_open'     => 0,
			'booked_total'     => 0,
			'capacity'         => 0,
			'booked_ids'       => [],
			'booked_table_ids' => [],
		];

		if ( ! empty( $selected_date ) ) {
			$reservation              = Reservation::get_instance()->resi_capacity_status( $selected_date, $start_time, $end_time, 'table_layout' );
			$booking_data['capacity'] = $reservation['capacity'];

			if ( in_array( $reservation['status'], [ 'open', 'closed' ], true ) ) {
				$booking_data['booking_open']     = 1;
				$booking_data['booked_total']     = $reservation['date_booked_total'];
				$booking_data['booked_ids']       = ! empty( $reservation['date_booked_ids'] ) ? array_merge( ...$reservation['date_booked_ids'] ) : [];
				$booking_data['booked_table_ids'] = ! empty( $reservation['date_booked_table_ids'] ) ? array_merge( ...$reservation['date_booked_table_ids'] ) : [];
			}
		}

		return $booking_data;
	}

	/**
	 * Get booked seats info
	 *
	 * @param number $post_id .
	 *
	 * @return array
	 */
	public static function get_booked_seats_info( $post_id = 0 ) {
		$booked_seats_info = [];
		$booked_ids        = get_post_meta( $post_id, 'fmp_resi_meta_booked_ids', true ); //store all chair ids
		$booked_ids        = maybe_unserialize( $booked_ids );

		// Check if booked_ids empty then return.
		if ( empty( $booked_ids ) && ! is_array( $booked_ids ) ) {
			return $booked_seats_info;
		}

		$obj_names        = get_post_meta( $post_id, 'fmp_resi_meta_obj_names', true ); //total object of the canvas
		$intersected_data = get_post_meta( $post_id, 'fmp_resi_meta_intersected_data', true ); //all chairs under the table

		if ( empty( $obj_names ) ) {
			return $booked_seats_info;
		}

		$obj_names        = json_decode( $obj_names, true );
		$intersected_data = json_decode( $intersected_data, true );

		return self::process_booked_seats_info( $booked_ids, $obj_names, $intersected_data );
	}

	/**
	 * Booked seats info
	 *
	 * @param array $booked_ids .
	 * @param array $obj_names .
	 * @param array $intersected_data .
	 *
	 * @return array
	 */
	private static function process_booked_seats_info( $booked_ids, $obj_names, $intersected_data ) {
		$table_chairs      = [];
		$table_chair_names = [];

		foreach ( $intersected_data as $table_id => $chair_arr ) {
			$table_chairs[ $table_id ] = [];

			// Check if all chairs under a table are booked.
			if ( empty( array_diff( $chair_arr, $booked_ids ) ) ) {
				$booked_ids = array_diff( $booked_ids, $chair_arr );
				//$table_chair_names[] = $obj_names[ $table_id ] . ' / ' . esc_html__( 'All chairs', 'food-menu-pro' ) . ' (' . count( $chair_arr ) . ')';

				$table_chair_names[] = sprintf(
					"<span class='table-name'>%s</span> : <span class='chair-name all-chair-book'>%s</span>",
					esc_html( $obj_names[ $table_id ] ),
					esc_html__( 'All chairs booked', 'food-menu-pro' ) . ' (' . count( $chair_arr ) . ')'
				);
			} else {
				foreach ( $booked_ids as $index => $booked_id ) {
					// Check if the booked chair belongs to the current table.
					if ( in_array( $booked_id, $chair_arr ) ) {
						$table_chairs[ $table_id ][] = $obj_names[ $booked_id ];
						unset( $booked_ids[ $index ] );
					}
				}
			}
		}

		// Format booked chairs for each table.
		foreach ( $table_chairs as $t_id => $t_chairs ) {
			if ( ! empty( $t_chairs ) ) {
				//$table_chair_names[] = $obj_names[ $t_id ] . ' / ' . join( ', ', $t_chairs );

				$table_chair_names[] = sprintf(
					"<span class='table-name'>%s</span> : %s",
					esc_html( $obj_names[ $t_id ] ),
					implode( '<span class="separate">, </span>', array_map( function( $chair ) {
						return '<span class="chair-name">' . esc_html( $chair ) . '</span>';
					}, $t_chairs ) )
				);
			}
		}

		// Format individually booked chairs.
		foreach ( $booked_ids as $booked_id ) {
			$table_chair_names[] = $obj_names[ $booked_id ];
		}

		return $table_chair_names;
	}

	/**
	 * Get reservation message.
	 *
	 * @param array $settings .
	 * @param string $type .
	 *
	 * @return mixed
	 */
	public static function get_reservation_message( $settings, $type, $booking_id = '' ) {
		// Default messages.
		$default_messages = [
			'pending' => esc_html__( 'Thank you for your booking. Your reservation is currently pending. We will notify you once it has been confirmed.', 'food-menu-pro' ),
			'confirm' => esc_html__( 'Thank you for your booking. Your reservation has been successfully confirmed.', 'food-menu-pro' ),
			'cancel'  => esc_html__( 'Your cancellation request has been successfully processed.', 'food-menu-pro' ),
		];

		// Settings keys corresponding to each type.
		$settings_keys = [
			'pending' => 'fmp_resi_pending_msg',
			'confirm' => 'fmp_resi_confirm_msg',
			'cancel'  => 'fmp_resi_cancel_msg',
		];

		$message = ! empty( $settings[ $settings_keys[ $type ] ] ) ? $settings[ $settings_keys[ $type ] ] : $default_messages[ $type ];

		if ( $booking_id ) {
			$message .= " - Booking ID: $booking_id";
		}

		// Retrieve the message from settings or use the default message.
		return $message;
	}

	/**
	 * Get reservation list.
	 *
	 * @return int[]|\WP_Post[]
	 */
	public static function get_reservation_list() {
		return get_posts(
			[
				'post_type'   => 'fmp_reservation',
				'numberposts' => - 1,
				'post_status' => 'publish',
			]
		);
	}

	/**
	 * Clear any cache plugins
	 */
	public static function site_cache_clear() {
		wp_cache_flush();

		$cleared_cache = false;

		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
			$cleared_cache = true;
		}

		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
			$cleared_cache = true;
		}

		if ( function_exists( 'opcache_reset' ) && ! ini_get( 'opcache.restrict_api' ) ) {
			@opcache_reset();
			$cleared_cache = true;
		}

		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
			$cleared_cache = true;
		}

		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
			$cleared_cache = true;
		}

		global $wp_fastest_cache;
		if ( method_exists( 'WpFastestCache', 'deleteCache' ) && ! empty( $wp_fastest_cache ) ) {
			$wp_fastest_cache->deleteCache();
			$cleared_cache = true;
		}

		// If your host has installed APC cache this plugin allows you to clear the cache from within WordPress
		if ( function_exists( 'apc_clear_cache' ) ) {
			apc_clear_cache();
			$cleared_cache = true;
		}

		if ( function_exists( 'fvm_purge_all' ) ) {
			fvm_purge_all();
			$cleared_cache = true;
		}

		if ( class_exists( 'autoptimizeCache' ) ) {
			autoptimizeCache::clearall();
			$cleared_cache = true;
		}

		// WPEngine
		if ( class_exists( 'WpeCommon' ) ) {
			if ( method_exists( 'WpeCommon', 'purge_memcached' ) ) {
				WpeCommon::purge_memcached();
			}
			if ( method_exists( 'WpeCommon', 'clear_maxcdn_cache' ) ) {
				WpeCommon::clear_maxcdn_cache();
			}
			if ( method_exists( 'WpeCommon', 'purge_varnish_cache' ) ) {
				WpeCommon::purge_varnish_cache();
			}

			$cleared_cache = true;
		}

		if ( class_exists( 'Cache_Enabler_Disk' ) && method_exists( 'Cache_Enabler_Disk', 'clear_cache' ) ) {
			Cache_Enabler_Disk::clear_cache();
			$cleared_cache = true;
		}

		// Perfmatters
		if ( class_exists( 'Perfmatters\CSS' ) && method_exists( 'Perfmatters\CSS', 'clear_used_css' ) ) {
			Perfmatters\CSS::clear_used_css();
			$cleared_cache = true;
		}

		if ( defined( 'BREEZE_VERSION' ) ) {
			do_action( 'breeze_clear_all_cache' );
			$cleared_cache = true;
		}

		if ( function_exists( 'sg_cachepress_purge_everything' ) ) {
			sg_cachepress_purge_everything();
			$cleared_cache = true;
		}

		if ( defined( 'FLYING_PRESS_VERSION' ) ) {
			do_action( 'flying_press_purge_everything:before' );

			wp_delete_file( FLYING_PRESS_CACHE_DIR . '/preload.txt' );

			// Delete all files and subdirectories.
			FlyingPress\Purge::purge_everything();

			//phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_mkdir
			@mkdir( FLYING_PRESS_CACHE_DIR, 0755, true );

			do_action( 'flying_press_purge_everything:after' );

			$cleared_cache = true;
		}

		if ( class_exists( '\LiteSpeed\Purge' ) ) {
			\LiteSpeed\Purge::purge_all();
			$cleared_cache = true;
		}

		return $cleared_cache;
	}

	/**
	 * Tip Information generate
	 *
	 * @param $order
	 *
	 * @return array
	 */
	public static function tip_information( $order ) {
		$order_amout           = $order->get_total();
		$fmp_tip_type          = $order->get_meta( 'fmp_tip_type' );
		$fmp_percentage_amount = $order->get_meta( 'fmp_percentage_amount' );
		$fmp_fixed_amount      = $order->get_meta( 'fmp_fixed_amount' );

		if ( 'fixed' === $fmp_tip_type ) {
			$tip_prefix = esc_html__( 'Fixed', 'food-menu-pro' );
			$tip_amount = $fmp_fixed_amount;
		} else {
			$tip_prefix = sprintf( esc_html__( '%s of %s', 'food-menu-pro' ),
				esc_html( $fmp_percentage_amount ) . '%',
				esc_html( $order_amout ),
			);
			$amount     = ( strpos( $fmp_percentage_amount, '.' ) !== false ) ? (float) $fmp_percentage_amount : (int) $fmp_percentage_amount;

			$tip_amount = $order_amout / 100 * $amount;
		}

		return [
			'prefix' => $tip_prefix,
			'amount' => $tip_amount,
		];
	}

}
