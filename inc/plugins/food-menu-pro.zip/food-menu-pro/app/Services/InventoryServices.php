<?php
/**
 * Inventory Controller.
 *
 * @package RT_FoodMenu
 */

namespace RT\FoodMenuPro\Services;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Models\InventoryModel;

/**
 * InventoryController Class.
 */
class InventoryServices {

	private $inventoryModal;

	public function __construct() {
		$this->inventoryModal = new InventoryModel();
	}


	/**
	 * When plugin activate the seeding process will run automatically
	 * for the opening inventory of all product who have the inventory enable
	 *
	 * @param $model
	 *
	 * @return void
	 */
	public function inventory_seeding() {
		if ( get_option( 'fmp_inventory_seeding' ) ) {
			return;
		}
		$products = wc_get_products( [
			'limit'        => - 1,
			'manage_stock' => true,
			'status'       => 'publish',
		] );

		foreach ( $products as $product ) {

			// opening_inventory exist
			if ( $this->inventoryModal->has_opening_log( $product->get_id() ) ) {
				continue;
			}

			$stock = $product->get_stock_quantity();

			if ( ! $stock || $stock <= 0 ) {
				$stock = 0;
			}

			$this->inventoryModal->insert_inventory_log( [
				'product_id'  => $product->get_id(),
				'change_type' => 'add',
				'quantity'    => $stock,
				'reason'      => 'opening_inventory',
			] );
			update_post_meta( $product->get_id(), '_fmp_inventory', '1' );
		}

		update_option( 'fmp_inventory_seeding', '1' );
	}

	/**
	 * Product wise add opening log when enable one by one product later install the plugins
	 *
	 * @param $model
	 * @param $product_id
	 *
	 * @return void
	 */
	public function add_opening_log( $product_id ) {

		/*if ( defined( 'FMP_INVENTORY_INTERNAL_UPDATE' ) && FMP_INVENTORY_INTERNAL_UPDATE ) {
			return;
		}*/

		if ( ! empty( $GLOBALS['fmp_inventory_internal_update'] ) ) {
			return;
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->managing_stock() ) {
			return;
		}

		// opening_inventory exist
		if ( $this->inventoryModal->has_opening_log( $product->get_id() ) ) {
			return;
		}

		$stock = $product->get_stock_quantity();

		if ( $stock === null ) {
			return;
		}

		$this->inventoryModal->insert_inventory_log( [
			'product_id'  => $product_id,
			'change_type' => 'opening',
			'quantity'    => $stock,
			'reason'      => 'opening_inventory',
		] );

		update_post_meta( $product_id, '_fmp_inventory', '1' );
	}


	/**
	 * Manual add inventory.
	 * This function helps to add any kind of logs with difference change_type and reason.
	 * Default change type: 'add', default reason: 'manual_add'
	 *
	 * @param int $product_id
	 * @param int $qty
	 * @param string $note
	 * @param string $change_type
	 * @param string $reason
	 *
	 * @return bool|int|\WP_Error|null
	 */
	public function add_inventory_qty( int $product_id, int $qty, string $note = '', string $change_type = 'add', string $reason = 'manual_add', $date = '', array $extra = [] ) {

		if ( $qty <= 0 ) {
			return new \WP_Error( 'invalid_qty', 'Quantity must be greater than zero' );
		}

		/*	if ( ! defined( 'FMP_INVENTORY_INTERNAL_UPDATE' ) ) {
				define( 'FMP_INVENTORY_INTERNAL_UPDATE', true );
			}*/

		$GLOBALS['fmp_inventory_internal_update'] = true;

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return new \WP_Error( 'invalid_product', 'Invalid product ID #' . $product_id );
		}

		if ( ! $product->managing_stock() ) {
			return new \WP_Error(
				'stock_disabled',
				'Stock management is disabled for this product'
			);
		}

		if ( $product->get_stock_quantity() === null ) {
			$product->set_stock_quantity( 0 );
			$product->save();
		}

		$operation = in_array( $change_type, [ 'add', 'adj_add', 'purchase' ] ) ? 'increase' : 'decrease';

		$result = wc_update_product_stock( $product, $qty, $operation );
		// Force status + save
		$product->set_stock_status( 'instock' );
		$product->save();


		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$log_data = [
			'product_id'  => $product_id,
			'change_type' => $change_type,
			'quantity'    => $qty,
			'reason'      => $reason,
			'note'        => $note,
			'occurred_at' => $date,
		];

		if ( ! empty( $extra['supplier_name'] ) ) {
			$log_data['supplier_name'] = $extra['supplier_name'];
		}
		if ( isset( $extra['cost_price'] ) && is_numeric( $extra['cost_price'] ) ) {
			$log_data['cost_price'] = $extra['cost_price'];
		}

		$this->inventoryModal->insert_inventory_log( $log_data );
		$GLOBALS['fmp_inventory_internal_update'] = false;

		delete_transient( FnsPro::dashboard_stats_cache_key() );

		return true;
	}

	/**
	 * @param int $product_id
	 * @param int $opening_qty
	 * @param string $note
	 * @param bool $hasOpeningPreviously
	 * @param array $extra Optional `supplier_name` / `cost_price` for the opening log.
	 *
	 * @return true|\WP_Error
	 */
	public function enable_inventory_with_opening_stock( int $product_id, int $opening_qty, string $note = '', $hasOpeningPreviously = false, array $extra = [] ) {

		if ( $opening_qty < 0 ) {
			return new \WP_Error( 'invalid_qty', 'Opening stock must be zero or greater.' );
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return new \WP_Error( 'invalid_product', 'Invalid product ID #' . $product_id );
		}

		// Prevent recursive hooks
		/*if ( ! defined( 'FMP_INVENTORY_INTERNAL_UPDATE' ) ) {
			define( 'FMP_INVENTORY_INTERNAL_UPDATE', true );
		}*/
		$GLOBALS['fmp_inventory_internal_update'] = true;
		// Enable inventory management
		$product->set_manage_stock( true );

		// Set opening stock
		$product->set_stock_quantity( $opening_qty );

		// Set stock status properly
		$product->set_stock_status(
			$opening_qty > 0 ? 'instock' : 'outofstock'
		);

		$product->save();

		// Log inventory action
		if ( ! $hasOpeningPreviously ) {
			$log_data = [
				'product_id'  => $product_id,
				'change_type' => 'opening',
				'quantity'    => $opening_qty,
				'reason'      => 'opening_inventory',
				'note'        => $note,
			];

			// Cost price on the opening log is what makes the money reports
			// (valuation, profit, waste cost) work for a product whose stock
			// never went through a separate "Add" entry.
			if ( ! empty( $extra['supplier_name'] ) ) {
				$log_data['supplier_name'] = $extra['supplier_name'];
			}
			if ( isset( $extra['cost_price'] ) && is_numeric( $extra['cost_price'] ) ) {
				$log_data['cost_price'] = $extra['cost_price'];
			}

			$this->inventoryModal->insert_inventory_log( $log_data );
		}

		update_post_meta( $product_id, '_fmp_inventory', '1' );

		$GLOBALS['fmp_inventory_internal_update'] = false;

		delete_transient( FnsPro::dashboard_stats_cache_key() );

		return true;
	}

	/**
	 * Manual wastage.
	 */
	public function add_wastage_qty( int $product_id, int $qty, $reason, string $note = '', $date = '' ) {

		if ( $qty <= 0 ) {
			return new \WP_Error( 'invalid_qty', 'Quantity must be greater than zero' );
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return new \WP_Error( 'invalid_product', 'Invalid product ID #' . $product_id );
		}

		/*if ( ! defined( 'FMP_INVENTORY_INTERNAL_UPDATE' ) ) {
			define( 'FMP_INVENTORY_INTERNAL_UPDATE', true );
		}*/
		$GLOBALS['fmp_inventory_internal_update'] = true;

		$result = wc_update_product_stock( $product, $qty, 'decrease' );

		if ( is_wp_error( $result ) ) {
			return $result;
		}


		$this->inventoryModal->insert_inventory_log( [
			'product_id'  => $product_id,
			'change_type' => 'wastage',
			'quantity'    => $qty,
			'reason'      => $reason,
			'occurred_at' => $date,
			'note'        => $note,
		] );

		$GLOBALS['fmp_inventory_internal_update'] = false;

		delete_transient( FnsPro::dashboard_stats_cache_key() );
	}

}
