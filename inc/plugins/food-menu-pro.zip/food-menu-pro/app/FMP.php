<?php
/**
 * Main initialization class.
 *
 * @package RT_FoodMenuPro
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

require_once FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'vendor/autoload.php';

use RT\FoodMenu\Helpers as Helpers;
use RT\FoodMenuPro\Api as Api;
use RT\FoodMenuPro\Controllers as Controllers;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Helpers\ScheduleMigration;
use RT\FoodMenuPro\Helpers\Upgrade;
use RT\FoodMenu\Helpers\Upgrade as FreeUpgrade;

if ( ! class_exists( FMP::class ) ) {
	/**
	 * Main initialization class.
	 */
	final class FMP {

		use RT\FoodMenuPro\Traits\SingletonTrait;

		/**
		 * Options
		 *
		 * @var array
		 */
		public $options;

		/**
		 * Class init.
		 *
		 * @return void
		 */
		protected function init() {
			if ( ! $this->has_free() ) {
				return;
			}

			// Checks for Free and checks version.
			if ( ! $this->check_free() ) {
				return;
			}

			// Defaults.
			$this->defaults();

			// Hooks.
			$this->init_hooks();
		}

		/**
		 * Checks for Free and checks version.
		 *
		 * @return bool True if compatible, false otherwise.
		 */
		private function check_free() {
			if ( false === Upgrade::check_plugin_version() ) {
				return false;
			}

			add_action( 'admin_init', [ __CLASS__, 'admin_init_notice' ] );

			return true;
		}

		public static function admin_init_notice() {
			if ( ! function_exists( 'get_plugin_data' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			$fm_free_path = WP_PLUGIN_DIR . '/tlp-food-menu/tlp-food-menu.php';

			if ( file_exists( $fm_free_path ) ) {
				$plugin_data = get_plugin_data( $fm_free_path );

				if ( isset( $plugin_data['Version'] ) ) {
					if ( version_compare( $plugin_data['Version'], FOOD_MENU_PRO_REQUIRED_FREE_VERSION, '<' ) ) {
						FreeUpgrade::notice();
					}
				}
			}
		}

		/**
		 * Defaults
		 *
		 * @return void
		 */
		private function defaults() {
			$this->options = [
				'version'           => FOOD_MENU_PRO_VERSION,
				'installed_version' => 'fmp-installed-version',
			];

			TLPFoodMenu()->taxonomies['tag']        = TLPFoodMenu()->post_type . '-tag';
			TLPFoodMenu()->taxonomies['ingredient'] = TLPFoodMenu()->post_type . '-ingredient';
			TLPFoodMenu()->taxonomies['nutrition']  = TLPFoodMenu()->post_type . '-nutrition';
			TLPFoodMenu()->taxonomies['unit']       = TLPFoodMenu()->post_type . '-unit';
		}

		/**
		 * Init Hooks.
		 *
		 * @return void
		 */
		private function init_hooks() {
			// Not in controllers(): that list is instantiated on `init` and is
			// skipped entirely in debug mode, while `determine_current_user`
			// can fire as soon as anything asks who is logged in. The filter
			// has to already be attached by then, so it is attached here, at
			// plugin load.
			Api\App\AppAuthentication::get_instance();

			add_action( 'plugins_loaded', [ $this, 'on_plugins_loaded' ], - 1 );
			add_action( 'init', [ $this, 'initialize' ], 0 );
			add_action( 'update_option_tpl_food_menu_settings', [ FnsPro::class, 'sync_dashboard_roles' ], 10, 2 );
			// Also runs on every AJAX save (even when the settings value is unchanged), so menu caps
			// stay in sync after a plugin update that changes the capability schema.
			add_action( 'fmp_settings_saved', [ FnsPro::class, 'sync_dashboard_roles' ], 10, 2 );
		}

		/**
		 * Init Hooks
		 *
		 * @return void
		 */
		public function initialize() {
			\do_action( 'rtfmp_init' );

			if ( isset( $_GET['rtcl-debug-on'] ) ) {
				return;
			}
			$this->load_text_domain();
			$this->update_version();

			ScheduleMigration::maybe_migrate();

			Helpers\Fns::instances( $this->controllers() );
		}

		/**
		 * Load plugin text domain.
		 *
		 * @return void
		 */
		public function load_text_domain() {
			$locale = determine_locale();
			$locale = apply_filters( 'rtfm_plugin_locale', $locale );

			unload_textdomain( 'food-menu-pro' );
			load_textdomain( 'food-menu-pro', WP_LANG_DIR . '/food-menu-pro/food-menu-pro-' . $locale . '.mo' );
			load_plugin_textdomain( 'food-menu-pro', false, FOOD_MENU_PRO_LANGUAGE_PATH );
		}

		/**
		 * Update Version.
		 *
		 * @return void
		 */
		public function update_version() {
			\update_option( FMP()->options['installed_version'], FMP()->options['version'] );
		}

		/**
		 * Controllers.
		 *
		 * @return array
		 */
		public function controllers() {
			$controllers = [];

			if ( is_admin() ) {
				$controllers[] = Controllers\AdminController::class;
			}

			$controllers[] = Controllers\PostTypesController::class;
			$controllers[] = Controllers\ScriptsController::class;
			$controllers[] = Controllers\FrontendController::class;
//			$controllers[] = Controllers\FrontendOrderController::class; //Sould be remove later
			$controllers[] = Controllers\AjaxController::class;
			$controllers[] = Controllers\PickupDelivery\PickupDelivery::class;
			$controllers[] = Controllers\Discount\Discount::class;
			$controllers[] = Controllers\ProductAddons\Admin\AdminPAddons::class;
			$controllers[] = Controllers\ProductAddons\Frontend\FrontendPAddon::class;
			$controllers[] = Controllers\ProductAddons\Frontend\FrontendCartAction::class;
			$controllers[] = Controllers\OrderBumps\OrderBumps::class;
			$controllers[] = Controllers\FrontendDashboardController::class;

			if ( did_action( 'elementor/loaded' ) ) {
				$controllers[] = Controllers\ElementorController::class;
			}
			$controllers[] = Controllers\Reservation\TableLayoutReservation::class;
			$controllers[] = Controllers\TableLayout\TableLayout::class;
			$controllers[] = Controllers\OrderStatuses\OrderStatuses::class;
			$controllers[] = Controllers\PosPrinting\PosPrinting::class;
			$controllers[] = Controllers\QrTableOrdering\QrTableOrdering::class;
			$controllers[] = Controllers\Checkout\CustomCheckout::class;
			$controllers[] = Controllers\TimedProducts\TimedProducts::class;
			$controllers[] = Controllers\Admin\Metabox\ProductOrderLimit::class;
			$controllers[] = Controllers\Admin\Metabox\OrderInfoMetabox::class;
			$controllers[] = Controllers\KitchenMonitor\KitchenMonitorController::class;
			$controllers[] = Controllers\OrderTracking\OrderTracking::class;

			if ( Controllers\OrderTimeline\OrderTimelineFns::is_enabled() ) {
				$controllers[] = Controllers\OrderTimeline\OrderTimeline::class;
			}

			$controllers[] = Controllers\ProductFoodData\ProductFoodData::class;

			// Mobile app API. Booted unconditionally — unlike the staff APIs in
			// FrontendDashboardController, these must answer even when the
			// dashboard page is not in play.
			$controllers[] = Api\App\AuthApi::class;
			$controllers[] = Api\App\MeApi::class;
			$controllers[] = Api\App\WishlistApi::class;
			$controllers[] = Api\App\AddressFieldsApi::class;
			$controllers[] = Api\App\AccountSecurityApi::class;
			$controllers[] = Api\App\AppProductStoreApi::class;
			$controllers[] = Api\App\AddonsApi::class;
			$controllers[] = Api\App\AppCartAddons::class;
			$controllers[] = Api\App\AppCartItemAddons::class;
			$controllers[] = Api\App\OrderTypesApi::class;
			$controllers[] = Api\App\SlotsApi::class;
			$controllers[] = Api\App\BranchesApi::class;
			$controllers[] = Api\App\PaymentMethodsApi::class;
			$controllers[] = Api\App\AppOrdersApi::class;
			$controllers[] = Api\App\AppTrackingApi::class;
			$controllers[] = Api\App\AppReorderApi::class;
			$controllers[] = Api\App\AppBranchScope::class;

			$controllers[] = Controllers\WhatsAppNotificationController::class;

			return $controllers;
		}

		/**
		 * Actions on Plugins Loaded.
		 *
		 * @return void
		 */
		public function on_plugins_loaded() {
			do_action( 'rtfmp_loaded' );
		}

		/**
		 * PRO plugin path
		 *
		 * @return string
		 */
		public function pro_plugin_path() {
			return untrailingslashit( plugin_dir_path( FOOD_MENU_PRO_PLUGIN_PATH ) );
		}

		/**
		 * Plugin Template path
		 *
		 * @return string
		 */
		public function plugin_template_path() {
			return $this->pro_plugin_path() . '/templates/';
		}

		/**
		 * Checks if Free version installed
		 *
		 * @return boolean
		 */
		public function has_free() {
			return class_exists( 'TLPFoodMenu' );
		}

		/**
		 * Assets URL.
		 *
		 * @return string
		 */
		public function assets_url() {
			return esc_url( FOOD_MENU_PRO_PLUGIN_URL . '/assets/' );
		}

		/**
		 * Plugin Controller path
		 *
		 * @return string
		 */
		public function plugin_controllers_path() {
			return trailingslashit( $this->pro_plugin_path() . '/app/Controllers/' );
		}

	}

	/**
	 * Returns FMP.
	 *
	 * @return FMP
	 */
	function FMP() {
		return FMP::get_instance();
	}

	/**
	 * App Init.
	 */
	add_action( 'plugins_loaded', 'FMP', 20 );
}
