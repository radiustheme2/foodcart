<?php
namespace RT\FoodMenuPro\Abstracts;

defined( 'ABSPATH' ) || exit;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * CustomApi class
 */
abstract class CustomApi {

	/**
	 * Admin settings
	 *
	 * @var array
	 */
	protected $settings;

	/**
	 * Request method
	 *
	 * @var null
	 */
	protected $request = null;

	/**
	 * Constructor function
	 */
	public function __construct() {
		$this->settings = FnsPro::get_settings_option();
		$this->init();
	}

	/**
	 * Init function
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'rest_api_init', [ $this,'register_api_rest_route' ] );
	}

	/**
	 * Register api route
	 *
	 * @return void
	 */
	public function register_api_rest_route() {

		$namespace = untrailingslashit( 'fmp/' );

		// Define the base route for your custom endpoint.
		$base_route = '/(?P<action>\w+)/'; //GET, POST, PUT, etc

		// Define the options for your custom endpoint.
		$args = [
			'methods'             => \WP_REST_Server::ALLMETHODS,
			'callback'            => [ $this,'callback_custom_request' ],
			// Reading is public (the frontend reservation form renders the layout); writing is admin-only.
			'permission_callback' => static function ( $request ) {
				return 'GET' === $request->get_method() || current_user_can( 'manage_options' );
			},
		];

		register_rest_route( $namespace, $base_route, $args );
	}

	/**
	 * Rest route callback function
	 *
	 * @param object $request .
	 * @return method
	 */
	public function callback_custom_request( $request ) {
		$this->request   = $request;

		$method_name = strtolower( $this->request->get_method() ) . '_' . $this->request['action']; // post_table_option

		if ( method_exists( $this, $method_name ) ) {
			return $this->{$method_name}();
		}
	}
}
