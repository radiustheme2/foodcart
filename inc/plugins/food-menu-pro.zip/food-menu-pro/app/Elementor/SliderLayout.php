<?php
/**
 * Elementor GridCatLayout Widget Class.
 *
 * @package RT_FoodMenu
 */

namespace RT\FoodMenuPro\Elementor;

use RT\FoodMenu\Models\QueryArgs;
use RT\FoodMenu\Abstracts\ElementorWidget;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenu\Helpers\RenderHelpers;
use RT\FoodMenu\Widgets\Elementor\Sections\{
	Style,
	Layout,
	Settings
};

/**
 * Elementor GridCatLayout Widget Class.
 */
class SliderLayout extends ElementorWidget {
	/**
	 * Class constructor.
	 *
	 * @param array $data default data.
	 * @param array $args default arg.
	 */
	public function __construct( $data = [], $args = null ) {
		$this->elBase   = 'rtfm-food-slider-layout';
		$this->elName   = esc_html__( 'Slider Layouts', 'food-menu-pro' );
		$this->elIcon   = 'rtfm-elementor-icon eicon-gallery-grid';
		$this->elPrefix = 'slider';
		parent::__construct( $data, $args );
	}

	/**
	 * Controls for layout tab
	 *
	 * @return object
	 */

	protected function layoutTab() {
		$sections = [
			'grid_layout'   => [ $this, $this->elPrefix ],
			'columnsSlider' => [ $this ],
			'query'         => [ $this ],
			'image'         => [ $this ],
		];
		foreach ( $sections as $method => $args ) {
			if ( method_exists( Layout::class, $method ) ) {
				call_user_func_array( [ Layout::class, $method ], $args );
			}
		}
		return $this;
	}

	/**
	 * Controls for settings tab
	 *
	 * @return object
	 */
	protected function settingsTab() {
		$sections = [
			'ContentVisibility',
			'slider',
			'links',
			'contentLimit',
		];
		foreach ( $sections as $section ) {
			Settings::$section( $this );
		}

		return $this;
	}

	/**
	 * Controls for style tab
	 *
	 * @return object
	 */
	protected function styleTab() {

		$sections = apply_filters(
			'fm_grid_layout_section',
			[
				'globaltSection',
				'catSection',
				'titleSection',
				'priceSection',
				'excerptSection',
				'imageSection',
				'readmoreButton',
				'addToCarButton',
				'sliderStyle',
			]
		);

		foreach ( $sections as $section ) {
			Style::$section( $this, $this->elPrefix );
		}

		return $this;
	}

	public function get_script_depends() {
		return [
			'fmp-swiper',
			'fmp-frontend'
		];
	}

	protected function render() {
		\wp_enqueue_script( 'fmp-modal' );
		wp_dequeue_script( 'fmp-swiper' );
		\wp_enqueue_script( 'fmp-swiper' );
		wp_dequeue_script( 'fmp-frontend' );
		\wp_enqueue_script( 'fmp-frontend' );

		$nonce   = wp_create_nonce( Fns::nonceText() );
		$ajaxurl = '';

		if ( in_array( 'sitepress-multilingual-cms/sitepress.php', get_option( 'active_plugins' ) ) ) {
			$ajaxurl .= admin_url( 'admin-ajax.php?lang=' . ICL_LANGUAGE_CODE );
		} else {
			$ajaxurl .= admin_url( 'admin-ajax.php' );
		}

		wp_localize_script(
			'fmp-frontend',
			'fmp',
			[
				'ajaxurl'     => esc_url( $ajaxurl ),
				'nonceID'     => esc_attr( Fns::nonceID() ),
				'nonce'       => esc_attr( $nonce ),
				'hasPro'      => TLPFoodMenu()->has_pro() ? 'true' : 'false',
				'wc_cart_url' => TLPFoodMenu()->isWcActive() ? wc_get_cart_url() : '',
			]
		);

		$settings = $this->get_settings_for_display();


		//Slider Settings

		$settings['fmp_slide_groups'] = $settings['fmp_desktop_column'] >2 ? 2 : $settings['fmp_desktop_column'];

		$sliderData = RenderHelpers::sliderMetaBuilderEl( $settings );

		$is_rtl   = is_rtl() ? 'rtl' : 'ltr';
		$nav      = ! empty( $sliderData['nav'] ) ? 1 : 0;
		$dots     = ! empty( $sliderData['dots'] ) ? 1 : 0;
		$lazyLoad = ! empty( $sliderData['lazyLoad'] ) ? 1 : 0;

		$scID = (int) $this->get_id();

		$animation = '';

		if ( 'zoom_out' === $settings['tlp_el_image_animation'] ) {
			$animation = 'fmp-hover-zoom_out';
		} elseif ( 'zoom_in' === $settings['tlp_el_image_animation'] ) {
			$animation = 'fmp-hover-zoom_in';
		}

		$layout  = isset( $settings['fmp_layout'] ) ? $settings['fmp_layout'] : '1';


		$base_arg = RenderHelpers::metaScBuilderEl( $settings );

		$args = ( new QueryArgs() )->buildArgs( $scID, $base_arg );

		if ( $base_arg['source'] === 'product' ) {
			$args['post_type'] = 'product';
			if ( ! empty( $args['tax_query'] ) && is_array( $args['tax_query'] ) ) {
				array_walk_recursive(
					$args['tax_query'],
					function ( &$value, $key ) {
						if ( 'taxonomy' === $key && 'food-menu-cat' === $value ) {
							$value = 'product_cat';
						}
					}
				);
			}
		}

		switch ( $layout ) {
			case 'layout2':
				$template = 'layout-slider-layout-2';
				break;
			case 'layout3':
				$template = 'layout-slider-layout-3';
				break;
			case 'layout4':
				$template = 'layout-slider-layout-4';
				break;
			default:
				$template = 'layout-slider-layout-1';
				break;
		}

		$desktop_col = $sliderData['dCols'] ?? 2;
		$query       = new \WP_Query( $args );


		echo "<div data-layout='" . esc_attr( $layout ) . "' data-desktop-col='" . esc_attr( $desktop_col ) . "' class='fmp-elementor-slider fmp-slider-isotope fmp-elementor-widget fmp-slider-layout-wrapper fmp-" . esc_attr( $layout ) . " " . esc_attr( $animation ) . " fmp-container-fluid fmp-wrapper fmp-grid-layout' id='fmp-container-" . esc_attr( $layout ) . " '>";
		echo "<div class='fmp-content-loader fmp-read-more-active'>";
		echo "<div dir='" . esc_attr( $is_rtl ) . "' class='fmp-carousel slider-loading " . esc_attr( $sliderData['class'] ) . " ' data-options='" . esc_js( $sliderData['data'] ) . "'>";
		echo "<div class='swiper-wrapper'>";

		if ( $query->have_posts() ) :
			while ( $query->have_posts() ) :
				$query->the_post();
				$post_id   = get_the_ID();
				$post_data = array(
					'ID'        => $post_id,
					'title'     => get_the_title(),
					'content'   => get_the_content(),
					'excerpt'   => get_the_excerpt(),
					'permalink' => get_permalink(),
					'image'     => get_the_post_thumbnail_url( $post_id, 'full' ),
					'meta'      => array(
						'price' => get_post_meta( $post_id, '_regular_price', true ),
					),
					'terms'     => wp_get_post_terms( $post_id, 'food-category', array( 'fields' => 'names' ) ),
				);

				$arg = array_merge( $base_arg, $post_data, array(
					'pID'      => $post_id,
					'lazyLoad' => $lazyLoad,
				) );
				Fns::render( 'elementor/' . $template, $arg );
			endwhile;
			wp_reset_postdata();

		else :
			echo 'No food menu items found.';
		endif;

		echo '</div>';


		if ( $nav == 1 ) {
			echo '<div class="swiper-nav"><div class="swiper-arrow swiper-button-next"><i class="fa fa-chevron-right"></i></div><div class="swiper-arrow swiper-button-prev"><i class="fa fa-chevron-left"></i></div></div>';
		}


		if ( $dots == 1 ) {
			echo '<div class="swiper-pagination rt-pos-s"></div>';
		}

		echo '</div>';

		echo '</div>';
		echo '</div>';

	}
}