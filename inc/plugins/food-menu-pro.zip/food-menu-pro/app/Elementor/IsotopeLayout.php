<?php
/**
 * Elementor GridCatLayout Widget Class.
 *
 * @package RT_FoodMenu
 */

namespace RT\FoodMenuPro\Elementor;

use RT\FoodMenu\Models\QueryArgs;
use RT\FoodMenu\Abstracts\ElementorWidget;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenu\Helpers\RenderHelpers;
use RT\FoodMenu\Widgets\Elementor\Sections\{
        Style,
        Layout,
        Settings
};

/**
 * Elementor GridCatLayout Widget Class.
 */
class IsotopeLayout extends ElementorWidget {
    /**
     * Class constructor.
     *
     * @param array $data default data.
     * @param array $args default arg.
     */
    public function __construct( $data = [], $args = null ) {
        $this->elBase   = 'rtfm-food-isotope-layout';
        $this->elName   = esc_html__( 'Isotope Layouts', 'food-menu-pro' );
        $this->elIcon   = 'rtfm-elementor-icon eicon-gallery-grid';
        $this->elPrefix = 'isotope';
        parent::__construct( $data, $args );
    }

    /**
     * Controls for layout tab
     *
     * @return object
     */

    protected function layoutTab() {
        $sections = [
                'grid_layout'  => [ $this, $this->elPrefix ],
                'columns'      => [ $this ],
                'queryIsotope' => [ $this ],
                'pagination'   => [ $this ],
                'image'        => [ $this ],
        ];
        foreach ( $sections as $method => $args ) {
            if ( method_exists( Layout::class, $method ) ) {
                call_user_func_array( [ Layout::class, $method ], $args );
            }
        }

        return $this;
    }

    /**
     * Controls for settings tab
     *
     * @return object
     */
    protected function settingsTab() {
        $sections = [
                'ContentVisibility',
                'isotopeLayout',
                'links',
                'contentLimit',
        ];
        foreach ( $sections as $section ) {
            Settings::$section( $this );
        }

        return $this;
    }

    /**
     * Controls for style tab
     *
     * @return object
     */
    protected function styleTab() {

        $sections = apply_filters(
                'fm_grid_layout_section',
                [
                        'globaltSection',
                        'filterButtons',
                        'searchButton',
                        'titleSection',
                        'priceSection',
                        'excerptSection',
                        'imageSection',
                        'readmoreButton',
                        'addToCarButton',
                ]
        );

        foreach ( $sections as $section ) {
            Style::$section( $this, $this->elPrefix );
        }

        return $this;
    }

    public function get_script_depends() {
        return [
                'fmp-image-load',
                'fmp-isotope',
                'fmp-frontend',
        ];
    }

    protected function render() {
        $is_elementor_editor = class_exists( '\Elementor\Plugin' )
                               && \Elementor\Plugin::$instance->editor->is_edit_mode();

        wp_enqueue_script( 'fmp-modal' );
        wp_dequeue_script( 'fmp-image-load' );
        wp_enqueue_script( 'fmp-image-load' );
        wp_dequeue_script( 'fmp-frontend' );
        wp_enqueue_script( 'fmp-frontend' );
        if ( ! $is_elementor_editor ) {
            wp_dequeue_script( 'fmp-isotope' );
            wp_enqueue_script( 'fmp-isotope' );
        }

        $nonce   = wp_create_nonce( Fns::nonceText() );
        $ajaxurl = '';

        if ( in_array( 'sitepress-multilingual-cms/sitepress.php', get_option( 'active_plugins' ) ) ) {
            $ajaxurl .= admin_url( 'admin-ajax.php?lang=' . ICL_LANGUAGE_CODE );
        } else {
            $ajaxurl .= admin_url( 'admin-ajax.php' );
        }

        wp_localize_script(
                'fmp-frontend',
                'fmp',
                [
                        'ajaxurl'     => esc_url( $ajaxurl ),
                        'nonceID'     => esc_attr( Fns::nonceID() ),
                        'nonce'       => esc_attr( $nonce ),
                        'hasPro'      => TLPFoodMenu()->has_pro() ? 'true' : 'false',
                        'wc_cart_url' => TLPFoodMenu()->isWcActive() ? wc_get_cart_url() : '',
                ]
        );


        $settings = $this->get_settings_for_display();

        // "Group items by category" (Isotope "Show All" ordering). Forces the Even
        // grid style, because Masonry positions items absolutely by height and would
        // break the category grouping order.
        $group_by_cat = ! empty( $settings['fmp_isotope_group_by_cat'] ) && 'yes' === $settings['fmp_isotope_group_by_cat'];

        if ( ! $group_by_cat && 'masonry' === $settings['tlp_el_grid_style_promo'] && ! $is_elementor_editor ) {
            $this->get_widget_scripts( $this->elPrefix );
        }
        $scID      = (int) $this->get_id();
        $animation = '';
        if ( 'zoom_out' === $settings['tlp_el_image_animation'] ) {
            $animation = 'fmp-hover-zoom_out';
        } elseif ( 'zoom_in' === $settings['tlp_el_image_animation'] ) {
            $animation = 'fmp-hover-zoom_in';
        }

        $layout = isset( $settings['fmp_layout'] ) ? $settings['fmp_layout'] : '1';

        $masonry = ( ! $group_by_cat && isset( $settings['tlp_el_grid_style_promo'] ) && $settings['tlp_el_grid_style_promo'] === 'masonry' && ! $is_elementor_editor ) ? 'rt-masonry-grid' : '';

        $arg      = [];
        $base_arg = RenderHelpers::metaScBuilderEl( $settings );

        // Force Even grid item class so the category grouping order is preserved.
        if ( $group_by_cat ) {
            $base_arg['grid_style'] = 'even';
        }
        $args     = ( new QueryArgs() )->buildArgs( $scID, $base_arg );


        if ( $base_arg['source'] === 'product' ) {
            $args['post_type'] = 'product';
            unset( $args['tax_query'] );

            // Re-apply location filter after removing category tax_query.
            $args = apply_filters( 'rt_fm_sc_query_args', $args, $scID );
        }

        switch ( $layout ) {
            case 'layout2':
                $template = 'layout-isotope-layout-2';
                break;
            case 'layout3':
                $template = 'layout-isotope-layout-3';
                break;
            case 'layout4':
                $template = 'layout-isotope-layout-4';
                break;
            default:
                $template = 'layout-isotope-layout-1';
                break;
        }

        $query = new \WP_Query( $args );

        if ( '4' == $base_arg['dCols'] ) {
            $desktop_col = 3;
        } elseif ( '3' == $base_arg['dCols'] ) {
            $desktop_col = 4;
        } elseif ( '2' == $base_arg['dCols'] ) {
            $desktop_col = 6;
        } else {
            $desktop_col = '2';
        }

        //jqueryn jon
        $query_json = htmlspecialchars( wp_json_encode( $args ), ENT_QUOTES, 'UTF-8' );

        //settings_json
        $ajax_data = Fns::get_render_data_set( $settings, $query->max_num_pages, $animation, $template );

        $settings_json = htmlspecialchars( wp_json_encode( $ajax_data ), ENT_QUOTES, 'UTF-8' );

        $ajax_class = '';
        if ( $base_arg['posts_loading_type'] === 'ajax-number-pagination' || $base_arg['posts_loading_type'] === 'ajax-load-more-button' ) {
            $ajax_class = 'fmp-el-ajax-loader';
        } elseif ( $base_arg['posts_loading_type'] === 'ajax-load-more-scroll' ) {
            $ajax_class = 'fmp-autoloader-scroll fmp-el-ajax-loader';
        }

        $wrapper_data_layout = $is_elementor_editor ? '' : "data-layout='" . esc_attr( $layout ) . "'";

        echo "<div " . $wrapper_data_layout . " data-desktop-col='" . esc_attr( $desktop_col ) . "' class='fmp-elementor-isotope fmp-slider-isotope fmp-" . esc_attr( $layout ) . " " . esc_attr( $animation ) . " fmp-container-fluid fmp-wrapper fmp-grid-layout fmp-elementor-widget fmp-isotope-layout-wrapper' id='fmp-container-" . esc_attr( $layout ) . " '>";

        echo "<div class='fmp-row fmp-isotope-layout' data-el-query='" . $query_json . "' data-el-settings='" . $settings_json . "'>";

        //Isotope Fulter Menu

        if ( $base_arg['source'] === 'product' ) {
            $terms_cat  = Fns::getElProductAllFmpCategoryList();
            $selectedId = ! empty( $settings['fmp_wc_categories_isotope'] ) ? $settings['fmp_wc_categories_isotope'] : 'all';
        } else {
            $terms_cat  = Fns::getElAllFmpCategoryList();
            $selectedId = ! empty( $settings['fmp_categories_isotope'] ) ? $settings['fmp_categories_isotope'] : 'all';
        }

        $random         = wp_rand( 100000000, 999999999 );
        $htmlButton     = '';
        $fSelectTrigger = false;


        if ( ! empty( $settings['fmp_categories'] ) && is_array( $settings['fmp_categories'] ) ) {
            $terms_cat = Fns::el_cat_maping( $settings['fmp_categories'] );
        }

        if ( ! empty( $settings['fmp_wc_categories_include'] ) && is_array( $settings['fmp_wc_categories_include'] ) ) {
            $terms_cat = Fns::el_cat_maping( $settings['fmp_wc_categories_include'] );
        }

        // Filter out empty categories by collecting term IDs from query results.
        if ( ! empty( $terms_cat ) && $query->have_posts() ) {
            $active_term_ids = [];
            $cat_taxonomy    = ( $base_arg['source'] === 'product' ) ? 'product_cat' : 'food-menu-cat';

            while ( $query->have_posts() ) {
                $query->the_post();
                $post_term_ids = wp_get_post_terms( get_the_ID(), $cat_taxonomy, [ 'fields' => 'ids' ] );

                if ( ! empty( $post_term_ids ) && is_array( $post_term_ids ) ) {
                    $active_term_ids = array_merge( $active_term_ids, $post_term_ids );
                }
            }

            $active_term_ids = array_unique( $active_term_ids );
            $terms_cat       = array_intersect_key( $terms_cat, array_flip( $active_term_ids ) );

            $query->rewind_posts();
        }

        // Group items by the category filter-bar order (Show All ordering).
        if ( $group_by_cat && ! empty( $terms_cat ) && $query->have_posts() ) {
            $group_taxonomy   = ( $base_arg['source'] === 'product' ) ? 'product_cat' : 'food-menu-cat';
            $ordered_term_ids = array_map( 'intval', array_keys( $terms_cat ) );

            $query->posts      = Fns::group_posts_by_term_order( $query->posts, $ordered_term_ids, $group_taxonomy );
            $query->post_count = count( $query->posts );

            $query->rewind_posts();
        }

        if ( ! empty( $terms_cat ) && ! is_wp_error( $terms_cat ) ) {
            foreach ( $terms_cat as $id => $term ) {
                $fSelect    = ( (string) $id === (string) $selectedId && $selectedId !== 'all' ) ? 'class="selected"' : '';
                $htmlButton .= '<button data-filter=".iso_' . esc_attr( $id ) . '" ' . $fSelect . '>' . esc_html( $term ) . '</button>';
            }
        }

        if ( ! empty( $settings['fmp_switch_all_button'] ) && $settings['fmp_change_btn_text'] ) {
            $fSelect    = ( $selectedId === 'all' ) ? 'class="selected"' : '';
            $htmlButton = '<button data-filter="*" ' . $fSelect . '>' . esc_html( $settings['fmp_change_btn_text'] ) . '</button>' . $htmlButton;
        }

        if ( ! empty( $settings['fmp_isotope_filter'] ) || $settings['fmp_filer_search'] ) {
            echo '<div class="fmp-iso-filter ' . esc_attr( $settings['menu_type'] ) . '">';
            if ( ! empty( $settings['fmp_isotope_filter'] ) ) {
                echo '<div id="iso-button-' . esc_attr( $random ) . '" class="fmp-isotope-buttons button-group filter-button-group option-set">';
                echo $htmlButton;
                echo '</div>';
            }
            if ( ! empty( $settings['fmp_filer_search'] ) ) {
                echo "<div class='iso-search'><input type='text' class='iso-search-input' placeholder='" . esc_html__( 'Search', 'food-menu-pro' ) . "' /></div>";
            }
            echo '</div>';
        }

        echo "<div class='" . esc_attr( $ajax_class ) . " fmp-isotope fmp-content-loader " . esc_attr( $masonry ) . " fmp-read-more-active' id='fmp-isotope-" . esc_attr( $random ) . "'>";

        if ( $query->have_posts() ) :

            while ( $query->have_posts() ) :
                $query->the_post();

                $post_id = get_the_ID();

                $term_ids = [];

                if ( $base_arg['source'] == 'product' ) {
                    $term_ids = wp_get_post_terms( $post_id, 'product_cat', [ 'fields' => 'ids' ] );
                } else {
                    $term_ids = wp_get_post_terms( $post_id, 'food-menu-cat', [ 'fields' => 'ids' ] );
                }

                $termClasses = '';
                if ( ! empty( $term_ids ) && is_array( $term_ids ) ) {
                    foreach ( $term_ids as $term_id ) {
                        $termClasses .= ' iso_' . esc_attr( $term_id ) . ' menu-cat-' . esc_attr( $term_id );
                    }
                }

                $post_data = array(
                        'ID'         => $post_id,
                        'title'      => get_the_title(),
                        'content'    => get_the_content(),
                        'excerpt'    => get_the_excerpt(),
                        'permalink'  => get_permalink(),
                        'image'      => get_the_post_thumbnail_url( $post_id, 'full' ),
                        'meta'       => array(
                                'price' => get_post_meta( $post_id, '_regular_price', true ),
                        ),
                        'term_ids'   => $term_ids,
                        'term_class' => $termClasses,
                );

                $arg = array_merge( $base_arg, $post_data, array(
                        'pID' => $post_id,
                ) );
                Fns::render( 'elementor/' . $template, $arg );

            endwhile;
            wp_reset_postdata();

        else :
            echo 'No food menu items found.';
        endif;

        echo '</div>';

        //Normal Pagination Code
        if ( $base_arg['posts_loading_type'] == 'number-pagination' ) {
            $pagination = ! empty( $base_arg['pagination'] ) && $base_arg['pagination'] == 1;
            if ( $pagination ) {
                $renderPagination = RenderHelpers::renderElPagination(
                        $query,
                        $base_arg,
                        $base_arg['limit'] ?? 2,
                );
                echo '<div class="fmp-col-xs-12">';
                echo '<div class="fmp-utility">';
                $loading_type = $base_arg['posts_loading_type'] ?? '';
                $allowedTypes = [ 'ajax-number-pagination', 'number-pagination', 'ajax-load-more-scroll' ];
                if ( in_array( $loading_type, $allowedTypes, true ) && ! empty( $renderPagination ) && is_string( $renderPagination ) ) {
                    echo wp_kses_post( $renderPagination );
                }
                echo '</div>';
                echo '</div>';
            };
        }

        //Ajax Number Pagination Code
        if ( $base_arg['posts_loading_type'] === 'ajax-number-pagination' ) {
            $total_pages = $query->max_num_pages;
            $paged       = isset( $_POST['paged'] ) ? intval( $_POST['paged'] ) : 1;
            if ( $total_pages > 1 ) { ?>
                <div class="ajax-el-number-pagination fmp-pagination">
                    <?php for ( $i = 1; $i <= $total_pages; $i ++ ) :
                        $active_class = ( $i === $paged ) ? ' active' : '';
                        ?>
                        <a href="#" class="page-num<?php echo esc_attr( $active_class ); ?>" data-page="<?php echo esc_attr( $i ); ?>">
                            <?php echo esc_html( $i ); ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php }
        }

        //Ajax Loadmore Button Pagination Code
        if ( $base_arg['posts_loading_type'] === 'ajax-load-more-button' ) {
            echo '<div class="fmp-pagination"><button class="fmp-load-more-btn">Load More</button></div> ';
        }

        echo '</div>';
        echo '</div>';

    }
}