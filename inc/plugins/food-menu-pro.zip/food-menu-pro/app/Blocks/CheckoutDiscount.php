<?php
/**
 * WooCommerce Blocks Checkout integration for Fixed Discount.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Blocks;

defined( 'ABSPATH' ) || exit();

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Checkout Discount block integration.
 */
class CheckoutDiscount implements IntegrationInterface {

	/**
	 * The name of the integration.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'fmp-checkout-discount';
	}

	/**
	 * Runs on initialize.
	 *
	 * @return void
	 */
	public function initialize() {
		$this->register_block_frontend_scripts();
	}

	/**
	 * Register frontend scripts for the checkout block.
	 *
	 * @return void
	 */
	private function register_block_frontend_scripts() {
		$asset_url = FMP()->assets_url();
		wp_register_script(
			'fmp-checkout-discount',
			$asset_url . 'js/checkout-discount.min.js',
			[ 'wp-element', 'wp-plugins', 'wp-data', 'wc-blocks-checkout', 'wc-settings' ],
			FOOD_MENU_PRO_VERSION,
			true
		);
		wp_set_script_translations( 'fmp-checkout-discount', 'food-menu-pro', FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages' );
	}

	/**
	 * Returns an array of script handles to enqueue in the frontend context.
	 *
	 * @return string[]
	 */
	public function get_script_handles() {
		return [ 'fmp-checkout-discount' ];
	}

	/**
	 * Returns an array of script handles to enqueue in the editor context.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles() {
		return [];
	}

	/**
	 * An array of key, value pairs of data made available to the block on the client side.
	 *
	 * @return array
	 */
	public function get_script_data() {
		$settings = FnsPro::get_settings_option();

		return [
			'fmp_fixed_order_amount'    => ! empty( $settings['fmp_fixed_order_amount'] ) ? (float) $settings['fmp_fixed_order_amount'] : 0,
			'fmp_fixed_discount'        => ! empty( $settings['fmp_fixed_discount'] ) ? (float) $settings['fmp_fixed_discount'] : 0,
			'fmp_fixed_discount_message' => ! empty( $settings['fmp_fixed_discount_message'] )
				? $settings['fmp_fixed_discount_message']
				: esc_html__( 'Exclusive discount applied', 'food-menu-pro' ),
			'currency_symbol'           => get_woocommerce_currency_symbol(),
			'currency_position'         => get_option( 'woocommerce_currency_pos', 'left' ),
			'currency_decimals'         => wc_get_price_decimals(),
			'currency_thousand_sep'     => wc_get_price_thousand_separator(),
			'currency_decimal_sep'      => wc_get_price_decimal_separator(),
		];
	}
}
