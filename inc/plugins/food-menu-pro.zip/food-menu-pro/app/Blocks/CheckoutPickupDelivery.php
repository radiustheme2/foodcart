<?php
/**
 * WooCommerce Blocks Checkout integration for Pickup & Delivery.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Blocks;

defined( 'ABSPATH' ) || exit();

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\QrTableOrdering\QrTableOrdering;
use RT\FoodMenuPro\Controllers\PickupDelivery\PickupDeliveryFns;
use RT\FoodMenu\Helpers\Fns;

/**
 * Checkout Pickup Delivery block integration.
 */
class CheckoutPickupDelivery implements IntegrationInterface {

	/**
	 * The name of the integration.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'fmp-checkout-pickup-delivery';
	}

	/**
	 * Runs on initialize.
	 *
	 * @return void
	 */
	public function initialize() {
		$this->register_block_frontend_scripts();

		// Enqueue style when the checkout block script is enqueued.
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_style' ] );
	}

	/**
	 * Enqueue the checkout pickup/delivery style if the script is enqueued.
	 *
	 * @return void
	 */
	public function maybe_enqueue_style() {
		if ( wp_script_is( 'fmp-checkout-pickup-delivery', 'enqueued' ) || wp_script_is( 'fmp-checkout-pickup-delivery', 'registered' ) ) {
			wp_enqueue_style( 'fmp-checkout-pickup-delivery' );
		}
	}

	/**
	 * Register frontend scripts for the checkout block.
	 *
	 * @return void
	 */
	private function register_block_frontend_scripts() {
		$asset_url = FMP()->assets_url();
		wp_register_script(
			'fmp-checkout-pickup-delivery',
			$asset_url . 'js/checkout-pickup-delivery.min.js',
			[ 'wp-element', 'wp-plugins', 'wp-data', 'wc-blocks-checkout', 'wc-settings' ],
			FOOD_MENU_PRO_VERSION,
			true
		);
		wp_set_script_translations( 'fmp-checkout-pickup-delivery', 'food-menu-pro', FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages' );

		wp_register_style(
			'fmp-checkout-pickup-delivery',
			$asset_url . 'css/checkout-pickup-delivery-css.min.css',
			[],
			FOOD_MENU_PRO_VERSION
		);
	}

	/**
	 * Returns an array of script handles to enqueue in the frontend context.
	 *
	 * @return string[]
	 */
	public function get_script_handles() {
		return [ 'fmp-checkout-pickup-delivery' ];
	}

	/**
	 * Returns an array of script handles to enqueue in the editor context.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles() {
		return [];
	}

	/**
	 * An array of key, value pairs of data made available to the block on the client side.
	 *
	 * @return array
	 */
	public function get_script_data() {
		$settings = FnsPro::get_settings_option();

		$enable_pickup       = $settings['enable_pickup'] ?? 'on';
		$enable_delivery     = $settings['enable_delivery'] ?? 'on';
		$enable_pickup_time  = $settings['enable_pickup_time'] ?? 'on';
		$enable_delivery_time = $settings['enable_delivery_time'] ?? 'on';
		$enable_dinein       = $settings['enable_dinein'] ?? '';
		$enable_dinein_time  = $settings['enable_dinein_time'] ?? 'on';

		// QR scan orders are already seated at a known table, so none of the
		// order-type UI applies — force every flag off so the block-checkout JS
		// skips it. Custom order fields keep rendering since they're a separate
		// concern.
		if ( QrTableOrdering::has_active_session() ) {
			$enable_pickup   = 'off';
			$enable_delivery = 'off';
			$enable_dinein   = 'off';
		}

		$delivery_prep_day = ! empty( $settings['delivery_preparation_day'] )
			? FnsPro::preparing_date( $settings['delivery_preparation_day'] )
			: FnsPro::preparing_date( '0' );
		$pickup_prep_day   = FnsPro::preparing_date( 0 );

		// Delivery schedule data.
		$delivery_schedule           = FnsPro::get_setting( 'new_fmp_delivery_weekly_schedule', [] );
		$delivery_holiday            = FnsPro::get_offday_schedule( $delivery_schedule );
		$delivery_schedule_start     = FnsPro::get_schedule_time( $delivery_schedule );
		$delivery_schedule_end       = FnsPro::get_schedule_time( $delivery_schedule, 'end' );
		$delivery_schedule_slots     = FnsPro::get_schedule_slots( $delivery_schedule );

		// Pickup schedule data.
		$pickup_schedule             = FnsPro::get_setting( 'new_fmp_pickup_weekly_schedule', [] );
		$pickup_holiday              = FnsPro::get_offday_schedule( $pickup_schedule );
		$pickup_schedule_start       = FnsPro::get_schedule_time( $pickup_schedule );
		$pickup_schedule_end         = FnsPro::get_schedule_time( $pickup_schedule, 'end' );
		$pickup_schedule_slots       = FnsPro::get_schedule_slots( $pickup_schedule );

		// Dine in schedule data.
		$dinein_schedule             = FnsPro::get_setting( 'new_fmp_dinein_weekly_schedule', [] );
		$dinein_holiday              = FnsPro::get_offday_schedule( $dinein_schedule );
		$dinein_schedule_start       = FnsPro::get_schedule_time( $dinein_schedule );
		$dinein_schedule_end         = FnsPro::get_schedule_time( $dinein_schedule, 'end' );
		$dinein_schedule_slots       = FnsPro::get_schedule_slots( $dinein_schedule );

		// Dine in tables, scoped to the active location when multi-location is on.
		$dinein_location_id = ! empty( $settings['fmp_food_location_popup'] ) && ! empty( $_COOKIE['fmp_location_id'] )
			? absint( $_COOKIE['fmp_location_id'] )
			: 0;

		// Per-location schedule override. The classic checkout does this, so
		// without it the block checkout shows the global hours for a branch
		// that has its own — which reads as the wrong times for each type.
		$schedule_by_type = [
			'pickup'   => [
				'holiday'  => $pickup_holiday,
				'start'    => $pickup_schedule_start,
				'end'      => $pickup_schedule_end,
				'slots'    => $pickup_schedule_slots,
				'interval' => intval( $settings['pickup_time_interval'] ?? 15 ),
			],
			'delivery' => [
				'holiday'  => $delivery_holiday,
				'start'    => $delivery_schedule_start,
				'end'      => $delivery_schedule_end,
				'slots'    => $delivery_schedule_slots,
				'interval' => intval( $settings['delivery_time_interval'] ?? 15 ),
			],
			'dinein'   => [
				'holiday'  => $dinein_holiday,
				'start'    => $dinein_schedule_start,
				'end'      => $dinein_schedule_end,
				'slots'    => $dinein_schedule_slots,
				'interval' => intval( $settings['dinein_time_interval'] ?? 15 ),
			],
		];

		if ( $dinein_location_id > 0 ) {
			$location_data = FnsPro::get_location_schedule_data( $dinein_location_id );

			if ( null !== $location_data ) {
				foreach ( array_keys( $schedule_by_type ) as $sched_type ) {
					// Only override a type this branch actually configured —
					// an empty location schedule would strip all time bounds.
					if ( empty( $location_data[ "has_{$sched_type}_schedule" ] ) ) {
						continue;
					}

					$schedule_by_type[ $sched_type ] = [
						'holiday'  => $location_data[ "fmp_loc_{$sched_type}_weekly_holiday" ],
						'start'    => $location_data[ "fmp_loc_{$sched_type}_weekly_schedule_start_time" ],
						'end'      => $location_data[ "fmp_loc_{$sched_type}_weekly_schedule_end_time" ],
						'slots'    => $location_data[ "fmp_loc_{$sched_type}_weekly_schedule_slots" ],
						'interval' => intval( $location_data[ "fmp_loc_{$sched_type}_time_interval" ] ),
					];
				}
			}
		}

		$preorder_max_days = absint( $settings['fmp_preorder_max_days'] ?? 0 );

		return [
			'enable_pickup'                       => $enable_pickup,
			'enable_delivery'                     => $enable_delivery,
			'enable_pickup_time'                  => $enable_pickup_time,
			'enable_delivery_time'                => $enable_delivery_time,
			'pickup_message'                      => $settings['pickup_message'] ?? '',
			'delivery_message'                    => $settings['delivery_message'] ?? '',
			'delivery_time_interval'              => $schedule_by_type['delivery']['interval'],
			'pickup_time_interval'                => $schedule_by_type['pickup']['interval'],
			'delivery_preparing_date'             => $delivery_prep_day,
			'pickup_preparing_date'               => $pickup_prep_day,
			'delivery_weekly_holiday'             => $schedule_by_type['delivery']['holiday'],
			'pickup_weekly_holiday'               => $schedule_by_type['pickup']['holiday'],
			'delivery_weekly_schedule_start_time' => $schedule_by_type['delivery']['start'],
			'delivery_weekly_schedule_end_time'   => $schedule_by_type['delivery']['end'],
			'delivery_weekly_schedule_slots'      => $schedule_by_type['delivery']['slots'],
			'pickup_weekly_schedule_start_time'   => $schedule_by_type['pickup']['start'],
			'pickup_weekly_schedule_end_time'     => $schedule_by_type['pickup']['end'],
			'pickup_weekly_schedule_slots'        => $schedule_by_type['pickup']['slots'],
			'enable_dinein'                       => $enable_dinein,
			'enable_dinein_time'                  => $enable_dinein_time,
			'dinein_message'                      => $settings['dinein_message'] ?? '',
			'dinein_time_interval'                => $schedule_by_type['dinein']['interval'],
			'dinein_preparing_date'               => FnsPro::preparing_date( 0 ),
			'dinein_weekly_holiday'               => $schedule_by_type['dinein']['holiday'],
			'dinein_weekly_schedule_start_time'   => $schedule_by_type['dinein']['start'],
			'dinein_weekly_schedule_end_time'     => $schedule_by_type['dinein']['end'],
			'dinein_weekly_schedule_slots'        => $schedule_by_type['dinein']['slots'],
			'dinein_tables'                       => wp_list_pluck( PickupDeliveryFns::get_dinein_tables( $dinein_location_id ), 'name' ),
			'dinein_require_table'                => $settings['dinein_require_table'] ?? 'on',
			'preorder_max_days'                   => $preorder_max_days,
			'enable_slot_limits'                  => $settings['fmp_enable_order_slot_limits'] ?? '',
			'pickup_max_orders_per_slot'          => absint( $settings['pickup_max_orders_per_slot'] ?? 0 ),
			'delivery_max_orders_per_slot'        => absint( $settings['delivery_max_orders_per_slot'] ?? 0 ),
			'dinein_max_orders_per_slot'          => absint( $settings['dinein_max_orders_per_slot'] ?? 0 ),
			'date_format'                         => get_option( 'date_format', 'Y-m-d' ),
			'time_format'                         => get_option( 'time_format', 'H:i' ),
			'ajaxurl'                             => esc_url( admin_url( 'admin-ajax.php' ) ),
			'nonce_id'                            => esc_attr( Fns::nonceId() ),
			'nonce'                               => esc_attr( wp_create_nonce( Fns::nonceText() ) ),
			'custom_field_defs'                   => array_values(
					array_map(
						function ( $field ) {
							$field['required'] = filter_var( $field['required'] ?? false, FILTER_VALIDATE_BOOLEAN );
							$field['multiple'] = filter_var( $field['multiple'] ?? false, FILTER_VALIDATE_BOOLEAN );
							return $field;
						},
						array_filter(
							(array) FnsPro::get_setting( 'fmp_order_custom_fields', [] ),
							'is_array'
						)
					)
				),
			'i18n'                                => [
				/* translators: %d: number of orders remaining */
				'orders_left' => esc_html__( '%d order(s) left for this time slot', 'food-menu-pro' ),
				'available'   => esc_html__( 'Available', 'food-menu-pro' ),
				'slot_full'   => esc_html__( 'This time slot is full.', 'food-menu-pro' ),
				'checking'    => esc_html__( 'Checking availability...', 'food-menu-pro' ),
			],
		];
	}

	/**
	 * Validate pickup/delivery data during Store API checkout.
	 * Note: Store API endpoint data and order save hooks are registered
	 * in PickupDelivery::register_store_api_hooks() via woocommerce_blocks_loaded.
	 *
	 * @param \WC_Order $order The order object.
	 *
	 * @return void
	 * @throws \Automattic\WooCommerce\StoreApi\Exceptions\RouteException When validation fails.
	 */
	public function validate_checkout_data( $order ) {
		$settings   = FnsPro::get_settings_option();
		$order_type = $order->get_meta( 'fmp_order_time_type' );

		if ( empty( $order_type ) ) {
			return;
		}

		$enable_key = "enable_{$order_type}";
		$time_key   = "enable_{$order_type}_time";

		if ( ! empty( $settings[ $enable_key ] ) && empty( $order->get_meta( "fmp_{$order_type}_date" ) ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
				'fmp_missing_date',
				sprintf(
					/* translators: %s order type */
					esc_html__( 'Please select %s date', 'food-menu-pro' ),
					$order_type
				),
				400
			);
		}

		if ( ! empty( $settings[ $enable_key ] ) && ! empty( $settings[ $time_key ] ) && empty( $order->get_meta( "fmp_{$order_type}_time" ) ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
				'fmp_missing_time',
				sprintf(
					/* translators: %s order type */
					esc_html__( 'Please select %s time', 'food-menu-pro' ),
					$order_type
				),
				400
			);
		}
	}
}
