<?php
/**
 * Low Stock Email Notification.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RT\FoodMenuPro\Traits\SingletonTrait;

class LowStockNotification {

	use SingletonTrait;

	/**
	 * Init hooks.
	 */
	protected function init() {
		add_action( 'init', [ $this, 'schedule_event' ] );
		add_action( 'fmp_low_stock_check', [ $this, 'check_and_notify' ] );
	}

	/**
	 * Schedule the low stock check if not already scheduled.
	 */
	public function schedule_event() {
		if ( ! wp_next_scheduled( 'fmp_low_stock_check' ) ) {
			wp_schedule_event( time(), 'daily', 'fmp_low_stock_check' );
		}
	}

	/**
	 * Check for low stock products and send email notification.
	 */
	public function check_and_notify() {
		$settings  = get_option( 'fmp_inventory_settings', [] );
		$enabled   = ! empty( $settings['low_stock_email_enabled'] );
		$threshold = isset( $settings['low_stock_threshold'] ) ? (int) $settings['low_stock_threshold'] : 10;

		if ( ! $enabled ) {
			return;
		}

		$recipients = ! empty( $settings['low_stock_email_recipients'] )
			? $settings['low_stock_email_recipients']
			: get_option( 'admin_email' );

		// Get all inventory-tracked products.
		$product_ids = get_posts( [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'meta_key'       => '_fmp_inventory',
			'meta_value'     => '1',
			'fields'         => 'ids',
			'posts_per_page' => -1,
		] );

		$low_stock_products = [];

		foreach ( $product_ids as $pid ) {
			$product = wc_get_product( $pid );
			if ( ! $product || ! $product->managing_stock() ) {
				continue;
			}

			$stock = (int) $product->get_stock_quantity();

			if ( $stock <= $threshold ) {
				// Skip if already notified and stock hasn't changed.
				$last_notified = get_post_meta( $pid, '_fmp_low_stock_notified_qty', true );
				if ( $last_notified !== '' && (int) $last_notified === $stock ) {
					continue;
				}

				$low_stock_products[] = [
					'id'    => $pid,
					'name'  => $product->get_name(),
					'stock' => $stock,
				];

				update_post_meta( $pid, '_fmp_low_stock_notified_qty', $stock );
			} else {
				// Stock is above threshold — clear notification flag.
				delete_post_meta( $pid, '_fmp_low_stock_notified_qty' );
			}
		}

		if ( empty( $low_stock_products ) ) {
			return;
		}

		$site_name = get_bloginfo( 'name' );
		$subject   = sprintf( '[%s] Low Stock Alert — %d product(s)', $site_name, count( $low_stock_products ) );

		$body = "The following products have low stock:\n\n";
		foreach ( $low_stock_products as $p ) {
			$status = $p['stock'] <= 0 ? 'OUT OF STOCK' : 'Low';
			$body  .= sprintf( "• %s (ID: %d) — Stock: %d [%s]\n", $p['name'], $p['id'], $p['stock'], $status );
		}
		$body .= sprintf( "\nThreshold: %d\n", $threshold );
		$body .= sprintf( "Manage inventory: %s\n", admin_url( 'edit.php?post_type=food-menu&page=inventory' ) );

		wp_mail( $recipients, $subject, $body );

		// Log alerts to database.
		$this->log_alerts( $low_stock_products, $threshold, $recipients );
	}

	/**
	 * Log stock alerts to the database.
	 *
	 * @param array  $products   Low stock products.
	 * @param int    $threshold  Threshold value.
	 * @param string $recipients Email recipients.
	 */
	private function log_alerts( $products, $threshold, $recipients ) {
		global $wpdb;
		$table = $wpdb->prefix . 'fm_stock_alert_log';

		// Check if table exists.
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $table_exists ) {
			return;
		}

		foreach ( $products as $p ) {
			$wpdb->insert( $table, [
				'product_id'  => $p['id'],
				'alert_type'  => $p['stock'] <= 0 ? 'out_of_stock' : 'low_stock',
				'stock_level' => $p['stock'],
				'threshold'   => $threshold,
				'notified_to' => $recipients,
				'created_at'  => current_time( 'mysql' ),
			] );
		}
	}
}
