<?php
/**
 * Inventory Hooks.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Models\InventoryModel;

class InventoryHooks {

	use SingletonTrait;

	private InventoryModel $model;

	/**
	 * Per-request cache of the "is this the order's first stock reduction?" answer,
	 * keyed by order ID.
	 *
	 * `woocommerce_reduce_order_item_stock` fires once per order *item*, so the
	 * order-level flag must be resolved once for the whole reduction pass —
	 * otherwise the first item is logged as a new sale and every other item in
	 * the same order is logged as a reprocess.
	 *
	 * @var array<int, bool>
	 */
	private array $first_reduction = [];

	/**
	 * Init hooks.
	 */
	protected function init() {

		$this->model = new InventoryModel();
		add_action( 'woocommerce_reduce_order_item_stock', [ $this, 'log_item_stock_reduce' ], 10, 3 );
		add_action( 'woocommerce_restore_order_item_stock', [ $this, 'log_item_stock_restore' ], 10, 4 );


		/**
		 * Preventing save stock amount from the product edit page.
		 * It should be handled by Food Menu Inventory.
		 * _fmp_inventory meta key: it specifies that a product's stock is managed by food-menu.
		 *
		 * Runs on `woocommerce_admin_process_product_object`, which fires after
		 * WooCommerce has read the form onto the product object but *before* it
		 * saves — the only point where the posted value can still be overruled.
		 */
		add_action( 'woocommerce_admin_process_product_object', [ $this, 'preserve_managed_stock' ], 20 );

		/**
		 * Disable inventory input box from the product edit page.
		 */
		add_action( 'admin_footer', [$this, 'disable_edit_page_stock_input'] );

		/**
		 * Remove all admin notice from inventory page
		 */
		add_action('admin_init', function () {
			if (
				isset($_GET['post_type'], $_GET['page']) &&
				$_GET['post_type'] === 'food-menu' &&
				$_GET['page'] === 'inventory'
			) {
				remove_all_actions('admin_notices');
				remove_all_actions('all_admin_notices');
			}
		});

		/**
		 * Register inventory endpoint for frontend order page
		 */
/*		add_action( 'init', function () {

			// Adds /inventory/ after any page URL
			add_rewrite_endpoint( 'inventory', EP_PAGES );
		} );*/



		/**
		 * Render Inventory template on frontend order page
		 */
		/*add_action( 'template_redirect', function () {

			global $post;

			// Safety checks
			if ( ! is_singular() || ! $post ) {
				return;
			}

			// Get the dynamic frontend order page ID
			$frontend_page_id = FnsPro::get_frontend_order_page();

			// Check:
			// 1. Correct page
			// 2. Inventory endpoint exists in URL
			if (
				(int) $post->ID === (int) $frontend_page_id &&
				get_query_var( 'inventory', false ) !== false
			) {
				$file_path   = 'frontend-dashboard/frontend-dashboard.php';
				$plugin_file = FMP()->plugin_template_path() . $file_path;

				if ( file_exists( $plugin_file ) ) {
					include $plugin_file;
					exit;
				}
			}
		} );*/
	}

	public function log_item_stock_reduce( $item, $change, $order ) {

		$variation_id = $item->get_variation_id();
		$product_id   = $item->get_product_id();

		// The line's own product — the variation when there is one. Stock is
		// normally managed on the variation while the parent manages none, so
		// checking the parent here would skip every variable-product sale.
		$product = $item->get_product();

		if ( ! $product || ! $product->managing_stock() ) {
			return;
		}

		$order_id = $order->get_id();
		$qty      = (int) $change['from'] - (int) $change['to'];

		// WooCommerce only reduces each order item's stock once (guarded by the item
		// `_reduced_stock` meta + the order `_order_stock_reduced` flag) and fires this
		// hook once per genuine reduction, passing the real before/after stock in $change.
		// A delta of 0 or less is not an actual sale, so skip it.
		if ( $qty <= 0 ) {
			return;
		}

		$current_status = $order->get_status();

		// Resolve the flag once per order, then reuse it for the order's other items.
		if ( ! isset( $this->first_reduction[ $order_id ] ) ) {
			// Read from order meta (HPOS-safe) and fall back to legacy postmeta for
			// orders flagged before this was stored on the order object.
			$already_reduced = $order->get_meta( '_fm_stock_reduced_once' )
				|| get_post_meta( $order_id, '_fm_stock_reduced_once', true );

			$this->first_reduction[ $order_id ] = ! $already_reduced;

			if ( ! $already_reduced ) {
				$order->update_meta_data( '_fm_stock_reduced_once', 1 );
				// Meta-only save — avoids firing the full order-update pipeline mid-reduction.
				$order->save_meta_data();
			}
		}

		if ( $this->first_reduction[ $order_id ] ) {
			$reason = 'new_sale';
			$note   = 'A new order has created';
		} else {
			$reason = 'order_reprocessed';
			$note   = 'order status changed to ' . $current_status;
		}

		$this->model->insert_inventory_log( [
			'product_id'   => $product_id,
			'variation_id' => $variation_id,
			'change_type'  => 'sale',
			'quantity'     => $qty,
			'reason'       => $reason,
			'reference_id' => $order_id,
			'note'         => $note,
		] );

		delete_transient( FnsPro::dashboard_stats_cache_key() );
	}

	public function log_item_stock_restore( $item, $new_stock, $old_stock, $order ) {

		if ( ! empty( $GLOBALS['fmp_inventory_internal_update'] ) ) {
			return $new_stock;
		}

		$variation_id = $item->get_variation_id();
		$product_id   = $item->get_product_id();

		// Same as the reduce path: read the variation, not the parent.
		$product = $item->get_product();

		if ( ! $product || ! $product->managing_stock() ) {
			return $new_stock;
		}

		$order_id = $order->get_id();
		$qty      = (int) $new_stock - (int) $old_stock;

		// WooCommerce fires this hook once per genuine restore, passing the real
		// before/after stock. A delta of 0 or less is not an actual restore, so skip it.
		if ( $qty <= 0 ) {
			return $new_stock;
		}

		$current_status = $order->get_status();

		$this->model->insert_inventory_log( [
			'product_id'   => $product_id,
			'variation_id' => $variation_id,
			'quantity'     => $qty,
			'change_type'  => 'restore',
			'reason'       => 'order_cancelled',
			'reference_id' => $order_id,
			'note'         => 'Order status changed to ' . $current_status,
		] );

		delete_transient( FnsPro::dashboard_stats_cache_key() );
	}

	/**
	 * Bring one line item's stock in line with its current quantity, and log it.
	 *
	 * WooCommerce only moves stock on an order *status transition*. Once an order
	 * has reduced its stock, editing its items — adding a dish, changing a
	 * quantity, removing a line — moves no stock at all, so the shelf count and
	 * the inventory ledger both drift away from what was actually sold.
	 *
	 * wp-admin papers over this with `wc_maybe_adjust_line_item_product_stock()`,
	 * but that helper lives in an admin-only file (so it isn't loaded for REST
	 * requests) and fires none of the stock hooks, meaning it writes no inventory
	 * log either. This does both, using the same `_reduced_stock` bookkeeping
	 * WooCommerce does so the two never fight over the same item.
	 *
	 * Orders that have *not* yet reduced stock are left alone: WooCommerce will
	 * reduce the whole order at its next status change, and adjusting here as
	 * well would take the stock twice.
	 *
	 * @param \WC_Order_Item_Product $item     Line item, already saved.
	 * @param \WC_Order              $order    Its order.
	 * @param int|float|null         $quantity Target quantity. The item's own when
	 *                                         null; pass 0 when removing the item.
	 *
	 * @return void
	 */
	public function sync_order_item_stock( $item, $order, $quantity = null ) {

		if ( ! $item instanceof \WC_Order_Item_Product || ! $order instanceof \WC_Order ) {
			return;
		}

		// Resolves to the variation when the line has one — that is where stock lives.
		$product = $item->get_product();

		if ( ! $product || ! $product->managing_stock() ) {
			return;
		}

		if ( ! $order->get_data_store()->get_stock_reduced( $order->get_id() ) ) {
			return;
		}

		$target   = wc_stock_amount( null === $quantity ? $item->get_quantity() : $quantity );
		$already  = wc_stock_amount( $item->get_meta( '_reduced_stock', true ) );
		$refunded = wc_stock_amount( $item->get_meta( '_restock_refunded_items', true ) );

		// A target of 0 means the line is going away — give back everything it took.
		$diff = 0 === (int) $target ? -$already : $target - $refunded - $already;

		if ( ! $diff ) {
			return;
		}

		// Our own change, so the guard that suppresses plugin-driven stock writes
		// stays off — but the restore hook must not double-log what we log below.
		$was_internal                             = ! empty( $GLOBALS['fmp_inventory_internal_update'] );
		$GLOBALS['fmp_inventory_internal_update'] = true;

		$new_stock = wc_update_product_stock( $product, abs( $diff ), $diff > 0 ? 'decrease' : 'increase' );

		$GLOBALS['fmp_inventory_internal_update'] = $was_internal;

		if ( is_wp_error( $new_stock ) ) {
			return;
		}

		$item->update_meta_data( '_reduced_stock', max( 0, $target - $refunded ) );
		$item->save();

		$this->model->insert_inventory_log( [
			'product_id'   => $item->get_product_id(),
			'variation_id' => $item->get_variation_id(),
			'change_type'  => $diff > 0 ? 'sale' : 'restore',
			'quantity'     => abs( $diff ),
			'reason'       => $diff > 0 ? 'order_item_added' : 'order_item_reduced',
			'reference_id' => $order->get_id(),
			'note'         => sprintf(
				/* translators: 1: product name, 2: order number. */
				__( 'Order item edited: %1$s on order #%2$s', 'food-menu-pro' ),
				$product->get_name(),
				$order->get_order_number()
			),
		] );

		delete_transient( FnsPro::dashboard_stats_cache_key() );
	}

	/**
	 * Keep the ledger's stock figure when a managed product is saved from the
	 * product edit page.
	 *
	 * This replaces a guard that never worked: it was registered as a *filter* on
	 * `woocommerce_product_set_stock`, which WooCommerce fires as an action with
	 * the product as its only argument — so the callback's return value was
	 * discarded and its `instanceof` check bailed on every call.
	 *
	 * That left a silent data-loss bug. `disable_edit_page_stock_input()` disables
	 * the `#_stock` field, and a disabled field is not submitted; WooCommerce
	 * reads a missing `_stock` as `null`, and `set_stock_quantity( null )` runs it
	 * through `wc_stock_amount()` — which is `intval()` — landing on **0**. Every
	 * save of a managed product therefore wiped its stock to zero.
	 *
	 * Restoring the stored figure here covers both cases: the field that wasn't
	 * submitted at all, and a value someone posted anyway.
	 *
	 * @param \WC_Product $product Product object, populated from the form, unsaved.
	 *
	 * @return void
	 */
	public function preserve_managed_stock( $product ) {

		if ( ! $product instanceof \WC_Product || ! $product->get_id() ) {
			return;
		}

		if ( '1' !== get_post_meta( $product->get_id(), '_fmp_inventory', true ) ) {
			return;
		}

		if ( ! empty( $GLOBALS['fmp_inventory_internal_update'] ) ) {
			return;
		}

		// Once stock management is switched off the quantity stops meaning
		// anything, so that is left as the admin's decision.
		if ( ! $product->get_manage_stock( 'edit' ) ) {
			return;
		}

		$stored = get_post_meta( $product->get_id(), '_stock', true );

		if ( '' === $stored || null === $stored ) {
			return;
		}

		$stored    = wc_stock_amount( $stored );
		$submitted = wc_stock_amount( $product->get_stock_quantity( 'edit' ) );

		if ( $submitted === $stored ) {
			return;
		}

		$product->set_stock_quantity( $stored );
		$product->set_stock_status( $stored > 0 ? 'instock' : 'outofstock' );

		// Only say something when a value was actually typed and posted. The
		// disabled-field case is the normal path and needs no scolding.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verified the nonce before this hook.
		if ( ! isset( $_POST['_stock'] ) || did_action( 'fmp_stock_edit_blocked_notice' ) ) {
			return;
		}

		$product_name = $product->get_name();

		add_action( 'admin_notices', function () use ( $product_name ) {
			printf(
				'<div class="notice notice-warning is-dismissible"><p><strong>%s:</strong> %s</p></div>',
				esc_html__( 'Food Menu Inventory', 'food-menu-pro' ),
				sprintf(
					/* translators: %s: product name */
					esc_html__( 'Stock for "%s" is managed by the Food Menu Inventory system. Manual stock changes from this page are blocked. Use the Inventory Dashboard instead.', 'food-menu-pro' ),
					esc_html( $product_name )
				)
			);
		} );

		do_action( 'fmp_stock_edit_blocked_notice' );
	}

	public function disable_edit_page_stock_input() {
		global $post;

		if ( ! $post || 'product' !== $post->post_type ) {
			return;
		}

		if ( '1' !== get_post_meta( $post->ID, '_fmp_inventory', true ) ) {
			return;
		}
		?>
        <script>
            jQuery(function ($) {
                const stockInput = $('#_stock');
                if (!stockInput.length) return;
                // readonly, not disabled: a disabled field is never submitted, and
                // WooCommerce reads a missing _stock as 0 — which silently wiped
                // the product's stock every time the product was saved.
                stockInput.prop('readonly', true);
                stockInput.parent().append('<div class="fmp-fd-note" style="background: #ffcfcf;padding:5px 15px;clear: both;"><?php echo esc_js( __( 'The inventory is now managed through the Food Menu Inventory system.', 'food-menu-pro' ) ); ?></div>');
            });
        </script>
		<?php
	}

    public function prevent_bulk_edit_save_stock( $allow, $product) {
	    if ( '1' === get_post_meta( $product->get_id(), '_fmp_inventory', true ) ) {
		    return false;
	    }

	    return $allow;
    }

}