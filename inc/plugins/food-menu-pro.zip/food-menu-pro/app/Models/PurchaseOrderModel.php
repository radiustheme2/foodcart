<?php
/**
 * Purchase Order Model.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

class PurchaseOrderModel {

	protected string $table = 'fm_purchase_orders';
	protected string $items_table = 'fm_purchase_order_items';

	/**
	 * Generate a unique PO number.
	 *
	 * @return string
	 */
	public function generate_po_number(): string {
		global $wpdb;
		$table  = $wpdb->prefix . $this->table;
		$prefix = 'PO-' . date( 'Ymd' );

		$last = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT po_number FROM {$table} WHERE po_number LIKE %s ORDER BY id DESC LIMIT 1",
				$prefix . '%'
			)
		);

		if ( $last ) {
			$seq = (int) substr( $last, -3 ) + 1;
		} else {
			$seq = 1;
		}

		return $prefix . '-' . str_pad( $seq, 3, '0', STR_PAD_LEFT );
	}

	/**
	 * Insert a new purchase order.
	 *
	 * @param array $data PO data.
	 *
	 * @return int Inserted PO ID.
	 */
	public function insert_po( array $data ): int {
		global $wpdb;

		$wpdb->insert(
			$wpdb->prefix . $this->table,
			[
				'po_number'      => $data['po_number'] ?? $this->generate_po_number(),
				'supplier_name'  => sanitize_text_field( $data['supplier_name'] ?? '' ),
				'supplier_email' => sanitize_email( $data['supplier_email'] ?? '' ) ?: null,
				'supplier_phone' => sanitize_text_field( $data['supplier_phone'] ?? '' ) ?: null,
				'status'         => sanitize_text_field( $data['status'] ?? 'draft' ),
				'notes'          => sanitize_textarea_field( $data['notes'] ?? '' ) ?: null,
				'expected_date'  => ! empty( $data['expected_date'] ) ? sanitize_text_field( $data['expected_date'] ) : null,
				'total_cost'     => (float) ( $data['total_cost'] ?? 0 ),
				'created_by'     => get_current_user_id(),
				'created_at'     => current_time( 'mysql' ),
				'updated_at'     => current_time( 'mysql' ),
			]
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * Update a purchase order.
	 *
	 * @param int   $id   PO ID.
	 * @param array $data Data to update.
	 *
	 * @return bool
	 */
	public function update_po( int $id, array $data ): bool {
		global $wpdb;

		$update = [];

		if ( isset( $data['supplier_name'] ) ) {
			$update['supplier_name'] = sanitize_text_field( $data['supplier_name'] );
		}
		if ( isset( $data['supplier_email'] ) ) {
			$update['supplier_email'] = sanitize_email( $data['supplier_email'] ) ?: null;
		}
		if ( isset( $data['supplier_phone'] ) ) {
			$update['supplier_phone'] = sanitize_text_field( $data['supplier_phone'] ) ?: null;
		}
		if ( isset( $data['status'] ) ) {
			$update['status'] = sanitize_text_field( $data['status'] );
		}
		if ( isset( $data['notes'] ) ) {
			$update['notes'] = sanitize_textarea_field( $data['notes'] ) ?: null;
		}
		if ( isset( $data['expected_date'] ) ) {
			$update['expected_date'] = sanitize_text_field( $data['expected_date'] ) ?: null;
		}
		if ( isset( $data['received_date'] ) ) {
			$update['received_date'] = sanitize_text_field( $data['received_date'] );
		}
		if ( isset( $data['total_cost'] ) ) {
			$update['total_cost'] = (float) $data['total_cost'];
		}

		if ( empty( $update ) ) {
			return false;
		}

		$update['updated_at'] = current_time( 'mysql' );

		return (bool) $wpdb->update(
			$wpdb->prefix . $this->table,
			$update,
			[ 'id' => $id ]
		);
	}

	/**
	 * Get a single purchase order with its items.
	 *
	 * @param int $id PO ID.
	 *
	 * @return array|null
	 */
	public function get_po( int $id ): ?array {
		global $wpdb;

		$po = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}{$this->table} WHERE id = %d",
				$id
			),
			ARRAY_A
		);

		if ( ! $po ) {
			return null;
		}

		$po['items'] = $this->get_po_items( $id );

		return $po;
	}

	/**
	 * Get paginated list of purchase orders.
	 *
	 * @param array $filters Filters.
	 *
	 * @return array
	 */
	public function get_pos( array $filters = [] ): array {
		global $wpdb;
		$table = $wpdb->prefix . $this->table;

		$page     = max( 1, (int) ( $filters['page'] ?? 1 ) );
		$per_page = max( 1, (int) ( $filters['per_page'] ?? 10 ) );
		$offset   = ( $page - 1 ) * $per_page;

		$where  = '1=1';
		$params = [];

		if ( ! empty( $filters['status'] ) && 'all' !== $filters['status'] ) {
			$where   .= ' AND status = %s';
			$params[] = $filters['status'];
		}

		if ( ! empty( $filters['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( $filters['search'] ) . '%';
			$where   .= ' AND (po_number LIKE %s OR supplier_name LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
		$list_sql  = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d";

		$params_count = $params;
		$params[]     = $per_page;
		$params[]     = $offset;

		$total = empty( $params_count )
			? (int) $wpdb->get_var( $count_sql )
			: (int) $wpdb->get_var( $wpdb->prepare( $count_sql, ...$params_count ) );

		$rows = empty( $params )
			? $wpdb->get_results( $list_sql, ARRAY_A )
			: $wpdb->get_results( $wpdb->prepare( $list_sql, ...$params ), ARRAY_A );

		// Attach item count to each PO.
		$items_table = $wpdb->prefix . $this->items_table;
		foreach ( $rows as &$row ) {
			$row['items_count'] = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT COUNT(*) FROM {$items_table} WHERE po_id = %d", $row['id'] )
			);
		}

		return [
			'items' => $rows,
			'meta'  => [
				'total'    => $total,
				'current'  => $page,
				'pageSize' => $per_page,
			],
		];
	}

	/**
	 * Delete a purchase order and its items.
	 *
	 * @param int $id PO ID.
	 *
	 * @return bool
	 */
	public function delete_po( int $id ): bool {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . $this->items_table, [ 'po_id' => $id ] );

		return (bool) $wpdb->delete( $wpdb->prefix . $this->table, [ 'id' => $id ] );
	}

	/**
	 * Insert a PO item.
	 *
	 * @param array $data Item data.
	 *
	 * @return int Inserted item ID.
	 */
	public function insert_po_item( array $data ): int {
		global $wpdb;

		$wpdb->insert(
			$wpdb->prefix . $this->items_table,
			[
				'po_id'             => (int) $data['po_id'],
				'product_id'        => (int) $data['product_id'],
				'quantity_ordered'  => max( 0, (int) $data['quantity_ordered'] ),
				'quantity_received' => max( 0, (int) ( $data['quantity_received'] ?? 0 ) ),
				'cost_price'        => isset( $data['cost_price'] ) && is_numeric( $data['cost_price'] ) ? max( 0, (float) $data['cost_price'] ) : null, // A negative cost skews valuation and margins.
				'created_at'        => current_time( 'mysql' ),
			]
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * Update a PO item.
	 *
	 * @param int   $id   Item ID.
	 * @param array $data Data to update.
	 *
	 * @return bool
	 */
	public function update_po_item( int $id, array $data ): bool {
		global $wpdb;

		$update = [];
		if ( isset( $data['quantity_ordered'] ) ) {
			$update['quantity_ordered'] = max( 0, (int) $data['quantity_ordered'] );
		}
		if ( isset( $data['quantity_received'] ) ) {
			$update['quantity_received'] = max( 0, (int) $data['quantity_received'] );
		}
		if ( isset( $data['cost_price'] ) ) {
			$update['cost_price'] = max( 0, (float) $data['cost_price'] );
		}

		if ( empty( $update ) ) {
			return false;
		}

		return (bool) $wpdb->update(
			$wpdb->prefix . $this->items_table,
			$update,
			[ 'id' => $id ]
		);
	}

	/**
	 * Delete a PO item.
	 *
	 * @param int $id Item ID.
	 *
	 * @return bool
	 */
	public function delete_po_item( int $id ): bool {
		global $wpdb;

		return (bool) $wpdb->delete( $wpdb->prefix . $this->items_table, [ 'id' => $id ] );
	}

	/**
	 * Get items for a purchase order.
	 *
	 * @param int $po_id PO ID.
	 *
	 * @return array
	 */
	public function get_po_items( int $po_id ): array {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}{$this->items_table} WHERE po_id = %d ORDER BY id ASC",
				$po_id
			),
			ARRAY_A
		);

		foreach ( $rows as &$row ) {
			$product = wc_get_product( (int) $row['product_id'] );
			$row['product_name'] = $product ? $product->get_name() : 'Deleted Product';
			$row['current_stock'] = $product && $product->managing_stock() ? $product->get_stock_quantity() : null;
		}

		return $rows;
	}

	/**
	 * Recalculate total cost for a PO.
	 *
	 * @param int $po_id PO ID.
	 */
	public function recalculate_total( int $po_id ): void {
		global $wpdb;

		$total = (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT SUM(quantity_ordered * COALESCE(cost_price, 0)) FROM {$wpdb->prefix}{$this->items_table} WHERE po_id = %d",
				$po_id
			)
		);

		$wpdb->update(
			$wpdb->prefix . $this->table,
			[ 'total_cost' => $total, 'updated_at' => current_time( 'mysql' ) ],
			[ 'id' => $po_id ]
		);
	}
}
