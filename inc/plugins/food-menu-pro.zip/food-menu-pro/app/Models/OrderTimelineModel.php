<?php
/**
 * Order Timeline Model.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Models;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Handles direct database operations for the order status history table.
 */
class OrderTimelineModel {

	/**
	 * Get the table name.
	 *
	 * @return string
	 */
	private static function table_name() {
		global $wpdb;
		return "{$wpdb->prefix}fm_order_status_history";
	}

	/**
	 * Insert a new timeline entry.
	 *
	 * @param array $data {
	 *     @type int    $order_id     Order ID.
	 *     @type string $status       Status slug.
	 *     @type string $status_label Human-readable status label.
	 *     @type string $note         Optional note.
	 *     @type int    $updated_by   User ID who made the change.
	 * }
	 *
	 * @return int|false Inserted row ID or false on failure.
	 */
	public static function insert_entry( array $data ) {
		global $wpdb;

		$result = $wpdb->insert(
			self::table_name(),
			[
				'order_id'     => absint( $data['order_id'] ),
				'status'       => sanitize_text_field( $data['status'] ),
				'status_label' => sanitize_text_field( $data['status_label'] ),
				'note'         => isset( $data['note'] ) ? sanitize_textarea_field( $data['note'] ) : null,
				'updated_by'   => isset( $data['updated_by'] ) ? absint( $data['updated_by'] ) : null,
				'created_at'   => current_time( 'mysql' ),
			],
			[ '%d', '%s', '%s', '%s', '%d', '%s' ]
		);

		return $result ? $wpdb->insert_id : false;
	}

	/**
	 * Get timeline entries for an order.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return array
	 */
	public static function get_timeline( $order_id ) {
		global $wpdb;

		$table = self::table_name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, order_id, status, status_label, note, updated_by, created_at
				FROM $table
				WHERE order_id = %d
				ORDER BY created_at ASC, id ASC",
				absint( $order_id )
			),
			ARRAY_A
		);
	}

	/**
	 * Get timeline entries by tracking token (for public access).
	 * Looks up the order by meta, then fetches timeline by order_id.
	 *
	 * @param string $token Tracking token.
	 *
	 * @return array
	 */
	public static function get_by_token( $token ) {
		$orders = wc_get_orders( [
			'meta_key'   => '_fmp_tracking_token',
			'meta_value' => sanitize_text_field( $token ),
			'limit'      => 1,
			'return'     => 'ids',
		] );

		if ( empty( $orders ) ) {
			return [];
		}

		return self::get_timeline( $orders[0] );
	}

	/**
	 * Update the note on the last timeline entry for an order.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $note     Note text.
	 *
	 * @return bool
	 */
	public static function update_last_entry_note( $order_id, $note ) {
		global $wpdb;

		$table = self::table_name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$last_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM $table WHERE order_id = %d ORDER BY created_at DESC, id DESC LIMIT 1",
				absint( $order_id )
			)
		);

		if ( ! $last_id ) {
			return false;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (bool) $wpdb->update(
			$table,
			[ 'note' => sanitize_textarea_field( $note ) ],
			[ 'id' => absint( $last_id ) ],
			[ '%s' ],
			[ '%d' ]
		);
	}
}
