<?php
/**
 * InventoryLogs Model.
 *
 * @package RT_FoodMenu
 */

namespace RT\FoodMenuPro\Models;

use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * InventoryLogs Model Class.
 */
class InventoryModel {

	protected string $table = 'fm_inventory_logs';

	/**
	 * Check if already opening_inventory exist
	 *
	 * @param $product_id
	 *
	 * @return bool
	 */
	public function has_opening_log( $product_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table;

		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1
             FROM {$table_name}
             WHERE product_id = %d
             AND reason = 'opening_inventory'
             LIMIT 1",
				$product_id
			)
		);
	}

	/**
	 * @throws \Exception
	 */
	public function insert_inventory_log( array $data ) {
		global $wpdb;

		if ( empty( $data['product_id'] ) ) {
			throw new \Exception( 'Product ID cannot be empty' );
		}

		$occurred_at = ! empty( $data['occurred_at'] )
			? wp_date( 'Y-m-d H:i:s', strtotime( $data['occurred_at'] ) )
			: current_time( 'mysql' );

		$variation_id = ! empty( $data['variation_id'] ) ? $data['variation_id'] : 0;
		$wpdb->insert(
			"{$wpdb->prefix}fm_inventory_logs",
			[
				'product_id'   => (int) $data['product_id'],
				'variation_id' => (int) $variation_id,
				'change_type'  => sanitize_text_field( $data['change_type'] ),
				'quantity'     => (int) $data['quantity'],
				'reason'       => sanitize_text_field( $data['reason'] ?? '' ),
				'note'         => sanitize_text_field( $data['note'] ?? '' ),
				'reference_id'  => $data['reference_id'] ?? null,
				'created_by'    => $data['created_by'] ?? get_current_user_id(),
				'supplier_name' => sanitize_text_field( $data['supplier_name'] ?? '' ) ?: null,
				'cost_price'    => isset( $data['cost_price'] ) && is_numeric( $data['cost_price'] ) ? (float) $data['cost_price'] : null,
				'location_id'   => (int) ( $data['location_id'] ?? 0 ),
				'occurred_at'   => $occurred_at,
				'created_at'    => current_time( 'mysql' ),
			]
		);
	}

	/**
	 * Get a log entry by ID.
	 *
	 * @param int $id Log ID.
	 *
	 * @return array|null
	 */
	public function get_log_by_id( $id ) {
		global $wpdb;
		$table = $wpdb->prefix . $this->table;

		return $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ),
			ARRAY_A
		);
	}

	/**
	 * Check if a log entry has already been reversed.
	 *
	 * @param int $log_id Original log ID.
	 *
	 * @return bool
	 */
	public function has_reversal( $log_id ) {
		global $wpdb;
		$table = $wpdb->prefix . $this->table;

		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$table} WHERE reference_id = %d AND reason = 'reversal' LIMIT 1",
				$log_id
			)
		);
	}
}
