<?php
/**
 * QR Table Ordering main class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\QrTableOrdering;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Api\QrTableOrdering\QrTableOrderingApi;

/**
 * QR Table Ordering main class.
 */
class QrTableOrdering {

	use SingletonTrait;

	/**
	 * Settings option.
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Init function — hooks if conditions are met.
	 *
	 * @return void
	 */
	protected function init() {
		$this->options = FnsPro::get_settings_option();

		$fm_type = $this->options['fm_food_menu_type'] ?? 'food_menu_post';
		$enabled = $this->options['fmp_enable_qr_table_ordering'] ?? '';

		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type || 'on' !== $enabled ) {
			return;
		}

		// REST API.
		QrTableOrderingApi::get_instance();

		// Admin hooks.
		add_filter( 'fmp/sub_menu/qr_table_ordering', [ $this, 'render_page' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue' ] );

		// Frontend: handle ?fmp_location= param from QR codes.
		$food_location_enabled = $this->options['fmp_food_location_popup'] ?? '';

		if ( 'on' === $food_location_enabled ) {
			// Set cookie in PHP early so LocationFilter picks it up on the same request.
			add_action( 'wp_loaded', [ $this, 'set_qr_location_cookie' ], 1 );
			// Set localStorage + dispatch JS event for popup/UI updates.
			add_action( 'wp_footer', [ $this, 'handle_qr_location_param' ] );
		}

		// Frontend ordering flow: session, order meta, admin display.
		// Use wp_loaded (not woocommerce_init) because both WC and FMP hook init at priority 0,
		// so woocommerce_init may fire before our controller registers its listener.
		add_action( 'wp_loaded', [ $this, 'frontend_detect_table_param' ] );
		add_action( 'woocommerce_checkout_create_order', [ $this, 'save_table_meta_to_order' ], 10, 1 );
		// Block (Gutenberg) checkout uses StoreAPI, which doesn't fire
		// woocommerce_checkout_create_order — mirror the save there too.
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', [ $this, 'save_table_meta_to_order_block' ], 10, 1 );
		add_action( 'woocommerce_new_order', [ $this, 'clear_table_session' ] );
		// Customer-facing order details (thank-you + My Account → View Order).
		// Owned by this controller so QR info survives any override changes to
		// the shared Pro `food_menu_order_details` renderer.
		add_action( 'woocommerce_order_details_after_order_table_items', [ $this, 'render_table_on_order_details' ], 20 );
		// Render inside the Order Information metabox (view + edit slots).
		add_action( 'fmp_order_info_view', [ $this, 'render_table_view' ] );
		add_action( 'fmp_order_info_edit', [ $this, 'render_table_edit' ] );
		// Ensure the metabox doesn't render its "no info" empty state when only
		// the QR table value is set.
		add_filter( 'fmp_order_info_has_data', [ $this, 'flag_metabox_has_data' ], 10, 2 );

		// Save edits to the QR Table field on the admin order screen (legacy + HPOS).
		add_action( 'woocommerce_process_shop_order_meta', [ $this, 'save_table_from_admin_order' ], 10, 2 );
		add_action( 'woocommerce_admin_process_order_object', [ $this, 'save_table_from_admin_order_object' ], 10, 1 );

		// Admin orders list — add Table column.
		add_filter( 'manage_edit-shop_order_columns', [ $this, 'add_table_column' ] );
		add_filter( 'manage_woocommerce_page_wc-orders_columns', [ $this, 'add_table_column' ] );
		add_action( 'manage_shop_order_posts_custom_column', [ $this, 'render_table_column' ], 10, 2 );
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', [ $this, 'render_table_column' ], 10, 2 );

		// Show the chosen table at the top of the checkout (classic shortcode
		// + custom checkout template — both fire this action).
		add_action( 'woocommerce_before_checkout_form', [ $this, 'render_checkout_table_banner' ], 5 );
		// Block (Gutenberg) checkout doesn't fire the action above — prepend
		// the banner to the_content when the page actually has the block.
		add_filter( 'the_content', [ $this, 'prepend_banner_to_block_checkout' ], 5 );

		// Minimal-checkout field filter for QR/dine-in orders.
		add_filter( 'woocommerce_checkout_fields', [ $this, 'filter_checkout_fields_for_minimal_mode' ], 100 );
		// Also tell WC the cart no longer needs a shipping address so the
		// classic shortcode checkout doesn't render an empty shipping block.
		add_filter( 'woocommerce_cart_needs_shipping_address', [ $this, 'filter_needs_shipping_address_for_minimal_mode' ], 100 );
	}

	/**
	 * Whether the current visitor has an active QR table session — i.e. they
	 * arrived through a `?fmp_table=…` link and the WC session still carries
	 * the matched table data. Used by checkout modules to skip the
	 * Pickup & Delivery UI for dine-in QR orders.
	 *
	 * Safe to call even when the QR feature is disabled (returns false).
	 *
	 * @return bool
	 */
	public static function has_active_session() {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return false;
		}

		$data = WC()->session->get( 'fmp_qr_table' );

		if ( empty( $data ) || ! is_array( $data ) || empty( $data['name'] ) ) {
			return false;
		}

		// Auto-reset stale sessions when the configured timeout has elapsed
		// without an order. set_at < required => self-clear and return false.
		$timeout = self::get_session_timeout_seconds();
		$set_at  = isset( $data['set_at'] ) ? (int) $data['set_at'] : 0;
		if ( $timeout > 0 && $set_at > 0 && ( time() - $set_at ) > $timeout ) {
			WC()->session->__unset( 'fmp_qr_table' );
			return false;
		}

		return true;
	}

	/**
	 * Get the active QR table session data (after the expiry check). Returns
	 * null when no session is active or it has been auto-cleared.
	 *
	 * @return array|null
	 */
	public static function get_active_session() {
		if ( ! self::has_active_session() ) {
			return null;
		}
		return WC()->session->get( 'fmp_qr_table' );
	}

	/**
	 * Billing field keys kept when minimal-checkout mode is active. Everything
	 * else gets stripped from the WC checkout form for in-house QR orders.
	 *
	 * @return string[]
	 */
	public static function minimal_billing_field_keys() {
		return [
			'billing_first_name',
			'billing_last_name',
			'billing_email',
			'billing_phone',
		];
	}

	/**
	 * Whether the minimal-checkout layout should be applied right now —
	 * i.e. the admin enabled the toggle AND there is an active QR session.
	 *
	 * @return bool
	 */
	public static function is_minimal_checkout_active() {
		$settings = function_exists( 'TLPFoodMenu' )
			? get_option( TLPFoodMenu()->options['settings'], [] )
			: [];

		if ( 'on' !== ( $settings['fmp_qr_minimal_checkout'] ?? 'on' ) ) {
			return false;
		}

		return self::has_active_session();
	}

	/**
	 * Strip the WC checkout fields down to name/email/phone when minimal
	 * mode is active. Shipping section is emptied too — dine-in QR orders
	 * don't need a delivery address.
	 *
	 * @param array $fields Checkout fields grouped by section.
	 *
	 * @return array
	 */
	public function filter_checkout_fields_for_minimal_mode( $fields ) {
		if ( ! self::is_minimal_checkout_active() ) {
			return $fields;
		}

		if ( isset( $fields['billing'] ) && is_array( $fields['billing'] ) ) {
			$keep = array_flip( self::minimal_billing_field_keys() );
			$fields['billing'] = array_intersect_key( $fields['billing'], $keep );

			// Only the mobile number is required — everything else is
			// optional in minimal mode.
			foreach ( self::minimal_billing_field_keys() as $key ) {
				if ( ! isset( $fields['billing'][ $key ] ) ) {
					continue;
				}
				$fields['billing'][ $key ]['required'] = ( 'billing_phone' === $key );
			}
		}

		if ( isset( $fields['shipping'] ) && is_array( $fields['shipping'] ) ) {
			$fields['shipping'] = [];
		}

		return $fields;
	}

	/**
	 * Drop the cart's shipping-address requirement while minimal QR mode
	 * is active so the classic checkout doesn't render a shipping section.
	 *
	 * @param bool $needs Current value from WC.
	 *
	 * @return bool
	 */
	public function filter_needs_shipping_address_for_minimal_mode( $needs ) {
		return self::is_minimal_checkout_active() ? false : $needs;
	}

	/**
	 * Prepend the table banner to the_content when the post contains the
	 * block checkout. Block checkout doesn't fire
	 * `woocommerce_before_checkout_form`, so the standard action-based
	 * banner never renders there — this fills that gap without affecting
	 * classic shortcode checkout (which doesn't use the block) or the
	 * custom checkout template (which bypasses `the_content` via
	 * `template_include`).
	 *
	 * @param string $content Original post content.
	 *
	 * @return string
	 */
	public function prepend_banner_to_block_checkout( $content ) {
		if ( is_admin() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return $content;
		}

		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			return $content;
		}

		global $post;
		if ( ! $post || ! function_exists( 'has_block' ) || ! has_block( 'woocommerce/checkout', $post ) ) {
			return $content;
		}

		ob_start();
		$this->render_checkout_table_banner();
		$banner = ob_get_clean();

		// render_checkout_table_banner() already self-suppresses when there's
		// nothing to show. Skip prepending if it produced no output.
		if ( '' === trim( $banner ) ) {
			return $content;
		}

		return $banner . $content;
	}

	/**
	 * Render the chosen-table banner above the checkout form. Fires on
	 * woocommerce_before_checkout_form (classic + custom checkout). No-op
	 * when there's no active QR session.
	 *
	 * @return void
	 */
	public function render_checkout_table_banner() {
		$session    = self::get_active_session();
		$table_name = $session ? (string) ( $session['name'] ?? '' ) : '';

		// Resolve the active location from the cookie. Works for QR-scanned
		// sessions (set via ?fmp_location=) and for normal popup-selected
		// locations, since both write the same cookie.
		$location_name = '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$location_id = ! empty( $_COOKIE['fmp_location_id'] ) ? absint( $_COOKIE['fmp_location_id'] ) : 0;
		if ( $location_id && taxonomy_exists( 'tpl-food-location' ) ) {
			$term = get_term( $location_id, 'tpl-food-location' );
			if ( $term && ! is_wp_error( $term ) ) {
				$location_name = $term->name;
			}
		}

		// Nothing to show — bail (no QR session, no chosen location).
		if ( '' === $table_name && '' === $location_name ) {
			return;
		}
		?>
		<div class="fmp-checkout-table-banner" style="display:flex;flex-wrap:wrap;align-items:center;gap:18px;padding:14px 18px;margin:0 0 18px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;color:#1e3a8a;">
			<?php if ( '' !== $table_name ) : ?>
				<div class="fmp-checkout-table-banner__item" style="display:flex;align-items:center;gap:10px;font-size:14px;">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
					</svg>
					<span><?php echo esc_html__( 'Table', 'food-menu-pro' ); ?>:</span>
					<strong style="font-weight:700;font-size:15px;"><?php echo esc_html( $table_name ); ?></strong>
				</div>
			<?php endif; ?>

			<?php if ( '' !== $location_name ) : ?>
				<div class="fmp-checkout-table-banner__item fmp-checkout-table-banner__location" style="display:flex;align-items:center;gap:10px;font-size:14px;color:#9a3412;">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
					</svg>
					<span><?php echo esc_html__( 'Location', 'food-menu-pro' ); ?>:</span>
					<strong style="font-weight:700;font-size:15px;"><?php echo esc_html( $location_name ); ?></strong>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render the React mount point.
	 *
	 * @return void
	 */
	public function render_page() {
		echo '<div class="wrap"><div id="fmp-qr-table-ordering"></div></div>';
	}

	/**
	 * Enqueue React app script on the QR Table Ordering page.
	 *
	 * @return void
	 */
	public function admin_enqueue() {
		$screen = get_current_screen();

		if ( ! $screen || 'food-menu_page_qr_table_ordering' !== $screen->id ) {
			return;
		}

		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : FMP()->options['version'];

		wp_enqueue_script(
			'fmp-qr-table-ordering',
			FMP()->assets_url() . 'js/qr-table-ordering.min.js',
			[ 'wp-element', 'wp-api-fetch', 'wp-i18n' ],
			$version,
			true
		);
		wp_set_script_translations( 'fmp-qr-table-ordering', 'food-menu-pro', FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages' );

		// Build locations array if food location is enabled.
		$locations = [];
		$food_location_enabled = $this->options['fmp_food_location_popup'] ?? '';

		if ( 'on' === $food_location_enabled && taxonomy_exists( 'tpl-food-location' ) ) {
			$terms = get_terms(
				[
					'taxonomy'   => 'tpl-food-location',
					'hide_empty' => false,
				]
			);

			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$locations[] = [
						'value' => $term->term_id,
						'label' => $term->name,
					];
				}
			}
		}

		wp_localize_script(
			'fmp-qr-table-ordering',
			'fmpQrTableOrdering',
			[
				'nonce'        => wp_create_nonce( 'wp_rest' ),
				'restRoot'     => esc_url_raw( rest_url() ),
				'apiUrl'       => esc_url( rest_url( 'fmp/v1' ) ),
				'pluginUrl'    => esc_url( FOOD_MENU_PRO_PLUGIN_URL ),
				'siteUrl'      => esc_url( home_url( '/' ) ),
				'locations'    => $locations,
				'primaryColor' => \RT\FoodMenu\Helpers\Fns::get_setting( 'fm_primary_color', '#fc202e' ),
			]
		);
	}

	/**
	 * Detect ?fmp_table= URL parameter and store the matching QR code data in the
	 * WooCommerce session so it can be saved to the order when checkout completes.
	 *
	 * Runs on woocommerce_init so WC()->session is available.
	 *
	 * @return void
	 */
	public function frontend_detect_table_param() {
		// Only run on frontend page loads (not admin, AJAX, REST).
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['fmp_table'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$param_slug = sanitize_title( wp_unslash( $_GET['fmp_table'] ) );

		if ( ! $param_slug ) {
			return;
		}

		$qr_codes = get_option( 'fmp_qr_codes', [] );

		if ( ! is_array( $qr_codes ) || empty( $qr_codes ) ) {
			return;
		}

		$matched = null;

		foreach ( $qr_codes as $qr ) {
			if ( sanitize_title( $qr['table_name'] ?? '' ) === $param_slug ) {
				$matched = $qr;
				break;
			}
		}

		if ( ! $matched ) {
			return;
		}

		if ( ! WC()->session ) {
			return;
		}

		// Ensure session cookie exists for new visitors so data persists across pages.
		if ( ! WC()->session->has_session() ) {
			WC()->session->set_customer_session_cookie( true );
		}

		WC()->session->set(
			'fmp_qr_table',
			[
				'id'     => $matched['id'],
				'name'   => $matched['table_name'],
				'set_at' => time(),
			]
		);
	}

	/**
	 * Session timeout in seconds. 0 disables auto-reset.
	 *
	 * @return int
	 */
	public static function get_session_timeout_seconds() {
		$settings = function_exists( 'TLPFoodMenu' )
			? get_option( TLPFoodMenu()->options['settings'], [] )
			: [];
		$minutes  = absint( $settings['fmp_qr_session_timeout'] ?? 0 );

		return $minutes * MINUTE_IN_SECONDS;
	}

	/**
	 * Save QR table session data as order meta when a new order is created.
	 *
	 * Runs on woocommerce_checkout_create_order (fires before the order is saved,
	 * so update_meta_data() is correct — WC will flush it on save).
	 *
	 * @param \WC_Order $order The order being created.
	 *
	 * @return void
	 */
	public function save_table_meta_to_order( $order ) {
		if ( ! WC()->session ) {
			return;
		}

		$table_data = WC()->session->get( 'fmp_qr_table' );

		if ( empty( $table_data ) || ! is_array( $table_data ) ) {
			return;
		}

		$table_id   = sanitize_text_field( $table_data['id'] ?? '' );
		$table_name = sanitize_text_field( $table_data['name'] ?? '' );

		if ( $table_id ) {
			$order->update_meta_data( 'fmp_qr_table_id', $table_id );
		}

		if ( $table_name ) {
			$order->update_meta_data( 'fmp_qr_table_name', $table_name );
		}
	}

	/**
	 * Block (Gutenberg) checkout variant of save_table_meta_to_order.
	 *
	 * The StoreAPI checkout flow doesn't fire
	 * `woocommerce_checkout_create_order`, so we listen on its dedicated
	 * `woocommerce_store_api_checkout_update_order_from_request` action to
	 * write the same meta keys.
	 *
	 * @param \WC_Order $order Order being created by the block checkout.
	 *
	 * @return void
	 */
	public function save_table_meta_to_order_block( $order ) {
		$this->save_table_meta_to_order( $order );
	}

	/**
	 * Customer-facing render of the QR Code Table on the WC order details
	 * template (order-received + My Account → View Order).
	 *
	 * Fires on `woocommerce_order_details_after_order_table_items` inside the
	 * items <tbody>, so output must be a <tr> row. Self-contained so it
	 * doesn't depend on the Pro/Free `food_menu_order_details` override chain.
	 *
	 * @param \WC_Order $order Order being viewed.
	 *
	 * @return void
	 */
	public function render_table_on_order_details( $order ) {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		$table_name = (string) $order->get_meta( 'fmp_qr_table_name' );

		if ( '' === $table_name ) {
			return;
		}
		?>
		<tr class="fmp-order-qr-table-row">
			<th><?php esc_html_e( 'QR Table:', 'food-menu-pro' ); ?></th>
			<td>
				<span style="display:inline-block;padding:2px 10px;background:#6366f1;border-radius:4px;color:#fff;font-weight:600;text-transform:uppercase;">
					<?php echo esc_html( $table_name ); ?>
				</span>
			</td>
		</tr>
		<?php
	}

	/**
	 * Clear the QR table session after the order is placed.
	 *
	 * Runs on woocommerce_new_order (fires after the order row is inserted).
	 *
	 * @return void
	 */
	public function clear_table_session() {
		if ( ! is_admin() && WC()->session ) {
			WC()->session->__unset( 'fmp_qr_table' );
		}
	}

	/**
	 * Read-only QR table block for the Order Information metabox view mode.
	 * Only renders when the order has a table assigned.
	 *
	 * @param \WC_Order $order Order being rendered.
	 *
	 * @return void
	 */
	public function render_table_view( $order ) {
		$table_name = (string) $order->get_meta( 'fmp_qr_table_name' );
		if ( '' === $table_name ) {
			return;
		}
		?>
		<div style="margin-top:14px;padding-top:14px;border-top:1px solid #e5e7eb;display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
			<span style="font-size:11px;color:#6b7280;text-transform:uppercase;letter-spacing:0.04em;font-weight:600;">
				<?php echo esc_html__( 'QR Code Table', 'food-menu-pro' ); ?>
			</span>
			<span style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;border-radius:6px;font-weight:600;">
				<?php echo esc_html( $table_name ); ?>
			</span>
			<span style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:#ecfdf5;color:#047857;border:1px solid #a7f3d0;border-radius:6px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.04em;">
				<?php echo esc_html__( 'QR Code Scan', 'food-menu-pro' ); ?>
			</span>
		</div>
		<?php
	}

	/**
	 * Editable QR table field for the Order Information metabox edit mode.
	 * Renders a strict <select> when QR codes exist, otherwise a text input.
	 *
	 * @param \WC_Order $order Order being rendered.
	 *
	 * @return void
	 */
	public function render_table_edit( $order ) {
		$table_name    = (string) $order->get_meta( 'fmp_qr_table_name' );
		$table_numbers = FnsPro::get_qr_table_names();
		$has_list      = ! empty( $table_numbers );

		$input_style = 'width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid #e5e7eb;border-radius:6px;background:#fff;font-size:14px;color:#111827;line-height:1.4;outline:none;';
		$label_style = 'font-size:11px;color:#6b7280;text-transform:uppercase;letter-spacing:0.04em;font-weight:600;margin-bottom:6px;display:block;';
		?>
		<div style="border-top:1px solid #e5e7eb;padding-top:14px;margin-top:14px;">
			<label for="fmp_qr_table_name" style="<?php echo esc_attr( $label_style ); ?>">
				<?php echo esc_html__( 'QR Code Table', 'food-menu-pro' ); ?>
			</label>
			<?php wp_nonce_field( 'fmp_save_qr_table', 'fmp_qr_table_nonce' ); ?>
			<?php if ( $has_list ) : ?>
				<select name="fmp_qr_table_name" id="fmp_qr_table_name" style="<?php echo esc_attr( $input_style ); ?>">
					<option value=""><?php echo esc_html__( '— Select a table —', 'food-menu-pro' ); ?></option>
					<?php foreach ( $table_numbers as $name ) : ?>
						<option value="<?php echo esc_attr( $name ); ?>" <?php selected( $name, $table_name ); ?>><?php echo esc_html( $name ); ?></option>
					<?php endforeach; ?>
				</select>
			<?php else : ?>
				<input type="text" name="fmp_qr_table_name" id="fmp_qr_table_name" value="<?php echo esc_attr( $table_name ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Make sure the Order Information metabox treats the box as populated
	 * when only the QR table name is set (so it shows the value instead of
	 * the "no info yet" empty state).
	 *
	 * @param bool      $has_data Current flag from the metabox.
	 * @param \WC_Order $order    Order being rendered.
	 *
	 * @return bool
	 */
	public function flag_metabox_has_data( $has_data, $order ) {
		if ( $has_data ) {
			return $has_data;
		}
		return (bool) $order->get_meta( 'fmp_qr_table_name' );
	}

	/**
	 * Save the QR table name when an admin saves an order on the legacy
	 * shop_order screen. Reads the posted value and updates the order meta.
	 *
	 * @param int      $order_id Order ID.
	 * @param \WP_Post $post     Post object (unused).
	 *
	 * @return void
	 */
	public function save_table_from_admin_order( $order_id, $post = null ) {
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$nonce = isset( $_POST['fmp_qr_table_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_qr_table_nonce'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'fmp_save_qr_table' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$raw = isset( $_POST['fmp_qr_table_name'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_qr_table_name'] ) ) : '';

		$this->persist_table_name_on_order( $order, $raw );
		$order->save();
	}

	/**
	 * HPOS-friendly save handler. Receives the WC_Order object directly.
	 *
	 * @param \WC_Order $order Order being saved.
	 *
	 * @return void
	 */
	public function save_table_from_admin_order_object( $order ) {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$nonce = isset( $_POST['fmp_qr_table_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_qr_table_nonce'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'fmp_save_qr_table' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$raw = isset( $_POST['fmp_qr_table_name'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_qr_table_name'] ) ) : '';

		$this->persist_table_name_on_order( $order, $raw );
		// WC's HPOS pipeline saves the object after this hook fires.
	}

	/**
	 * Apply the submitted table name to the order. Empty value clears the meta.
	 *
	 * @param \WC_Order $order Order object.
	 * @param string    $raw   Submitted value, already sanitized.
	 *
	 * @return void
	 */
	private function persist_table_name_on_order( $order, $raw ) {
		$value = trim( (string) $raw );

		if ( '' === $value ) {
			$order->delete_meta_data( 'fmp_qr_table_name' );
		} else {
			$order->update_meta_data( 'fmp_qr_table_name', $value );
		}
	}

	/**
	 * Set the location cookie from ?fmp_location= URL param in PHP,
	 * so LocationFilter can read it on the same request.
	 *
	 * Runs on wp_loaded at priority 1 (before shortcodes render).
	 *
	 * @return void
	 */
	public function set_qr_location_cookie() {
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['fmp_location'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$location_id = absint( $_GET['fmp_location'] );

		if ( ! $location_id ) {
			return;
		}

		// Set PHP superglobal so LocationFilter picks it up on this request.
		$_COOKIE['fmp_location_id'] = (string) $location_id;

		// Send cookie to browser for subsequent requests (30 days).
		if ( ! headers_sent() ) {
			setcookie( 'fmp_location_id', (string) $location_id, time() + ( 30 * DAY_IN_SECONDS ), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), false );
		}
	}

	/**
	 * Add Table column to WooCommerce admin orders list.
	 *
	 * @param array $columns Existing columns.
	 *
	 * @return array
	 */
	public function add_table_column( $columns ) {
		$food_location_enabled = $this->options['fmp_food_location_popup'] ?? '';

		if ( 'on' === $food_location_enabled ) {
			$columns['fmp_location'] = esc_html__( 'Location', 'food-menu-pro' );
		}

		$columns['fmp_qr_table'] = esc_html__( 'Table', 'food-menu-pro' );

		return $columns;
	}

	/**
	 * Render Table column content in WooCommerce admin orders list.
	 *
	 * @param string              $column         Column slug.
	 * @param \WC_Order|int|mixed $order_or_id    Order object or ID.
	 *
	 * @return void
	 */
	public function render_table_column( $column, $order_or_id ) {
		if ( 'fmp_qr_table' !== $column && 'fmp_location' !== $column ) {
			return;
		}

		$order = $order_or_id instanceof \WC_Order ? $order_or_id : wc_get_order( $order_or_id );

		if ( ! $order ) {
			echo '&mdash;';
			return;
		}

		if ( 'fmp_qr_table' === $column ) {
			// Fall back to the Dine In table so the column isn't blank for
			// dine-in orders. QR keeps its blue badge; dine-in gets its own.
			$table_name = $order->get_meta( 'fmp_qr_table_name' );
			$table_bg   = '#1677ff';

			if ( ! $table_name ) {
				$table_name = $order->get_meta( 'fmp_dinein_table' );
				$table_bg   = '#b8860b';
			}

			if ( $table_name ) {
				echo '<span style="display:inline-block;padding:1px 8px;background:' . esc_attr( $table_bg ) . ';border-radius:4px;color:#fff;font-size:12px;font-weight:bold;">' . esc_html( $table_name ) . '</span>';
			} else {
				echo '&mdash;';
			}
		}

		if ( 'fmp_location' === $column ) {
			$location_name = $order->get_meta( 'fmp_location_name' );
			if ( $location_name ) {
				echo '<span style="display:inline-block;padding:1px 8px;background:#52c41a;border-radius:4px;color:#fff;font-size:12px;font-weight:bold;">' . esc_html( $location_name ) . '</span>';
			} else {
				echo '&mdash;';
			}
		}
	}

	/**
	 * Handle ?fmp_location= parameter from QR code scans.
	 *
	 * Outputs inline JS that auto-sets the location cookie/localStorage
	 * to bypass the location popup when scanning a QR code.
	 *
	 * @return void
	 */
	public function handle_qr_location_param() {
		// Only output the script when ?fmp_location= is actually in the URL.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['fmp_location'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$location_id = absint( $_GET['fmp_location'] );

		if ( ! $location_id || ! taxonomy_exists( 'tpl-food-location' ) ) {
			return;
		}

		$term = get_term( $location_id, 'tpl-food-location' );

		if ( is_wp_error( $term ) || ! $term ) {
			return;
		}

		$location_name = $term->name;
		?>
		<script>
		(function() {
			var locationId = <?php echo wp_json_encode( (string) $location_id ); ?>;
			var locationName = <?php echo wp_json_encode( $location_name ); ?>;

			// Set cookie (same as location popup in foodmenu.js).
			document.cookie = 'fmp_location_id=' + locationId + '; path=/; max-age=2592000; SameSite=Lax';

			// Set localStorage (same format as location popup).
			try {
				localStorage.setItem('fmp_location', JSON.stringify({name: locationId, value: locationName}));
			} catch(e) {}

			// Dispatch event so pickup/delivery and other listeners react.
			document.dispatchEvent(new CustomEvent('fmp:location-changed', {detail: {id: locationId, name: locationName}}));
		})();
		</script>
		<?php
	}
}
