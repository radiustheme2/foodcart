<?php
/**
 * QR Table Ordering settings fields.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\QrTableOrdering;

defined( 'ABSPATH' ) || exit();

/**
 * QR Table Ordering settings fields class.
 */
class QrTableOrderingFns {

	/**
	 * QR Table Ordering setting fields.
	 *
	 * @return array
	 */
	public static function settings_field() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return [
			'fmp_enable_qr_table_ordering' => [
				'type'        => 'switch',
				'label'       => esc_html__( 'Enable QR Table Ordering', 'food-menu-pro' ),
				'description' => esc_html__( 'Generate QR codes for dine-in table ordering.', 'food-menu-pro' ),
				'value'       => $settings['fmp_enable_qr_table_ordering'] ?? '',
			],
		];
	}
}
