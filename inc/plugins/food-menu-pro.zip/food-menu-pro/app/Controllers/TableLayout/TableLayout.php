<?php

namespace RT\FoodMenuPro\Controllers\TableLayout;

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Table layout main class.
 */
class TableLayout {

	use SingletonTrait;

	/**
	 * Admin settings
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Auto call this function when create this class object
	 *
	 * @return void
	 */
	public function init() {
		$this->options = FnsPro::get_settings_option();
		new SettingsApi();
		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue_assets' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
		add_filter( 'fmp/sub_menu/table_layout', [ $this, 'table_layout_setting' ] );
	}

	/**
	 * Table layout setting page
	 *
	 * @return void
	 */
	public function table_layout_setting() {
		?>
        <div class="table-layout-settings">

            <div class="table-layout-header">
                <h2 class="fmp-page-heading"><?php echo esc_html__( 'Generate Table', 'food-menu-pro' ); ?></h2>
                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=food-menu&page=food_menu_settings_updated#/reservation' ) ); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                    <?php echo esc_html__( 'Go To Reservation Settings', 'food-menu-pro' ); ?>
                </a>
            </div>

            <div class="table-layout-settings-inner">
                <div class="fmp-main-table" id="fmp-table-layout"></div>

                <div class="fmp-table-export-import">
                    <h2><?php echo esc_html__("Export Table Layout", "food-menu-pro") ?></h2>

                    <!-- Export Form -->
                    <form method="post">
                        <?php wp_nonce_field('fmp_export_nonce', 'fmp_export_nonce_field'); ?>
                        <input type="submit" name="fmp_export" class="rt-image-upload-btn" value="Export">
                    </form>

                    <hr>
                    <h2><?php echo esc_html__("Import Table Layout", "food-menu-pro") ?></h2>
                    <!-- Import Form -->
                    <form method="post" enctype="multipart/form-data">
                        <?php wp_nonce_field('fmp_import_nonce', 'fmp_import_nonce_field'); ?>
                        <input type="file" name="fmp_import_file" class="fmp_import_file_btn" required>
                        <input type="submit" name="fmp_import" class="rt-image-upload-btn import-btn" value="Import">
                    </form>
                </div>
            </div>
        </div>
		<?php
	}

	/**
	 * Admin enqueue
	 *
	 * @return void
	 */
	public function admin_enqueue_assets() {
		global $pagenow, $typenow;
		$settings          = $this->options;
		$table_layout_page = $_GET['page'] ?? ''; //phpcs:ignore
		$table_page        = in_array( $pagenow, [ 'edit.php', 'post.php', 'post-new.php' ], true );

		if ( TLPFoodMenu()->post_type == $typenow && 'table_layout' == $table_layout_page && $table_page ) {
			wp_enqueue_media();
			wp_enqueue_script( 'fmp-table-layout' );
			wp_localize_script(
				'fmp-table-layout',
				'fmpTblParams',
				[
					'seatCapacity' => ! empty( $settings['fmp_resi_seat_capacity'] ) ? $settings['fmp_resi_seat_capacity'] : 30,
					'resturl'      => get_rest_url(),
					'restNonce'    => wp_create_nonce( 'wp_rest' ),
				]
			);
		}
	}

	/**
	 * Frontend enqueue.
	 *
	 * @return void
	 */
	public function frontend_enqueue_assets() {
		wp_enqueue_script( 'fmp-table-layout' );
		wp_localize_script(
			'fmp-table-layout',
			'fmpTblParams',
			[
				'seatCapacity' => $settings['fmp_resi_seat_capacity'] ?? 30,
				'resturl'      => get_rest_url(),
			]
		);
	}

}
