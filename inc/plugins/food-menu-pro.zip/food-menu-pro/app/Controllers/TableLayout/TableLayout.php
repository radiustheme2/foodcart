<?php

namespace RT\FoodMenuPro\Controllers\TableLayout;

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Table layout main class.
 */
class TableLayout {

	use SingletonTrait;

	/**
	 * Admin settings
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Auto call this function when create this class object
	 *
	 * @return void
	 */
	public function init() {
		$this->options = FnsPro::get_settings_option();
		new SettingsApi();
		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue_assets' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
		add_filter( 'fmp/sub_menu/table_layout', [ $this, 'table_layout_setting' ] );
	}

	/**
	 * Table layout setting page
	 *
	 * @return void
	 */
	public function table_layout_setting() {
		?>
        <div class="table-layout-settings">
            <h2 class="fmp-page-heading"><?php echo esc_html__( 'Generate Table', 'food-menu-pro' ); ?></h2>
            <div class="fmp-main-table" id="fmp-table-layout"></div>

            <div class="fmp-table-export-import" style="background: #FFF; padding: 30px; border-radius: 5px;">
                <h2><?php echo esc_html__("Export Table Layout", "food-menu-pro") ?></h2>

                <!-- Export Form -->
                <form method="post">
		            <?php wp_nonce_field('fmp_export_nonce', 'fmp_export_nonce_field'); ?>
                    <input type="submit" name="fmp_export" class="rt-image-upload-btn" value="Export">
                </form>

                <hr>
                <h2><?php echo esc_html__("Import Table Layout", "food-menu-pro") ?></h2>
                <!-- Import Form -->
                <form method="post" enctype="multipart/form-data">
		            <?php wp_nonce_field('fmp_import_nonce', 'fmp_import_nonce_field'); ?>
                    <input type="file" name="fmp_import_file" class="fmp_import_file_btn" required>
                    <input type="submit" name="fmp_import" class="rt-image-upload-btn import-btn" value="Import">
                </form>
            </div>
        </div>
		<?php
	}

	/**
	 * Admin enqueue
	 *
	 * @return void
	 */
	public function admin_enqueue_assets() {
		global $pagenow, $typenow;
		$settings          = $this->options;
		$table_layout_page = $_GET['page'] ?? ''; //phpcs:ignore
		$table_page        = in_array( $pagenow, [ 'edit.php', 'post.php', 'post-new.php' ], true );

		if ( TLPFoodMenu()->post_type == $typenow && 'table_layout' == $table_layout_page && $table_page ) {
			wp_enqueue_media();
			wp_enqueue_script( 'fmp-table-layout' );
			wp_localize_script(
				'fmp-table-layout',
				'fmpTblParams',
				[
					'seatCapacity' => ! empty( $settings['fmp_resi_seat_capacity'] ) ? $settings['fmp_resi_seat_capacity'] : 30,
					'resturl'      => get_rest_url(),
				]
			);
		}
	}

	/**
	 * Frontend enqueue.
	 *
	 * @return void
	 */
	public function frontend_enqueue_assets() {
		wp_enqueue_script( 'fmp-table-layout' );
		wp_localize_script(
			'fmp-table-layout',
			'fmpTblParams',
			[
				'seatCapacity' => $settings['fmp_resi_seat_capacity'] ?? 30,
				'resturl'      => get_rest_url(),
			]
		);
	}

}
