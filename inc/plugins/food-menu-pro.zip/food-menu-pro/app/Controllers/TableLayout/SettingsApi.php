<?php
namespace RT\FoodMenuPro\Controllers\TableLayout;

use RT\FoodMenuPro\Abstracts\CustomApi;
use RT\FoodMenuPro\Helpers\FnsPro;

defined( 'ABSPATH' ) || exit;

/**
 * Table layout setting api class
 */
class SettingsApi extends CustomApi {

	/**
	 * Table layout data insert in option
	 *
	 * @return array
	 */
	public function post_table_option() {
		$request     = $this->request;
		$status_code = 0;

		$nonce = $request->get_header( 'X-WP-Nonce' );
		if ( ! wp_verify_nonce( $nonce, 'fmp_nonce' ) ) {
			$messages = esc_html__( 'The nonce is invalid. Please try again.', 'food-menu-pro' );
			return [
				'status_code' => $status_code,
				'messages'    => $messages,
			];
		}

		if ( empty( $request['layout'] ) ) {
			$messages = esc_html__( 'Layout data is missing.', 'food-menu-pro' );
			return [
				'status_code' => $status_code,
				'messages'    => $messages,
			];
		}

		$table_layout_data = $request['layout'];
		$chair_qty         = absint( $table_layout_data['chairQty'] ) ?? 0;
		$set_capacity      = ! empty($this->settings['fmp_resi_seat_capacity']) ? $this->settings['fmp_resi_seat_capacity'] : 30;

		if ( $chair_qty > $set_capacity ) {
			$messages = esc_html__( 'You\'ve reached the max seats. Update capacity in settings to add more.', 'food-menu-pro' );
			return [
				'messages'    => $messages,
				'status_code' => $status_code,
			];
		}

		$schedule_slug = $request['schedule_slug'] ?? 'table_layout_slug';
		if ( empty( $schedule_slug ) ) {
			$messages = esc_html__( 'Reservation schedule setting issue. Review and update.', 'food-menu-pro' );
			return [
				'status_code' => $status_code,
				'messages'    => $messages,
			];
		}

		$chair_intersect_data = $table_layout_data['chairIntersectData'] ?? [];

		foreach ( $chair_intersect_data as  $chair_data ) {
			if ( empty( $chair_data ) ) {
				$messages = esc_html__( 'Ensure chairs are positioned under their respective tables to proceed.', 'food-menu-pro' );
				return [
					'status_code' => $status_code,
					'messages'    => $messages,
				];
			}
		}

		$status_code                         = 1;
		$messages                            = esc_html__( 'Table layout data saved successfully.', 'food-menu-pro' );
		$all_table_mapping                   = get_option( 'fmp_table_layout', [] );
		$all_table_mapping[ $schedule_slug ] = $table_layout_data;
		$all_table_mapping['common_mapping'] = $table_layout_data;

		update_option( 'fmp_table_layout', $all_table_mapping );

		return [
			'status_code' => $status_code,
			'messages'    => $messages,
		];
	}

	/**
	 * Get table layout option data
	 *
	 * @return array
	 */
	public function get_table_option() {
		$messages        = '';
		$status_code     = 1;
		$validation_code = 0;
		$booking_open    = 0;
		$table_content   = get_option( 'fmp_table_layout', [] );
		$request         = $this->request;
		$schedule_slug   = 'table_layout_slug';


		if ( ! empty( $table_content ) ) {

			$booked_ids       = [];
			$booked_table_ids = [];

			if ( ! is_admin() ) {
				if ( ! empty( $request['date'] ) ) {
					$inputs_field = [
						[
							'name'     => 'date',
							'required' => true,
							'type'     => 'text',
						],
						[
							'name'     => 'start_time',
							'required' => false,
							'type'     => 'text',
						],
						[
							'name'     => 'end_time',
							'required' => false,
							'type'     => 'text',
						],
					];

					$valid_data = FnsPro::input_field_validation( $request, $inputs_field );

					if ( ! empty( $valid_data['status_code'] ) ) {

						$validation_code = 1;
						$input_data      = $valid_data['data'];
						$selected_date   = $input_data['date'];
						$start_time      = ! empty( $input_data['start_time'] ) ? $input_data['start_time'] : '12:00 AM';
						$end_time        = ! empty( $input_data['end_time'] ) ? $input_data['end_time'] : '11:30 PM';

						$booking_data = FnsPro::get_booking_data( $selected_date, $start_time, $end_time );

						$booked_ids   = $booking_data['booked_ids'];
						$booking_open = $booking_data['booking_open'];

						if ( $booking_open && ! empty( $booked_ids ) ) {
							$table_chair_data = $table_content[ $schedule_slug ]['chairIntersectData'];

							foreach ( $table_chair_data as $table_id => $chair_arr ) {
								if ( empty( array_diff( $chair_arr, $booked_ids ) ) ) {
									$booked_table_ids[] = $table_id;
								}
							}
						}
					} else {
						$validation_code = $valid_data['status_code'];
						$messages        = $valid_data['messages'];
					}
				}
			}

			$table_content[ $schedule_slug ]['booked_ids']       = $booked_ids;
			$table_content[ $schedule_slug ]['booked_table_ids'] = $booked_table_ids;
		} else {
			$status_code = 0;
			$messages    = esc_html__( 'Mapping not yet established. Proceed to draw.', 'food-menu-pro' );
		}

		return [
			'status_code'     => $status_code,
			'booking_open'    => ! $booking_open,
			'validation_code' => $validation_code,
			'schedule_slug'   => $schedule_slug,
			'messages'        => $messages,
			'content'         => $table_content,
		];
	}
}
