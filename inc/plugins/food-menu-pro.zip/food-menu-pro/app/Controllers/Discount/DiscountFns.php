<?php

namespace RT\FoodMenuPro\Controllers\Discount;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * DiscountFns Class.
 */
class DiscountFns {
	/**
	 * Discount settings fields.
	 *
	 * @return array
	 */
	public static function discount_settings_fields() {
		return array_merge(
			self::percentage_settings_field(),
			self::fixed_settings_field(),
		);
	}

	/**
	 * Percentage setting fields.
	 *
	 * @return array
	 */
	public static function percentage_settings_field() {
		$settings         = FnsPro::get_settings_option();
		$fmp_include_menu = $settings['fmp_include_menu'] ?? [];
		$fmp_include_cat  = $settings['fmp_include_cat'] ?? [];
		return apply_filters(
			'fmp/discount_percentage_settings/fields',
			[
				'fmp_percentage_title'    => [
					'label' => esc_html__( 'Percentage discount applies to simple products included in specific menus and categories', 'food-menu-pro' ),
					'type'  => 'title',
				],

				'fmp_discount_percentage' => [
					'id'          => 'fmp_discount_percentage',
					'type'        => 'number',
					'placeholder' => esc_html__( 'Percentage', 'food-menu-pro' ),
					'label'       => esc_html__( 'Discount', 'food-menu-pro' ),
					'value'       => $settings['fmp_discount_percentage'] ?? '',
				],

				'fmp_include_menu'        => [
					'id'          => 'fmp_include_menu',
					'label'       => esc_html__( 'Include Menus', 'food-menu-pro' ),
					'type'        => 'select',
					'multiple'    => true,
					'class'       => 'fmp-ajax-select2',
					'post_type'   => 'product',
					'source_name' => 'post_type',
					'options'     => FnsPro::get_product_id_titles( $fmp_include_menu, 'product' ),
					'value'       => $settings['fmp_include_menu'] ?? [],
				],
				'fmp_include_cat'         => [
					'id'          => 'fmp_include_cat',
					'label'       => esc_html__( 'Include Categories', 'food-menu-pro' ),
					'type'        => 'select',
					'multiple'    => true,
					'class'       => 'fmp-ajax-select2',
					'post_type'   => 'product_cat',
					'source_name' => 'taxonomy',
					'options'     => FnsPro::get_term_names( $fmp_include_cat, 'product_cat' ),
					'value'       => $settings['fmp_include_cat'] ?? [],
				],

				'fmp_applicable_discount' => [
					'id'      => 'fmp_applicable_discount',
					'type'    => 'select',
					'label'   => esc_html__( 'Applicable Discount To?', 'food-menu-pro' ),
					'options' => [
						'total'       => esc_html__( 'Product Total Amount', 'food-menu-pro' ),
						'addon_total' => esc_html__( 'Product & Addons Total Amount', 'food-menu-pro' ),
					],
					'value'   => $settings['fmp_applicable_discount'] ?? '',
				],

			]
		);
	}

	/**
	 * Fixed setting fields.
	 *
	 * @return array
	 */
	public static function fixed_settings_field() {
		$settings = FnsPro::get_settings_option();

		return apply_filters(
			'fmp/discount_fixed_settings/fields',
			[
				'fmp_fixed_title'            => [
					'label' => esc_html__( 'Total order amount discount applies to total purchase and across all menus and categories', 'food-menu-pro' ),
					'type'  => 'title',
				],
				'fmp_fixed_order_amount'     => [
					'id'    => 'fmp_fixed_order_amount',
					'type'  => 'number',
					'label' => esc_html__( 'If Total Order >=:', 'food-menu-pro' ),
					'value' => $settings['fmp_fixed_order_amount'] ?? '',
				],
				'fmp_fixed_discount'         => [
					'id'    => 'fmp_fixed_discount',
					'type'  => 'number',
					'label' => esc_html__( 'Get Discount Amount:', 'food-menu-pro' ),
					'value' => $settings['fmp_fixed_discount'] ?? '',
				],
				'fmp_fixed_discount_message' => [
					'id'    => 'fmp_fixed_discount_message',
					'type'  => 'text',
					'label' => esc_html__( 'Discount Message', 'food-menu-pro' ),
					'value' => $settings['fmp_fixed_discount_message'] ?? '',
				],

			]
		);
	}
}
