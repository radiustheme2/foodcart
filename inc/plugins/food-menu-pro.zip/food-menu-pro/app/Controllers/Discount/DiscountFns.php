<?php

namespace RT\FoodMenuPro\Controllers\Discount;

use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * DiscountFns Class.
 *
 * Percentage-discount fields have been moved to the Free plugin; this class
 * now only exposes fixed-amount order discount fields.
 */
class DiscountFns {
	/**
	 * Discount settings fields.
	 *
	 * @return array
	 */
	public static function discount_settings_fields() {
		return self::fixed_settings_field();
	}

	/**
	 * Fixed setting fields.
	 *
	 * @return array
	 */
	public static function fixed_settings_field() {
		$settings = FnsPro::get_settings_option();

		return apply_filters(
			'fmp/discount_fixed_settings/fields',
			[
				'fmp_fixed_title'            => [
					'label' => esc_html__( 'Total order amount discount applies to total purchase and across all menus and categories', 'food-menu-pro' ),
					'type'  => 'title',
				],
				'fmp_fixed_order_amount'     => [
					'id'    => 'fmp_fixed_order_amount',
					'type'  => 'number',
					'label' => esc_html__( 'If Total Order >=:', 'food-menu-pro' ),
					'value' => $settings['fmp_fixed_order_amount'] ?? '',
				],
				'fmp_fixed_discount'         => [
					'id'    => 'fmp_fixed_discount',
					'type'  => 'number',
					'label' => esc_html__( 'Get Discount Amount:', 'food-menu-pro' ),
					'value' => $settings['fmp_fixed_discount'] ?? '',
				],
				'fmp_fixed_discount_message' => [
					'id'    => 'fmp_fixed_discount_message',
					'type'  => 'text',
					'label' => esc_html__( 'Discount Message', 'food-menu-pro' ),
					'value' => $settings['fmp_fixed_discount_message'] ?? '',
				],

			]
		);
	}
}
