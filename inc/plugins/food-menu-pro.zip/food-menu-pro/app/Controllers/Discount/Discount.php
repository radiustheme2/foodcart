<?php

namespace RT\FoodMenuPro\Controllers\Discount;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;

/**
 * Discount main class.
 */
class Discount {

	use SingletonTrait;

	/**
	 * Settings.
	 *
	 * @var array
	 */
	private $settings = [];

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		$this->settings = FnsPro::get_settings_option();
		$fm_type        = $this->settings['fm_food_menu_type'] ?? 'food_menu_post';
		if ( TLPFoodMenu()->isWcActive() && 'online_ordering' === $fm_type ) {

			// standard discount off.
			add_filter( 'woocommerce_calculated_total', [ $this, 'standard_discount_off' ] );
			add_action( 'woocommerce_cart_total', [ $this, 'cart_total_add_discount' ] );
			add_filter( 'woocommerce_cart_totals_order_total_html', [ $this, 'update_cart_total_html' ] );
			add_action( 'woocommerce_checkout_update_order_meta', [ $this, 'update_order_meta_data' ] );
			add_action( 'woocommerce_order_details_after_order_table', [ $this, 'checkout_order_thank_page' ] );
			add_action( 'woocommerce_admin_order_totals_after_total', [ $this, 'admin_order_details_page' ] );
			// percentage discount off.

			add_action( 'woocommerce_single_product_summary', [ $this, 'discount_percentage_product_single' ], 15 );
			add_filter( 'woocommerce_get_item_data', [ $this, 'show_cart_item_custom_meta_data' ], 10, 2 );
			// add_action( 'woocommerce_add_order_item_meta', [ $this, 'order_details_thank_you_add_discount' ], 1, 2 );
			add_action( 'woocommerce_new_order_item', [ $this, 'order_details_thank_you_add_discount' ], 1, 2 );
			add_filter( 'woocommerce_get_price_html', [ $this, 'simple_product_price_html' ], 10, 2 );

		}
	}

	/**
	 * Simple Product Price html change
	 *
	 * @param string $price_html .
	 * @param array  $product .
	 * @return mixed|string
	 */
	public function simple_product_price_html( $price_html, $product ) {

		$discount_price_args = [
			'product_id'    => $product->get_id(),
			'data'          => 'fmp_single_page',
			'product_price' => null,
		];

		$discount_data = FnsPro::discount_price( $discount_price_args );

		if (
			! empty( $discount_data['main_price'] ) &&
			! empty( $discount_data['price_after_discount'] ) &&
			$product->get_type() != 'variable'
		) {
			return sprintf(
				'<div class="fmp-price-wrap">
                            <del class="fmp-main-price">%s</del>
                            <span class="fmp-discount-price">%s</span>
                        </div>',
				wc_price( $discount_data['main_price'] ),
				wp_kses_post( $discount_data['price_after_discount'] )
			);
		}

		return $price_html;
	}


	/**
	 * Cart total add discount
	 *
	 * @param string $price .
	 * @return false|mixed|string
	 */
	public function cart_total_add_discount( $price ) {
		$actual_price = WC()->session->get( 'fmp_original_price' );
		$settings     = $this->settings;
		// Check if money off is not null and the necessary conditions are met.
		if (
			! empty( $actual_price ) &&
			! empty( $settings['fmp_fixed_order_amount'] ) &&
			! empty( $settings['fmp_fixed_discount'] ) &&
			absint( $settings['fmp_fixed_discount'] ) > 0 &&
			(float) $actual_price >= (float) $settings['fmp_fixed_order_amount']
		) {
			$settings_message = esc_html__( 'You earned discount ', 'food-menu-pro' ) . wc_price( $settings['fmp_fixed_discount'] );
			return sprintf( '<div>%s</div><div>(%s)</div>', $price, $settings_message );
		}
		return $price;
	}

	/**
	 * Total with standard money off function
	 *
	 * @param number $total .
	 * @return number
	 */
	public function standard_discount_off( $total ) {
		$settings = $this->settings;
		// Check if money off is not null and the necessary conditions are met.
		if (
			! empty( $settings['fmp_fixed_order_amount'] ) &&
			! empty( $settings['fmp_fixed_discount'] ) &&
			0 < absint( $settings['fmp_fixed_discount'] ) &&
			(float) $total >= (float) $settings['fmp_fixed_order_amount']
		) {
			WC()->session->set( 'fmp_discount_active', 'yes' );
			WC()->session->set( 'fmp_original_price', $total );
			return $total - $settings['fmp_fixed_discount'];
		}

		// Reset session variables if conditions are not met.
		WC()->session->set( 'fmp_discount_active', null );
		WC()->session->set( 'fmp_original_price', null );

		return $total;
	}

	/**
	 * Update Cart Total Message.
	 *
	 * @param mixed $value .
	 * @return mixed
	 */
	public function update_cart_total_html( $value ) {

		$discountApplied = WC()->session->get( 'fmp_discount_active' ) === 'yes';

		if ( $discountApplied ) {
			$settings        = $this->settings;
			$flatDiscountMsg = ! empty( $settings['fmp_fixed_discount_message'] )
				? $settings['fmp_fixed_discount_message']
				: esc_html__( 'Exclusive discount applied', 'food-menu-pro' );

			$discountMsgHtml = sprintf( '<span class="fmp-standard-discount-msg">(%s)</span>', esc_html( $flatDiscountMsg ) );
			$value          .= $discountMsgHtml;
		}

		return $value;
	}

	/**
	 * Update order meta data
	 *
	 * @param number $order_id .
	 * @return void
	 */
	public function update_order_meta_data( $order_id ) {
		$settings = $this->settings;
		$order    = wc_get_order( $order_id );

		$fmp_fixed_order_amount = $settings['fmp_fixed_order_amount'];
		$fmp_fixed_discount     = $settings['fmp_fixed_discount'];

		// Check if money off is applicable.
		if (
			! empty( $fmp_fixed_order_amount ) && ! empty( $fmp_fixed_discount )
			&& '0' !== $fmp_fixed_discount
			&& null !== $order && (float) $order->get_total() >= (float) $fmp_fixed_discount
		) {
			$settings_message = esc_html__( 'After Discount off ', 'food-menu-pro' ) . $fmp_fixed_discount;
			update_post_meta( $order_id, 'fmp_discount_off', $settings_message );
		}
	}

	/**
	 * Standard discount message function
	 *
	 * @param number $id .
	 * @return void
	 */
	private function standard_message( $id ) {
		$discount_off_msg = get_post_meta( $id, 'fmp_discount_off', true );
		?>
		<div class="fmp-standard-off"><?php echo esc_html( $discount_off_msg ); ?></div>
		<?php
	}

	/**
	 * Check discount for a product function
	 *
	 * @param number $product_id .
	 * @param string $flag .
	 * @return array
	 */
	public function check_discount_of_product( $product_id, $flag = null ) {

		$settings             = $this->settings;
		$fmp_discount_message = '';
		$tag_message          = '';
		$data                 = [];
		$fmp_discount_product = $settings['fmp_include_menu'] ?? [];
		$fmp_discount_cat     = $settings['fmp_include_cat'] ?? [];
		$fmp_percentage       = $settings['fmp_discount_percentage'] ?? null;

		if ( in_array( $product_id, $fmp_discount_product ) ) {
			if ( '0' !== $fmp_percentage && ! empty( $fmp_percentage ) ) {
				$fmp_discount_message .= esc_html__( 'Discount ', 'food-menu-pro' ) . $fmp_percentage . '%';
				$tag_message          .= esc_html( $fmp_percentage ) . '%';
			}
		} else {
			$fmp_terms = get_the_terms( $product_id, 'product_cat' );
			if ( is_array( $fmp_terms ) ) {
				foreach ( $fmp_terms as $term ) {
					if ( in_array( $term->term_id, $fmp_discount_cat ) ) {
						if ( '0' !== $fmp_percentage && ! empty( $fmp_percentage ) ) {
							$fmp_discount_message .= esc_html__( 'Discount ', 'food-menu-pro' ) . $fmp_percentage . '%';
							$tag_message          .= $fmp_percentage . esc_html__( '% off', 'food-menu-pro' );
						}
					}
				}
			}
		}

		if ( empty( $flag ) ) {
			$data['message']    = $fmp_discount_message;
			$data['percentage'] = ! empty( $data['message'] ) ? $fmp_percentage : '';
		} else {
			$data['percentage_offer'] = $tag_message;
		}

		return $data;
	}


	/**
	 * Checkout order thank you page add message.
	 *
	 * @param object $order .
	 * @return void
	 */
	public function checkout_order_thank_page( $order ) {
		$this->standard_message( $order->get_id() );
	}

	/**
	 * Admin order details page add standard discount message.
	 *
	 * @param number $order_id .
	 * @return void
	 */
	public function admin_order_details_page( $order_id ) {
		$this->standard_message( $order_id );
	}

	/**
	 * Show the discount percentage value in product single page
	 */
	public function discount_percentage_product_single() {
		global $product;
		$fmp_check_discount = $this->check_discount_of_product( $product->get_id(), null, );
		?>
		<div class="discount-message"><?php echo esc_html( $fmp_check_discount['message'] ); ?></div>
		<?php
	}

	/**
	 * Show discount data in cart item checkout and cart page.
	 *
	 * @param array $item_data .
	 * @param array $cart_item .
	 * @return array
	 */
	public function show_cart_item_custom_meta_data( $item_data, $cart_item ) {
		$fmp_check_discount = $this->check_discount_of_product( $cart_item['product_id'], null );
		if ( ! empty( $fmp_check_discount['message'] ) ) {
			$item_data['fmp_discount_price'] = [
				'key'     => esc_html__( 'Discount', 'food-menu-pro' ),
				'value'   => esc_html( $fmp_check_discount['message'] ),
				'display' => '',
			];
		}
		return $item_data;
	}

	/**
	 * Admin order details & Checkout thank you page add discount
	 *
	 * @param number $item_id .
	 * @param array  $values .
	 * @return void
	 */
	public function order_details_thank_you_add_discount( $item_id, $values ) {
		$discount_price_args = [
			'product_id'    => $values['product_id'],
			'data'          => 'thank_you_order_details',
			'product_price' => null,
		];

		$fmp_data = FnsPro::discount_price( $discount_price_args );

		if ( empty( $fmp_data['main_price'] ) || empty( $fmp_data['price_after_discount'] ) ) {
			return;
		}
		wc_add_order_item_meta( $item_id, esc_html__( 'Discount', 'food-menu-pro' ), $fmp_data['discount_percentage'] . '%' );
		wc_add_order_item_meta( $item_id, esc_html__( 'Main price', 'food-menu-pro' ), wc_price( $fmp_data['main_price'] ) );
		wc_add_order_item_meta( $item_id, esc_html__( 'Price after discount', 'food-menu-pro' ), $fmp_data['price_after_discount'] );
	}
}
