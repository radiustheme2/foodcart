<?php

namespace RT\FoodMenuPro\Controllers\Discount;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Blocks\CheckoutDiscount;

/**
 * Fixed-amount order discount controller (Pro).
 *
 * Percentage-based product discount lives in the Free plugin's
 * RT\FoodMenu\Controllers\Discount\Discount class.
 */
class Discount {

	use SingletonTrait;

	/**
	 * Settings.
	 *
	 * @var array
	 */
	private $settings = [];

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		$this->settings = FnsPro::get_settings_option();
		$fm_type        = $this->settings['fm_food_menu_type'] ?? 'food_menu_post';
		if ( TLPFoodMenu()->isWcActive() && 'online_ordering' === $fm_type ) {

			// standard fixed-amount discount off.
			add_filter( 'woocommerce_calculated_total', [ $this, 'standard_discount_off' ] );
			add_filter( 'woocommerce_cart_totals_order_total_html', [ $this, 'update_cart_total_html' ] );
			add_action( 'woocommerce_checkout_update_order_meta', [ $this, 'update_order_meta_data' ] );
			add_action( 'woocommerce_order_details_after_order_table', [ $this, 'checkout_order_thank_page' ] );
			add_action( 'woocommerce_admin_order_totals_after_total', [ $this, 'admin_order_details_page' ] );

			// WooCommerce Blocks cart/checkout integration.
			add_action( 'woocommerce_blocks_checkout_block_registration', [ $this, 'register_blocks_integration' ] );
			add_action( 'woocommerce_blocks_cart_block_registration', [ $this, 'register_blocks_integration' ] );
		}
	}

	/**
	 * Register WooCommerce Blocks integration for discount message.
	 *
	 * @param \Automattic\WooCommerce\Blocks\Integrations\IntegrationRegistry $integration_registry Integration registry.
	 *
	 * @return void
	 */
	public function register_blocks_integration( $integration_registry ) {
		$integration_registry->register( new CheckoutDiscount() );
	}

	/**
	 * Update Cart Total Message.
	 *
	 * @param mixed $value .
	 *
	 * @return mixed
	 */
	public function update_cart_total_html( $value ) {

		$actual_price = WC()->session->get( 'fmp_original_price' );
		$settings     = $this->settings;
		if (
				! empty( $actual_price ) &&
				! empty( $settings['fmp_fixed_order_amount'] ) &&
				! empty( $settings['fmp_fixed_discount'] ) &&
				absint( $settings['fmp_fixed_discount'] ) > 0 &&
				(float) $actual_price >= (float) $settings['fmp_fixed_order_amount']
		) {

			$flatDiscountMsg  = ! empty( $settings['fmp_fixed_discount_message'] )
					? $settings['fmp_fixed_discount_message']
					: esc_html__( 'Exclusive discount applied', 'food-menu-pro' );
			$discount_amlount = wc_price( $settings['fmp_fixed_discount'] );

			$value .= sprintf(
					'<div class="cart-fixed-discount">%s <strong>%s</strong></div>',
					$flatDiscountMsg,
					$discount_amlount
			);
		}

		return $value;
	}

	/**
	 * Total with standard money off function
	 *
	 * @param number $total .
	 *
	 * @return number
	 */
	public function standard_discount_off( $total ) {
		$settings = $this->settings;
		if (
				! empty( $settings['fmp_fixed_order_amount'] ) &&
				! empty( $settings['fmp_fixed_discount'] ) &&
				0 < absint( $settings['fmp_fixed_discount'] ) &&
				(float) $total >= (float) $settings['fmp_fixed_order_amount']
		) {
			WC()->session->set( 'fmp_discount_active', 'yes' );
			WC()->session->set( 'fmp_original_price', $total );

			return $total - $settings['fmp_fixed_discount'];
		}

		WC()->session->set( 'fmp_discount_active', null );
		WC()->session->set( 'fmp_original_price', null );

		return $total;
	}


	/**
	 * Update order meta data
	 *
	 * @param number $order_id .
	 *
	 * @return void
	 */
	public function update_order_meta_data( $order_id ) {
		$settings = $this->settings;
		$order    = wc_get_order( $order_id );

		$fmp_fixed_order_amount = $settings['fmp_fixed_order_amount'];
		$fmp_fixed_discount     = $settings['fmp_fixed_discount'];

		if (
				! empty( $fmp_fixed_order_amount ) && ! empty( $fmp_fixed_discount )
				&& '0' !== $fmp_fixed_discount
				&& null !== $order && (float) $order->get_total() >= (float) $fmp_fixed_discount
		) {
			$settings_message = esc_html__( 'After Discount off ', 'food-menu-pro' ) . $fmp_fixed_discount;
			update_post_meta( $order_id, 'fmp_discount_off', $settings_message );
		}
	}

	/**
	 * Standard discount message function
	 *
	 * @param number $id .
	 *
	 * @return void
	 */
	private function standard_message( $id ) {
		$discount_off_msg = get_post_meta( $id, 'fmp_discount_off', true );
		?>
		<div class="fmp-standard-off"><?php echo esc_html( $discount_off_msg ); ?></div>
		<?php
	}

	/**
	 * Checkout order thank you page add message.
	 *
	 * @param object $order .
	 *
	 * @return void
	 */
	public function checkout_order_thank_page( $order ) {
		$this->standard_message( $order->get_id() );
	}

	/**
	 * Admin order details page add standard discount message.
	 *
	 * @param number $order_id .
	 *
	 * @return void
	 */
	public function admin_order_details_page( $order_id ) {
		$this->standard_message( $order_id );
	}
}
