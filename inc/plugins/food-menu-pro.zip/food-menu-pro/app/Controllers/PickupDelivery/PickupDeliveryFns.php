<?php
/**
 * Main PickupDeliveryFns class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\PickupDelivery;

defined( 'ABSPATH' ) || exit();

/**
 * Main PickupDeliveryFns class.
 */
class PickupDeliveryFns {

	/**
	 * Pickup setting fields.
	 *
	 * @return array
	 */
	public static function settings_field() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/pickup_settings/fields',
			[
				'enable_pickup'                         => [
					'label'       => esc_html__( 'Enable Pickup?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable pickup option?', 'food-menu-pro' ),
					'value'       => $settings['enable_pickup'] ?? 'on',
				],
				'enable_pickup_time'                    => [
					'label'       => esc_html__( 'Enable Pickup Time?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable pickup time option?', 'food-menu-pro' ),
					'value'       => $settings['enable_pickup_time'] ?? 'on',
				],
				'pickup_message'                        => [
					'id'          => 'pickup_message',
					'type'        => 'text',
					'label'       => esc_html__( 'Pickup Message', 'food-menu-pro' ),
					'description' => esc_html__( 'When selecting the Pickup option at checkout, a message will be displayed. Leaving it blank will result in no message being shown. Please note that this option is effective only if Pickup is enabled in your order type settings.', 'food-menu-pro' ),
					'value'       => $settings['pickup_message'] ?? '',
				],
				'fmp_pickup_weekly_schedule'            => [
					'id'       => 'fmp_pickup_weekly_schedule',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_pickup_weekly_schedule_start_time' => [
					'id'       => 'fmp_pickup_weekly_schedule_start_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_pickup_weekly_schedule_end_time'   => [
					'id'       => 'fmp_pickup_weekly_schedule_end_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_pickup_weekly_holiday'             => [
					'id'       => 'fmp_pickup_weekly_holiday',
					'type'     => 'array',
					'multiple' => true,
				],
				'pickup_time_interval'                  => [
					'id'          => 'pickup_time_interval',
					'type'        => 'select',
					'class'       => 'fmp-select2',
					'value'       => $settings['pickup_time_interval'] ?? '',
					'label'       => esc_html__( 'Pickup Time Interval', 'food-menu-pro' ),
					'description' => esc_html__( 'Set pickup time interval at checkout.', 'food-menu-pro' ),
					'options'     => self::generateIntervalArray(),
				],
			]
		);
	}

	/**
	 * Delivery settings fields
	 *
	 * @return array
	 */
	public static function delivery_settings_field() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/delivery_settings/fields',
			[
				'enable_delivery'                         => [
					'label'       => esc_html__( 'Enable Delivery?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable delivery option?', 'food-menu-pro' ),
					'value'       => $settings['enable_delivery'] ?? 'on',
				],
				'enable_delivery_time'                    => [
					'label'       => esc_html__( 'Enable Delivery Time?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable delivery time option?', 'food-menu-pro' ),
					'value'       => $settings['enable_delivery_time'] ?? 'on',
				],
				'delivery_message'                        => [
					'id'          => 'delivery_message',
					'type'        => 'text',
					'label'       => esc_html__( 'Delivery Message', 'food-menu-pro' ),
					'description' => esc_html__( 'When selecting the Delivery option at checkout, a message will be displayed. Leaving it blank will result in no message being shown. Please note that this option is effective only if Delivery is enabled in your order type settings.', 'food-menu-pro' ),
					'value'       => $settings['delivery_message'] ?? '',
				],
				'fmp_delivery_weekly_schedule'            => [
					'id'       => 'fmp_delivery_weekly_schedule',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_delivery_weekly_schedule_start_time' => [
					'id'       => 'fmp_delivery_weekly_schedule_start_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_delivery_weekly_schedule_end_time'   => [
					'id'       => 'fmp_delivery_weekly_schedule_end_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_delivery_weekly_holiday'             => [
					'id'       => 'fmp_delivery_weekly_holiday',
					'type'     => 'array',
					'multiple' => true,
				],
				'delivery_time_interval'                  => [
					'id'          => 'delivery_time_interval',
					'type'        => 'select',
					'class'       => 'fmp-select2',
					'value'       => $settings['delivery_time_interval'] ?? '',
					'label'       => esc_html__( 'Delivery Time Interval', 'food-menu-pro' ),
					'description' => esc_html__( 'Set delivery time interval at checkout.', 'food-menu-pro' ),
					'options'     => self::generateIntervalArray(),
				],
			]
		);
	}

	/**
	 * Generate time interval in checkout page
	 *
	 * @return array
	 */
	public static function generateIntervalArray() {
		$intervals     = apply_filters( 'fmp_pickup_delivery_time_interval', [ 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60 ] );
		$interval_time = [];
		foreach ( $intervals as $value ) {
			$interval_time[ $value ] = $value;
		}

		return $interval_time;
	}

}
