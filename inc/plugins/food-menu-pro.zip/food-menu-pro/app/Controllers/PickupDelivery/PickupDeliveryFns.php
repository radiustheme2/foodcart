<?php
/**
 * Main PickupDeliveryFns class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\PickupDelivery;

defined( 'ABSPATH' ) || exit();

/**
 * Main PickupDeliveryFns class.
 */
class PickupDeliveryFns {

	/**
	 * Pickup setting fields.
	 *
	 * @return array
	 */
	public static function settings_field() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/pickup_settings/fields',
			[
				'enable_pickup'                         => [
					'label'       => esc_html__( 'Enable Pickup?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable pickup option?', 'food-menu-pro' ),
					'value'       => $settings['enable_pickup'] ?? 'on',
				],
				'enable_pickup_time'                    => [
					'label'       => esc_html__( 'Enable Pickup Time?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable pickup time option?', 'food-menu-pro' ),
					'value'       => $settings['enable_pickup_time'] ?? 'on',
				],
				'pickup_message'                        => [
					'id'          => 'pickup_message',
					'type'        => 'text',
					'label'       => esc_html__( 'Pickup Message', 'food-menu-pro' ),
					'description' => esc_html__( 'When selecting the Pickup option at checkout, a message will be displayed. Leaving it blank will result in no message being shown. Please note that this option is effective only if Pickup is enabled in your order type settings.', 'food-menu-pro' ),
					'value'       => $settings['pickup_message'] ?? '',
				],
				'fmp_pickup_weekly_schedule'            => [
					'id'       => 'fmp_pickup_weekly_schedule',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_pickup_weekly_schedule_start_time' => [
					'id'       => 'fmp_pickup_weekly_schedule_start_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_pickup_weekly_schedule_end_time'   => [
					'id'       => 'fmp_pickup_weekly_schedule_end_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_pickup_weekly_holiday'             => [
					'id'       => 'fmp_pickup_weekly_holiday',
					'type'     => 'array',
					'multiple' => true,
				],
				'pickup_time_interval'                  => [
					'id'          => 'pickup_time_interval',
					'type'        => 'select',
					'class'       => 'fmp-select2',
					'value'       => $settings['pickup_time_interval'] ?? '',
					'label'       => esc_html__( 'Pickup Time Interval', 'food-menu-pro' ),
					'description' => esc_html__( 'Set pickup time interval at checkout.', 'food-menu-pro' ),
					'options'     => self::generateIntervalArray(),
				],
				'pickup_prep_minutes'                   => [
					'id'          => 'pickup_prep_minutes',
					'type'        => 'number',
					'value'       => $settings['pickup_prep_minutes'] ?? '',
					'label'       => esc_html__( 'Pickup Preparation Time', 'food-menu-pro' ),
					'description' => esc_html__( 'Minutes the kitchen needs before an order is ready for collection. Shown to the customer as the wait on an "as soon as possible" pickup. Leave blank or 0 to quote no wait.', 'food-menu-pro' ),
					'attr'        => 'min="0" step="1"',
				],
			]
		);
	}

	/**
	 * Delivery settings fields
	 *
	 * @return array
	 */
	public static function delivery_settings_field() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/delivery_settings/fields',
			[
				'enable_delivery'                         => [
					'label'       => esc_html__( 'Enable Delivery?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable delivery option?', 'food-menu-pro' ),
					'value'       => $settings['enable_delivery'] ?? 'on',
				],
				'enable_delivery_time'                    => [
					'label'       => esc_html__( 'Enable Delivery Time?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable delivery time option?', 'food-menu-pro' ),
					'value'       => $settings['enable_delivery_time'] ?? 'on',
				],
				'delivery_message'                        => [
					'id'          => 'delivery_message',
					'type'        => 'text',
					'label'       => esc_html__( 'Delivery Message', 'food-menu-pro' ),
					'description' => esc_html__( 'When selecting the Delivery option at checkout, a message will be displayed. Leaving it blank will result in no message being shown. Please note that this option is effective only if Delivery is enabled in your order type settings.', 'food-menu-pro' ),
					'value'       => $settings['delivery_message'] ?? '',
				],
				'fmp_delivery_weekly_schedule'            => [
					'id'       => 'fmp_delivery_weekly_schedule',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_delivery_weekly_schedule_start_time' => [
					'id'       => 'fmp_delivery_weekly_schedule_start_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_delivery_weekly_schedule_end_time'   => [
					'id'       => 'fmp_delivery_weekly_schedule_end_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_delivery_weekly_holiday'             => [
					'id'       => 'fmp_delivery_weekly_holiday',
					'type'     => 'array',
					'multiple' => true,
				],
				'delivery_time_interval'                  => [
					'id'          => 'delivery_time_interval',
					'type'        => 'select',
					'class'       => 'fmp-select2',
					'value'       => $settings['delivery_time_interval'] ?? '',
					'label'       => esc_html__( 'Delivery Time Interval', 'food-menu-pro' ),
					'description' => esc_html__( 'Set delivery time interval at checkout.', 'food-menu-pro' ),
					'options'     => self::generateIntervalArray(),
				],
				'delivery_eta_min_minutes'                => [
					'id'          => 'delivery_eta_min_minutes',
					'type'        => 'number',
					'value'       => $settings['delivery_eta_min_minutes'] ?? '',
					'label'       => esc_html__( 'Delivery Estimate, From', 'food-menu-pro' ),
					'description' => esc_html__( 'Fastest a delivery normally arrives, in minutes. Quoted to the customer on an "as soon as possible" delivery. Leave blank or 0 to quote no estimate.', 'food-menu-pro' ),
					'attr'        => 'min="0" step="1"',
				],
				'delivery_eta_max_minutes'                => [
					'id'          => 'delivery_eta_max_minutes',
					'type'        => 'number',
					'value'       => $settings['delivery_eta_max_minutes'] ?? '',
					'label'       => esc_html__( 'Delivery Estimate, To', 'food-menu-pro' ),
					'description' => esc_html__( 'Slowest end of that estimate, in minutes. Leave blank to quote a single figure rather than a range.', 'food-menu-pro' ),
					'attr'        => 'min="0" step="1"',
				],
			]
		);
	}

	/**
	 * Dine In settings fields
	 *
	 * @return array
	 */
	public static function dinein_settings_field() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/dinein_settings/fields',
			[
				'enable_dinein'                         => [
					'label'       => esc_html__( 'Enable Dine In?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable dine in option?', 'food-menu-pro' ),
					'value'       => $settings['enable_dinein'] ?? '',
				],
				'enable_dinein_time'                    => [
					'label'       => esc_html__( 'Enable Dine In Time?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable dine in time option?', 'food-menu-pro' ),
					'value'       => $settings['enable_dinein_time'] ?? 'on',
				],
				'dinein_message'                        => [
					'id'          => 'dinein_message',
					'type'        => 'text',
					'label'       => esc_html__( 'Dine In Message', 'food-menu-pro' ),
					'description' => esc_html__( 'When selecting the Dine In option at checkout, a message will be displayed. Leaving it blank will result in no message being shown. Please note that this option is effective only if Dine In is enabled in your order type settings.', 'food-menu-pro' ),
					'value'       => $settings['dinein_message'] ?? '',
				],
				'fmp_dinein_tables'                     => [
					'id'       => 'fmp_dinein_tables',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_dinein_weekly_schedule'            => [
					'id'       => 'fmp_dinein_weekly_schedule',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_dinein_weekly_schedule_start_time' => [
					'id'       => 'fmp_dinein_weekly_schedule_start_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_dinein_weekly_schedule_end_time'   => [
					'id'       => 'fmp_dinein_weekly_schedule_end_time',
					'type'     => 'array',
					'multiple' => true,
				],
				'fmp_dinein_weekly_holiday'             => [
					'id'       => 'fmp_dinein_weekly_holiday',
					'type'     => 'array',
					'multiple' => true,
				],
				'dinein_time_interval'                  => [
					'id'          => 'dinein_time_interval',
					'type'        => 'select',
					'class'       => 'fmp-select2',
					'value'       => $settings['dinein_time_interval'] ?? '',
					'label'       => esc_html__( 'Dine In Time Interval', 'food-menu-pro' ),
					'description' => esc_html__( 'Set dine in time interval at checkout.', 'food-menu-pro' ),
					'options'     => self::generateIntervalArray(),
				],
			]
		);
	}

	/**
	 * Configured dine-in tables.
	 *
	 * Stored by the settings panel as a list of `[ 'name' => 'Table 1', 'location' => 12 ]`
	 * rows. Rows without a name are dropped; `location` is optional and only used
	 * to filter the checkout dropdown when multi-location is active.
	 *
	 * @param int $location_id Optional. Only return tables for this location (plus
	 *                         tables with no location set). 0 = no filtering.
	 *
	 * @return array List of [ 'name' => string, 'location' => int, 'location_name' => string ].
	 */
	public static function get_dinein_tables( $location_id = 0 ) {
		$settings = get_option( TLPFoodMenu()->options['settings'] );
		$rows     = $settings['fmp_dinein_tables'] ?? [];

		if ( ! is_array( $rows ) ) {
			return [];
		}

		// Resolve every referenced location in one query rather than calling
		// get_term() per row.
		$location_names = [];
		$location_ids   = [];

		foreach ( $rows as $row ) {
			if ( is_array( $row ) && ! empty( $row['location'] ) ) {
				$location_ids[] = absint( $row['location'] );
			}
		}

		$location_ids = array_unique( array_filter( $location_ids ) );

		if ( ! empty( $location_ids ) && taxonomy_exists( 'tpl-food-location' ) ) {
			$terms = get_terms(
				[
					'taxonomy'   => 'tpl-food-location',
					'include'    => $location_ids,
					'hide_empty' => false,
				]
			);

			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$location_names[ $term->term_id ] = $term->name;
				}
			}
		}

		$tables = [];

		foreach ( $rows as $row ) {
			// Tolerate a plain string row so a simple list keeps working.
			if ( is_string( $row ) ) {
				$row = [ 'name' => $row ];
			}

			if ( ! is_array( $row ) ) {
				continue;
			}

			$name = trim( (string) ( $row['name'] ?? '' ) );

			if ( '' === $name ) {
				continue;
			}

			$row_location = absint( $row['location'] ?? 0 );

			// Keep unassigned tables visible everywhere; filter assigned ones.
			if ( $location_id > 0 && $row_location > 0 && $row_location !== $location_id ) {
				continue;
			}

			$tables[] = [
				'name'          => $name,
				'location'      => $row_location,
				'location_name' => $location_names[ $row_location ] ?? '',
			];
		}

		return $tables;
	}

	/**
	 * Unique key for a dine-in table row.
	 *
	 * Table names are only unique within a branch, so pickers that list several
	 * branches at once need the location folded in — otherwise two rows share a
	 * value and a select renders both as chosen.
	 *
	 * @param string $name        Table name.
	 * @param int    $location_id Location term ID (0 when unassigned).
	 *
	 * @return string
	 */
	public static function dinein_table_key( $name, $location_id = 0 ) {
		return absint( $location_id ) . ':' . $name;
	}

	/**
	 * Table name from a key produced by `dinein_table_key()`.
	 *
	 * Tolerates a plain name so a caller can pass either form.
	 *
	 * @param string $key Table key or plain name.
	 *
	 * @return string
	 */
	public static function dinein_table_name_from_key( $key ) {
		$key = (string) $key;

		if ( preg_match( '/^(\d+):(.*)$/', $key, $matches ) ) {
			return $matches[2];
		}

		return $key;
	}

	/**
	 * Dine-in tables as value/label pairs for a picker.
	 *
	 * The stored value is the table name alone, so two branches can both have a
	 * "Table 5" and look identical in an unfiltered list. The label carries the
	 * location name to tell them apart wherever tables from several locations
	 * are shown together (admin order screen, front-end dashboard).
	 *
	 * @param int $location_id Optional. Restrict to one location.
	 *
	 * @return array List of [ 'value' => string, 'label' => string ].
	 */
	public static function get_dinein_table_options( $location_id = 0 ) {
		$options = [];

		foreach ( self::get_dinein_tables( $location_id ) as $table ) {
			$options[] = [
				// Two branches can both name a table "Table 5", so the option key
				// is `<location_id>:<name>` — unique per row. The *stored* order
				// meta stays the bare name (plus the order's own location), so
				// nothing that reads `fmp_dinein_table` has to change.
				'value'    => self::dinein_table_key( $table['name'], $table['location'] ),
				'label'    => $table['location_name']
					? sprintf( '%1$s (%2$s)', $table['name'], $table['location_name'] )
					: $table['name'],
				'name'     => $table['name'],
				'location' => $table['location'],
			];
		}

		return $options;
	}

	/**
	 * Whether Dine In is enabled.
	 *
	 * @return boolean
	 */
	public static function is_dinein_enabled() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return 'on' === ( $settings['enable_dinein'] ?? '' );
	}

	/**
	 * Generate time interval in checkout page
	 *
	 * @return array
	 */
	public static function generateIntervalArray() {
		$intervals     = apply_filters( 'fmp_pickup_delivery_time_interval', [ 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60 ] );
		$interval_time = [];
		foreach ( $intervals as $value ) {
			$interval_time[ $value ] = $value;
		}

		return $interval_time;
	}

}
