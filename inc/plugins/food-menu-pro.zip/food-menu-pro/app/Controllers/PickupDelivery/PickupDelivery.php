<?php
/**
 * PickupDelivery main class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\PickupDelivery;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Controllers\Checkout\CheckoutFns;
use RT\FoodMenuPro\Controllers\Checkout\CustomCheckout;
use RT\FoodMenuPro\Controllers\QrTableOrdering\QrTableOrdering;
use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Blocks\CheckoutPickupDelivery;
use WC_Order;

/**
 * PickupDelivery main class
 */
class PickupDelivery {

    use SingletonTrait;

    /**
     * Settings option
     *
     * @var array
     */
    private $options;

    /**
     * Init function call hooks
     *
     * @return void
     */
    public function init() {

        $this->options   = FnsPro::get_settings_option();
        $enable_pickup   = $this->options['enable_pickup'] ?? 'on';
        $enable_delivery = $this->options['enable_delivery'] ?? 'on';
        $enable_dinein   = $this->options['enable_dinein'] ?? '';
        $fm_type         = $this->options['fm_food_menu_type'] ?? 'food_menu_post';

        // Location schedule AJAX (gated by multi-location toggle).
        if ( ! empty( $this->options['fmp_food_location_popup'] ) ) {
            add_action( 'wp_ajax_fmp_get_location_schedule', [ $this, 'get_location_schedule' ] );
            add_action( 'wp_ajax_nopriv_fmp_get_location_schedule', [ $this, 'get_location_schedule' ] );
        }

        // Slot availability AJAX + per-product limit hooks (gated by slot limits toggle).
        if ( ! empty( $this->options['fmp_enable_order_slot_limits'] ) ) {
            add_action( 'wp_ajax_fmp_check_slot_availability', [ $this, 'check_slot_availability' ] );
            add_action( 'wp_ajax_nopriv_fmp_check_slot_availability', [ $this, 'check_slot_availability' ] );

            // Per-product order limit validation.
            add_filter( 'woocommerce_add_to_cart_validation', [ $this, 'validate_product_limit_add_to_cart' ], 10, 3 );
            add_action( 'woocommerce_check_cart_items', [ $this, 'validate_product_limits_cart' ] );
            add_action( 'woocommerce_checkout_create_order', [ $this, 'validate_product_limits_checkout' ], 5 );
        }

        // Custom order fields — works regardless of pickup/delivery settings.
        $custom_field_defs = FnsPro::get_setting( 'fmp_order_custom_fields', [] );
        if ( TLPFoodMenu()->isWcActive() && 'online_ordering' === $fm_type && ! empty( $custom_field_defs ) ) {
            add_action( 'woocommerce_after_order_notes', [ $this, 'render_custom_checkout_fields' ] );
            add_action( 'woocommerce_checkout_create_order', [ $this, 'save_custom_checkout_fields' ], 20 );
            add_action( 'woocommerce_checkout_process', [ $this, 'validate_custom_checkout_fields' ] );
        }

        $condition1 = ( TLPFoodMenu()->isWcActive() && 'on' == $enable_pickup && 'online_ordering' === $fm_type );
        $condition2 = ( TLPFoodMenu()->isWcActive() && 'on' == $enable_delivery && 'online_ordering' === $fm_type );
        $condition3 = ( TLPFoodMenu()->isWcActive() && 'on' == $enable_dinein && 'online_ordering' === $fm_type );
        if ( $condition1 || $condition2 || $condition3 ) {
            add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
            add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue_assets' ] );

            // pickup and delivery time form show in checkout page.
            add_action( 'woocommerce_checkout_before_customer_details', [ $this, 'render_order_time' ] );
            // pickup and delivery form validation.
            add_action( 'woocommerce_checkout_process', [ $this, 'pickup_delivery_form_validation' ] );

            // Save order meta data.
            add_action( 'woocommerce_checkout_create_order', [ $this, 'update_meta_order_type' ], 10, 2 );

            // Add Order Columns.
            add_filter( 'manage_edit-shop_order_columns', [ $this, 'add_order_columns' ] );
            add_filter( 'manage_woocommerce_page_wc-orders_columns', [ $this, 'add_order_columns' ] );
            add_action( 'manage_shop_order_posts_custom_column', [ $this, 'order_column_meta' ], 25, 2 );
            add_action( 'manage_woocommerce_page_wc-orders_custom_column', [ $this, 'order_column_meta' ], 25, 2 );

            // Order Quick View modify.
            add_filter( 'woocommerce_admin_order_preview_get_order_details', [ $this, 'order_preview_get_order_details' ], 10, 2 );
            add_action( 'woocommerce_admin_order_preview_end', [ $this, 'woocommerce_admin_order_preview_end' ] );

            // WooCommerce Blocks checkout integration.
            add_action( 'woocommerce_blocks_checkout_block_registration', [ $this, 'register_blocks_integration' ] );

            // Store API hooks — register immediately since woocommerce_blocks_loaded may have already fired.
            if ( did_action( 'woocommerce_blocks_loaded' ) ) {
                $this->register_store_api_hooks();
            } else {
                add_action( 'woocommerce_blocks_loaded', [ $this, 'register_store_api_hooks' ] );
            }
        }

        //add_action( 'woocommerce_order_details_after_order_table_items', [ $this, 'pickup_delivery_details' ] );
    }

    /**
     * Register Store API endpoint data and order save hooks for blocks checkout.
     * This runs on every request (including REST API) via woocommerce_blocks_loaded.
     *
     * @return void
     */
    public function register_store_api_hooks() {
        if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
            return;
        }

        woocommerce_store_api_register_endpoint_data(
            [
                'endpoint'        => \Automattic\WooCommerce\StoreApi\Schemas\V1\CheckoutSchema::IDENTIFIER,
                'namespace'       => 'food-menu-pro',
                'data_callback'   => function () {
                    return [
                        'fmp_order_time_type' => '',
                        'fmp_pickup_date'     => '',
                        'fmp_pickup_time'     => '',
                        'fmp_delivery_date'   => '',
                        'fmp_delivery_time'   => '',
                        'fmp_dinein_date'     => '',
                        'fmp_dinein_time'     => '',
                        'fmp_dinein_table'    => '',
                        'fmp_custom_fields'   => new \stdClass(),
                    ];
                },
                'schema_callback' => function () {
                    return [
                        'fmp_order_time_type' => [
                            'description' => 'Order type (pickup, delivery or dinein)',
                            'type'        => 'string',
                            'context'     => [ 'view', 'edit' ],
                        ],
                        'fmp_pickup_date'     => [
                            'description' => 'Pickup date',
                            'type'        => 'string',
                            'context'     => [ 'view', 'edit' ],
                        ],
                        'fmp_pickup_time'     => [
                            'description' => 'Pickup time',
                            'type'        => 'string',
                            'context'     => [ 'view', 'edit' ],
                        ],
                        'fmp_delivery_date'   => [
                            'description' => 'Delivery date',
                            'type'        => 'string',
                            'context'     => [ 'view', 'edit' ],
                        ],
                        'fmp_delivery_time'   => [
                            'description' => 'Delivery time',
                            'type'        => 'string',
                            'context'     => [ 'view', 'edit' ],
                        ],
                        'fmp_dinein_date'     => [
                            'description' => 'Dine in date',
                            'type'        => 'string',
                            'context'     => [ 'view', 'edit' ],
                        ],
                        'fmp_dinein_time'     => [
                            'description' => 'Dine in time',
                            'type'        => 'string',
                            'context'     => [ 'view', 'edit' ],
                        ],
                        'fmp_dinein_table'    => [
                            'description' => 'Dine in table',
                            'type'        => 'string',
                            'context'     => [ 'view', 'edit' ],
                        ],
                        'fmp_custom_fields'   => [
                            'description' => 'Custom order fields',
                            'type'        => 'object',
                            'context'     => [ 'view', 'edit' ],
                        ],
                    ];
                },
                'schema_type'     => ARRAY_A,
            ]
        );

        // Save pickup/delivery data when order is created via Store API.
        add_action(
            'woocommerce_store_api_checkout_update_order_from_request',
            function ( $order, $request ) {
                $extensions = $request->get_param( 'extensions' );
                $data       = $extensions['food-menu-pro'] ?? [];

                if ( empty( $data ) ) {
                    return;
                }

                $allowed_keys = [
                    'fmp_order_time_type',
                    'fmp_pickup_date',
                    'fmp_pickup_time',
                    'fmp_delivery_date',
                    'fmp_delivery_time',
                    'fmp_dinein_date',
                    'fmp_dinein_time',
                    'fmp_dinein_table',
                ];

                foreach ( $allowed_keys as $key ) {
                    if ( ! empty( $data[ $key ] ) ) {
                        $order->update_meta_data( $key, sanitize_text_field( $data[ $key ] ) );
                    }
                }

                // Save custom fields.
                if ( ! empty( $data['fmp_custom_fields'] ) && is_array( $data['fmp_custom_fields'] ) ) {
                    $sanitized = [];
                    foreach ( $data['fmp_custom_fields'] as $key => $value ) {
                        $sanitized[ sanitize_key( $key ) ] = is_array( $value )
                            ? array_map( 'sanitize_text_field', $value )
                            : sanitize_text_field( $value );
                    }
                    if ( ! empty( $sanitized ) ) {
                        $order->update_meta_data( '_fmp_custom_fields', $sanitized );
                    }
                }

                // Mark order as exempt from slot counting when slot limits are disabled.
                $settings = FnsPro::get_settings_option();
                if ( 'on' !== ( $settings['fmp_enable_order_slot_limits'] ?? '' ) ) {
                    $order->update_meta_data( '_fmp_slot_limit_exempt', 'yes' );
                }
            },
            10,
            2
        );
    }

    /**
     * Register WooCommerce Blocks checkout integration.
     *
     * @param object $integration_registry The integration registry.
     *
     * @return void
     */
    public function register_blocks_integration( $integration_registry ) {
        $integration_registry->register( new CheckoutPickupDelivery() );
    }

    /**
     * Render custom order fields on the classic checkout page.
     *
     * @param object $checkout WooCommerce checkout object.
     *
     * @return void
     */
    public function render_custom_checkout_fields( $checkout ) {
        $options = FnsPro::get_settings_option();
        if ( 'on' !== ( $options['fmp_checkout_show_additional_info'] ?? 'on' ) ) {
            return;
        }

        // Minimal QR-checkout mode hides custom additional info fields.
        if ( QrTableOrdering::is_minimal_checkout_active() ) {
            return;
        }

        $fields = FnsPro::get_setting( 'fmp_order_custom_fields', [] );
        if ( empty( $fields ) ) {
            return;
        }

        // Enqueue Select2 (bundled with WooCommerce).
        wp_enqueue_script( 'selectWoo' );
        wp_enqueue_style( 'select2' );

        echo '<div class="fmp-custom-checkout-fields"><h3>' . esc_html__( 'Additional Information', 'food-menu-pro' ) . '</h3>';

        foreach ( $fields as $idx => $field ) {
            $field_id  = 'fmp_custom_field_' . $idx;
            $label     = ! empty( $field['label'] ) ? $field['label'] : 'Field ' . ( $idx + 1 );
            $required  = filter_var( $field['required'] ?? false, FILTER_VALIDATE_BOOLEAN );
            $type      = $field['type'] ?? 'text';
            $multiple  = filter_var( $field['multiple'] ?? false, FILTER_VALIDATE_BOOLEAN );

            if ( 'select' === $type ) {
                $options = array_map( 'trim', explode( ',', $field['options'] ?? '' ) );
                $options = array_filter( $options );
                $req_attr = $required ? ' required' : '';
                $req_star = $required ? ' <abbr class="required" title="required">*</abbr>' : '';
                $name     = $multiple ? $field_id . '[]' : $field_id;
                $multi    = $multiple ? ' multiple="multiple"' : '';
                $class    = 'fmp-custom-select2';

                echo '<p class="form-row form-row-wide" id="' . esc_attr( $field_id ) . '_field">';
                echo '<label for="' . esc_attr( $field_id ) . '">' . esc_html( $label ) . $req_star . '</label>';
                echo '<select name="' . esc_attr( $name ) . '" id="' . esc_attr( $field_id ) . '" class="' . esc_attr( $class ) . '" data-placeholder="' . esc_attr__( 'Select...', 'food-menu-pro' ) . '"' . $multi . $req_attr . '>';
                if ( ! $multiple ) {
                    echo '<option value="">' . esc_html__( 'Select...', 'food-menu-pro' ) . '</option>';
                }
                foreach ( $options as $opt ) {
                    echo '<option value="' . esc_attr( $opt ) . '">' . esc_html( $opt ) . '</option>';
                }
                echo '</select></p>';
            } else {
                woocommerce_form_field(
                    $field_id,
                    [
                        'type'     => 'text',
                        'label'    => $label,
                        'required' => $required,
                        'class'    => [ 'form-row-wide' ],
                    ],
                    $checkout->get_value( $field_id )
                );
            }
        }

        echo '</div>';

        // Initialize Select2 on custom select fields.
        add_action(
            'wp_footer',
            function () {
                ?>
                <script>jQuery(function($){ $('.fmp-custom-select2').selectWoo({ width: '100%' }); });</script>
                <?php
            }
        );
    }

    /**
     * Validate custom checkout fields during classic checkout.
     *
     * @return void
     */
    public function validate_custom_checkout_fields() {
        $options = FnsPro::get_settings_option();
        if ( 'on' !== ( $options['fmp_checkout_show_additional_info'] ?? 'on' ) ) {
            return;
        }

        // Don't validate fields we never rendered.
        if ( QrTableOrdering::is_minimal_checkout_active() ) {
            return;
        }

        $fields = FnsPro::get_setting( 'fmp_order_custom_fields', [] );
        if ( empty( $fields ) ) {
            return;
        }

        foreach ( $fields as $idx => $field ) {
            $field_id = 'fmp_custom_field_' . $idx;
            $multiple = filter_var( $field['multiple'] ?? false, FILTER_VALIDATE_BOOLEAN ) && 'select' === ( $field['type'] ?? 'text' );
            $value    = $multiple
                ? ( isset( $_POST[ $field_id ] ) ? array_filter( array_map( 'sanitize_text_field', wp_unslash( $_POST[ $field_id ] ) ) ) : [] )
                : ( isset( $_POST[ $field_id ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field_id ] ) ) : '' );

            $is_empty = $multiple ? empty( $value ) : '' === $value;

            if ( filter_var( $field['required'] ?? false, FILTER_VALIDATE_BOOLEAN ) && $is_empty ) {
                $label = ! empty( $field['label'] ) ? $field['label'] : 'Field ' . ( $idx + 1 );
                wc_add_notice(
                    sprintf(
                        /* translators: %s field label */
                        esc_html__( '%s is a required field.', 'food-menu-pro' ),
                        '<strong>' . esc_html( $label ) . '</strong>'
                    ),
                    'error'
                );
            }
        }
    }

    /**
     * Save custom checkout fields to order meta during classic checkout.
     *
     * @param \WC_Order $order The order object.
     *
     * @return void
     */
    public function save_custom_checkout_fields( $order ) {
        $options = FnsPro::get_settings_option();
        if ( 'on' !== ( $options['fmp_checkout_show_additional_info'] ?? 'on' ) ) {
            return;
        }

        // No fields rendered means nothing to persist.
        if ( QrTableOrdering::is_minimal_checkout_active() ) {
            return;
        }

        $fields = FnsPro::get_setting( 'fmp_order_custom_fields', [] );
        if ( empty( $fields ) ) {
            return;
        }

        $custom_data = [];
        foreach ( $fields as $idx => $field ) {
            $field_id = 'fmp_custom_field_' . $idx;
            $key      = 'custom_' . $idx;
            $multiple = filter_var( $field['multiple'] ?? false, FILTER_VALIDATE_BOOLEAN ) && 'select' === ( $field['type'] ?? 'text' );

            if ( $multiple ) {
                $value = isset( $_POST[ $field_id ] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST[ $field_id ] ) ) : [];
                $value = array_filter( $value );
            } else {
                $value = isset( $_POST[ $field_id ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field_id ] ) ) : '';
            }

            $is_empty = $multiple ? empty( $value ) : '' === $value;
            if ( ! $is_empty ) {
                $custom_data[ $key ] = $value;
            }
        }

        if ( ! empty( $custom_data ) ) {
            $order->update_meta_data( '_fmp_custom_fields', $custom_data );
        }
    }

    /**
     * Update order meta data
     *
     * @param object $order .
     *
     * @return void
     */
    public function update_meta_order_type( $order ) {
        // Check for validation.
        $post_data = filter_input_array( INPUT_POST, FILTER_SANITIZE_SPECIAL_CHARS );
        if ( ! empty( $post_data ) ) {
            $allowed_order_types = array_values( FnsPro::get_order_type() );
            foreach ( $post_data as $key => $value ) {
                // Check if the key is an allowed order type and not empty.
                if ( in_array( $key, $allowed_order_types ) && ! empty( $key ) ) {
                    $order->update_meta_data( $key, $value );
                }
            }
        }

        // Mark order as exempt from slot counting when slot limits are disabled.
        if ( 'on' !== ( $this->options['fmp_enable_order_slot_limits'] ?? '' ) ) {
            $order->update_meta_data( '_fmp_slot_limit_exempt', 'yes' );
        }
    }

    /**
     * WooCommerce checkout order type form validation message.
     *
     * @return void
     */
    public function pickup_delivery_form_validation() {
        // No nonce gate here: WooCommerce already verified its checkout nonce before this hook, and
        // returning early on a missing fmp_nonce let a buyer skip slot/schedule/table validation
        // while update_meta_order_type() still saved the posted date, time and table.

        if ( empty( $_POST['fmp_order_time_type'] ) ) {
            return;
        }
        $settings   = $this->options;
        $order_type = sanitize_text_field( wp_unslash( $_POST['fmp_order_time_type'] ) );

        switch ( $order_type ) {
            case 'delivery':
                $this->validateDateTime( 'delivery', $settings, 'Please select delivery' );
                break;
            case 'pickup':
                $this->validateDateTime( 'pickup', $settings, 'Please select pickup' );
                break;
            case 'dinein':
                $this->validateDateTime( 'dinein', $settings, 'Please select dine in' );

                // Table is required unless the shop turned the requirement off.
                if ( 'on' === ( $settings['dinein_require_table'] ?? 'on' ) && empty( $_POST['fmp_dinein_table'] ) ) {
                    wc_add_notice( esc_html__( 'Please select a table for your dine in order', 'food-menu-pro' ), 'error' );
                }
                break;
            default:
                break;
        }

        // Server-side slot limit validation.
        if ( 'on' === ( $settings['fmp_enable_order_slot_limits'] ?? '' ) ) {
            $date = sanitize_text_field( wp_unslash( $_POST["fmp_{$order_type}_date"] ?? '' ) );
            $time = sanitize_text_field( wp_unslash( $_POST["fmp_{$order_type}_time"] ?? '' ) );

            if ( $date && $time ) {
                $location_id = ! empty( $_COOKIE['fmp_location_id'] ) ? absint( $_COOKIE['fmp_location_id'] ) : 0;

                // Reject times outside the configured schedule before counting —
                // otherwise a gap in the schedule bypasses the per-slot limit.
                if ( false === $this->is_time_within_schedule( $order_type, $date, $time, $location_id ) ) {
                    wc_add_notice(
                            esc_html__( 'We are not open at the selected time. Please select a different time.', 'food-menu-pro' ),
                            'error'
                    );

                    return;
                }

                $max = $this->get_max_per_slot( $order_type, $location_id, $date, $time );

                if ( $max > 0 ) {
                    $count = $this->get_slot_order_count( $order_type, $date, $time, $location_id );

                    if ( $count >= $max ) {
                        wc_add_notice(
                                esc_html__( 'This time slot is now full. Please select a different time.', 'food-menu-pro' ),
                                'error'
                        );
                    }
                }
            }
        }
    }

    /**
     * Validate date and time based on order type
     *
     * @param string $prefix .
     * @param array $settings .
     * @param string $message .
     */
    private function validateDateTime( $prefix, $settings, $message ) {
        if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
            return;
        }
        $date_input_field = "fmp_{$prefix}_date";
        $time_input_filed = "fmp_{$prefix}_time";
        $enable_date      = "enable_{$prefix}";
        $enable_time      = "enable_{$prefix}_time";

        if ( ! empty( $settings[ $enable_date ] ) && empty( $_POST[ $date_input_field ] ) ) {
            // translators: %s date.
            wc_add_notice( sprintf( esc_html__( '%s date', 'food-menu-pro' ), $message ), 'error' );
        }

        if ( ! empty( $settings[ $enable_date ] ) && ! empty( $settings[ $enable_time ] ) && empty( $_POST[ $time_input_filed ] ) ) {
            // translators: %s time.
            wc_add_notice( sprintf( esc_html__( '%s time', 'food-menu-pro' ), $message ), 'error' );
        }
    }

    /**
     * PickupDelivery admin assets enqueue
     *
     * @return void
     */
    public function admin_enqueue_assets() {
        wp_enqueue_script( 'fmp-timepicker' );
        wp_enqueue_style( 'fmp-timepicker' );
        wp_enqueue_script( 'fmp-admin-pickup-delivery' );

        $fm_time_format = get_option( 'time_format' ) ?? 'H:i A';
        wp_localize_script(
                'fmp-admin-pickup-delivery',
                'fmpResiParams',
                [
                        'time_format' => $fm_time_format,
                ]
        );
    }

    /**
     * Frontend enqueue file
     *
     * @return void
     */
    public function frontend_enqueue_assets() {
        // add enqueue timepicker in frontend.
        wp_enqueue_script( 'fmp-timepicker' );
        wp_enqueue_style( 'fmp-timepicker' );

        // add enqueue flatpickr for date in frontend.
        wp_enqueue_script( 'fmp-flatpickr' );
        wp_enqueue_style( 'fmp-flatpickr' );
        wp_enqueue_script( 'fmp-pickup-delivery' );
        \wp_localize_script(
                'fmp-pickup-delivery',
                'fmpPDParams',
                $this->pickup_delivery_data_obj()
        );
    }

    /**
     * Render form frontend in checkout page
     *
     * @return void
     */
    public function render_order_time() {
        // Skip if custom checkout already rendered the order type form at its own position.
        if ( did_action( 'fmp_custom_checkout_order_type_rendered' ) ) {
            return;
        }

        // Skip for dine-in QR scan orders — Pickup & Delivery doesn't apply.
        if ( QrTableOrdering::has_active_session() ) {
            return;
        }

        Fns::render( 'pickup-delivery/order-time' );
    }

    /**
     * Pickup deliver localize data object
     *
     * @return array
     */
    public function pickup_delivery_data_obj() {
        $settings                = $this->options;
        $delivery_preparing_date = ! empty( $settings['delivery_preparation_day'] ) ? FnsPro::preparing_date( $settings['delivery_preparation_day'] ) : FnsPro::preparing_date( '0' );

        $fm_date_format    = get_option( 'date_format' ) ?? 'Y-m-d';
        $fm_time_format    = get_option( 'time_format' ) ?? 'H:i A';
        $current_date_time = current_datetime();
        $current_date      = $current_date_time->format( $fm_date_format );
        $current_time      = $current_date_time->format( $fm_time_format );


        //New Delivery time schedule
        $new_fmp_delivery_weekly_schedule    = FnsPro::get_setting( 'new_fmp_delivery_weekly_schedule', [] );
        $delivery_weekly_schedule            = FnsPro::get_offday_schedule( $new_fmp_delivery_weekly_schedule );
        $delivery_weekly_schedule_start_time = FnsPro::get_schedule_time( $new_fmp_delivery_weekly_schedule );
        $delivery_weekly_schedule_end_time   = FnsPro::get_schedule_time( $new_fmp_delivery_weekly_schedule, 'end' );
        $delivery_weekly_schedule_slots      = FnsPro::get_schedule_slots( $new_fmp_delivery_weekly_schedule );

        //New Pickup time schedule
        $new_fmp_pickup_weekly_schedule    = FnsPro::get_setting( 'new_fmp_pickup_weekly_schedule', [] );
        $pickup_weekly_schedule            = FnsPro::get_offday_schedule( $new_fmp_pickup_weekly_schedule );
        $pickup_weekly_schedule_start_time = FnsPro::get_schedule_time( $new_fmp_pickup_weekly_schedule );
        $pickup_weekly_schedule_end_time   = FnsPro::get_schedule_time( $new_fmp_pickup_weekly_schedule, 'end' );
        $pickup_weekly_schedule_slots      = FnsPro::get_schedule_slots( $new_fmp_pickup_weekly_schedule );

        //New Dine in time schedule
        $new_fmp_dinein_weekly_schedule    = FnsPro::get_setting( 'new_fmp_dinein_weekly_schedule', [] );
        $dinein_weekly_schedule            = FnsPro::get_offday_schedule( $new_fmp_dinein_weekly_schedule );
        $dinein_weekly_schedule_start_time = FnsPro::get_schedule_time( $new_fmp_dinein_weekly_schedule );
        $dinein_weekly_schedule_end_time   = FnsPro::get_schedule_time( $new_fmp_dinein_weekly_schedule, 'end' );
        $dinein_weekly_schedule_slots      = FnsPro::get_schedule_slots( $new_fmp_dinein_weekly_schedule );

        $data = [
                'delivery_time_interval'              => $settings['delivery_time_interval'] ?? 15,
                'delivery_weekly_schedule_start_time' => $delivery_weekly_schedule_start_time,
                'delivery_weekly_schedule_end_time'   => $delivery_weekly_schedule_end_time,
                'delivery_weekly_schedule_slots'      => $delivery_weekly_schedule_slots,
                'delivery_weekly_holiday'             => $delivery_weekly_schedule,
                'pickup_time_interval'                => $settings['pickup_time_interval'] ?? 15,
                'pickup_weekly_schedule_start_time'   => $pickup_weekly_schedule_start_time,
                'pickup_weekly_schedule_end_time'     => $pickup_weekly_schedule_end_time,
                'pickup_weekly_schedule_slots'        => $pickup_weekly_schedule_slots,
                'pickup_weekly_holiday'               => $pickup_weekly_schedule,
                'dinein_time_interval'                => $settings['dinein_time_interval'] ?? 15,
                'dinein_weekly_schedule_start_time'   => $dinein_weekly_schedule_start_time,
                'dinein_weekly_schedule_end_time'     => $dinein_weekly_schedule_end_time,
                'dinein_weekly_schedule_slots'        => $dinein_weekly_schedule_slots,
                'dinein_weekly_holiday'               => $dinein_weekly_schedule,
                'delivery_preparing_date'             => $delivery_preparing_date,
                'pickup_preparing_date'               => FnsPro::preparing_date( 0 ),
                'dinein_preparing_date'               => FnsPro::preparing_date( 0 ),
                'enable_delivery'                     => $settings['enable_delivery'] ?? 'on',
                'enable_delivery_time'                => $settings['enable_delivery_time'] ?? 'on',
                'enable_pickup'                       => $settings['enable_pickup'] ?? 'on',
                'enable_pickup_time'                  => $settings['enable_pickup_time'] ?? 'on',
                'enable_dinein'                       => $settings['enable_dinein'] ?? '',
                'enable_dinein_time'                  => $settings['enable_dinein_time'] ?? 'on',
                'current_time'                        => $current_time,
                'current_date'                        => $current_date,
                'ajaxurl'                             => esc_url( admin_url( 'admin-ajax.php' ) ),
                'nonceID'                             => esc_attr( Fns::nonceId() ),
                'nonce'                               => esc_attr( wp_create_nonce( Fns::nonceText() ) ),
                'enable_slot_limits'                  => $settings['fmp_enable_order_slot_limits'] ?? '',
                'pickup_max_orders_per_slot'          => absint( $settings['pickup_max_orders_per_slot'] ?? 0 ),
                'delivery_max_orders_per_slot'        => absint( $settings['delivery_max_orders_per_slot'] ?? 0 ),
                'dinein_max_orders_per_slot'          => absint( $settings['dinein_max_orders_per_slot'] ?? 0 ),
                'dinein_tables'                       => PickupDeliveryFns::get_dinein_tables(
                    ! empty( $settings['fmp_food_location_popup'] ) && ! empty( $_COOKIE['fmp_location_id'] )
                        ? absint( $_COOKIE['fmp_location_id'] )
                        : 0
                ),
                'dinein_require_table'                => $settings['dinein_require_table'] ?? 'on',
                'preorder_max_days'                   => absint( $settings['fmp_preorder_max_days'] ?? 0 ),
                'i18n'                                => [
                    /* translators: %d: number of orders remaining */
                    'orders_left'    => esc_html__( '%d order(s) left for this time slot', 'food-menu-pro' ),
                    'available'      => esc_html__( 'Available', 'food-menu-pro' ),
                    'slot_full'      => esc_html__( 'This time slot is full.', 'food-menu-pro' ),
                    'checking'       => esc_html__( 'Checking availability...', 'food-menu-pro' ),
                    'no_times_today' => esc_html__( 'No times are available for this date. Please choose another date.', 'food-menu-pro' ),
                    'remaining'      => esc_html__( 'remaining', 'food-menu-pro' ),
                    'sold_out'       => esc_html__( 'sold out for this slot', 'food-menu-pro' ),
                    /* translators: %d: units available */
                    'reduce_qty'     => esc_html__( 'only %d available, reduce your quantity or choose another schedule', 'food-menu-pro' ),
                ],
        ];

        // Override with location-specific schedule if multi-location is active.
        if ( ! empty( $settings['fmp_food_location_popup'] ) ) {
            $location_id = ! empty( $_COOKIE['fmp_location_id'] ) ? absint( $_COOKIE['fmp_location_id'] ) : 0;

            if ( $location_id > 0 ) {
                $location_data = FnsPro::get_location_schedule_data( $location_id );

                if ( null !== $location_data ) {
                    // Only override a type's schedule when this location actually
                    // has one configured. Overwriting with an empty per-location
                    // schedule would leave the checkout with no time bounds and
                    // no per-slot limits for that type.
                    foreach ( [ 'pickup', 'delivery', 'dinein' ] as $sched_type ) {
                        if ( empty( $location_data[ "has_{$sched_type}_schedule" ] ) ) {
                            continue;
                        }

                        $data[ "{$sched_type}_time_interval" ]              = $location_data[ "fmp_loc_{$sched_type}_time_interval" ];
                        $data[ "{$sched_type}_weekly_schedule_start_time" ] = $location_data[ "fmp_loc_{$sched_type}_weekly_schedule_start_time" ];
                        $data[ "{$sched_type}_weekly_schedule_end_time" ]   = $location_data[ "fmp_loc_{$sched_type}_weekly_schedule_end_time" ];
                        $data[ "{$sched_type}_weekly_holiday" ]             = $location_data[ "fmp_loc_{$sched_type}_weekly_holiday" ];
                        $data[ "{$sched_type}_weekly_schedule_slots" ]      = $location_data[ "fmp_loc_{$sched_type}_weekly_schedule_slots" ];
                    }

                    // Override slot limits with per-location values if set.
                    $loc_pickup_max   = $location_data['fmp_loc_pickup_max_orders_per_slot'] ?? 0;
                    $loc_delivery_max = $location_data['fmp_loc_delivery_max_orders_per_slot'] ?? 0;
                    $loc_dinein_max   = $location_data['fmp_loc_dinein_max_orders_per_slot'] ?? 0;

                    if ( $loc_pickup_max > 0 ) {
                        $data['pickup_max_orders_per_slot'] = $loc_pickup_max;
                    }

                    if ( $loc_delivery_max > 0 ) {
                        $data['delivery_max_orders_per_slot'] = $loc_delivery_max;
                    }

                    if ( $loc_dinein_max > 0 ) {
                        $data['dinein_max_orders_per_slot'] = $loc_dinein_max;
                    }
                }
            }
        }

        // Expose cart items for per-product slot limit checks.
        if ( function_exists( 'WC' ) && WC()->cart ) {
            $cart_items = [];
            foreach ( WC()->cart->get_cart() as $item ) {
                $cart_items[] = [
                    'product_id' => (int) $item['product_id'],
                    'qty'        => (int) $item['quantity'],
                ];
            }
            $data['cart_items'] = $cart_items;
        }

        return $data;
    }

    /**
     * Add Order Columns
     *
     * @param $columns
     *
     * @return mixed
     */
    public function add_order_columns( $columns ) {
        $columns['delivery_options'] = 'Delivery Options';

        return $columns;
    }

    /**
     * Add extra inormation in order column
     *
     * @param $column
     * @param $order_or_order_id
     *
     * @return void
     */
    public function order_column_meta( $column, $order_or_order_id ) {
        $order = $order_or_order_id instanceof WC_Order ? $order_or_order_id : wc_get_order( $order_or_order_id );
        if ( $column == 'delivery_options' ) {
            $schedule = FnsPro::get_order_schedule( $order );

            if ( '' === $schedule['label'] ) {
                return;
            }

            printf(
                '<span style="display:inline-block;padding:0 10px;border-radius:5px;background:%1$s;color:#FFF">%2$s</span>',
                esc_attr( FnsPro::get_order_type_color( $schedule['type'] ) ),
                esc_html( $schedule['label'] )
            );

            if ( 'dinein' === $schedule['type'] && $schedule['table'] ) {
                printf(
                    '<br><strong>%1$s</strong> %2$s',
                    esc_html__( 'Table:', 'food-menu-pro' ),
                    esc_html( $schedule['table'] )
                );
            }

            if ( $schedule['date'] || $schedule['time'] ) {
                printf(
                    '<br>%1$s - <b>%2$s</b>',
                    esc_html( $schedule['date'] ),
                    esc_html( $schedule['time'] )
                );
            }
        }
    }

    /**
     * Send oder preview custom data for preview markup
     *
     * @param $data
     * @param $order
     *
     * @return mixed
     */
    public function order_preview_get_order_details( $data, $order ) {
        $tipInfo            = FnsPro::tip_information( $order );
        $data['order_info'] = [
                'fmp_order_time_type' => $order->get_meta( 'fmp_order_time_type' ),
                'fmp_delivery_date'   => $order->get_meta( 'fmp_delivery_date' ),
                'fmp_delivery_time'   => $order->get_meta( 'fmp_delivery_time' ),
                'fmp_pickup_date'     => $order->get_meta( 'fmp_pickup_date' ),
                'fmp_pickup_time'     => $order->get_meta( 'fmp_pickup_time' ),
                'fmp_dinein_date'     => $order->get_meta( 'fmp_dinein_date' ),
                'fmp_dinein_time'     => $order->get_meta( 'fmp_dinein_time' ),
                'fmp_dinein_table'    => $order->get_meta( 'fmp_dinein_table' ),
                'fmp_type_label'      => FnsPro::get_order_type_label( $order->get_meta( 'fmp_order_time_type' ) ),
                'fmp_type_color'      => FnsPro::get_order_type_color( $order->get_meta( 'fmp_order_time_type' ) ),
                'fmp_tip'             => $tipInfo,
                'fmp_location_name'   => $order->get_meta( 'fmp_location_name' ),
        ];

        return $data;
    }

    /**
     * Order Quick View modify
     *
     * @return void
     */
    public function woocommerce_admin_order_preview_end() {
        ?>
        <div>
            <p class="form-field form-field-wide" style='border: 1px solid #d3dedf;padding: 15px !important;border-radius:6px;margin: 15px;box-sizing:border-box;background-color: #e4f5f7;color:#000000;'>
				<span style="display:block;font-size: 16px;border-bottom:1px solid #d3dedf;padding-bottom: 5px;margin-bottom: 5px;">
					<strong><?php echo esc_html__( 'Food Delivery Details', 'food-menu-pro' ); ?></strong>
				</span>

                <# if ( data.order_info.fmp_location_name ) { #>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Location:', 'food-menu-pro' ); ?></strong>
                <span style="display: inline-block;padding: 1px 10px;background: #e67e22;border-radius: 5px;font-weight: bold;color: #FFF;">{{ data.order_info.fmp_location_name }}</span>
                <br>
                <# } #>

                <# if ( data.order_info.fmp_type_label ) { #>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Order Type:', 'food-menu-pro' ); ?></strong>
                <span style="display: inline-block;padding: 1px 10px;background: {{ data.order_info.fmp_type_color }} ;border-radius: 5px;font-weight: bold;color: #FFF;">
				{{ data.order_info.fmp_type_label }}
				</span>

                <br>
                <# } #>

                <# if ( 'dinein' == data.order_info.fmp_order_time_type ) { #>
                <# if ( data.order_info.fmp_dinein_table ) { #>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Table:', 'food-menu-pro' ); ?></strong>
                {{ data.order_info.fmp_dinein_table }}
                <br>
                <# } #>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Dine In Date:', 'food-menu-pro' ); ?></strong>
                {{ data.order_info.fmp_dinein_date }}
                <br>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Dine In Time:', 'food-menu-pro' ); ?></strong>
                {{ data.order_info.fmp_dinein_time }}
                <br>
                <# } #>

                <# if ( 'delivery' == data.order_info.fmp_order_time_type ) { #>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Delivery Date:', 'food-menu-pro' ); ?></strong>
                {{ data.order_info.fmp_delivery_date }}
                <br>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Delivery Time:', 'food-menu-pro' ); ?></strong>
                {{ data.order_info.fmp_delivery_time }}
                <br>
                <# } #>

                <# if ( 'pickup' == data.order_info.fmp_order_time_type ) { #>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Pickup Data:', 'food-menu-pro' ); ?></strong>
                {{ data.order_info.fmp_pickup_date }}
                <br>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Pickup Time:', 'food-menu-pro' ); ?></strong>
                {{ data.order_info.fmp_pickup_time }}
                <# } #>

                <br>
                <br>
                <# if( data.order_info.fmp_tip.amount ) { #>
                <span style="font-size: 16px;border-bottom:1px solid #d3dedf;padding-bottom: 5px;margin-bottom: 5px;display: inline-block">
					<strong>
						<?php echo esc_html__( 'Tip Amount: ', 'food-menu-pro' ); ?>
						{{ Math.round(data.order_info.fmp_tip.amount * 100) / 100 }}<?php echo get_woocommerce_currency_symbol(); ?> {{ data.order_info.fmp_tip.prefix }}
					</strong>
				</span>
                <# } #>
            </p>
        </div>

        <style>
            .wc-backbone-modal .wc-backbone-modal-content article {
                display: flex;
                flex-direction: column;
            }

            .wc-order-preview-table-wrapper {
                order: 10;
            }
        </style>


        <?php
    }

    /**
     * AJAX: Get location-specific schedule data.
     *
     * @return void
     */
    public function get_location_schedule() {
        $location_id = ! empty( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0;

        if ( $location_id > 0 ) {
            $location_data = FnsPro::get_location_schedule_data( $location_id );

            if ( null !== $location_data ) {
                $response = [
                    // Tables are location-scoped, so the picker must be rebuilt on switch.
                    'dinein_tables' => PickupDeliveryFns::get_dinein_tables( $location_id ),
                ];

                // Each type resolves independently: the location's schedule when
                // it has one, the global schedule when it doesn't. Every key is
                // always sent, so switching locations never leaves the checkout
                // holding the previous location's bounds.
                foreach ( [ 'pickup', 'delivery', 'dinein' ] as $sched_type ) {
                    $source = ! empty( $location_data[ "has_{$sched_type}_schedule" ] )
                        ? [
                            'interval' => $location_data[ "fmp_loc_{$sched_type}_time_interval" ],
                            'start'    => $location_data[ "fmp_loc_{$sched_type}_weekly_schedule_start_time" ],
                            'end'      => $location_data[ "fmp_loc_{$sched_type}_weekly_schedule_end_time" ],
                            'holiday'  => $location_data[ "fmp_loc_{$sched_type}_weekly_holiday" ],
                            'slots'    => $location_data[ "fmp_loc_{$sched_type}_weekly_schedule_slots" ],
                        ]
                        : $this->global_schedule( $sched_type );

                    $response[ "{$sched_type}_time_interval" ]              = $source['interval'];
                    $response[ "{$sched_type}_weekly_schedule_start_time" ] = $source['start'];
                    $response[ "{$sched_type}_weekly_schedule_end_time" ]   = $source['end'];
                    $response[ "{$sched_type}_weekly_holiday" ]             = $source['holiday'];
                    $response[ "{$sched_type}_weekly_schedule_slots" ]      = $source['slots'];
                }

                // Include per-location slot limits, falling back to global so the JS
                // always resets to the correct value when switching locations.
                $loc_pickup_max   = absint( $location_data['fmp_loc_pickup_max_orders_per_slot'] ?? 0 );
                $loc_delivery_max = absint( $location_data['fmp_loc_delivery_max_orders_per_slot'] ?? 0 );
                $settings         = $this->options;

                $response['pickup_max_orders_per_slot']   = $loc_pickup_max > 0
                        ? $loc_pickup_max
                        : absint( $settings['pickup_max_orders_per_slot'] ?? 0 );
                $response['delivery_max_orders_per_slot'] = $loc_delivery_max > 0
                        ? $loc_delivery_max
                        : absint( $settings['delivery_max_orders_per_slot'] ?? 0 );

                $loc_dinein_max                        = absint( $location_data['fmp_loc_dinein_max_orders_per_slot'] ?? 0 );
                $response['dinein_max_orders_per_slot'] = $loc_dinein_max > 0
                        ? $loc_dinein_max
                        : absint( $settings['dinein_max_orders_per_slot'] ?? 0 );

                wp_send_json_success( $response );

                return;
            }
        }

        // Return global schedule.
        wp_send_json_success( $this->pickup_delivery_data_obj() );
    }

    /**
     * The global (non location-specific) schedule for an order type, shaped for
     * the location AJAX response.
     *
     * @param string $type Order type ('pickup', 'delivery' or 'dinein').
     *
     * @return array{interval: int, start: array, end: array, holiday: array, slots: array}
     */
    private function global_schedule( $type ) {
        $schedule = FnsPro::get_setting( "new_fmp_{$type}_weekly_schedule", [] );

        return [
            'interval' => intval( $this->options[ "{$type}_time_interval" ] ?? 15 ),
            'start'    => FnsPro::get_schedule_time( $schedule ),
            'end'      => FnsPro::get_schedule_time( $schedule, 'end' ),
            'holiday'  => FnsPro::get_offday_schedule( $schedule ),
            'slots'    => FnsPro::get_schedule_slots( $schedule ),
        ];
    }

    /**
     * Whether a chosen time falls inside the configured schedule for that day.
     *
     * Returns null when the day has no slots configured at all — the shop hasn't
     * expressed an opinion, so callers should fall back to the global max rather
     * than blocking. Only an explicit set of slots that the time misses counts
     * as out-of-hours.
     *
     * @param string $type        Order type.
     * @param string $date        Date string.
     * @param string $time        Time string (12h or 24h).
     * @param int    $location_id Location term ID (0 for global).
     *
     * @return bool|null
     */
    private function is_time_within_schedule( $type, $date, $time, $location_id = 0 ) {
        $schedule = [];

        if ( $location_id > 0 && ! empty( $this->options['fmp_food_location_popup'] ) ) {
            $loc_schedule = get_term_meta( $location_id, "fmp_loc_new_{$type}_weekly_schedule", true );
            if ( ! empty( $loc_schedule ) && is_array( $loc_schedule ) ) {
                $schedule = $loc_schedule;
            }
        }

        if ( empty( $schedule ) ) {
            $schedule = FnsPro::get_setting( "new_fmp_{$type}_weekly_schedule", [] );
        }

        if ( empty( $schedule ) ) {
            return null;
        }

        $timestamp = strtotime( $date );
        if ( ! $timestamp ) {
            return null;
        }

        $day_name = strtolower( wp_date( 'l', $timestamp ) );
        $day_data = $schedule[ $day_name ] ?? [];
        $slots    = $day_data['slots'] ?? [];

        // Keep only slots that actually define a range.
        $slots = array_filter(
            (array) $slots,
            static function ( $slot ) {
                return ! empty( $slot['start'] ) && ! empty( $slot['end'] );
            }
        );

        if ( empty( $slots ) ) {
            return null;
        }

        $time_minutes = $this->time_to_minutes( $time );

        foreach ( $slots as $slot ) {
            $slot_start = $this->time_to_minutes( $slot['start'] );
            $slot_end   = $this->time_to_minutes( $slot['end'] );

            if ( $time_minutes >= $slot_start && $time_minutes < $slot_end ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get the number of orders for a specific time slot.
     *
     * @param string $type Order type ('pickup' or 'delivery').
     * @param string $date Date string.
     * @param string $time Time string.
     * @param int $location_id Location term ID (0 for no location).
     *
     * @return int Order count.
     */
    private function get_slot_order_count( $type, $date, $time, $location_id = 0 ) {
        $statuses = $this->options['fmp_slot_counting_statuses'] ?? [];

        if ( empty( $statuses ) || ! is_array( $statuses ) ) {
            $statuses = [ 'wc-processing', 'wc-on-hold', 'wc-completed' ];
        }

        $args = [
                'status'     => $statuses,
                'limit'      => - 1,
                'return'     => 'ids',
                'meta_query' => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                        [
                                'key'   => "fmp_{$type}_date",
                                'value' => $date,
                        ],
                        [
                                'key'   => "fmp_{$type}_time",
                                'value' => $time,
                        ],
                        [
                                'key'   => 'fmp_order_time_type',
                                'value' => $type,
                        ],
                        [
                                'key'     => '_fmp_slot_limit_exempt',
                                'compare' => 'NOT EXISTS',
                        ],
                ],
        ];

        if ( $location_id > 0 ) {
            $term = get_term( $location_id, 'tpl-food-location' );

            if ( $term && ! is_wp_error( $term ) ) {
                $args['meta_query'][] = [
                        'key'   => 'fmp_location_name',
                        'value' => $term->name,
                ];
            }
        }

        $orders = wc_get_orders( FnsPro::order_query_args( $args ) );

        return count( $orders );
    }

    /**
     * Get the maximum orders per slot for a given type and location.
     *
     * @param string $type Order type ('pickup' or 'delivery').
     * @param int $location_id Location term ID (0 for global).
     *
     * @return int Max orders (0 = unlimited).
     */
    private function get_max_per_slot( $type, $location_id = 0, $date = '', $time = '' ) {
        $settings   = $this->options;
        $global_max = absint( $settings["{$type}_max_orders_per_slot"] ?? 0 );

        if ( $location_id > 0 && ! empty( $settings['fmp_food_location_popup'] ) ) {
            $location_data = FnsPro::get_location_schedule_data( $location_id );

            if ( null !== $location_data ) {
                $loc_max = absint( $location_data["fmp_loc_{$type}_max_orders_per_slot"] ?? 0 );

                if ( $loc_max > 0 ) {
                    $global_max = $loc_max;
                }
            }
        }

        // Override with per-schedule slot max_order if available.
        if ( $date && $time ) {
            $slot_max = $this->get_schedule_slot_max_order( $type, $date, $time, $location_id );
            if ( $slot_max > 0 ) {
                return $slot_max;
            }
        }

        return $global_max;
    }

    /**
     * Get per-slot max_order from the weekly schedule for a given type, date, and time.
     *
     * @param string $type        'pickup' or 'delivery'.
     * @param string $date        Date string.
     * @param string $time        Time string (12h or 24h).
     * @param int    $location_id Location term ID (0 for global).
     *
     * @return int Per-slot max_order, or 0 if not set.
     */
    private function get_schedule_slot_max_order( $type, $date, $time, $location_id = 0 ) {
        $schedule = [];

        // Try location-specific schedule first.
        if ( $location_id > 0 && ! empty( $this->options['fmp_food_location_popup'] ) ) {
            $loc_schedule = get_term_meta( $location_id, "fmp_loc_new_{$type}_weekly_schedule", true );
            if ( ! empty( $loc_schedule ) && is_array( $loc_schedule ) ) {
                $schedule = $loc_schedule;
            }
        }

        // Fall back to global schedule.
        if ( empty( $schedule ) ) {
            $schedule = FnsPro::get_setting( "new_fmp_{$type}_weekly_schedule", [] );
        }

        if ( empty( $schedule ) ) {
            return 0;
        }

        $timestamp = strtotime( $date );
        if ( ! $timestamp ) {
            return 0;
        }

        $day_name = strtolower( wp_date( 'l', $timestamp ) );
        $day_data = $schedule[ $day_name ] ?? [];
        $slots    = $day_data['slots'] ?? [];

        if ( empty( $slots ) || ! is_array( $slots ) ) {
            return 0;
        }

        $time_minutes = $this->time_to_minutes( $time );

        foreach ( $slots as $slot ) {
            $slot_start = $this->time_to_minutes( $slot['start'] ?? '' );
            $slot_end   = $this->time_to_minutes( $slot['end'] ?? '' );

            if ( $time_minutes >= $slot_start && $time_minutes < $slot_end && ! empty( $slot['max_order'] ) ) {
                return absint( $slot['max_order'] );
            }
        }

        return 0;
    }

    /**
     * Convert a time string to minutes since midnight.
     *
     * @param string $time_str Time string (24h or 12h).
     *
     * @return int Minutes since midnight.
     */
    private function time_to_minutes( $time_str ) {
        if ( empty( $time_str ) ) {
            return 0;
        }

        $time_str = trim( $time_str );

        // 24h format.
        if ( preg_match( '/^(\d{1,2}):(\d{2})$/', $time_str, $m ) ) {
            return (int) $m[1] * 60 + (int) $m[2];
        }

        // 12h format.
        if ( preg_match( '/^(\d{1,2}):(\d{2})\s*(am|pm)$/i', $time_str, $m ) ) {
            $h   = (int) $m[1];
            $min = (int) $m[2];
            if ( 'pm' === strtolower( $m[3] ) && 12 !== $h ) {
                $h += 12;
            } elseif ( 'am' === strtolower( $m[3] ) && 12 === $h ) {
                $h = 0;
            }

            return $h * 60 + $min;
        }

        return 0;
    }

    /**
     * AJAX: Check if a time slot is available.
     *
     * @return void
     */
    public function check_slot_availability() {
        if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
            wp_send_json_error( [ 'message' => esc_html__( 'Security check failed.', 'food-menu-pro' ) ] );

            return;
        }

        $order_type  = ! empty( $_POST['order_type'] ) ? sanitize_text_field( wp_unslash( $_POST['order_type'] ) ) : '';
        $date        = ! empty( $_POST['selected_date'] ) ? sanitize_text_field( wp_unslash( $_POST['selected_date'] ) ) : '';
        $time        = ! empty( $_POST['selected_time'] ) ? sanitize_text_field( wp_unslash( $_POST['selected_time'] ) ) : '';
        $location_id = ! empty( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0;

        if ( ! $order_type || ! $date || ! $time ) {
            wp_send_json_error( [ 'message' => esc_html__( 'Missing required fields.', 'food-menu-pro' ) ] );

            return;
        }

        if ( ! in_array( $order_type, [ 'pickup', 'delivery', 'dinein' ], true ) ) {
            wp_send_json_error( [ 'message' => esc_html__( 'Invalid order type.', 'food-menu-pro' ) ] );

            return;
        }

        // A time outside every configured slot is closed, not unlimited —
        // without this a schedule gap silently falls through to the global max.
        if ( false === $this->is_time_within_schedule( $order_type, $date, $time, $location_id ) ) {
            wp_send_json_success(
                [
                    'status'  => 'closed',
                    'message' => esc_html__( 'We are not open at this time. Please select a different time.', 'food-menu-pro' ),
                ]
            );

            return;
        }

        $max = $this->get_max_per_slot( $order_type, $location_id, $date, $time );

        // Build response.
        $response = [];

        if ( 0 === $max ) {
            $response['status'] = 'open';
        } else {
            $count     = $this->get_slot_order_count( $order_type, $date, $time, $location_id );
            $remaining = $max - $count;

            if ( $remaining <= 0 ) {
                $response['status']  = 'closed';
                $response['message'] = esc_html__( 'This time slot is full. Please select a different time.', 'food-menu-pro' );

                wp_send_json_success( $response );

                return;
            }

            $response['status']    = 'open';
            $response['remaining'] = $remaining;
        }

        // Per-product capacity info from cart items.
        $cart_items = ! empty( $_POST['cart_items'] ) && is_array( $_POST['cart_items'] )
            ? $_POST['cart_items'] // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
            : [];

        if ( ! empty( $cart_items ) ) {
            $cart_map = [];

            foreach ( $cart_items as $item ) {
                $pid = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
                $qty = isset( $item['qty'] ) ? absint( $item['qty'] ) : 0;

                if ( $pid > 0 && $qty > 0 ) {
                    $cart_map[ $pid ] = ( $cart_map[ $pid ] ?? 0 ) + $qty;
                }
            }

            if ( ! empty( $cart_map ) ) {
                $product_ids = array_keys( $cart_map );
                update_meta_cache( 'post', $product_ids );

                // Find which cart products have limits enabled.
                $caps = [];
                foreach ( $product_ids as $pid ) {
                    $cap = $this->get_product_slot_cap( $pid, $location_id );

                    if ( $cap > 0 ) {
                        $caps[ $pid ] = $cap;
                    }
                }

                if ( ! empty( $caps ) ) {
                    $limited_ids = array_keys( $caps );
                    $order_ids   = $this->get_combined_slot_order_ids( $date, $time, $location_id );
                    $sold_map    = $this->get_slot_product_quantities( $order_ids, $limited_ids );

                    $bottlenecks = [];
                    foreach ( $caps as $pid => $cap ) {
                        $sold     = $sold_map[ $pid ] ?? 0;
                        $left     = max( 0, $cap - $sold );
                        $in_cart  = $cart_map[ $pid ] ?? 0;
                        $product  = wc_get_product( $pid );
                        $name     = $product ? $product->get_name() : '#' . $pid;

                        $bottlenecks[] = [
                            'name'      => $name,
                            'remaining' => $left,
                            'cap'       => $cap,
                            'in_cart'   => $in_cart,
                        ];
                    }

                    $response['bottlenecks'] = $bottlenecks;
                }
            }
        }

        wp_send_json_success( $response );
    }

    // ─── Per-Product Order Limit helpers ────────────────────────────────

    /**
     * Resolve the per-slot cap for a product, considering location overrides.
     *
     * @param int $product_id Parent product ID.
     * @param int $location_id Location term ID (0 = no location).
     *
     * @return int Cap (0 = unlimited / not enabled).
     */
    private function get_product_slot_cap( $product_id, $location_id = 0 ) {
        if ( 'on' !== get_post_meta( $product_id, '_fmp_order_limit_enable', true ) ) {
            return 0;
        }

        $default_cap = (int) get_post_meta( $product_id, '_fmp_order_limit_per_slot', true );

        if ( $location_id > 0 && ! empty( $this->options['fmp_food_location_popup'] ) ) {
            $by_loc = get_post_meta( $product_id, '_fmp_order_limit_by_location', true );

            if ( is_array( $by_loc ) && isset( $by_loc[ $location_id ] ) && '' !== $by_loc[ $location_id ] ) {
                return (int) $by_loc[ $location_id ];
            }
        }

        return $default_cap;
    }

    /**
     * Get order IDs for BOTH pickup and delivery in a given slot.
     *
     * Combined pool: delivery + pickup share the same per-product counter.
     *
     * @param string $date Date string.
     * @param string $time Time string.
     * @param int    $location_id Location term ID (0 = no location).
     *
     * @return int[] Order IDs.
     */
    private function get_combined_slot_order_ids( $date, $time, $location_id = 0 ) {
        $statuses = $this->options['fmp_slot_counting_statuses'] ?? [];

        if ( empty( $statuses ) || ! is_array( $statuses ) ) {
            $statuses = [ 'wc-processing', 'wc-on-hold', 'wc-completed' ];
        }

        $base_meta = [
            [
                'key'     => '_fmp_slot_limit_exempt',
                'compare' => 'NOT EXISTS',
            ],
        ];

        if ( $location_id > 0 ) {
            $term = get_term( $location_id, 'tpl-food-location' );

            if ( $term && ! is_wp_error( $term ) ) {
                $base_meta[] = [
                    'key'   => 'fmp_location_name',
                    'value' => $term->name,
                ];
            }
        }

        $base_args = [
            'status' => $statuses,
            'limit'  => -1,
            'return' => 'ids',
        ];

        // Per-product capacity is shared by every order type — a dish consumed by
        // a dine-in order is no longer available to pickup or delivery in the
        // same slot — so all three types are counted here.
        $order_ids = [];

        foreach ( [ 'pickup', 'delivery', 'dinein' ] as $slot_type ) {
            $type_meta   = $base_meta;
            $type_meta[] = [ 'key' => 'fmp_order_time_type', 'value' => $slot_type ];
            $type_meta[] = [ 'key' => "fmp_{$slot_type}_date", 'value' => $date ];
            $type_meta[] = [ 'key' => "fmp_{$slot_type}_time", 'value' => $time ];

            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
            $order_ids = array_merge( $order_ids, wc_get_orders( FnsPro::order_query_args( array_merge( $base_args, [ 'meta_query' => $type_meta ] ) ) ) );
        }

        return array_unique( $order_ids );
    }

    /**
     * Get total sold quantities for specific products across orders in a slot.
     *
     * Single batched SQL: one query for ALL product IDs regardless of count.
     * Uses `_product_id` which naturally rolls up variations to parent.
     *
     * @param int[] $order_ids   Order IDs in the slot.
     * @param int[] $product_ids Parent product IDs to check.
     *
     * @return array<int, int> Map of product_id => total_qty.
     */
    private function get_slot_product_quantities( $order_ids, $product_ids ) {
        if ( empty( $order_ids ) || empty( $product_ids ) ) {
            return [];
        }

        global $wpdb;

        $oid_placeholders = implode( ',', array_fill( 0, count( $order_ids ), '%d' ) );
        $pid_placeholders = implode( ',', array_fill( 0, count( $product_ids ), '%d' ) );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT im_pid.meta_value AS product_id, SUM(im_qty.meta_value) AS total_qty
                 FROM {$wpdb->prefix}woocommerce_order_items oi
                 INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta im_pid
                     ON oi.order_item_id = im_pid.order_item_id AND im_pid.meta_key = '_product_id'
                 INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta im_qty
                     ON oi.order_item_id = im_qty.order_item_id AND im_qty.meta_key = '_qty'
                 WHERE oi.order_id IN ({$oid_placeholders})
                   AND oi.order_item_type = 'line_item'
                   AND im_pid.meta_value IN ({$pid_placeholders})
                 GROUP BY im_pid.meta_value",
                array_merge( array_map( 'intval', $order_ids ), array_map( 'intval', $product_ids ) )
            )
        );

        $map = [];
        foreach ( $rows as $row ) {
            $map[ (int) $row->product_id ] = (int) $row->total_qty;
        }

        return $map;
    }

    /**
     * Build a map of parent_product_id => total cart qty from the WC cart.
     *
     * Variations roll up to parent. Primes post meta cache in one batch call.
     *
     * @return array<int, int> Map of product_id => cart_qty.
     */
    private function get_cart_product_qty_map() {
        $cart = WC()->cart;

        if ( ! $cart ) {
            return [];
        }

        $map        = [];
        $parent_ids = [];

        foreach ( $cart->get_cart() as $item ) {
            $pid = (int) $item['product_id']; // Always the parent.
            $qty = (int) $item['quantity'];

            $map[ $pid ] = ( $map[ $pid ] ?? 0 ) + $qty;
            $parent_ids[] = $pid;
        }

        // Prime meta cache once for all parent product IDs.
        if ( ! empty( $parent_ids ) ) {
            update_meta_cache( 'post', array_unique( $parent_ids ) );
        }

        return $map;
    }

    /**
     * Get the currently selected slot date/time from POST or session.
     *
     * @return array{date: string, time: string, location_id: int}
     */
    private function get_selected_slot() {
        $order_type = '';

        if ( ! empty( $_POST['fmp_order_time_type'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $order_type = sanitize_text_field( wp_unslash( $_POST['fmp_order_time_type'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        }

        $date = '';
        $time = '';

        if ( $order_type ) {
            $date = ! empty( $_POST[ "fmp_{$order_type}_date" ] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
                ? sanitize_text_field( wp_unslash( $_POST[ "fmp_{$order_type}_date" ] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
                : '';
            $time = ! empty( $_POST[ "fmp_{$order_type}_time" ] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
                ? sanitize_text_field( wp_unslash( $_POST[ "fmp_{$order_type}_time" ] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
                : '';
        }

        $location_id = ! empty( $_COOKIE['fmp_location_id'] ) ? absint( $_COOKIE['fmp_location_id'] ) : 0;

        return [
            'date'        => $date,
            'time'        => $time,
            'location_id' => $location_id,
        ];
    }

    /**
     * Validate per-product limits. Returns error messages keyed by product_id.
     *
     * Performance: one meta-cache prime, one get_combined_slot_order_ids call,
     * one batched SQL for all limited products.
     *
     * @param array<int, int> $cart_map product_id => cart_qty.
     * @param string          $date     Slot date.
     * @param string          $time     Slot time.
     * @param int             $location_id Location term ID.
     *
     * @return array<int, array{name: string, remaining: int}> Failing products.
     */
    private function check_product_limits( $cart_map, $date, $time, $location_id ) {
        if ( empty( $cart_map ) || ! $date || ! $time ) {
            return [];
        }

        $product_ids = array_keys( $cart_map );

        // Prime meta cache before per-product cap lookups.
        update_meta_cache( 'post', $product_ids );

        // Filter to only products that have limits enabled and build caps map.
        $caps = [];
        foreach ( $product_ids as $pid ) {
            $cap = $this->get_product_slot_cap( $pid, $location_id );

            if ( $cap > 0 ) {
                $caps[ $pid ] = $cap;
            }
        }

        if ( empty( $caps ) ) {
            return [];
        }

        $limited_ids = array_keys( $caps );
        $order_ids   = $this->get_combined_slot_order_ids( $date, $time, $location_id );
        $sold_map    = $this->get_slot_product_quantities( $order_ids, $limited_ids );

        $failures = [];

        foreach ( $caps as $pid => $cap ) {
            $sold      = $sold_map[ $pid ] ?? 0;
            $in_cart   = $cart_map[ $pid ] ?? 0;
            $remaining = $cap - $sold;

            if ( $sold + $in_cart > $cap ) {
                $product = wc_get_product( $pid );
                $name    = $product ? $product->get_name() : '#' . $pid;

                $failures[ $pid ] = [
                    'name'      => $name,
                    'remaining' => max( 0, $remaining ),
                ];
            }
        }

        return $failures;
    }

    // ─── Per-Product validation hooks ───────────────────────────────────

    /**
     * Validate on add-to-cart: check the incoming product against its slot cap.
     *
     * @param bool $passed     Current validation state.
     * @param int  $product_id Product being added.
     * @param int  $quantity   Quantity being added.
     *
     * @return bool
     */
    public function validate_product_limit_add_to_cart( $passed, $product_id, $quantity ) {
        if ( ! $passed ) {
            return false;
        }

        $slot = $this->get_selected_slot();

        // No slot selected yet (e.g., shop page). Will re-validate at checkout.
        if ( ! $slot['date'] || ! $slot['time'] ) {
            return true;
        }

        // Build a cart map including the item being added.
        // In woocommerce_add_to_cart_validation, $product_id is always the parent.
        $cart_map = $this->get_cart_product_qty_map();
        $cart_map[ $product_id ] = ( $cart_map[ $product_id ] ?? 0 ) + $quantity;

        $failures = $this->check_product_limits( $cart_map, $slot['date'], $slot['time'], $slot['location_id'] );

        if ( ! empty( $failures ) ) {
            foreach ( $failures as $fail ) {
                wc_add_notice(
                    sprintf(
                        /* translators: 1: product name, 2: units remaining */
                        esc_html__( '%1$s — only %2$d unit(s) left for this time slot.', 'food-menu-pro' ),
                        esc_html( $fail['name'] ),
                        $fail['remaining']
                    ),
                    'error'
                );
            }

            return false;
        }

        return true;
    }

    /**
     * Re-validate all cart items against per-product limits.
     *
     * Fires on woocommerce_check_cart_items (cart page, mini cart).
     *
     * @return void
     */
    public function validate_product_limits_cart() {
        $slot = $this->get_selected_slot();

        if ( ! $slot['date'] || ! $slot['time'] ) {
            return;
        }

        $cart_map = $this->get_cart_product_qty_map();
        $failures = $this->check_product_limits( $cart_map, $slot['date'], $slot['time'], $slot['location_id'] );

        foreach ( $failures as $fail ) {
            wc_add_notice(
                sprintf(
                    /* translators: 1: product name, 2: units remaining */
                    esc_html__( '%1$s — only %2$d unit(s) left for this time slot.', 'food-menu-pro' ),
                    esc_html( $fail['name'] ),
                    $fail['remaining']
                ),
                'error'
            );
        }
    }

    /**
     * Final validation at order creation — throws exception to abort.
     *
     * @param \WC_Order $order The order being created.
     *
     * @return void
     *
     * @throws \Exception When a per-product limit is exceeded.
     */
    public function validate_product_limits_checkout( $order ) {
        $slot = $this->get_selected_slot();

        if ( ! $slot['date'] || ! $slot['time'] ) {
            return;
        }

        $cart_map = $this->get_cart_product_qty_map();
        $failures = $this->check_product_limits( $cart_map, $slot['date'], $slot['time'], $slot['location_id'] );

        if ( ! empty( $failures ) ) {
            $messages = [];

            foreach ( $failures as $fail ) {
                $messages[] = sprintf(
                    /* translators: 1: product name, 2: units remaining */
                    esc_html__( '%1$s — only %2$d unit(s) left for this time slot.', 'food-menu-pro' ),
                    esc_html( $fail['name'] ),
                    $fail['remaining']
                );
            }

            throw new \Exception( implode( ' ', $messages ) );
        }
    }


}
