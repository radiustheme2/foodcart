<?php
/**
 * PickupDelivery main class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\PickupDelivery;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;
use WC_Order;

/**
 * PickupDelivery main class
 */
class PickupDelivery {

	use SingletonTrait;

	/**
	 * Settings option
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		$this->options   = FnsPro::get_settings_option();
		$enable_pickup   = $this->options['enable_pickup'] ?? 'on';
		$enable_delivery = $this->options['enable_delivery'] ?? 'on';
		$fm_type         = $this->options['fm_food_menu_type'] ?? 'food_menu_post';

		$condition1 = ( TLPFoodMenu()->isWcActive() && 'on' == $enable_pickup && 'online_ordering' === $fm_type );
		$condition2 = ( TLPFoodMenu()->isWcActive() && 'on' == $enable_delivery && 'online_ordering' === $fm_type );
		if ( $condition1 || $condition2 ) {
			add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
			add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue_assets' ] );

			// pickup and delivery time form show in checkout page.
			add_action( 'woocommerce_checkout_before_customer_details', [ $this, 'render_order_time' ] );
			// pickup and delivery form validation.
			add_action( 'woocommerce_checkout_process', [ $this, 'pickup_delivery_form_validation' ] );

			// Save order meta data.
			add_action( 'woocommerce_checkout_create_order', [ $this, 'update_meta_order_type' ], 10, 2 );
			// Show order details.
			add_action( 'woocommerce_admin_order_data_after_order_details', [ $this, 'add_order_details' ] );

			// Add Order Columns.
			add_filter( 'manage_edit-shop_order_columns', [ $this, 'add_order_columns' ] );
			add_filter( 'manage_woocommerce_page_wc-orders_columns', [ $this, 'add_order_columns' ] );
			add_action( 'manage_shop_order_posts_custom_column', [ $this, 'order_column_meta' ], 25, 2 );
			add_action( 'manage_woocommerce_page_wc-orders_custom_column', [ $this, 'order_column_meta' ], 25, 2 );

			// Order Quick View modify.
			add_filter( 'woocommerce_admin_order_preview_get_order_details', [ $this, 'order_preview_get_order_details' ], 10, 2 );
			add_action( 'woocommerce_admin_order_preview_end', [ $this, 'woocommerce_admin_order_preview_end' ] );
		}
	}

	/**
	 * Add extra information in order column
	 *
	 * @param object $order .
	 *
	 * @return void
	 */
	public function add_order_details( $order ) {
		$order_type    = $order->get_meta( 'fmp_order_time_type' );
		$delivery_data = $order->get_meta( 'fmp_delivery_date' );
		$delivery_time = $order->get_meta( 'fmp_delivery_time' );
		$pickup_data   = $order->get_meta( 'fmp_pickup_date' );
		$pickup_time   = $order->get_meta( 'fmp_pickup_time' );
		$tipInfo       = FnsPro::tip_information( $order );
		?>

        <p class="form-field form-field-wide" style='border: 1px solid #d3dedf;padding: 15px !important;border-radius:6px;margin-top: 15px;box-sizing:border-box;background-color: #e4f5f7;color:#000000;'>
            <span style="display:block;font-size: 16px;border-bottom:1px solid #d3dedf;padding-bottom: 5px;margin-bottom: 5px;"><strong><?php echo esc_html__( 'Food Delivery Details', 'food-menu-pro' ); ?></strong></span>

			<?php
			$label_bg = 'delivery' === $order_type ? '#3577c1' : '#35c183';
			if ( $order_type ) :
				?>

                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Order Type:', 'food-menu-pro' ); ?></strong>

                <span style="display: inline-block;padding: 1px 10px;background: <?php echo esc_attr( $label_bg ); ?>;border-radius: 5px;text-transform: capitalize;font-weight: bold;color: #FFF;"><?php echo esc_html( $order_type ); ?></span>

                <br>
			<?php
			endif;
			if ( 'delivery' == $order_type ) :
				?>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Delivery Date:', 'food-menu-pro' ); ?></strong>
				<?php echo esc_html( $delivery_data ); ?>
                <br>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Delivery Time:', 'food-menu-pro' ); ?></strong>
				<?php echo esc_html( $delivery_time ); ?>
                <br>
			<?php
			endif;

			if ( 'pickup' == $order_type ) :
				?>

                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Pickup Data:', 'food-menu-pro' ); ?></strong>
				<?php echo esc_html( $pickup_data ); ?>
                <br>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Pickup Time:', 'food-menu-pro' ); ?></strong>
				<?php echo esc_html( $pickup_time ); ?>
			<?php endif; ?>
            <br>
            <br>
			<?php if ( $tipInfo['amount'] ) : ?>
                <span style="display:inline-block;font-size: 16px;border-bottom:1px solid #d3dedf;padding-bottom: 5px;margin-bottom: 5px;">
					<strong>
						<?php echo esc_html__( 'Tip: ', 'food-menu-pro' ); ?>
						<?php Fns::print_html( wc_price( $tipInfo['amount'] ) ); ?>
					</strong>
				</span>
				<?php if ( ! empty( $tipInfo['prefix'] ) ) : ?>
                    (<?php echo esc_html( $tipInfo['prefix'] ); ?>)
				<?php endif; ?>
			<?php endif; ?>
        </p>
		<?php
	}

	/**
	 * Update order meta data
	 *
	 * @param object $order .
	 *
	 * @return void
	 */
	public function update_meta_order_type( $order ) {
		// Check for validation.
		$post_data = filter_input_array( INPUT_POST, FILTER_SANITIZE_SPECIAL_CHARS );
		if ( ! empty( $post_data ) ) {
			$allowed_order_types = array_values( FnsPro::get_order_type() );
			foreach ( $post_data as $key => $value ) {
				// Check if the key is an allowed order type and not empty.
				if ( in_array( $key, $allowed_order_types ) && ! empty( $key ) ) {
					$order->update_meta_data( $key, $value );
				}
			}
		}
	}

	/**
	 * WooCommerce checkout order type form validation message.
	 *
	 * @return void
	 */
	public function pickup_delivery_form_validation() {
		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			return;
		}

		if ( empty( $_POST['fmp_order_time_type'] ) ) {
			return;
		}
		$settings   = $this->options;
		$order_type = sanitize_text_field( wp_unslash( $_POST['fmp_order_time_type'] ) );

		switch ( $order_type ) {
			case 'delivery':
				$this->validateDateTime( 'delivery', $settings, 'Please select delivery' );
				break;
			case 'pickup':
				$this->validateDateTime( 'pickup', $settings, 'Please select pickup' );
				break;
			default:
				break;
		}
	}

	/**
	 * Validate date and time based on order type
	 *
	 * @param string $prefix .
	 * @param array $settings .
	 * @param string $message .
	 */
	private function validateDateTime( $prefix, $settings, $message ) {
		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			return;
		}
		$date_input_field = "fmp_{$prefix}_date";
		$time_input_filed = "fmp_{$prefix}_time";
		$enable_date      = "enable_{$prefix}";
		$enable_time      = "enable_{$prefix}_time";

		if ( ! empty( $settings[ $enable_date ] ) && empty( $_POST[ $date_input_field ] ) ) {
			// translators: %s date.
			wc_add_notice( sprintf( esc_html__( '%s date', 'food-menu-pro' ), $message ), 'error' );
		}

		if ( ! empty( $settings[ $enable_date ] ) && ! empty( $settings[ $enable_time ] ) && empty( $_POST[ $time_input_filed ] ) ) {
			// translators: %s time.
			wc_add_notice( sprintf( esc_html__( '%s time', 'food-menu-pro' ), $message ), 'error' );
		}
	}

	/**
	 * PickupDelivery admin assets enqueue
	 *
	 * @return void
	 */
	public function admin_enqueue_assets() {
		wp_enqueue_script( 'fmp-timepicker' );
		wp_enqueue_style( 'fmp-timepicker' );
		wp_enqueue_script( 'fmp-admin-pickup-delivery' );

		$fm_time_format = get_option( 'time_format' ) ?? 'H:i A';
		wp_localize_script(
			'fmp-admin-pickup-delivery',
			'fmpResiParams',
			[
				'time_format' => $fm_time_format,
			]
		);
	}

	/**
	 * Frontend enqueue file
	 *
	 * @return void
	 */
	public function frontend_enqueue_assets() {
		// add enqueue timepicker in frontend.
		wp_enqueue_script( 'fmp-timepicker' );
		wp_enqueue_style( 'fmp-timepicker' );

		// add enqueue flatpickr for date in frontend.
		wp_enqueue_script( 'fmp-flatpickr' );
		wp_enqueue_style( 'fmp-flatpickr' );
		wp_enqueue_script( 'fmp-pickup-delivery' );
		\wp_localize_script(
			'fmp-pickup-delivery',
			'fmpPDParams',
			$this->pickup_delivery_data_obj()
		);
	}

	/**
	 * Render form frontend in checkout page
	 *
	 * @return void
	 */
	public function render_order_time() {
		Fns::render( 'pickup-delivery/order-time' );
	}

	/**
	 * Pickup deliver localize data object
	 *
	 * @return array
	 */
	public function pickup_delivery_data_obj() {
		$settings                = $this->options;
		$delivery_preparing_date = ! empty( $settings['delivery_preparation_day'] ) ? FnsPro::preparing_date( $settings['delivery_preparation_day'] ) : FnsPro::preparing_date( '0' );

		$fm_date_format    = get_option( 'date_format' ) ?? 'Y-m-d';
		$fm_time_format    = get_option( 'time_format' ) ?? 'H:i A';
		$current_date_time = current_datetime();
		$current_date      = $current_date_time->format( $fm_date_format );
		$current_time      = $current_date_time->format( $fm_time_format );

		return [
			'delivery_time_interval'              => $settings['delivery_time_interval'] ?? 15,
			'delivery_weekly_schedule'            => $settings['fmp_delivery_weekly_schedule'] ?? [],
			'delivery_weekly_schedule_start_time' => $settings['fmp_delivery_weekly_schedule_start_time'] ?? [],
			'delivery_weekly_schedule_end_time'   => $settings['fmp_delivery_weekly_schedule_end_time'] ?? [],
			'pickup_time_interval'                => $settings['pickup_time_interval'] ?? 15,
			'pickup_weekly_schedule'              => $settings['fmp_pickup_weekly_schedule'] ?? [],
			'pickup_weekly_schedule_start_time'   => $settings['fmp_pickup_weekly_schedule_start_time'] ?? [],
			'pickup_weekly_schedule_end_time'     => $settings['fmp_pickup_weekly_schedule_end_time'] ?? [],
			'delivery_preparing_date'             => $delivery_preparing_date,
			'pickup_preparing_date'               => FnsPro::preparing_date( 0 ),
			'enable_delivery'                     => $settings['enable_delivery'] ?? 'on',
			'enable_delivery_time'                => $settings['enable_delivery_time'] ?? 'on',
			'enable_pickup'                       => $settings['enable_pickup'] ?? 'on',
			'enable_pickup_time'                  => $settings['enable_pickup_time'] ?? 'on',
			'pickup_weekly_holiday'               => $settings['fmp_pickup_weekly_holiday'] ?? [],
			'delivery_weekly_holiday'             => $settings['fmp_delivery_weekly_holiday'] ?? [],
			'current_time'                        => $current_time,
			'current_date'                        => $current_date,
		];
	}

	/**
	 * Add Order Columns
	 *
	 * @param $columns
	 *
	 * @return mixed
	 */
	public function add_order_columns( $columns ) {
		$columns['delivery_options'] = 'Delivery Options';

		return $columns;
	}

	/**
	 * Add extra inormation in order column
	 *
	 * @param $column
	 * @param $order_or_order_id
	 *
	 * @return void
	 */
	public function order_column_meta( $column, $order_or_order_id ) {
		$order = $order_or_order_id instanceof WC_Order ? $order_or_order_id : wc_get_order( $order_or_order_id );
		if ( $column == 'delivery_options' ) {
			$order_type = $order->get_meta( 'fmp_order_time_type' );

			if ( $order_type == 'delivery' ) {
				$date = $order->get_meta( 'fmp_delivery_date' );
				$time = $order->get_meta( 'fmp_delivery_time' );
			} else {
				$date = $order->get_meta( 'fmp_pickup_date' );
				$time = $order->get_meta( 'fmp_pickup_time' );
			}
			$label_bg = 'delivery' === $order_type ? '#3577c1' : '#35c183';
			echo "<span style='display:inline-block;padding: 0 10px;border-radius:5px;background:" . esc_attr( $label_bg ) . ";color:#FFF'>$order_type</span><br> $date - <b>$time</b>";
		}
	}

	/**
	 * Send oder preview custom data for preview markup
	 *
	 * @param $data
	 * @param $order
	 *
	 * @return mixed
	 */
	public function order_preview_get_order_details( $data, $order ) {
		$tipInfo            = FnsPro::tip_information( $order );
		$data['order_info'] = [
			'fmp_order_time_type' => $order->get_meta( 'fmp_order_time_type' ),
			'fmp_delivery_date'   => $order->get_meta( 'fmp_delivery_date' ),
			'fmp_delivery_time'   => $order->get_meta( 'fmp_delivery_time' ),
			'fmp_pickup_date'     => $order->get_meta( 'fmp_pickup_date' ),
			'fmp_pickup_time'     => $order->get_meta( 'fmp_pickup_time' ),
			'fmp_tip'             => $tipInfo,
		];

		return $data;
	}

	/**
	 * Order Quick View modify
	 *
	 * @return void
	 */
	public function woocommerce_admin_order_preview_end() {
		?>
        <div>
            {{{ console.log( data.order_info.fmp_tip.amount ) }}}
            <p class="form-field form-field-wide" style='border: 1px solid #d3dedf;padding: 15px !important;border-radius:6px;margin: 15px;box-sizing:border-box;background-color: #e4f5f7;color:#000000;'>
				<span style="display:block;font-size: 16px;border-bottom:1px solid #d3dedf;padding-bottom: 5px;margin-bottom: 5px;">
					<strong><?php echo esc_html__( 'Food Delivery Details', 'food-menu-pro' ); ?></strong>
				</span>

                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Order Type:', 'food-menu-pro' ); ?></strong>
                <span style="display: inline-block;padding: 1px 10px;background: {{{ data.order_info.fmp_order_time_type == 'delivery' ? '#3577c1' : '#35c183' }}} ;border-radius: 5px;text-transform: capitalize;font-weight: bold;color: #FFF;">
				{{{ data.order_info.fmp_order_time_type}}}
				</span>

                <br>

                <# if ( 'delivery' == data.order_info.fmp_order_time_type ) { #>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Delivery Date:', 'food-menu-pro' ); ?></strong>
                {{{ data.order_info.fmp_delivery_date}}}
                <br>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Delivery Time:', 'food-menu-pro' ); ?></strong>
                {{{ data.order_info.fmp_delivery_time}}}
                <br>
                <# } #>

                <# if ( 'pickup' == data.order_info.fmp_order_time_type ) { #>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Pickup Data:', 'food-menu-pro' ); ?></strong>
                {{{ data.order_info.fmp_pickup_date}}}
                <br>
                <strong style="min-width: 110px;display: inline-block;"><?php echo esc_html__( 'Pickup Time:', 'food-menu-pro' ); ?></strong>
                {{{ data.order_info.fmp_pickup_time}}}
                <# } #>

                <br>
                <br>
                <# if( data.order_info.fmp_tip.amount ) { #>
                <span style="font-size: 16px;border-bottom:1px solid #d3dedf;padding-bottom: 5px;margin-bottom: 5px;display: inline-block">
					<strong>
						<?php echo esc_html__( 'Tip Amount: ', 'food-menu-pro' ); ?>
						{{{ Math.round(data.order_info.fmp_tip.amount * 100) / 100 }}}<?php echo get_woocommerce_currency_symbol(); ?> {{{ data.order_info.fmp_tip.prefix }}}
					</strong>
				</span>
                <# } #>
            </p>
        </div>

        <style>
            .wc-backbone-modal .wc-backbone-modal-content article {
                display: flex;
                flex-direction: column;
            }
            .wc-order-preview-table-wrapper {
                order: 10;
            }
        </style>


		<?php
	}

}
