<?php
/**
 * Slot Limits settings fields.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\PickupDelivery;

defined( 'ABSPATH' ) || exit();

/**
 * Slot Limits settings fields class.
 */
class SlotLimitsFns {

	/**
	 * Slot limits setting fields.
	 *
	 * @return array
	 */
	public static function settings_field() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return [
			'fmp_enable_order_slot_limits' => [
				'type'        => 'switch',
				'label'       => esc_html__( 'Enable Time Slot Order Limits', 'food-menu-pro' ),
				'description' => esc_html__( 'Limit the number of pickup/delivery orders per time slot.', 'food-menu-pro' ),
				'value'       => $settings['fmp_enable_order_slot_limits'] ?? '',
			],
			'pickup_max_orders_per_slot'   => [
				'type'        => 'number',
				'label'       => esc_html__( 'Max Orders Per Pickup Slot', 'food-menu-pro' ),
				'description' => esc_html__( 'Maximum pickup orders allowed per time slot. 0 = unlimited.', 'food-menu-pro' ),
				'value'       => $settings['pickup_max_orders_per_slot'] ?? 0,
				'attr'        => 'min="0" step="1"',
			],
			'delivery_max_orders_per_slot' => [
				'type'        => 'number',
				'label'       => esc_html__( 'Max Orders Per Delivery Slot', 'food-menu-pro' ),
				'description' => esc_html__( 'Maximum delivery orders allowed per time slot. 0 = unlimited.', 'food-menu-pro' ),
				'value'       => $settings['delivery_max_orders_per_slot'] ?? 0,
				'attr'        => 'min="0" step="1"',
			],
			'dinein_max_orders_per_slot'   => [
				'type'        => 'number',
				'label'       => esc_html__( 'Max Orders Per Dine In Slot', 'food-menu-pro' ),
				'description' => esc_html__( 'Maximum dine in orders allowed per time slot. 0 = unlimited.', 'food-menu-pro' ),
				'value'       => $settings['dinein_max_orders_per_slot'] ?? 0,
				'attr'        => 'min="0" step="1"',
			],
			'fmp_slot_counting_statuses'  => [
				'type'        => 'checkbox',
				'multiple'    => true,
				'label'       => esc_html__( 'Order Statuses That Count Toward Slot Limits', 'food-menu-pro' ),
				'description' => esc_html__( 'Select which order statuses count against slot limits. If none selected, defaults to Processing, On Hold, and Completed.', 'food-menu-pro' ),
				'options'     => self::get_status_options(),
				'value'       => $settings['fmp_slot_counting_statuses'] ?? [ 'wc-processing', 'wc-on-hold', 'wc-completed' ],
				'alignment'   => 'vertical',
			],
		];
	}

	/**
	 * Get all available order statuses for the slot limits checkbox.
	 *
	 * @return array Associative array of slug => label.
	 */
	public static function get_status_options() {
		$options = [];

		// Include all WooCommerce order statuses.
		if ( function_exists( 'wc_get_order_statuses' ) ) {
			$wc_statuses = wc_get_order_statuses();
			$exclude     = [ 'wc-checkout-draft' ];

			foreach ( $wc_statuses as $key => $label ) {
				if ( in_array( $key, $exclude, true ) ) {
					continue;
				}
				$options[ $key ] = esc_html( $label );
			}
		}

		return $options;
	}
}
