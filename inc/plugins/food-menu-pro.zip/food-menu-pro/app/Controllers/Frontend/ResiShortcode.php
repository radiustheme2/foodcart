<?php

namespace RT\FoodMenuPro\Controllers\Frontend;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;

/**
 * Reservation form shortcode
 */
class ResiShortcode {


	use SingletonTrait;

	/**
	 * Settings option
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		$this->options = FnsPro::get_settings_option();
		add_shortcode( 'fm_reservation_form', [ $this, 'render' ] );
		add_shortcode( 'fm_visual_table_reservation_form', [ $this, 'visual_table_render' ] );
	}

	/**
	 * Render visual table reservation form
	 *
	 * @param array $atts .
	 * @return false|string
	 */
	public function visual_table_render( $atts ) {
		ob_start();
		$settings           = $this->options;
		$enable_cancel_form = ! empty( $settings['fmp_resi_enable_cancel_form'] ) ? $settings['fmp_resi_enable_cancel_form'] : 'on';
		$attrs_data         = apply_filters( 'fmp/resi/visual_table_reservation_form_atts', $atts );
		$data               = [
			'settings'   => $settings,
			'attrs_data' => $attrs_data,
		];
		$table_content      = get_option( 'fmp_table_layout', [] );

		?>
		<div class="fmp-reservation-form-wrap">
			<?php
			if ( ! empty( $table_content ) ) {
				Fns::render( 'reservation/visual-table-reservation', $data );
				if ( ! empty( $enable_cancel_form ) ) {
					Fns::render( 'reservation/cancel-form', $data );
				}
			} else {
				?>
					<p class="fmp-resi-error-msg fmp-show"><?php echo esc_html__( 'Please first create visual table in backend food menu option then show the visual table form.', 'food-menu-pro' ); ?></p>
				<?php
			}
			?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Renders normal reservation form shortcode.
	 *
	 * @param array $atts Attributes.
	 * @return false|string
	 */
	public function render( $atts ) {
		ob_start();
		$settings           = $this->options;
		$enable_cancel_form = ! empty( $settings['fmp_resi_enable_cancel_form'] ) ? $settings['fmp_resi_enable_cancel_form'] : 'on';
		$attrs_data         = apply_filters( 'fmp/resi/reservation_form_atts', $atts );
		$data               = [
			'settings'   => $settings,
			'attrs_data' => $attrs_data,
		];
		?>
		<div class="fmp-reservation-form-wrap">
			<?php
			Fns::render( 'reservation/reservation-form', $data );
			if ( ! empty( $enable_cancel_form ) ) {
				Fns::render( 'reservation/cancel-form', $data );
			}
			?>
		</div>
		<?php
		return ob_get_clean();
	}
}
