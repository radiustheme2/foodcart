<?php
/**
 * Single Popup Ajax Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Frontend\Ajax;

use RT\FoodMenuPro\Helpers\FnsPro;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Single Popup Ajax Class.
 */
class Popup {

	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'wp_ajax_fmp_ajax', [ $this, 'response' ] );
		add_action( 'wp_ajax_nopriv_fmp_ajax', [ $this, 'response' ] );

		add_action( 'wp_enqueue_scripts', [ $this, 'ensure_variation_scripts' ] );
	}

	function ensure_variation_scripts() {
		if ( function_exists( 'wc_enqueue_js' ) ) {
			wp_enqueue_script( 'wc-add-to-cart-variation' );
		}
	}

	/**
	 * Ajax Response.
	 *
	 * @return void
	 */
	public function response() {
		$content = '';
		if ( ! empty( $_REQUEST['id'] ) && $id = absint( $_REQUEST['id'] ) ) { //phpcs:ignore
			global $post;

			$post = get_post( absint( $id ) );

			// Public endpoint: only published food items / products, never drafts, private posts or other types.
			if ( ! $post || ! in_array( $post->post_type, [ TLPFoodMenu()->post_type, 'product' ], true ) || 'publish' !== $post->post_status || post_password_required( $post ) ) {
				wp_send_json_error();
			}

			setup_postdata( $post );

			$sid            = $_REQUEST['sid'] ? absint( $_REQUEST['sid'] ) : '';
			$primaryColor   = get_post_meta( $sid, 'fmp_primary_color', true );
			$_primary_color = $primaryColor ? "--rtfm-primary-color: {$primaryColor};" : '';

			$tabs = apply_filters( 'fmp_food_menu_tabs', [] );
//			unset( $tabs['reviews'] );
			ob_start();

			echo "<div class='fmp-wrapper fmp-popup-container fmp-row' style='{$_primary_color}'>"; //phpcs:ignore
			do_action( 'fmp_single_summery', $sid );

			if ( ! empty( $tabs ) ) : ?>
				<div class="fmp-tabs-wrapper">
					<ul class="fmp-tabs">
						<?php foreach ( $tabs as $key => $tab ) :
							if ( 'description' === $key && ! get_the_content() ) {
								continue;
							} elseif ( 'ingredient' === $key && ! FnsPro::get_fm_ingredient_list() ) {
								continue;
							} elseif ( 'nutrition' === $key && ! FnsPro::get_fm_nutrition_list() ) {
								continue;
							}
							?>
							<li class="<?php echo esc_attr( $key ); ?>_tab" data-id="tab-fmp-<?php echo esc_attr( $key ); ?>">
								<?php echo esc_html( $tab['title'] ); ?>
							</li>
						<?php endforeach; ?>
					</ul>
					<?php foreach ( $tabs as $key => $tab ) :
						if ( 'description' === $key && ! get_the_content() ) {
							continue;
						} elseif ( 'ingredient' === $key && ! FnsPro::get_fm_ingredient_list() ) {
							continue;
						} elseif ( 'nutrition' === $key && ! FnsPro::get_fm_nutrition_list() ) {
							continue;
						}
						?>
						<div class="fmp-tab-panel fmp-tab-panel-<?php echo esc_attr( $key ); ?>" id="tab-fmp-<?php echo esc_attr( $key ); ?>">
							<?php call_user_func( $tab['callback'], $key, $tab ); ?>
						</div>
					<?php endforeach; ?>
				</div>
				<?php
			endif;

			echo '</div>';
			?>
			<script>
				jQuery(document).ready(function ($) {
					jQuery('form.variations_form').on('show_variation', function (event, variation) {
						$('.woocommerce-variation-price').html(variation.price_html)
					})
				})
			</script>
			<?php
			$content = ob_get_clean();
			wp_reset_postdata();
		}
		wp_send_json( [ 'html' => $content ] );
		die();
	}
}