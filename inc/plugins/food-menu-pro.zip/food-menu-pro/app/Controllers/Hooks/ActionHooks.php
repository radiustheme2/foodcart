<?php
/**
 * Action Hook Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Hooks;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Controllers\TimedProducts\TimedProducts;
use RT\FoodMenuPro\Helpers\FnsPro;
use WC_Order;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Action Hook Class.
 */
class ActionHooks {
	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		remove_action( 'fmp_single_summery', [ TLPFoodMenu(), 'fmp_summery_price' ], 30 );

		add_action( 'fmp_single_summery', [ $this, 'fmp_summery_price' ], 30 );
		add_action( 'fmp_single_details', [ $this, 'fmp_single_before_details' ], 10 );
		add_action( 'fmp_single_details', [ $this, 'fmp_single_tabs' ], 20 );
		add_action( 'fmp_single_details', [ $this, 'fmp_single_after_details' ], 30 );

		add_action( 'fmp_review_before', [ $this, 'fmp_review_display_gravatar' ], 10 );
		add_action( 'fmp_review_before_comment_meta', [ $this, 'fmp_review_display_rating' ], 10 );
		add_action( 'fmp_review_meta', [ $this, 'fmp_review_display_meta' ], 10 );
		add_action( 'fmp_review_comment_text', [ $this, 'fmp_review_display_comment_text' ], 10 );

		add_action( 'pre_get_posts', [ $this, 'pre_get_posts' ] );
		add_action( 'admin_init', [ $this, 'refresh' ] );

		// Replace free's location-only renderer with the Pro version that also
		// surfaces pickup/delivery, QR table, tip, and custom fields.
		$free_action_hooks = FnsPro::free_instance( \RT\FoodMenu\Controllers\Hooks\ActionHooks::class );
		if ( $free_action_hooks ) {
			remove_action( 'woocommerce_order_details_after_order_table_items', [ $free_action_hooks, 'food_menu_order_details' ] );
		}
		add_action( 'woocommerce_order_details_after_order_table_items', [ $this, 'food_menu_order_details' ] );
	}

	/**
	 * Price.
	 *
	 * @return void
	 */
	public function fmp_summery_price() {
		$settings      = get_option( TLPFoodMenu()->options['settings'] );
		$hiddenOptions = ! empty( $settings['hide_options'] ) ? $settings['hide_options'] : [];
		global $post;

		$is_unavailable = TimedProducts::get_instance()->is_product_unavailable( $post->ID );

		if ( ! in_array( 'price', $hiddenOptions ) && ! $is_unavailable ) {
			if ( $post->post_type == 'product' && TLPFoodMenu()->isWcActive() ) {
				woocommerce_template_single_price();

				echo '<div class="wc-add-to-cart fmp-qv-add-to-cart">';
				woocommerce_template_single_add_to_cart();
				echo '</div>';
			} else {
				$fmp_type = get_post_meta( $post->ID, '_fmp_type', true );

				if ( 'variable' === $fmp_type ) {
					$variations = get_posts(
						[
							'post_type'      => 'fmp_variation',
							'posts_per_page' => -1,
							'post_status'    => 'any',
							'post_parent'    => $post->ID,
							'order'          => 'ASC',
						]
					);
					$html       = null;

					if ( ! empty( $variations ) ) {
						$html .= '<table class="fmp-price-listing">';

						foreach ( $variations as $variation ) {
							$name  = get_post_meta( $variation->ID, '_name', true );
							$price = FnsPro::getPriceWithSymbol( get_post_meta( $variation->ID, '_price', true ) );
							$html .= "<tr><td>{$name}</td><td>{$price}</td>";
						}

						$html .= '</table>';
					}

					Fns::print_html( $html );
				} else {
					$gTotal = FnsPro::fmpHtmlPrice();
					printf( "<div class='offers'>%s</div>", wp_kses_post( $gTotal ) );
				}
			}
		}
	}

	/**
	 * Ratings
	 *
	 * @return void
	 */
	public function fmp_review_display_rating() {
		Fns::render( 'single/review-rating' );
	}

	/**
	 * Meta.
	 *
	 * @return void
	 */
	public function fmp_review_display_meta() {
		Fns::render( 'single/review-meta' );
	}

	/**
	 * Comment text.
	 *
	 * @return void
	 */
	public function fmp_review_display_comment_text() {
		echo '<div itemprop="description" class="description">';
		comment_text();
		echo '</div>';
	}

	/**
	 * Gravatar display.
	 *
	 * @param string $comment Comment.
	 * @return void
	 */
	public function fmp_review_display_gravatar( $comment ) {
		echo get_avatar( $comment, apply_filters( 'fmp_review_gravatar_size', '60' ), '' );
	}

	/**
	 * Wrapper start.
	 *
	 * @return void
	 */
	public function fmp_single_before_details() {
		echo "<div id='fmp-single-details'>";
	}

	/**
	 * Renders tab.
	 *
	 * @return void
	 */
	public function fmp_single_tabs() {
		Fns::render( 'single/tabs/tabs' );
	}

	/**
	 * Wrapper end.
	 *
	 * @return void
	 */
	public function fmp_single_after_details() {
		echo '</div>';
	}

	/**
	 * pre_get_posts Query update for FMP()->post_type.
	 *
	 * @param $wp_query
	 */
	public function pre_get_posts( $wp_query ) {
		if ( is_admin() ) {
			if ( isset( $wp_query->query['post_type'] ) && ! isset( $_GET['orderby'] ) && $wp_query->query['post_type'] == TLPFoodMenu()->post_type && $wp_query->is_main_query() ) { //phpcs:ignore
				$wp_query->set( 'orderby', 'menu_order' );
				$wp_query->set( 'order', 'ASC' );
			}
		}
	}

	/**
	 * Refresh Sorting
	 */
	public function refresh() {
		global $wpdb, $typenow;

		if ( $typenow != TLPFoodMenu()->post_type ) {
			return;
		}

		//phpcs:disable
		$results = $wpdb->get_results(
			"
			SELECT ID
			FROM $wpdb->posts
			WHERE post_type = '" . TLPFoodMenu()->post_type . "' AND post_status IN ('publish', 'pending', 'draft', 'private', 'future')
			ORDER BY menu_order ASC
			"
		);


		foreach ( $results as $key => $result ) {
			$wpdb->update( $wpdb->posts, [ 'menu_order' => $key + 1 ], [ 'ID' => $result->ID ] );
		}
		//phpcs:enable
	}

	/**
	 * Render pickup/delivery info on the customer-facing order details page
	 * (thank-you + My Account → View Order).
	 *
	 * Hooked to `woocommerce_order_details_after_order_table_items`, which
	 * fires inside the order items `<tbody>` — output must be `<tr>` rows.
	 *
	 * @param WC_Order $order Order being viewed.
	 *
	 * @return void
	 */
	public function food_menu_order_details( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$order_type    = $order->get_meta( 'fmp_order_time_type' );
		$location      = $order->get_meta( 'fmp_location_name' );
		$delivery_date = $order->get_meta( 'fmp_delivery_date' );
		$delivery_time = $order->get_meta( 'fmp_delivery_time' );
		$pickup_date   = $order->get_meta( 'fmp_pickup_date' );
		$pickup_time   = $order->get_meta( 'fmp_pickup_time' );
		$dinein_date   = $order->get_meta( 'fmp_dinein_date' );
		$dinein_time   = $order->get_meta( 'fmp_dinein_time' );
		$dinein_table  = $order->get_meta( 'fmp_dinein_table' );
		$tip_info      = FnsPro::tip_information( $order );

		$custom_fields = $order->get_meta( '_fmp_custom_fields' );
		$custom_fields = is_array( $custom_fields ) ? $custom_fields : [];
		$field_defs    = FnsPro::get_setting( 'fmp_order_custom_fields', [] );

		$has_custom = false;
		foreach ( $custom_fields as $v ) {
			$disp = is_array( $v ) ? implode( ', ', $v ) : $v;
			if ( '' !== (string) $disp ) {
				$has_custom = true;
				break;
			}
		}

		$has_any = $order_type || $location || $delivery_date || $delivery_time
		           || $pickup_date || $pickup_time
		           || $dinein_date || $dinein_time || $dinein_table
		           || ! empty( $tip_info['amount'] ) || $has_custom;

		if ( ! $has_any ) {
			return;
		}

		$type_dates  = [
			'delivery' => $delivery_date,
			'pickup'   => $pickup_date,
			'dinein'   => $dinein_date,
		];
		$type_times  = [
			'delivery' => $delivery_time,
			'pickup'   => $pickup_time,
			'dinein'   => $dinein_time,
		];
		$date_labels = [
			'delivery' => __( 'Delivery Date', 'food-menu-pro' ),
			'pickup'   => __( 'Pickup Date', 'food-menu-pro' ),
			'dinein'   => __( 'Dine In Date', 'food-menu-pro' ),
		];
		$time_labels = [
			'delivery' => __( 'Delivery Time', 'food-menu-pro' ),
			'pickup'   => __( 'Pickup Time', 'food-menu-pro' ),
			'dinein'   => __( 'Dine In Time', 'food-menu-pro' ),
		];

		$type_date  = $type_dates[ $order_type ] ?? '';
		$type_time  = $type_times[ $order_type ] ?? '';
		$date_label = $date_labels[ $order_type ] ?? $date_labels['pickup'];
		$time_label = $time_labels[ $order_type ] ?? $time_labels['pickup'];
		$type_bg    = FnsPro::get_order_type_color( $order_type );
		?>
		<tr class="fmp-order-details-row">
			<th colspan="2" style="padding-top:20px;border-top:2px solid #e5e7eb;">
				<?php esc_html_e( 'Food Order Details', 'food-menu-pro' ); ?>
			</th>
		</tr>

		<?php if ( $location ) : ?>
			<tr>
				<th><?php esc_html_e( 'Location:', 'food-menu-pro' ); ?></th>
				<td>
                    <span style="display:inline-block;padding:2px 10px;background:#e67e22;border-radius:4px;color:#fff;font-weight:600;">
                        <?php echo esc_html( $location ); ?>
                    </span>
				</td>
			</tr>
		<?php endif; ?>

		<?php if ( $order_type ) : ?>
			<tr>
				<th><?php esc_html_e( 'Order Type:', 'food-menu-pro' ); ?></th>
				<td>
                    <span style="display:inline-block;padding:2px 10px;background:<?php echo esc_attr( $type_bg ); ?>;border-radius:4px;color:#fff;font-weight:600;text-transform:capitalize;">
                        <?php echo esc_html( FnsPro::get_order_type_label( $order_type ) ?: $order_type ); ?>
                    </span>
				</td>
			</tr>
		<?php endif; ?>

		<?php if ( 'dinein' === $order_type && $dinein_table ) : ?>
			<tr>
				<th><?php esc_html_e( 'Table:', 'food-menu-pro' ); ?></th>
				<td><?php echo esc_html( $dinein_table ); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ( $type_date ) : ?>
			<tr>
				<th><?php echo esc_html( $date_label ); ?>:</th>
				<td><?php echo esc_html( $type_date ); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ( $type_time ) : ?>
			<tr>
				<th><?php echo esc_html( $time_label ); ?>:</th>
				<td><?php echo esc_html( $type_time ); ?></td>
			</tr>
		<?php endif; ?>
		<?php
		if ( $has_custom ) {
			foreach ( $custom_fields as $key => $value ) {
				$display = is_array( $value ) ? implode( ', ', $value ) : $value;
				if ( '' === (string) $display ) {
					continue;
				}
				$idx   = (int) str_replace( 'custom_', '', $key );
				$label = isset( $field_defs[ $idx ]['label'] ) && '' !== $field_defs[ $idx ]['label']
					? $field_defs[ $idx ]['label']
					: $key;
				?>
				<tr>
					<th><?php echo esc_html( $label ); ?>:</th>
					<td><?php echo esc_html( $display ); ?></td>
				</tr>
				<?php
			}
		}
	}
}
