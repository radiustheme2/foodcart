<?php
/**
 * WhatsApp Notification Controller.
 *
 * Sends WhatsApp messages via Twilio API when orders are placed
 * and when order statuses change.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * WhatsApp Notification Controller.
 */
class WhatsAppNotificationController {

	use SingletonTrait;

	/**
	 * Plugin settings.
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Placeholders for message templates.
	 *
	 * @var array
	 */
	private $placeholders = [
		'{customer_name}',
		'{order_number}',
		'{order_date}',
		'{status_label}',
		'{site_name}',
		'{order_url}',
		'{tracking_url}',
		'{order_total}',
		'{order_items}',
		'{payment_method}',
		'{order_type}',
		'{order_schedule}',
		'{table_number}',
	];

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	protected function init() {
		$this->options = FnsPro::get_settings_option();

		$fm_type = $this->options['fm_food_menu_type'] ?? 'food_menu_post';
		$enabled = $this->options['fmp_enable_whatsapp'] ?? '';

		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type || 'on' !== $enabled ) {
			return;
		}

		// Send WhatsApp when a new order is placed.
		add_action( 'woocommerce_thankyou', [ $this, 'send_new_order_notification' ], 20 );

		// Send WhatsApp when order status changes.
		add_action( 'woocommerce_order_status_changed', [ $this, 'send_status_change_notification' ], 20, 4 );
	}

	/**
	 * Get enabled notification channels.
	 *
	 * @return array List of enabled channels ('whatsapp', 'sms').
	 */
	private function get_enabled_channels() {
		$channels = [];

		if ( 'on' === ( $this->options['fmp_enable_whatsapp_channel'] ?? 'on' ) ) {
			$channels[] = 'whatsapp';
		}

		if ( 'on' === ( $this->options['fmp_enable_sms_channel'] ?? '' ) ) {
			$channels[] = 'sms';
		}

		return $channels;
	}

	/**
	 * Send WhatsApp notification when a new order is placed.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return void
	 */
	public function send_new_order_notification( $order_id ) {
		if ( ! $order_id ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return;
		}

		if ( $order->get_meta( '_fmp_whatsapp_new_order_sent' ) ) {
			return;
		}

		$phone = $order->get_billing_phone();

		if ( empty( $phone ) ) {
			return;
		}

		$default_message = 'Hi {customer_name}, your order #{order_number} has been placed successfully!'
			. "\n\nOrder Date: {order_date}"
			. "\nItems: {order_items}"
			. "\nTotal: {order_total}"
			. "\nPayment: {payment_method}"
			. "\n\nTrack your order: {order_url}"
			. "\n\nThank you for ordering from {site_name}!";

		$message_template = $this->options['fmp_whatsapp_new_order_message'] ?? $default_message;

		if ( empty( trim( $message_template ) ) ) {
			$message_template = $default_message;
		}

		$message  = $this->replace_placeholders( $message_template, $order );
		$channels = $this->get_enabled_channels();
		$sent     = false;

		foreach ( $channels as $channel ) {
			if ( $this->send_message( $phone, $message, $channel ) ) {
				$sent = true;
			}
		}

		if ( $sent ) {
			$order->update_meta_data( '_fmp_whatsapp_new_order_sent', 'yes' );
			$order->save();
		}
	}

	/**
	 * Send WhatsApp notification when order status changes.
	 *
	 * @param int       $order_id   Order ID.
	 * @param string    $old_status Old status slug (without wc- prefix).
	 * @param string    $new_status New status slug (without wc- prefix).
	 * @param \WC_Order $order      Order object.
	 *
	 * @return void
	 */
	public function send_status_change_notification( $order_id, $old_status, $new_status, $order ) {
		$phone = $order->get_billing_phone();

		if ( empty( $phone ) ) {
			return;
		}

		$message = $this->get_status_change_message( $new_status, $order );
		if ( empty( $message ) ) {
			return;
		}

		foreach ( $this->get_enabled_channels() as $channel ) {
			$this->send_message( $phone, $message, $channel );
		}
	}

	/**
	 * Build the status change message.
	 *
	 * First checks custom order statuses for a whatsapp_body template,
	 * then falls back to WooCommerce core statuses with a default message.
	 *
	 * @param string    $new_status New status slug (without wc- prefix).
	 * @param \WC_Order $order      Order object.
	 *
	 * @return string Message text, or empty string to skip.
	 */
	private function get_status_change_message( $new_status, $order ) {
		$wc_status = 'wc-' . $new_status;

		// Check custom order statuses for a whatsapp_body template.
		$custom_statuses = get_option( 'fmp_custom_order_statuses', [] );

		if ( is_array( $custom_statuses ) ) {
			foreach ( $custom_statuses as $status ) {
				if ( empty( $status['enabled'] ) ) {
					continue;
				}

				if ( ( $status['slug'] ?? '' ) !== $wc_status ) {
					continue;
				}

				$whatsapp_body = $status['whatsapp_body'] ?? '';

				if ( ! empty( $whatsapp_body ) ) {
					return $this->replace_placeholders( $whatsapp_body, $order, $status['label'] ?? '' );
				}

				// Custom status matched but no WhatsApp template —
				// fall through to the default status change message
				// using the custom status label.
				break;
			}
		}

		// Default message for both core WC statuses and custom statuses without a WhatsApp template.
		$status_label = wc_get_order_status_name( $new_status );

		$default_template = $this->options['fmp_whatsapp_status_change_message'] ?? '';

		if ( empty( trim( $default_template ) ) ) {
			$default_template = 'Hi {customer_name}, your order #{order_number} status has been updated to: {status_label}.'
				. "\n\nTrack your order: {order_url}"
				. "\n\n{site_name}";
		}

		return $this->replace_placeholders( $default_template, $order, $status_label );
	}

	/**
	 * Replace placeholders in a message template.
	 *
	 * @param string    $template     Message template.
	 * @param \WC_Order $order        Order object.
	 * @param string    $status_label Optional status label.
	 *
	 * @return string
	 */
	private function replace_placeholders( $template, $order, $status_label = '' ) {
		$items = [];

		foreach ( $order->get_items() as $item ) {
			$items[] = $item->get_name() . ' x' . $item->get_quantity();
		}

		$schedule          = FnsPro::get_order_schedule( $order );
		$schedule_readable = trim( $schedule['date'] . ' ' . $schedule['time'] );

		$replacements = [
			'{order_type}'     => $schedule['label'],
			'{order_schedule}' => $schedule_readable,
			'{table_number}'   => $schedule['table'],
			'{customer_name}'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'{order_number}'   => $order->get_order_number(),
			'{order_date}'     => wc_format_datetime( $order->get_date_created() ),
			'{status_label}'   => $status_label ?: wc_get_order_status_name( $order->get_status() ),
			'{site_name}'      => get_bloginfo( 'name' ),
			'{order_url}'      => $order->get_view_order_url(),
			'{tracking_url}'   => $this->get_tracking_url( $order ),
			'{order_total}'    => $order->get_formatted_order_total(),
			'{order_items}'    => implode( ', ', $items ),
			'{payment_method}' => $order->get_payment_method_title(),
		];

		return str_replace( array_keys( $replacements ), array_values( $replacements ), $template );
	}

	/**
	 * Send a message via Twilio (WhatsApp or SMS).
	 *
	 * @param string $to      Recipient phone number.
	 * @param string $message Message body.
	 * @param string $type    Channel type: 'whatsapp' or 'sms'.
	 *
	 * @return bool True on success, false on failure.
	 */
	private function send_message( $to, $message, $type = 'whatsapp' ) {
		$sid        = $this->options['fmp_whatsapp_sid'] ?? '';
		$api_token  = $this->options['fmp_whatsapp_api_token'] ?? '';

		// Use dedicated SMS sender number if set, otherwise fall back to WhatsApp number.
		if ( 'sms' === $type ) {
			$sender_number = $this->options['fmp_sms_sender_number'] ?? '';

			if ( empty( $sender_number ) ) {
				$sender_number = $this->options['fmp_whatsapp_sender_number'] ?? '';
			}
		} else {
			$sender_number = $this->options['fmp_whatsapp_sender_number'] ?? '';
		}

		if ( empty( $sid ) || empty( $api_token ) || empty( $sender_number ) ) {
			$this->log( "Twilio {$type} credentials are not configured." );
			return false;
		}

		$api_url = "https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json";

		// Normalize phone number — ensure it has + prefix.
		$to = preg_replace( '/[^0-9+]/', '', $to );

		if ( strpos( $to, '+' ) !== 0 ) {
			$to = '+' . $to;
		}

		// Format From/To based on channel.
		if ( 'whatsapp' === $type ) {
			$from = 'whatsapp:' . $sender_number;
			$to   = 'whatsapp:' . $to;
		} else {
			$from = $sender_number;
		}

		$response = wp_remote_post( $api_url, [
			'timeout' => 30,
			'headers' => [
				'Authorization' => 'Basic ' . base64_encode( $sid . ':' . $api_token ),
			],
			'body'    => [
				'From' => $from,
				'To'   => $to,
				'Body' => $message,
			],
		] );

		if ( is_wp_error( $response ) ) {
			$this->log( "Twilio {$type} request failed: " . $response->get_error_message() );
			return false;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( $code < 200 || $code >= 300 ) {
			$this->log( "Twilio {$type} error (HTTP {$code}): {$body}" );
			return false;
		}

		return true;
	}

	/**
	 * Log a message using WooCommerce logger.
	 *
	 * @param string $message Log message.
	 *
	 * @return void
	 */
	private function log( $message ) {
		if ( ! function_exists( 'wc_get_logger' ) ) {
			return;
		}

		$logger = wc_get_logger();
		$logger->error( $message, [ 'source' => 'fmp-whatsapp-notification' ] );
	}

	/**
	 * Get the public tracking URL for an order.
	 *
	 * @param \WC_Order $order Order object.
	 *
	 * @return string
	 */
	private function get_tracking_url( $order ) {
		$token = $order->get_meta( '_fmp_tracking_token' );

		if ( empty( $token ) ) {
			return $order->get_view_order_url();
		}

		return home_url( '/fmp-track/' . $token );
	}
}
