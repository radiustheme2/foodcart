<?php
/**
 * Admin Tax Metabox Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin\Metabox;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenu\Helpers\Options;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\PickupDelivery\PickupDeliveryFns;
use RT\FoodMenu\Controllers\Reservation\ReservationFns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'This script cannot be accessed directly.' );
}
//phpcs:disable PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage

/**
 * Admin Tax Metabox Class.
 */
class TaxMeta {

    use \RT\FoodMenuPro\Traits\SingletonTrait;

    /**
     * Settings option
     *
     * @var array
     */
    private $settings;

    /**
     * Class Init.
     *
     * @return void
     */
    protected function init() {
        $this->settings = get_option( TLPFoodMenu()->options['settings'] );
        // Add field to category.
        add_action( 'food-menu-cat_add_form_fields', [ $this, 'add_category_fields' ] );
        add_action( 'food-menu-cat_edit_form_fields', [ $this, 'edit_category_fields' ], 10 );

        // Save taxonomy fields.
        add_action( 'created_term', [ $this, 'save_taxonomy_fields' ], 10, 3 );
        add_action( 'edit_term', [ $this, 'save_taxonomy_fields' ], 10, 3 );
        add_action( 'edited_terms', [ $this, 'save_taxonomy_fields' ], 10, 3 );
        add_action( 'delete_term', [ $this, 'delete_taxonomy_fields' ], 5 );

        add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ] );

        add_action( 'quick_edit_custom_box', [ $this, 'taxonomy_quick_edit_order' ], 10, 2 );
        add_action( 'admin_print_footer_scripts-edit-tags.php', [ $this, 'taxonomy_quick_edit_order_javascript' ] );

        // Food location meta data.
        add_action( 'tpl-food-location_add_form_fields', [ $this, 'add_meta_field_location' ] );
        add_action( 'tpl-food-location_edit_form_fields', [ $this, 'edit_meta_field_location' ] );
        add_action( 'edited_tpl-food-location', [ $this, 'location_save_meta_field' ] );
        add_action( 'create_tpl-food-location', [ $this, 'location_save_meta_field' ] );
    }

    /**
     * Save location meta data.
     *
     * @param number $term_id .
     *
     * @return void
     */
    public function location_save_meta_field( $term_id ) {
        $location_input = [
                'address'                              => [],
            // Coordinates. Absent from this list until now, so the latitude
            // and longitude fields on this screen were rendered, drawn on the
            // map and then silently dropped on save.
                'location_latitude'                    => [],
                'location_longitude'                   => [],
            // Schedule fields.
                'fmp_location_has_custom_schedule'     => [],
                'fmp_loc_delivery_time_interval'       => [],
                'fmp_loc_pickup_time_interval'         => [],
                'fmp_loc_dinein_time_interval'         => [],
            // Per-day multi-slot schedules (with max_order per slot).
                'fmp_loc_new_pickup_weekly_schedule'   => [ 'flags' => FILTER_REQUIRE_ARRAY ],
                'fmp_loc_new_delivery_weekly_schedule' => [ 'flags' => FILTER_REQUIRE_ARRAY ],
                'fmp_loc_new_dinein_weekly_schedule'   => [ 'flags' => FILTER_REQUIRE_ARRAY ],
            // Slot limit fields.
                'fmp_loc_pickup_max_orders_per_slot'   => [],
                'fmp_loc_delivery_max_orders_per_slot' => [],
                'fmp_loc_dinein_max_orders_per_slot'   => [],
            // Reservation fields.
                'fmp_location_has_custom_reservation'  => [],
                'fmp_loc_resi_seat_capacity'           => [],
                'fmp_loc_resi_min_guest'               => [],
                'fmp_loc_resi_max_guest'               => [],
                'fmp_loc_resi_time_interval'           => [],
                'fmp_loc_new_resi_weekly_schedule'     => [ 'flags' => FILTER_REQUIRE_ARRAY ],
        ];
        $location_input = filter_input_array( INPUT_POST, $location_input );

        if ( is_array( $location_input ) && count( $location_input ) > 0 ) {
            // Normalize schedule slot times to 24h before saving (for all per-day schedules).
            $schedule_keys = [
                    'fmp_loc_new_resi_weekly_schedule',
                    'fmp_loc_new_pickup_weekly_schedule',
                    'fmp_loc_new_delivery_weekly_schedule',
                    'fmp_loc_new_dinein_weekly_schedule',
            ];
            foreach ( $schedule_keys as $sched_key ) {
                if ( empty( $location_input[ $sched_key ] ) || ! is_array( $location_input[ $sched_key ] ) ) {
                    continue;
                }
                foreach ( $location_input[ $sched_key ] as $day => &$day_data ) {
                    if ( ! empty( $day_data['slots'] ) && is_array( $day_data['slots'] ) ) {
                        foreach ( $day_data['slots'] as &$slot ) {
                            if ( ! empty( $slot['start'] ) ) {
                                $slot['start'] = self::normalize_time_to_24h( $slot['start'] );
                            }
                            if ( ! empty( $slot['end'] ) ) {
                                $slot['end'] = self::normalize_time_to_24h( $slot['end'] );
                            }
                        }
                        unset( $slot );
                    }
                }
                unset( $day_data );
            }

            foreach ( $location_input as $key => $value ) {
                if ( null === $value ) {
                    delete_term_meta( $term_id, $key );
                } else {
                    update_term_meta( $term_id, $key, $value );
                }
            }
        }
    }


    /**
     * Add food location taxonomy meta field.
     *
     * @return void
     */
    public function add_meta_field_location() {
        ?>

        <div class="form-field term-group">
            <label for="address"><?php esc_html_e( 'Address', 'food-menu-pro' ); ?></label>
            <textarea type="number" name="address" id="address" rows="3" cols="3"></textarea>
            <p class="description"><?php // esc_html_e( 'Note: The latitude and longitude fields will be automatically populated from this address. After updating the address, click the "Address Position" button to trigger the auto-population of the latitude and longitude fields. if google map enable on the general setting.', 'food-menu-pro' ); ?></p>
        </div>

        <?php
        $settings          = $this->settings;
        $api_key           = ! empty( $settings['google_api_key'] ) ? $settings['google_api_key'] : '';
        $enable_google_map = $settings['enable_google_map'] ?? '';
        ?>

        <div class="form-field term-group">
            <label for="location_latitude"><?php esc_html_e( 'Latitude', 'food-menu-pro' ); ?></label>
            <input type="text" id="location_latitude" name="location_latitude" value="">
        </div>

        <div class="form-field term-group">
            <label for="location_longitude"><?php esc_html_e( 'Longitude', 'food-menu-pro' ); ?></label>
            <input type="text" id="location_longitude" name="location_longitude" value="">
            <p class="description">
                <?php esc_html_e( 'Used to show this location on a map, and by the mobile app to tell a customer how far away it is. Leave blank if you do not know it.', 'food-menu-pro' ); ?>
            </p>
        </div>

        <?php if ( ! empty( $enable_google_map ) ) : ?>

            <div class="form-field term-group">
                <?php

                if ( empty( $api_key ) ) {
                    $settings_api_key_url = '<a href="' . esc_url( admin_url() . 'edit.php?post_type=food-menu&page=food_menu_settings' ) . '" target="_blank" >' . esc_html__( 'Settings', 'food-menu-pro' ) . '</a>';
                    ?>
                    <p class="location-api-msg">
                        <?php
                        printf(
                                '%s %s',
                                esc_html__( 'The Google API Key is missing. Please populate the API Key field in the ', 'food-menu-pro' ),
                                esc_html( $settings_api_key_url )
                        );
                        ?>
                    </p>
                    <?php
                } else {
                    ?>
                    <a href="#" id="fmp-location-map-position"
                       class="button button-primary"><?php esc_html_e( 'Address Map Position', 'food-menu-pro' ); ?></a>
                    <p><?php esc_html_e( 'Display the location on the map based on the value in the address field.', 'food-menu-pro' ); ?></p>
                    <div class="fmp-location-map" data-lat="" data-long="" data-zoom="14">
                        <div id="fmp-location-map-container" style="height: 300px"></div>
                    </div>
                <?php } ?>
            </div>
        <?php endif; ?>

        <?php
        // Per-location schedule & reservation fields (only when multi-location is enabled).
        if ( ! empty( $settings['fmp_food_location_popup'] ) ) {
            $pickup_on   = ( $settings['enable_pickup'] ?? 'on' ) === 'on';
            $delivery_on = ( $settings['enable_delivery'] ?? 'on' ) === 'on';

            if ( $pickup_on || $delivery_on ) {
                $this->render_location_schedule_fields_add();
                $this->render_location_reservation_fields_add();
            }
        }
    }

    /**
     * Edit food location taxonomy meta field.
     *
     * @param object $term .
     *
     * @return void
     */
    public function edit_meta_field_location( $term ) {
        ?>
        <tr class="form-field term-group-wrap">
            <th scope="row" style="min-width: 200px;">
                <label for="address"><?php esc_html_e( 'Address', 'food-menu-pro' ); ?></label>
            </th>
            <td>
				<textarea id="address" name="address" rows="3" cols="3"><?php echo esc_textarea( get_term_meta( $term->term_id, 'address', true ) ); ?></textarea>
            </td>
        </tr>

        <?php
        $settings          = $this->settings;
        $api_key           = ! empty( $settings['google_api_key'] ) ? $settings['google_api_key'] : '';
        $enable_google_map = $settings['enable_google_map'] ?? '';
        ?>

        <?php
        $location_latitude  = get_term_meta( $term->term_id, 'location_latitude', true );
        $location_longitude = get_term_meta( $term->term_id, 'location_longitude', true );
        ?>

        <tr class="form-field term-group-wrap">
            <th scope="row">
                <label for="location_latitude"><?php esc_html_e( 'Latitude', 'food-menu-pro' ); ?></label>
            </th>
            <td>
                <input type="text" id="location_latitude" name="location_latitude"
                       value="<?php echo esc_attr( $location_latitude ); ?>">
            </td>
        </tr>

        <tr class="form-field term-group-wrap">
            <th scope="row">
                <label for="location_longitude"><?php esc_html_e( 'Longitude', 'food-menu-pro' ); ?></label>
            </th>
            <td>
                <input type="text" id="location_longitude" name="location_longitude"
                       value="<?php echo esc_attr( $location_longitude ); ?>">
                <p class="description">
                    <?php esc_html_e( 'Used to show this location on a map, and by the mobile app to tell a customer how far away it is. Leave blank if you do not know it.', 'food-menu-pro' ); ?>
                </p>
            </td>
        </tr>

        <?php if ( ! empty( $enable_google_map ) ) : ?>

            <tr class="form-field term-group-wrap">
                <th scope="row">
                    <label for="location_map"><?php esc_html_e( 'Location Map', 'food-menu-pro' ); ?></label>
                </th>
                <td>
                    <?php
                    if ( empty( $api_key ) ) {
                        $settings_page_url = '<a href="' . esc_url( admin_url() . 'admin.php?page=cafe_settings' ) . '" target="_blank" >' . esc_html__( 'Settings', 'food-menu-pro' ) . '</a>';
                        ?>
                        <p class="location-api-msg">
                            <?php
                            printf(
                                    '%s %s',
                                    esc_html__( 'The Google API Key is missing. Please populate the API Key field in the ', 'food-menu-pro' ),
                                    esc_html( $settings_page_url )
                            );
                            ?>
                        </p>
                        <?php
                    } else {
                        ?>
                        <a href="#" id="fmp-location-map-position"
                           class="button button-primary"><?php esc_html_e( 'Address Position', 'food-menu-pro' ); ?></a>
                        <p><?php esc_html_e( 'Display the location on the map based on the value in the address field.', 'food-menu-pro' ); ?></p>
                        <div class="fmp-location-map" data-lat="<?php echo esc_attr( $location_latitude ); ?>"
                             data-long="<?php echo esc_attr( $location_longitude ); ?>" data-zoom="12">
                            <div id="fmp-location-map-container" style="height: 300px"></div>
                        </div>
                        <?php
                    }
                    ?>
                </td>
            </tr>

        <?php endif; ?>

        <?php
        // Per-location schedule & reservation fields (only when multi-location is enabled).
        if ( ! empty( $this->settings['fmp_food_location_popup'] ) ) {
            $pickup_on   = ( $this->settings['enable_pickup'] ?? 'on' ) === 'on';
            $delivery_on = ( $this->settings['enable_delivery'] ?? 'on' ) === 'on';

            if ( $pickup_on || $delivery_on ) {
                $this->render_location_schedule_fields_edit( $term );
                $this->render_location_reservation_fields_edit( $term );
            }
        }
    }

    /**
     * Render schedule fields for add form.
     *
     * @return void
     */
    private function render_location_schedule_fields_add() {
        ?>
        <div class="form-field term-group">
            <label for="fmp_location_has_custom_schedule">
                <input type="checkbox" name="fmp_location_has_custom_schedule" id="fmp_location_has_custom_schedule" value="on"/>
                <?php esc_html_e( 'Enable Custom Schedule', 'food-menu-pro' ); ?>
            </label>
            <p class="description"><?php esc_html_e( 'Override global delivery/pickup schedule for this location.', 'food-menu-pro' ); ?></p>
        </div>

        <div class="fmp-location-schedule-wrap" style="display:none;">
            <div class="fmp-loc-pd-tabs" role="tablist">
                <button type="button" class="fmp-loc-pd-tab is-active" data-target="pickup" role="tab">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 2h12l1 5H5z"/>
                        <path d="M5 7v13a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V7"/>
                        <path d="M9 11h6"/>
                    </svg>
                    <span><?php esc_html_e( 'Pickup', 'food-menu-pro' ); ?></span>
                </button>
                <button type="button" class="fmp-loc-pd-tab" data-target="delivery" role="tab">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M1 3h15v13H1z"/>
                        <path d="M16 8h4l3 3v5h-7"/>
                        <circle cx="6" cy="19" r="2"/>
                        <circle cx="18" cy="19" r="2"/>
                    </svg>
                    <span><?php esc_html_e( 'Delivery', 'food-menu-pro' ); ?></span>
                </button>
                <?php if ( 'on' === ( $this->settings['enable_dinein'] ?? '' ) ) : ?>
                    <button type="button" class="fmp-loc-pd-tab" data-target="dinein" role="tab">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 2v7a3 3 0 0 0 3 3v10"/>
                            <path d="M6 2v7"/>
                            <path d="M9 2v7"/>
                            <path d="M18 2c-1.7 0-3 3-3 7s1.3 5 3 5v8"/>
                        </svg>
                        <span><?php esc_html_e( 'Dine In', 'food-menu-pro' ); ?></span>
                    </button>
                <?php endif; ?>
            </div>
            <div class="fmp-loc-pd-panel" data-panel="pickup">
                <?php
                $slot_limits_on = ! empty( $this->settings['fmp_enable_order_slot_limits'] );
                FnsPro::renderView( 'location-pd-weekly-schedule', [
                        'prefix'              => 'pickup',
                        'term_id'             => 0,
                        'slot_limits_enabled' => $slot_limits_on,
                ] );
                ?>
                <div class="fmp-loc-pd-fields">
                    <div class="fmp-loc-interval-row">
                        <label for="fmp_loc_pickup_time_interval"><?php esc_html_e( 'Pickup Time Interval (minutes)', 'food-menu-pro' ); ?></label>
                        <select name="fmp_loc_pickup_time_interval" id="fmp_loc_pickup_time_interval">
                            <?php foreach ( PickupDeliveryFns::generateIntervalArray() as $min => $label ) : ?>
                                <option value="<?php echo esc_attr( $min ); ?>"><?php echo esc_html( $label ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php if ( $slot_limits_on ) : ?>
                        <div class="fmp-loc-interval-row">
                            <label for="fmp_loc_pickup_max_orders_per_slot"><?php esc_html_e( 'Max Pickup Orders Per Slot', 'food-menu-pro' ); ?></label>
                            <input type="number" name="fmp_loc_pickup_max_orders_per_slot" id="fmp_loc_pickup_max_orders_per_slot" value="0" min="0" step="1"/>
                            <p class="description"><?php esc_html_e( '0 = use global setting.', 'food-menu-pro' ); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="fmp-loc-pd-panel" data-panel="delivery" style="display:none;">
                <?php
                FnsPro::renderView( 'location-pd-weekly-schedule', [
                        'prefix'              => 'delivery',
                        'term_id'             => 0,
                        'slot_limits_enabled' => $slot_limits_on,
                ] );
                ?>
                <div class="fmp-loc-pd-fields">
                    <div class="fmp-loc-interval-row">
                        <label for="fmp_loc_delivery_time_interval"><?php esc_html_e( 'Delivery Time Interval (minutes)', 'food-menu-pro' ); ?></label>
                        <select name="fmp_loc_delivery_time_interval" id="fmp_loc_delivery_time_interval">
                            <?php foreach ( PickupDeliveryFns::generateIntervalArray() as $min => $label ) : ?>
                                <option value="<?php echo esc_attr( $min ); ?>"><?php echo esc_html( $label ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php if ( $slot_limits_on ) : ?>
                        <div class="fmp-loc-interval-row">
                            <label for="fmp_loc_delivery_max_orders_per_slot"><?php esc_html_e( 'Max Delivery Orders Per Slot', 'food-menu-pro' ); ?></label>
                            <input type="number" name="fmp_loc_delivery_max_orders_per_slot" id="fmp_loc_delivery_max_orders_per_slot" value="0" min="0" step="1"/>
                            <p class="description"><?php esc_html_e( '0 = use global setting.', 'food-menu-pro' ); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if ( 'on' === ( $this->settings['enable_dinein'] ?? '' ) ) : ?>
                <div class="fmp-loc-pd-panel" data-panel="dinein" style="display:none;">
                    <?php
                    FnsPro::renderView( 'location-pd-weekly-schedule', [
                            'prefix'              => 'dinein',
                            'term_id'             => 0,
                            'slot_limits_enabled' => $slot_limits_on,
                    ] );
                    ?>
                    <div class="fmp-loc-pd-fields">
                        <div class="fmp-loc-interval-row">
                            <label for="fmp_loc_dinein_time_interval"><?php esc_html_e( 'Dine In Time Interval (minutes)', 'food-menu-pro' ); ?></label>
                            <select name="fmp_loc_dinein_time_interval" id="fmp_loc_dinein_time_interval">
                                <?php foreach ( PickupDeliveryFns::generateIntervalArray() as $min => $label ) : ?>
                                    <option value="<?php echo esc_attr( $min ); ?>"><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php if ( $slot_limits_on ) : ?>
                            <div class="fmp-loc-interval-row">
                                <label for="fmp_loc_dinein_max_orders_per_slot"><?php esc_html_e( 'Max Dine In Orders Per Slot', 'food-menu-pro' ); ?></label>
                                <input type="number" name="fmp_loc_dinein_max_orders_per_slot" id="fmp_loc_dinein_max_orders_per_slot" value="0" min="0" step="1"/>
                                <p class="description"><?php esc_html_e( '0 = use global setting.', 'food-menu-pro' ); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <style>
            .fmp-location-schedule-wrap .fmp-loc-pd-tabs {
                display: inline-flex;
                gap: 4px;
                padding: 4px;
                margin: 0 0 16px;
                background: #f0f0f1;
                border-radius: 10px;
                box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.04);
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                padding: 8px 16px;
                background: transparent;
                border: 0;
                border-radius: 7px;
                cursor: pointer;
                font-weight: 500;
                color: #50575e;
                transition: color .15s ease, background-color .15s ease, box-shadow .15s ease, transform .15s ease;
                line-height: 1;
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab:hover {
                color: #1d2327;
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab:focus {
                outline: 2px solid transparent;
                box-shadow: 0 0 0 2px #2271b1;
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab.is-active {
                background: #fff;
                color: #2271b1;
                box-shadow: 0 1px 2px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.04);
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab svg {
                flex: 0 0 16px;
            }

            .fmp-loc-pd-panel {
                margin-top: 4px;
            }

            .fmp-loc-pd-fields {
                /*display: grid;*/
                /*grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));*/
                gap: 12px 20px;
                margin-top: 16px;
                padding: 14px 16px;
                background: #fafafa;
                border: 1px solid #e2e4e7;
                border-radius: 8px;
            }

            .fmp-loc-pd-fields .fmp-loc-interval-row {
                margin: 0;
            }

            .fmp-loc-pd-fields label {
                display: block;
                font-weight: 600;
                margin-bottom: 6px;
            }

            .fmp-loc-pd-fields select,
            .fmp-loc-pd-fields input[type="number"] {
                width: 100%;
                max-width: 260px;
            }
        </style>
        <script>
            jQuery(function ($) {
                $('#fmp_location_has_custom_schedule').on('change', function () {
                    $('.fmp-location-schedule-wrap').toggle(this.checked);
                });
                $(document).on('click', '.fmp-loc-pd-tab', function () {
                    var $tabsWrap = $(this).closest('.fmp-location-schedule-wrap');
                    var target = $(this).data('target');
                    $tabsWrap.find('.fmp-loc-pd-tab').removeClass('is-active');
                    $(this).addClass('is-active');
                    $tabsWrap.find('.fmp-loc-pd-panel').hide().filter('[data-panel="' + target + '"]').show();
                });
            });
        </script>
        <?php
    }

    /**
     * Render schedule fields for edit form.
     *
     * @param object $term Term being edited.
     *
     * @return void
     */
    private function render_location_schedule_fields_edit( $term ) {
        $has_custom   = get_term_meta( $term->term_id, 'fmp_location_has_custom_schedule', true );
        $is_checked   = ( 'on' === $has_custom );
        $display      = $is_checked ? '' : 'display:none;';
        $delivery_int = get_term_meta( $term->term_id, 'fmp_loc_delivery_time_interval', true );
        $pickup_int   = get_term_meta( $term->term_id, 'fmp_loc_pickup_time_interval', true );
        ?>
        <tr class="form-field term-group-wrap">
            <th scope="row" style="min-width: 200px;"><label><?php esc_html_e( 'Pickup/Delivery Schedule', 'food-menu-pro' ); ?></label></th>
            <td>
                <label>
                    <input type="checkbox" name="fmp_location_has_custom_schedule" id="fmp_location_has_custom_schedule" value="on" <?php checked( $is_checked ); ?> />
                    <?php esc_html_e( 'Enable Pickup/Delivery Schedule', 'food-menu-pro' ); ?>
                </label>
                <p class="description"><?php esc_html_e( 'Override global delivery/pickup schedule for this location.', 'food-menu-pro' ); ?></p>
            </td>
        </tr>

        <tr class="form-field fmp-location-schedule-wrap" style="<?php echo esc_attr( $display ); ?>">
            <th scope="row" style="min-width: 200px;"><label><?php //esc_html_e( 'Location Schedules', 'food-menu-pro' ); ?></label></th>
            <td>
                <?php
                $slot_limits_on = ! empty( $this->settings['fmp_enable_order_slot_limits'] );
                $pickup_max     = absint( get_term_meta( $term->term_id, 'fmp_loc_pickup_max_orders_per_slot', true ) );
                $delivery_max   = absint( get_term_meta( $term->term_id, 'fmp_loc_delivery_max_orders_per_slot', true ) );
                $dinein_max     = absint( get_term_meta( $term->term_id, 'fmp_loc_dinein_max_orders_per_slot', true ) );
                $dinein_int     = get_term_meta( $term->term_id, 'fmp_loc_dinein_time_interval', true );
                $dinein_on      = 'on' === ( $this->settings['enable_dinein'] ?? '' );
                ?>
                <div class="fmp-loc-pd-tabs-wrapper" style="padding:20px 25px 30px;background: #FFF;border-radius:8px">
                <div class="fmp-loc-pd-tabs" role="tablist">
                    <button type="button" class="fmp-loc-pd-tab is-active" data-target="pickup" role="tab">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2h12l1 5H5z"/>
                            <path d="M5 7v13a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V7"/>
                            <path d="M9 11h6"/>
                        </svg>
                        <span><?php esc_html_e( 'Pickup', 'food-menu-pro' ); ?></span>
                    </button>
                    <button type="button" class="fmp-loc-pd-tab" data-target="delivery" role="tab">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 3h15v13H1z"/>
                            <path d="M16 8h4l3 3v5h-7"/>
                            <circle cx="6" cy="19" r="2"/>
                            <circle cx="18" cy="19" r="2"/>
                        </svg>
                        <span><?php esc_html_e( 'Delivery', 'food-menu-pro' ); ?></span>
                    </button>
                    <?php if ( $dinein_on ) : ?>
                        <button type="button" class="fmp-loc-pd-tab" data-target="dinein" role="tab">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M3 2v7a3 3 0 0 0 3 3v10"/>
                                <path d="M6 2v7"/>
                                <path d="M9 2v7"/>
                                <path d="M18 2c-1.7 0-3 3-3 7s1.3 5 3 5v8"/>
                            </svg>
                            <span><?php esc_html_e( 'Dine In', 'food-menu-pro' ); ?></span>
                        </button>
                    <?php endif; ?>
                </div>
                <div class="fmp-loc-pd-panel" data-panel="pickup">
                    <?php
                    FnsPro::renderView( 'location-pd-weekly-schedule', [
                            'prefix'              => 'pickup',
                            'term_id'             => $term->term_id,
                            'slot_limits_enabled' => $slot_limits_on,
                    ] );
                    ?>
                    <div class="fmp-loc-pd-fields">
                        <div class="fmp-loc-interval-row">
                            <label for="fmp_loc_pickup_time_interval"><?php esc_html_e( 'Pickup Time Interval (minutes)', 'food-menu-pro' ); ?></label>
                            <select name="fmp_loc_pickup_time_interval" id="fmp_loc_pickup_time_interval">
                                <?php foreach ( PickupDeliveryFns::generateIntervalArray() as $min => $label ) : ?>
                                    <option value="<?php echo esc_attr( $min ); ?>" <?php selected( $pickup_int, $min ); ?>><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php if ( $slot_limits_on ) : ?>
                            <div class="fmp-loc-interval-row">
                                <label for="fmp_loc_pickup_max_orders_per_slot"><?php esc_html_e( 'Max Pickup Orders Per Slot', 'food-menu-pro' ); ?></label>
                                <input type="number" name="fmp_loc_pickup_max_orders_per_slot" id="fmp_loc_pickup_max_orders_per_slot" value="<?php echo esc_attr( $pickup_max ); ?>" min="0" step="1"/>
                                <p class="description"><?php esc_html_e( '0 = use global setting.', 'food-menu-pro' ); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="fmp-loc-pd-panel" data-panel="delivery" style="display:none;">
                    <?php
                    FnsPro::renderView( 'location-pd-weekly-schedule', [
                            'prefix'              => 'delivery',
                            'term_id'             => $term->term_id,
                            'slot_limits_enabled' => $slot_limits_on,
                    ] );
                    ?>
                    <div class="fmp-loc-pd-fields">
                        <div class="fmp-loc-interval-row">
                            <label for="fmp_loc_delivery_time_interval"><?php esc_html_e( 'Delivery Time Interval (minutes)', 'food-menu-pro' ); ?></label>
                            <select name="fmp_loc_delivery_time_interval" id="fmp_loc_delivery_time_interval">
                                <?php foreach ( PickupDeliveryFns::generateIntervalArray() as $min => $label ) : ?>
                                    <option value="<?php echo esc_attr( $min ); ?>" <?php selected( $delivery_int, $min ); ?>><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php if ( $slot_limits_on ) : ?>
                            <div class="fmp-loc-interval-row">
                                <label for="fmp_loc_delivery_max_orders_per_slot"><?php esc_html_e( 'Max Delivery Orders Per Slot', 'food-menu-pro' ); ?></label>
                                <input type="number" name="fmp_loc_delivery_max_orders_per_slot" id="fmp_loc_delivery_max_orders_per_slot" value="<?php echo esc_attr( $delivery_max ); ?>" min="0" step="1"/>
                                <p class="description"><?php esc_html_e( '0 = use global setting.', 'food-menu-pro' ); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if ( $dinein_on ) : ?>
                    <div class="fmp-loc-pd-panel" data-panel="dinein" style="display:none;">
                        <?php
                        FnsPro::renderView( 'location-pd-weekly-schedule', [
                                'prefix'              => 'dinein',
                                'term_id'             => $term->term_id,
                                'slot_limits_enabled' => $slot_limits_on,
                        ] );
                        ?>
                        <div class="fmp-loc-pd-fields">
                            <div class="fmp-loc-interval-row">
                                <label for="fmp_loc_dinein_time_interval"><?php esc_html_e( 'Dine In Time Interval (minutes)', 'food-menu-pro' ); ?></label>
                                <select name="fmp_loc_dinein_time_interval" id="fmp_loc_dinein_time_interval">
                                    <?php foreach ( PickupDeliveryFns::generateIntervalArray() as $min => $label ) : ?>
                                        <option value="<?php echo esc_attr( $min ); ?>" <?php selected( $dinein_int, $min ); ?>><?php echo esc_html( $label ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php if ( $slot_limits_on ) : ?>
                                <div class="fmp-loc-interval-row">
                                    <label for="fmp_loc_dinein_max_orders_per_slot"><?php esc_html_e( 'Max Dine In Orders Per Slot', 'food-menu-pro' ); ?></label>
                                    <input type="number" name="fmp_loc_dinein_max_orders_per_slot" id="fmp_loc_dinein_max_orders_per_slot" value="<?php echo esc_attr( $dinein_max ); ?>" min="0" step="1"/>
                                    <p class="description"><?php esc_html_e( '0 = use global setting.', 'food-menu-pro' ); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                </div>
            </td>
        </tr>

        <style>
            .fmp-location-schedule-wrap .fmp-loc-pd-tabs {
                display: inline-flex;
                gap: 4px;
                padding: 4px;
                margin: 0 0 16px;
                background: #f0f0f1;
                border-radius: 10px;
                box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.04);
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                padding: 8px 16px;
                background: transparent;
                border: 0;
                border-radius: 7px;
                cursor: pointer;
                font-weight: 500;
                color: #50575e;
                transition: color .15s ease, background-color .15s ease, box-shadow .15s ease, transform .15s ease;
                line-height: 1;
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab:hover {
                color: #1d2327;
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab:focus {
                outline: 2px solid transparent;
                box-shadow: 0 0 0 2px #2271b1;
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab.is-active {
                background: #fff;
                color: #2271b1;
                box-shadow: 0 1px 2px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.04);
            }

            .fmp-location-schedule-wrap .fmp-loc-pd-tab svg {
                flex: 0 0 16px;
            }

            .fmp-loc-pd-panel {
                margin-top: 4px;
            }

            .fmp-loc-pd-fields {
                /*display: grid;*/
                /*grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));*/
                display: flex;
                flex-direction: column;
                gap: 12px 20px;
                margin-top: 16px;
                padding: 14px 16px;
                background: #fafafa;
                border: 1px solid #e2e4e7;
                border-radius: 8px;
            }

            .fmp-loc-pd-fields .fmp-loc-interval-row {
                margin: 0;
            }

            .fmp-loc-pd-fields label {
                display: block;
                font-weight: 600;
                margin-bottom: 6px;
            }

            .fmp-loc-pd-fields select,
            .fmp-loc-pd-fields input[type="number"] {
                width: 100%;
                max-width: 260px;
            }
        </style>
        <script>
            jQuery(function ($) {
                $('#fmp_location_has_custom_schedule').on('change', function () {
                    $('.fmp-location-schedule-wrap').toggle(this.checked);
                });
                $(document).on('click', '.fmp-loc-pd-tab', function () {
                    var $tabsWrap = $(this).closest('.fmp-location-schedule-wrap');
                    var target = $(this).data('target');
                    $tabsWrap.find('.fmp-loc-pd-tab').removeClass('is-active');
                    $(this).addClass('is-active');
                    $tabsWrap.find('.fmp-loc-pd-panel').hide().filter('[data-panel="' + target + '"]').show();
                });
            });
        </script>
        <?php
    }

    /**
     * Render reservation fields for add form.
     *
     * @return void
     */
    private function render_location_reservation_fields_add() {
        ?>
        <div class="form-field term-group">
            <label for="fmp_location_has_custom_reservation">
                <input type="checkbox" name="fmp_location_has_custom_reservation" id="fmp_location_has_custom_reservation" value="on"/>
                <?php esc_html_e( 'Enable Custom Reservation', 'food-menu-pro' ); ?>
            </label>
            <p class="description"><?php esc_html_e( 'Override global reservation capacity and schedule for this location.', 'food-menu-pro' ); ?></p>
        </div>

        <div class="fmp-location-reservation-wrap" style="display:none;">
            <div class="fmp-loc-resi-settings">
                <div class="fmp-loc-resi-fields">
                    <div class="fmp-loc-resi-field">
                        <label for="fmp_loc_resi_seat_capacity"><?php esc_html_e( 'Seat Capacity', 'food-menu-pro' ); ?></label>
                        <input type="number" name="fmp_loc_resi_seat_capacity" id="fmp_loc_resi_seat_capacity" value="30" min="1"/>
                    </div>
                    <div class="fmp-loc-resi-field">
                        <label for="fmp_loc_resi_min_guest"><?php esc_html_e( 'Min Guest', 'food-menu-pro' ); ?></label>
                        <input type="number" name="fmp_loc_resi_min_guest" id="fmp_loc_resi_min_guest" value="1" min="1"/>
                    </div>
                    <div class="fmp-loc-resi-field">
                        <label for="fmp_loc_resi_max_guest"><?php esc_html_e( 'Max Guest', 'food-menu-pro' ); ?></label>
                        <input type="number" name="fmp_loc_resi_max_guest" id="fmp_loc_resi_max_guest" value="10" min="1"/>
                    </div>
                </div>
                <div class="fmp-loc-interval-row">
                    <label for="fmp_loc_resi_time_interval"><?php esc_html_e( 'Reservation Time Interval (minutes)', 'food-menu-pro' ); ?></label>
                    <select name="fmp_loc_resi_time_interval" id="fmp_loc_resi_time_interval">
                        <?php foreach ( ReservationFns::generateIntervalArray() as $min => $label ) : ?>
                            <option value="<?php echo esc_attr( $min ); ?>" <?php selected( 30, $min ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php
            FnsPro::renderView( 'location-resi-weekly-schedule', [
                    'term_id' => 0,
            ] );
            ?>
        </div>

        <script>
            jQuery(function ($) {
                $('#fmp_location_has_custom_reservation').on('change', function () {
                    $('.fmp-location-reservation-wrap').toggle(this.checked);
                });
            });
        </script>
        <?php
    }

    /**
     * Render reservation fields for edit form.
     *
     * @param object $term Term being edited.
     *
     * @return void
     */
    private function render_location_reservation_fields_edit( $term ) {
        $has_custom    = get_term_meta( $term->term_id, 'fmp_location_has_custom_reservation', true );
        $is_checked    = ( 'on' === $has_custom );
        $display       = $is_checked ? '' : 'display:none;';
        $seat_capacity = get_term_meta( $term->term_id, 'fmp_loc_resi_seat_capacity', true ) ?: 30;
        $min_guest     = get_term_meta( $term->term_id, 'fmp_loc_resi_min_guest', true ) ?: 1;
        $max_guest     = get_term_meta( $term->term_id, 'fmp_loc_resi_max_guest', true ) ?: 10;
        $time_interval = get_term_meta( $term->term_id, 'fmp_loc_resi_time_interval', true ) ?: 30;
        ?>
        <tr class="form-field term-group-wrap">
            <th scope="row"><label><?php esc_html_e( 'Reservation Schedule', 'food-menu-pro' ); ?></label></th>
            <td>
                <label>
                    <input type="checkbox" name="fmp_location_has_custom_reservation" id="fmp_location_has_custom_reservation" value="on" <?php checked( $is_checked ); ?> />
                    <?php esc_html_e( 'Enable Reservation Schedule', 'food-menu-pro' ); ?>
                </label>
                <p class="description"><?php esc_html_e( 'Override global reservation capacity and schedule for this location.', 'food-menu-pro' ); ?></p>
            </td>
        </tr>

        <tr class="form-field fmp-location-reservation-wrap" style="<?php echo esc_attr( $display ); ?>">
            <th scope="row"><label><?php //esc_html_e( 'Reservation Settings', 'food-menu-pro' ); ?></label></th>
            <td>
                <div class="fmp-loc-resi-settings-wrapper" style="padding:20px 25px 12px;background: #FFF;border-radius:8px">
                    <div class="fmp-loc-resi-settings">
                        <div class="fmp-loc-resi-fields">
                            <div class="fmp-loc-resi-field">
                                <label for="fmp_loc_resi_seat_capacity"><?php esc_html_e( 'Seat Capacity', 'food-menu-pro' ); ?></label>
                                <input type="number" name="fmp_loc_resi_seat_capacity" id="fmp_loc_resi_seat_capacity" value="<?php echo esc_attr( $seat_capacity ); ?>" min="1"/>
                            </div>
                            <div class="fmp-loc-resi-field">
                                <label for="fmp_loc_resi_min_guest"><?php esc_html_e( 'Min Guest', 'food-menu-pro' ); ?></label>
                                <input type="number" name="fmp_loc_resi_min_guest" id="fmp_loc_resi_min_guest" value="<?php echo esc_attr( $min_guest ); ?>" min="1"/>
                            </div>
                            <div class="fmp-loc-resi-field">
                                <label for="fmp_loc_resi_max_guest"><?php esc_html_e( 'Max Guest', 'food-menu-pro' ); ?></label>
                                <input type="number" name="fmp_loc_resi_max_guest" id="fmp_loc_resi_max_guest" value="<?php echo esc_attr( $max_guest ); ?>" min="1"/>
                            </div>
                        </div>
                        <div class="fmp-loc-interval-row">
                            <label for="fmp_loc_resi_time_interval"><?php esc_html_e( 'Reservation Time Interval (minutes)', 'food-menu-pro' ); ?></label>
                            <select name="fmp_loc_resi_time_interval" id="fmp_loc_resi_time_interval">
                                <?php foreach ( ReservationFns::generateIntervalArray() as $min => $label ) : ?>
                                    <option value="<?php echo esc_attr( $min ); ?>" <?php selected( $time_interval, $min ); ?>><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <?php
                    FnsPro::renderView( 'location-resi-weekly-schedule', [
                            'term_id' => $term->term_id,
                    ] );
                    ?></div>
            </td>
        </tr>

        <script>
            jQuery(function ($) {
                $('#fmp_location_has_custom_reservation').on('change', function () {
                    $('.fmp-location-reservation-wrap').toggle(this.checked);
                });
            });
        </script>
        <?php
    }

    public function taxonomy_quick_edit_order_javascript() {
        $current_screen = get_current_screen();

        if ( $current_screen->id != 'edit-' . TLPFoodMenu()->taxonomies['category'] || $current_screen->taxonomy != TLPFoodMenu()->taxonomies['category'] ) {
            return;
        }

        wp_enqueue_script( 'jquery' );
        ?>
        <script type="text/javascript">
            jQuery(function ($) {
                $('#the-list').on('click', 'button.editinline', function (e) {
                    // e.preventDefault();
                    var $tr = $(this).closest('tr'),
                        order = $tr.find('td._fmp_order').text();
                    var nonce = $('input#fmp_nonce').val();
                    // Update field
                    $('tr.inline-edit-row :input[name="_order"]').val(order ? parseInt(order, 10) : 0);
                    $('tr.inline-edit-row :input[name="fmp_nonce"]').val(nonce);
                });
            });
        </script>
        <style>
            .fmp-quick-field-wrap:before,
            .fmp-quick-field-wrap:after {
                clear: both;
                display: block;
                content: "";
                float: none;
            }
        </style>
        <?php
    }

    public function taxonomy_quick_edit_order( $column_name, $screen ) {
        if ( $screen != 'edit-tags' || $column_name != '_fmp_order' || ! isset( $_GET['taxonomy'] ) || $_GET['taxonomy'] !== TLPFoodMenu()->taxonomies['category'] ) { //phpcs:ignore
            return false;
        }
        ?>
        <div class="fmp-quick-field-wrap">
            <fieldset style="width: 50%; float: left">
                <div id="rtcl-taxonomy-content" class="inline-edit-col">
                    <label>
                        <span class="title"><?php esc_html_e( 'Order', 'food-menu-pro' ); ?></span>
                        <span class="input-text-wrap"><input type="number" name="_order" value=""></span>
                        <span class="input-quick-edit-nonce"><input type="hidden" name="fmp_nonce" value=""></span>
                    </label>
                </div>
            </fieldset>
        </div>
        <?php
    }

    public function admin_enqueue_scripts() {
        global $pagenow, $typenow;

        // validate page.
        if ( ! in_array( $pagenow, [ 'edit-tags.php', 'term.php' ] ) ) {
            return;
        }

        if ( ! in_array( $typenow, [ TLPFoodMenu()->post_type, 'product' ] ) ) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_script(
                [
                        'jquery',
                        'jquery-ui-core',
                        'jquery-ui-sortable',
                        'fmp-admin-taxonomy',
                ]
        );

        wp_enqueue_style(
                [
                        'fmp-admin',
                ]
        );

        // Enqueue timepicker for per-location schedule fields.
        if ( ! empty( $this->settings['fmp_food_location_popup'] ) ) {
            wp_enqueue_script( 'fmp-timepicker' );
            wp_enqueue_style( 'fmp-timepicker' );

            $fm_time_format = get_option( 'time_format' ) ?? 'H:i';
            wp_add_inline_script(
                    'fmp-timepicker',
                    'jQuery(function($){
					function fmpInitLocTimePickers(){
						$(".fmp_time_picker").not(".ui-timepicker-input").each(function(){
							var timeFormat = "' . esc_js( $fm_time_format ) . '";
							var defaultMinTime = (timeFormat === "H:i") ? "00:00" : "12:00 am";
							$(this).timepicker({
								minTime: defaultMinTime,
								timeFormat: timeFormat,
								dynamic: true,
								step: 30,
								listWidth: 1
							});
						});
					}
					fmpInitLocTimePickers();
					$(document).on("focus click", ".fmp_time_picker:not(.ui-timepicker-input)", function(){
						fmpInitLocTimePickers();
					});
				});'
            );
        }

        $nonce = wp_create_nonce( Fns::nonceText() );

        wp_localize_script(
                'fmp-admin',
                'fmp_var',
                [
                        'nonceID'        => esc_attr( Fns::nonceId() ),
                        'nonce'          => esc_attr( $nonce ),
                        'ajaxurl'        => esc_url( admin_url( 'admin-ajax.php' ) ),
                        'placeholderUrl' => TLPFoodMenu()->assets_url() . 'images/placeholder.png',
                ]
        );
        wp_localize_script(
                'fmp-admin-taxonomy',
                'fmp_var1',
                [
                        'nonceID'        => esc_attr( Fns::nonceId() ),
                        'nonce'          => esc_attr( $nonce ),
                        'ajaxurl'        => esc_url( admin_url( 'admin-ajax.php' ) ),
                        'placeholderUrl' => TLPFoodMenu()->assets_url() . 'images/placeholder.png',
                        'adminTaxonomy'  => [
                                'geocode' => esc_html__( 'Google geocoder error', 'food-menu-pro' ),
                                'address' => esc_html__( 'Address is empty', 'food-menu-pro' ),
                        ],
                        'wpTimeFormat'   => get_option( 'time_format', 'H:i' ),
                ]
        );
    }

    /**
     * save_taxonomy_fields function.
     *
     * @param mixed $term_id Term ID being saved
     * @param mixed $tt_id
     * @param string $taxonomy
     */
    public function save_taxonomy_fields( $term_id, $tt_id = '', $taxonomy = '' ) {

        if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
            return;
        }
        if ( isset( $_POST['fmp_cat_thumbnail_id'] ) && TLPFoodMenu()->taxonomies['category'] === $taxonomy ) {
            update_term_meta( $term_id, 'fmp_cat_thumbnail_id', absint( $_POST['fmp_cat_thumbnail_id'] ) );
        }

        if ( isset( $_POST['_order'] ) && TLPFoodMenu()->taxonomies['category'] === $taxonomy ) {
            update_term_meta( $term_id, '_order', absint( $_POST['_order'] ) );
        } else {
            update_term_meta( $term_id, '_order', 0 );
        }
    }

    public function delete_taxonomy_fields() {
    }

    /**
     * Category thumbnail fields.
     */
    public function add_category_fields() {
        wp_nonce_field( Fns::nonceText(), Fns::nonceId() );
        ?>
        <div class="form-field">
            <label><?php esc_html_e( 'Order', 'food-menu-pro' ); ?></label>
            <input type="number" name="_order" value="0">
        </div>
        <div class="form-field term-thumbnail-wrap">
            <label><?php esc_html_e( 'Thumbnail', 'food-menu-pro' ); ?></label>
            <div id="fmp_cat_thumbnail" style="float: left; margin-right: 10px;">
                <img src="<?php echo esc_url( Fns::placeholder_img_src() ); ?>" width="60px" height="60px"/>
            </div>
            <div style="line-height: 60px;">
                <input type="hidden" id="fmp_cat_thumbnail_id" name="fmp_cat_thumbnail_id"/>
                <button type="button" class="upload_image_button button">
                    <?php esc_html_e( 'Upload/Add image', 'food-menu-pro' ); ?>
                </button>
                <button type="button"
                        class="remove_image_button button"><?php esc_html_e( 'Remove image', 'food-menu-pro' ); ?></button>
            </div>
        </div>
        <?php
    }

    /**
     * Edit category thumbnail field.
     *
     * @param mixed $term Term (category) being edited.
     */
    public function edit_category_fields( $term ) {
        $thumbnail_id = absint( get_term_meta( $term->term_id, 'fmp_cat_thumbnail_id', true ) );
        $order        = absint( get_term_meta( $term->term_id, '_order', true ) );

        if ( $thumbnail_id ) {
            $image = wp_get_attachment_thumb_url( $thumbnail_id );
        } else {
            $image = Fns::placeholder_img_src();
        }
        wp_nonce_field( Fns::nonceText(), Fns::nonceId() );
        ?>
        <tr class="form-field">
            <th scope="row" valign="top"><label><?php esc_html_e( 'Order', 'food-menu-pro' ); ?></label></th>
            <td><input type="number" name="_order" value="<?php echo esc_attr( $order ); ?>"></td>
        </tr>
        <tr class="form-field">
            <th scope="row" valign="top"><label><?php esc_html_e( 'Thumbnail', 'food-menu-pro' ); ?></label></th>
            <td>
                <div id="fmp_cat_thumbnail" style="float: left; margin-right: 10px;">
                    <img src="<?php echo esc_url( $image ); ?>" width="60px" height="60px"/>
                </div>
                <div style="line-height: 60px;">
                    <input type="hidden" id="fmp_cat_thumbnail_id" name="fmp_cat_thumbnail_id"
                           value="<?php echo absint( $thumbnail_id ); ?>"/>
                    <button type="button" class="upload_image_button button">
                        <?php esc_html_e( 'Upload/Add image', 'food-menu-pro' ); ?>
                    </button>
                    <button type="button" class="remove_image_button button">
                        <?php esc_html_e( 'Remove image', 'food-menu-pro' ); ?>
                    </button>
                </div>

            </td>
        </tr>
        <?php
    }

    /**
     * Convert a time string (12h or 24h) to 24h "HH:mm" format.
     *
     * @param string $time Time string (e.g. "1:00 PM", "13:00", "9:18 am").
     *
     * @return string Time in "HH:mm" format.
     */
    private static function normalize_time_to_24h( $time ) {
        $time = trim( $time );

        // Already 24h format.
        if ( preg_match( '/^\d{1,2}:\d{2}$/', $time ) ) {
            return $time;
        }

        // 12h format: "1:00 PM", "9:18am", "12:30 AM".
        if ( preg_match( '/^(\d{1,2}):(\d{2})\s*(am|pm)$/i', $time, $m ) ) {
            $h      = (int) $m[1];
            $min    = $m[2];
            $period = strtolower( $m[3] );

            if ( 'pm' === $period && 12 !== $h ) {
                $h += 12;
            } elseif ( 'am' === $period && 12 === $h ) {
                $h = 0;
            }

            return str_pad( $h, 2, '0', STR_PAD_LEFT ) . ':' . $min;
        }

        return $time;
    }
}
