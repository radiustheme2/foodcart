<?php
/**
 * Admin Tax Metabox Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin\Metabox;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenu\Helpers\Options;
use RT\FoodMenuPro\Helpers\FnsPro;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}
//phpcs:disable PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage
/**
 * Admin Tax Metabox Class.
 */
class TaxMeta {

	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Settings option
	 *
	 * @var array
	 */
	private $settings;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		$this->settings = get_option( TLPFoodMenu()->options['settings'] );
		// Add field to category.
		\add_action( 'food-menu-cat_add_form_fields', [ $this, 'add_category_fields' ] );
		\add_action( 'food-menu-cat_edit_form_fields', [ $this, 'edit_category_fields' ], 10 );

		// Save taxonomy fields.
		\add_action( 'created_term', [ $this, 'save_taxonomy_fields' ], 10, 3 );
		\add_action( 'edit_term', [ $this, 'save_taxonomy_fields' ], 10, 3 );
		\add_action( 'edited_terms', [ $this, 'save_taxonomy_fields' ], 10, 3 );
		\add_action( 'delete_term', [ $this, 'delete_taxonomy_fields' ], 5 );

		\add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ] );

		\add_action( 'quick_edit_custom_box', [ $this, 'taxonomy_quick_edit_order' ], 10, 2 );
		\add_action( 'admin_print_footer_scripts-edit-tags.php', [ $this, 'taxonomy_quick_edit_order_javascript' ] );

		// Food location meta data.
		\add_action( 'tpl-food-location_add_form_fields', [ $this, 'add_meta_field_location' ] );
		\add_action( 'tpl-food-location_edit_form_fields', [ $this, 'edit_meta_field_location' ] );
		\add_action( 'edited_tpl-food-location', [ $this, 'location_save_meta_field' ] );
		\add_action( 'create_tpl-food-location', [ $this, 'location_save_meta_field' ] );

		// Food location table columns.
		add_filter( 'manage_edit-tpl-food-location_columns', [ $this, 'fmp_custom_fields_title' ] );
		add_action( 'manage_tpl-food-location_custom_column', [ $this, 'fmp_custom_fields_list_display' ], 10, 3 );
	}

	/**
	 * Display column data.
	 *
	 * @param array  $columns .
	 * @param string $column .
	 * @param number $id .
	 *
	 * @return void
	 */
	public function fmp_custom_fields_list_display( $columns, $column, $id ) {

		switch ( $column ) {
			case 'location_image':
				$image_id = get_term_meta( $id, 'fmp_location_image_id', true );
				echo wp_get_attachment_image( $image_id );
				break;

			// case 'location_latitude':
			// $location_latitude = get_term_meta( $id, 'location_latitude', true );
			// echo Fns::fmp_render( $location_latitude );
			// break;
			// case 'location_longitude':
			// $location_longitude = get_term_meta( $id, 'location_longitude', true );
			// echo Fns::fmp_render( $location_longitude );
			// break;
		}
	}

	/**
	 * Location table columns
	 *
	 * @param array $columns .
	 *
	 * @return array
	 */
	public function fmp_custom_fields_title( $columns ) {
		$columns['location_image'] = esc_html__( 'Image', 'food-menu-pro' );
		// $columns['location_latitude']  = esc_html__( 'Latitude', 'food-menu-pro' );
		// $columns['location_longitude'] = esc_html__( 'Longitude', 'food-menu-pro' );
		return $columns;
	}

	/**
	 * Save location meta data.
	 *
	 * @param number $term_id .
	 *
	 * @return void
	 */
	public function location_save_meta_field( $term_id ) {
		$location_input = [
			'address'               => [],
			'fmp_location_image_id' => [],
		// 'location_latitude'     => [],
		// 'location_longitude'    => [],
		];
		$location_input = filter_input_array( INPUT_POST, $location_input );

		if ( count( $location_input ) > 0 ) {
			foreach ( $location_input as $key => $value ) {
				update_term_meta( $term_id, $key, $value, false );
			}
		}
	}


	/**
	 * Add food location taxonomy meta field.
	 *
	 * @return void
	 */
	public function add_meta_field_location() {
		?>

		<div class="form-field term-group">
			<label for="address"><?php esc_html_e( 'Address', 'food-menu-pro' ); ?></label>
			<textarea type="number" name="address" id="address" rows="3" cols="3"></textarea>
			<p class="description"><?php // esc_html_e( 'Note: The latitude and longitude fields will be automatically populated from this address. After updating the address, click the "Address Position" button to trigger the auto-population of the latitude and longitude fields. if google map enable on the general setting.', 'food-menu-pro' ); ?></p>
		</div>

		<div class="form-field term-thumbnail-wrap">
			<label><?php esc_html_e( 'Thumbnail', 'food-menu-pro' ); ?></label>
			<div id="fmp_location_image" style="float: left; margin-right: 10px;">
				<img src="<?php echo esc_url( Fns::placeholder_img_src() ); ?>" width="60px" height="60px" alt="<?php echo esc_attr( 'Location Image' ); ?>"/>
			</div>
			<div style="line-height: 60px;">
				<input type="hidden" id="fmp_location_image_id" name="fmp_location_image_id"/>
				<button type="button"
						class="upload_location_image button"><?php esc_html_e( 'Upload/Add image', 'food-menu-pro' ); ?></button>
				<button type="button"
						class="remove_image_button button"><?php esc_html_e( 'Remove image', 'food-menu-pro' ); ?></button>
			</div>
		</div>

		<?php
		$settings          = $this->settings;
		$api_key           = ! empty( $settings['google_api_key'] ) ? $settings['google_api_key'] : '';
		$enable_google_map = $settings['enable_google_map'] ?? '';
		?>

		<?php if ( ! empty( $enable_google_map ) ) : ?>

			<div class="form-field term-group">
				<label for="location_latitude"><?php esc_html_e( 'Latitude', 'food-menu-pro' ); ?></label>
				<input type="text" id="location_latitude" name="location_latitude" value="">
			</div>

			<div class="form-field term-group">
				<label for="location_longitude"><?php esc_html_e( 'Longitude', 'food-menu-pro' ); ?></label>
				<input type="text" id="location_longitude" name="location_longitude" value="">
			</div>

			<div class="form-field term-group">
				<?php

				if ( empty( $api_key ) ) {
					$settings_api_key_url = '<a href="' . esc_url( admin_url() . 'edit.php?post_type=food-menu&page=food_menu_settings' ) . '" target="_blank" >' . esc_html__( 'Settings', 'food-menu-pro' ) . '</a>';
					?>
					<p class="location-api-msg">
						<?php
						printf(
							'%s %s',
							esc_html__( 'The Google API Key is missing. Please populate the API Key field in the ', 'food-menu-pro' ),
							esc_html( $settings_api_key_url )
						);
						?>
					</p>
					<?php
				} else {
					?>
					<a href="#" id="fmp-location-map-position"
					   class="button button-primary"><?php esc_html_e( 'Address Map Position', 'food-menu-pro' ); ?></a>
					<p><?php esc_html_e( 'Display the location on the map based on the value in the address field.', 'food-menu-pro' ); ?></p>
					<div class="fmp-location-map" data-lat="37.4224428" data-long="-122.0842467" data-zoom="14">
						<div id="fmp-location-map-container" style="height: 300px"></div>
					</div>
				<?php } ?>
			</div>
		<?php endif; ?>

		<?php
	}

	/**
	 * Edit food location taxonomy meta field.
	 *
	 * @param object $term .
	 *
	 * @return void
	 */
	public function edit_meta_field_location( $term ) {
		$thumbnail_id = absint( get_term_meta( $term->term_id, 'fmp_location_image_id', true ) );
		if ( $thumbnail_id ) {
			$image = wp_get_attachment_thumb_url( $thumbnail_id );
		} else {
			$image = Fns::placeholder_img_src();
		}
		?>
		<tr class="form-field term-group-wrap">
			<th scope="row">
				<label for="address"><?php esc_html_e( 'Address', 'food-menu-pro' ); ?></label>
			</th>
			<td>
				<textarea type="address" id="address" name="address" rows="3" cols="3">
					<?php echo esc_attr( get_term_meta( $term->term_id, 'address', true ) ); ?>
				</textarea>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row"><label><?php esc_html_e( 'Thumbnail', 'food-menu-pro' ); ?></label></th>
			<td>
				<div id="fmp_location_image" style="float: left; margin-right: 10px;">
					<img src="<?php echo esc_url( $image ); ?>" width="60px" height="60px"/>
				</div>
				<div style="line-height: 60px;">
					<input type="hidden" id="fmp_location_image_id" name="fmp_location_image_id"
						   value="<?php echo absint( $thumbnail_id ); ?>"/>
					<button type="button"
							class="upload_location_image button"><?php esc_html_e( 'Upload/Add image', 'food-menu-pro' ); ?></button>
					<button type="button"
							class="remove_image_button button"><?php esc_html_e( 'Remove image', 'food-menu-pro' ); ?></button>
				</div>
			</td>
		</tr>

		<?php
		$settings          = $this->settings;
		$api_key           = ! empty( $settings['google_api_key'] ) ? $settings['google_api_key'] : '';
		$enable_google_map = $settings['enable_google_map'] ?? '';
		?>

		<?php if ( ! empty( $enable_google_map ) ) : ?>

			<tr class="form-field term-group-wrap">
				<th scope="row">
					<label for="location_latitude"><?php esc_html_e( 'Latitude', 'food-menu-pro' ); ?></label>
				</th>
				<td>
					<?php
					$location_latitude = get_term_meta( $term->term_id, 'location_latitude', true );
					if ( empty( $location_latitude ) ) {
						$location_latitude = '37.4224428';
					}
					?>
					<input type="text" id="location_latitude" name="location_latitude"
						   value="<?php echo esc_attr( $location_latitude ); ?>">
				</td>
			</tr>

			<tr class="form-field term-group-wrap">
				<th scope="row">
					<label for="location_longitude"><?php esc_html_e( 'Longitude', 'food-menu-pro' ); ?></label>
				</th>
				<td>
					<?php
					$location_longitude = get_term_meta( $term->term_id, 'location_longitude', true );
					if ( empty( $location_longitude ) ) {
						$location_longitude = '-122.0842467';
					}
					?>
					<input type="text" id="location_longitude" name="location_longitude"
						   value="<?php echo esc_attr( $location_longitude ); ?>">
				</td>
			</tr>

			<tr class="form-field term-group-wrap">
				<th scope="row">
					<label for="location_map"><?php esc_html_e( 'Location Map', 'food-menu-pro' ); ?></label>
				</th>
				<td>
					<?php
					if ( empty( $api_key ) ) {
						$settings_page_url = '<a href="' . esc_url( admin_url() . 'admin.php?page=cafe_settings' ) . '" target="_blank" >' . esc_html__( 'Settings', 'food-menu-pro' ) . '</a>';
						?>
						<p class="location-api-msg">
							<?php
							printf(
								'%s %s',
								esc_html__( 'The Google API Key is missing. Please populate the API Key field in the ', 'food-menu-pro' ),
								esc_html( $settings_page_url )
							);
							?>
						</p>
						<?php
					} else {
						?>
						<a href="#" id="fmp-location-map-position"
						   class="button button-primary"><?php esc_html_e( 'Address Position', 'food-menu-pro' ); ?></a>
						<p><?php esc_html_e( 'Display the location on the map based on the value in the address field.', 'food-menu-pro' ); ?></p>
						<div class="fmp-location-map" data-lat="<?php echo esc_attr( $location_latitude ); ?>"
							 data-long="<?php echo esc_attr( $location_longitude ); ?>" data-zoom="12">
							<div id="fmp-location-map-container" style="height: 300px"></div>
						</div>
						<?php
					}
					?>
				</td>
			</tr>

		<?php endif; ?>

		<?php
	}

	public function taxonomy_quick_edit_order_javascript() {
		$current_screen = get_current_screen();

		if ( $current_screen->id != 'edit-' . TLPFoodMenu()->taxonomies['category'] || $current_screen->taxonomy != TLPFoodMenu()->taxonomies['category'] ) {
			return;
		}

		wp_enqueue_script( 'jquery' );
		?>
		<script type="text/javascript">
			jQuery(function ($) {
				$('#the-list').on('click', 'button.editinline', function (e) {
					// e.preventDefault();
					var $tr = $(this).closest('tr'),
						order = $tr.find('td._fmp_order').text();
					var nonce = $('input#fmp_nonce').val();
					// Update field
					$('tr.inline-edit-row :input[name="_order"]').val(order ? parseInt(order, 10) : 0);
					$('tr.inline-edit-row :input[name="fmp_nonce"]').val(nonce);
				});
			});
		</script>
		<style>
			.fmp-quick-field-wrap:before,
			.fmp-quick-field-wrap:after {
				clear: both;
				display: block;
				content: "";
				float: none;
			}
		</style>
		<?php
	}

	public function taxonomy_quick_edit_order( $column_name, $screen ) {
		if ( $screen != 'edit-tags' || $column_name != '_fmp_order' || ! isset( $_GET['taxonomy'] ) || $_GET['taxonomy'] !== TLPFoodMenu()->taxonomies['category'] ) { //phpcs:ignore
			return false;
		}
		?>
		<div class="fmp-quick-field-wrap">
			<fieldset style="width: 50%; float: left">
				<div id="rtcl-taxonomy-content" class="inline-edit-col">
					<label>
						<span class="title"><?php esc_html_e( 'Order', 'food-menu-pro' ); ?></span>
						<span class="input-text-wrap"><input type="number" name="_order" value=""></span>
						<span class="input-quick-edit-nonce"><input type="hidden" name="fmp_nonce" value=""></span>
					</label>
				</div>
			</fieldset>
		</div>
		<?php
	}

	public function admin_enqueue_scripts() {
		global $pagenow, $typenow;

		// validate page.
		if ( ! in_array( $pagenow, [ 'edit-tags.php', 'term.php' ] ) ) {
			return;
		}

		if ( ! in_array( $typenow, [ TLPFoodMenu()->post_type, 'product' ] ) ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_script(
			[
				'jquery',
				'jquery-ui-core',
				'jquery-ui-sortable',
				'fmp-admin-taxonomy',
			]
		);

		wp_enqueue_style(
			[
				'fmp-admin',
			]
		);

		$nonce = wp_create_nonce( Fns::nonceText() );

		wp_localize_script(
			'fmp-admin',
			'fmp_var',
			[
				'nonceID'        => esc_attr( Fns::nonceId() ),
				'nonce'          => esc_attr( $nonce ),
				'ajaxurl'        => esc_url( admin_url( 'admin-ajax.php' ) ),
				'placeholderUrl' => TLPFoodMenu()->assets_url() . 'images/placeholder.png',
			]
		);
		wp_localize_script(
			'fmp-admin-taxonomy',
			'fmp_var1',
			[
				'nonceID'        => esc_attr( Fns::nonceId() ),
				'nonce'          => esc_attr( $nonce ),
				'ajaxurl'        => esc_url( admin_url( 'admin-ajax.php' ) ),
				'placeholderUrl' => TLPFoodMenu()->assets_url() . 'images/placeholder.png',
				'adminTaxonomy'  => [
					'geocode' => esc_html__( 'Google geocoder error', 'food-menu-pro' ),
					'address' => esc_html__( 'Address is empty', 'food-menu-pro' ),
				],
			]
		);
	}

	/**
	 * save_taxonomy_fields function.
	 *
	 * @param mixed  $term_id Term ID being saved
	 * @param mixed  $tt_id
	 * @param string $taxonomy
	 */
	public function save_taxonomy_fields( $term_id, $tt_id = '', $taxonomy = '' ) {

		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			return;
		}
		if ( isset( $_POST['fmp_cat_thumbnail_id'] ) && TLPFoodMenu()->taxonomies['category'] === $taxonomy ) {
			update_term_meta( $term_id, 'fmp_cat_thumbnail_id', absint( $_POST['fmp_cat_thumbnail_id'] ) );
		}

		if ( isset( $_POST['_order'] ) && TLPFoodMenu()->taxonomies['category'] === $taxonomy ) {
			update_term_meta( $term_id, '_order', absint( $_POST['_order'] ) );
		} else {
			update_term_meta( $term_id, '_order', 0 );
		}
	}

	public function delete_taxonomy_fields() {
	}

	/**
	 * Category thumbnail fields.
	 */
	public function add_category_fields() {
		wp_nonce_field( Fns::nonceText(), Fns::nonceId() );
		?>
		<div class="form-field">
			<label><?php esc_html_e( 'Order', 'food-menu-pro' ); ?></label>
			<input type="number" name="_order" value="0">
		</div>
		<div class="form-field term-thumbnail-wrap">
			<label><?php esc_html_e( 'Thumbnail', 'food-menu-pro' ); ?></label>
			<div id="fmp_cat_thumbnail" style="float: left; margin-right: 10px;">
				<img src="<?php echo esc_url( Fns::placeholder_img_src() ); ?>" width="60px" height="60px"/>
			</div>
			<div style="line-height: 60px;">
				<input type="hidden" id="fmp_cat_thumbnail_id" name="fmp_cat_thumbnail_id"/>
				<button type="button" class="upload_image_button button">
					<?php esc_html_e( 'Upload/Add image', 'food-menu-pro' ); ?>
				</button>
				<button type="button"
						class="remove_image_button button"><?php esc_html_e( 'Remove image', 'food-menu-pro' ); ?></button>
			</div>
		</div>
		<?php
	}

	/**
	 * Edit category thumbnail field.
	 *
	 * @param mixed $term Term (category) being edited.
	 */
	public function edit_category_fields( $term ) {
		$thumbnail_id = absint( get_term_meta( $term->term_id, 'fmp_cat_thumbnail_id', true ) );
		$order        = absint( get_term_meta( $term->term_id, '_order', true ) );

		if ( $thumbnail_id ) {
			$image = wp_get_attachment_thumb_url( $thumbnail_id );
		} else {
			$image = Fns::placeholder_img_src();
		}
		wp_nonce_field( Fns::nonceText(), Fns::nonceId() );
		?>
		<tr class="form-field">
			<th scope="row" valign="top"><label><?php esc_html_e( 'Order', 'food-menu-pro' ); ?></label></th>
			<td><input type="number" name="_order" value="<?php echo esc_attr( $order ); ?>"></td>
		</tr>
		<tr class="form-field">
			<th scope="row" valign="top"><label><?php esc_html_e( 'Thumbnail', 'food-menu-pro' ); ?></label></th>
			<td>
				<div id="fmp_cat_thumbnail" style="float: left; margin-right: 10px;">
					<img src="<?php echo esc_url( $image ); ?>" width="60px" height="60px"/>
				</div>
				<div style="line-height: 60px;">
					<input type="hidden" id="fmp_cat_thumbnail_id" name="fmp_cat_thumbnail_id"
						   value="<?php echo absint( $thumbnail_id ); ?>"/>
					<button type="button" class="upload_image_button button">
						<?php esc_html_e( 'Upload/Add image', 'food-menu-pro' ); ?>
					</button>
					<button type="button" class="remove_image_button button">
						<?php esc_html_e( 'Remove image', 'food-menu-pro' ); ?>
					</button>
				</div>

			</td>
		</tr>
		<?php
	}
}
