<?php
/**
 * Order Information Metabox.
 *
 * Renders a consolidated panel of pickup/delivery, location, tip and custom
 * field data on the WooCommerce admin order edit page. Auto-hides when the
 * order has none of these fields set.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin\Metabox;

defined( 'ABSPATH' ) || exit;

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\PickupDelivery\PickupDeliveryFns;
use RT\FoodMenu\Helpers\Fns;

/**
 * Order Information Metabox.
 */
class OrderInfoMetabox {

    use SingletonTrait;

    /**
     * Init.
     *
     * @return void
     */
    protected function init() {
        // Replace free's slim location-only metabox with the Pro version that
        // also covers pickup/delivery, tip, custom fields, etc.
        // Guarded: older free plugin versions don't ship this class yet.
        $free_metabox = FnsPro::free_instance( \RT\FoodMenu\Controllers\Admin\Metabox\OrderInfoMetabox::class );
        if ( $free_metabox ) {
            remove_action( 'add_meta_boxes', [ $free_metabox, 'register_metabox' ], 10 );
            remove_action( 'woocommerce_process_shop_order_meta', [ $free_metabox, 'save' ], 30 );
        }

        add_action( 'add_meta_boxes', [ $this, 'register_metabox' ], 30, 2 );
        // Reorder after WC has added its own high-priority boxes (data + items),
        // so ours slots in directly after woocommerce-order-data by default.
        add_action( 'add_meta_boxes', [ $this, 'reorder_metabox' ], 100 );
        // Save handler — fires for both HPOS and legacy CPT order saves.
        add_action( 'woocommerce_process_shop_order_meta', [ $this, 'save' ], 30, 2 );
    }

    /**
     * Register the metabox on the WC order edit screen (HPOS + legacy CPT),
     * but only when the order actually has data worth showing.
     *
     * @param string $post_type Screen/post type.
     * @param \WP_Post|\WC_Order|null $post_or_order Post (legacy) or order (HPOS).
     *
     * @return void
     */
    public function register_metabox( $post_type, $post_or_order ) {
        $screens = [ 'shop_order' ];
        if ( function_exists( 'wc_get_page_screen_id' ) ) {
            $hpos = wc_get_page_screen_id( 'shop-order' );
            if ( $hpos ) {
                $screens[] = $hpos;
            }
        }

        if ( ! in_array( $post_type, $screens, true ) ) {
            return;
        }

        $order = $post_or_order instanceof \WC_Order ? $post_or_order : wc_get_order( $post_or_order );
        if ( ! $order ) {
            return;
        }

        add_meta_box(
                'fmp_order_info_metabox',
                esc_html__( 'Food Menu - Order Information', 'food-menu-pro' ),
                [ $this, 'render' ],
                $post_type,
                'normal',
                'high'
        );
    }

    /**
     * Default-position our metabox directly after WC's `woocommerce-order-data`
     * box in the normal/high bucket. Runs after all `add_meta_boxes` callbacks
     * so WC's boxes are present in `$wp_meta_boxes`. User-saved order via drag
     * is stored separately in user meta and still takes precedence.
     *
     * @return void
     */
    public function reorder_metabox() {
        global $wp_meta_boxes;

        $screens = [ 'shop_order' ];
        if ( function_exists( 'wc_get_page_screen_id' ) ) {
            $hpos = wc_get_page_screen_id( 'shop-order' );
            if ( $hpos ) {
                $screens[] = $hpos;
            }
        }

        foreach ( $screens as $screen ) {
            $high = $wp_meta_boxes[ $screen ]['normal']['high'] ?? null;
            if ( ! is_array( $high ) ) {
                continue;
            }
            if ( ! isset( $high['fmp_order_info_metabox'], $high['woocommerce-order-data'] ) ) {
                continue;
            }

            $ours = $high['fmp_order_info_metabox'];
            unset( $high['fmp_order_info_metabox'] );

            $reordered = [];
            foreach ( $high as $id => $box ) {
                $reordered[ $id ] = $box;
                if ( 'woocommerce-order-data' === $id ) {
                    $reordered['fmp_order_info_metabox'] = $ours;
                }
            }

            $wp_meta_boxes[ $screen ]['normal']['high'] = $reordered;
        }
    }

    /**
     * Render the metabox.
     *
     * @param \WP_Post|\WC_Order $post_or_order Post (legacy) or order (HPOS).
     *
     * @return void
     */
    public function render( $post_or_order ) {
        $order = $post_or_order instanceof \WC_Order ? $post_or_order : wc_get_order( $post_or_order );
        if ( ! $order ) {
            return;
        }

        $order_type    = $order->get_meta( 'fmp_order_time_type' );
        $delivery_date = $order->get_meta( 'fmp_delivery_date' );
        $delivery_time = $order->get_meta( 'fmp_delivery_time' );
        $pickup_date   = $order->get_meta( 'fmp_pickup_date' );
        $pickup_time   = $order->get_meta( 'fmp_pickup_time' );
        $dinein_date   = $order->get_meta( 'fmp_dinein_date' );
        $dinein_time   = $order->get_meta( 'fmp_dinein_time' );
        $dinein_table  = $order->get_meta( 'fmp_dinein_table' );
        $location      = $order->get_meta( 'fmp_location_name' );
        $tip_info      = FnsPro::tip_information( $order );

        $custom_fields     = $order->get_meta( '_fmp_custom_fields' );
        $custom_fields     = is_array( $custom_fields ) ? $custom_fields : [];
        $custom_field_defs = FnsPro::get_setting( 'fmp_order_custom_fields', [] );

        $has_any_data = $order_type || $location || $delivery_date || $delivery_time || $pickup_date || $pickup_time || $dinein_date || $dinein_time || $dinein_table || ! empty( $tip_info['amount'] );
        if ( ! $has_any_data ) {
            foreach ( $custom_fields as $v ) {
                $disp = is_array( $v ) ? implode( ', ', $v ) : $v;
                if ( '' !== (string) $disp ) {
                    $has_any_data = true;
                    break;
                }
            }
        }
        /**
         * Filter: lets modules signal that they have content to show even when
         * the base order info fields are empty, so the "No order information"
         * empty state is suppressed when QR/etc. data is present.
         *
         * @param bool      $has_any_data Current value.
         * @param \WC_Order $order        Order being rendered.
         */
        $has_any_data = (bool) apply_filters( 'fmp_order_info_has_data', $has_any_data, $order );

        $input_style = 'width:100%;box-sizing:border-box;padding:8px 10px;border:1px solid #e5e7eb;border-radius:6px;background:#fff;font-size:14px;color:#111827;line-height:1.4;outline:none;transition:border-color .15s,box-shadow .15s;';
        $label_style = 'font-size:11px;color:#6b7280;text-transform:uppercase;letter-spacing:0.04em;font-weight:600;margin-bottom:6px;display:block;';

        $type_palettes = [
                'delivery' => [ 'bg' => '#eff6ff', 'fg' => '#1d4ed8', 'border' => '#bfdbfe' ],
                'pickup'   => [ 'bg' => '#ecfdf5', 'fg' => '#047857', 'border' => '#a7f3d0' ],
                'dinein'   => [ 'bg' => '#fefce8', 'fg' => '#a16207', 'border' => '#fde68a' ],
        ];
        $type_palette  = $type_palettes[ $order_type ] ?? $type_palettes['pickup'];

        $view_dates  = [
                'delivery' => $delivery_date,
                'pickup'   => $pickup_date,
                'dinein'   => $dinein_date,
        ];
        $view_times  = [
                'delivery' => $delivery_time,
                'pickup'   => $pickup_time,
                'dinein'   => $dinein_time,
        ];
        $date_labels = [
                'delivery' => __( 'Delivery Date', 'food-menu-pro' ),
                'pickup'   => __( 'Pickup Date', 'food-menu-pro' ),
                'dinein'   => __( 'Dine In Date', 'food-menu-pro' ),
        ];
        $time_labels = [
                'delivery' => __( 'Delivery Time', 'food-menu-pro' ),
                'pickup'   => __( 'Pickup Time', 'food-menu-pro' ),
                'dinein'   => __( 'Dine In Time', 'food-menu-pro' ),
        ];

        $view_date  = $view_dates[ $order_type ] ?? '';
        $view_time  = $view_times[ $order_type ] ?? '';
        $date_label = $date_labels[ $order_type ] ?? $date_labels['pickup'];
        $time_label = $time_labels[ $order_type ] ?? $time_labels['pickup'];
        ?>
        <div class="fmp-order-info" data-mode="view" style="position:relative;font-size:13px;color:#111827;line-height:1.5;">
            <?php wp_nonce_field( 'fmp_order_info_save', 'fmp_order_info_nonce' ); ?>

            <button type="button" class="fmp-order-info__toggle" aria-label="<?php esc_attr_e( 'Edit order information', 'food-menu-pro' ); ?>" style="position:absolute;top:-4px;right:0;display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;background:#fff;border:1px solid #e5e7eb;border-radius:6px;color:#6b7280;cursor:pointer;padding:0;transition:all .15s;">
                <svg class="fmp-order-info__icon-edit" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                <svg class="fmp-order-info__icon-close" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:none;"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>

            <?php
            /**
             * Header slot for module-provided UI that should always be visible
             * (regardless of view/edit mode) — e.g. the POS Print Slips bar.
             *
             * @param \WC_Order $order The order being rendered.
             */
            do_action( 'fmp_order_info_header', $order );
            ?>

            <div class="fmp-order-info__view">
                <?php if ( ! $has_any_data ) : ?>
                    <div style="padding:18px;text-align:center;color:#9ca3af;font-size:13px;background:#f9fafb;border:1px dashed #e5e7eb;border-radius:8px;">
                        <?php esc_html_e( 'No order information yet. Click the edit icon to add details.', 'food-menu-pro' ); ?>
                    </div>
                <?php else : ?>

                    <?php if ( $location || $order_type ) : ?>
                        <div style="display:flex;flex-wrap:wrap;gap:24px;margin-bottom:16px;padding-top:10px">
                            <?php if ( $location ) : ?>
                                <div>
                                    <div style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Location', 'food-menu-pro' ); ?></div>
                                    <span style="display:inline-flex;align-items:center;gap:6px;padding:6px 12px;background:#fff7ed;color:#c2410c;border:1px solid #fed7aa;border-radius:6px;font-weight:600;">
                                        <span style="width:6px;height:6px;border-radius:50%;background:#ea580c;display:inline-block;"></span>
                                        <?php echo esc_html( $location ); ?>
                                    </span>
                                </div>
                            <?php endif; ?>

                            <?php if ( $order_type ) : ?>
                                <div>
                                    <div style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Order Type', 'food-menu-pro' ); ?></div>
                                    <span style="display:inline-flex;align-items:center;gap:6px;padding:6px 12px;background:<?php echo esc_attr( $type_palette['bg'] ); ?>;color:<?php echo esc_attr( $type_palette['fg'] ); ?>;border:1px solid <?php echo esc_attr( $type_palette['border'] ); ?>;border-radius:6px;font-weight:600;text-transform:capitalize;">
                                        <?php echo esc_html( FnsPro::get_order_type_label( $order_type ) ?: $order_type ); ?>
                                    </span>
                                </div>
                            <?php endif; ?>

                            <?php if ( 'dinein' === $order_type && $dinein_table ) : ?>
                                <div>
                                    <div style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Table', 'food-menu-pro' ); ?></div>
                                    <span style="display:inline-flex;align-items:center;gap:6px;padding:6px 12px;background:#fefce8;color:#a16207;border:1px solid #fde68a;border-radius:6px;font-weight:600;">
                                        <?php echo esc_html( $dinein_table ); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ( $view_date || $view_time ) : ?>
                        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;padding:14px 16px;background:#f9fafb;border:1px solid #f1f5f9;border-radius:8px;margin-bottom:16px;">
                            <?php if ( $view_date ) : ?>
                                <div>
                                    <div style="<?php echo esc_attr( $label_style ); ?>margin-bottom:4px;"><?php echo esc_html( $date_label ); ?></div>
                                    <div style="font-size:14px;color:#111827;font-weight:500;"><?php echo esc_html( $view_date ); ?></div>
                                </div>
                            <?php endif; ?>
                            <?php if ( $view_time ) : ?>
                                <div>
                                    <div style="<?php echo esc_attr( $label_style ); ?>margin-bottom:4px;"><?php echo esc_html( $time_label ); ?></div>
                                    <div style="font-size:14px;color:#111827;font-weight:500;"><?php echo esc_html( $view_time ); ?></div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ( ! empty( $tip_info['amount'] ) ) : ?>
                        <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#fefce8;border:1px solid #fef3c7;border-radius:8px;margin-bottom:16px;">
                            <span style="font-size:12px;color:#854d0e;text-transform:uppercase;letter-spacing:0.04em;font-weight:600;">
                                <?php esc_html_e( 'Tip', 'food-menu-pro' ); ?>
                                <?php if ( ! empty( $tip_info['prefix'] ) ) : ?>
                                    <span style="font-weight:500;text-transform:none;letter-spacing:0;color:#a16207;margin-left:6px;">(<?php echo esc_html( $tip_info['prefix'] ); ?>)</span>
                                <?php endif; ?>
                            </span>
                            <span style="font-size:15px;color:#854d0e;font-weight:700;">
                                <?php Fns::print_html( wc_price( $tip_info['amount'] ) ); ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <?php
                    $rendered_cf = [];
                    foreach ( $custom_fields as $key => $value ) {
                        $idx     = intval( str_replace( 'custom_', '', $key ) );
                        $label   = isset( $custom_field_defs[ $idx ]['label'] ) ? $custom_field_defs[ $idx ]['label'] : $key;
                        $display = is_array( $value ) ? implode( ', ', $value ) : $value;
                        if ( '' === (string) $display ) {
                            continue;
                        }
                        $rendered_cf[] = [ 'label' => $label, 'value' => $display ];
                    }
                    if ( ! empty( $rendered_cf ) ) : ?>
                        <div style="border-top:1px solid #e5e7eb;padding-top:14px;">
                            <div style="<?php echo esc_attr( $label_style ); ?>margin-bottom:10px;">
                                <?php esc_html_e( 'Custom Fields', 'food-menu-pro' ); ?>
                            </div>
                            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
                                <?php foreach ( $rendered_cf as $field ) : ?>
                                    <div>
                                        <div style="font-size:12px;color:#6b7280;margin-bottom:2px;"><?php echo esc_html( $field['label'] ); ?></div>
                                        <div style="font-size:14px;color:#111827;font-weight:500;"><?php echo esc_html( $field['value'] ); ?></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                <?php endif; ?>

                <?php
                /**
                 * View-mode slot for module-provided read-only UI (e.g. the QR
                 * Code Table badge). Hides when the edit-mode toggle is on.
                 *
                 * @param \WC_Order $order Order being rendered.
                 */
                do_action( 'fmp_order_info_view', $order );
                ?>
            </div>

            <div class="fmp-order-info__edit" style="display:none;padding-top:20px">

                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-bottom:16px;">
                    <div>
                        <label for="fmp_order_time_type" style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Order Type', 'food-menu-pro' ); ?></label>
                        <select id="fmp_order_time_type" name="fmp_order_time_type" style="<?php echo esc_attr( $input_style ); ?>">
                            <option value=""<?php selected( $order_type, '' ); ?>><?php esc_html_e( '— None —', 'food-menu-pro' ); ?></option>
                            <option value="delivery"<?php selected( $order_type, 'delivery' ); ?>><?php esc_html_e( 'Delivery', 'food-menu-pro' ); ?></option>
                            <option value="pickup"<?php selected( $order_type, 'pickup' ); ?>><?php esc_html_e( 'Pickup', 'food-menu-pro' ); ?></option>
                            <option value="dinein"<?php selected( $order_type, 'dinein' ); ?>><?php esc_html_e( 'Dine In', 'food-menu-pro' ); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="fmp_location_name" style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Location', 'food-menu-pro' ); ?></label>
                        <input type="text" id="fmp_location_name" name="fmp_location_name" value="<?php echo esc_attr( $location ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
                    </div>
                    <div>
                        <label for="fmp_dinein_table" style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Table', 'food-menu-pro' ); ?></label>
                        <?php
                        // Scope to the order's own branch so two locations with a
                        // same-named table can't both appear here.
                        $dinein_table_options = PickupDeliveryFns::get_dinein_table_options(
                            (int) $order->get_meta( 'fmp_location_id' )
                        );
                        ?>
                        <?php if ( ! empty( $dinein_table_options ) ) : ?>
                            <select id="fmp_dinein_table" name="fmp_dinein_table" style="<?php echo esc_attr( $input_style ); ?>">
                                <option value=""><?php esc_html_e( '— None —', 'food-menu-pro' ); ?></option>
                                <?php foreach ( $dinein_table_options as $dinein_table_option ) : ?>
                                    <option value="<?php echo esc_attr( $dinein_table_option['name'] ); ?>"<?php selected( $dinein_table, $dinein_table_option['name'] ); ?>><?php echo esc_html( $dinein_table_option['label'] ); ?></option>
                                <?php endforeach; ?>
                                <?php if ( $dinein_table && ! in_array( $dinein_table, wp_list_pluck( $dinein_table_options, 'name' ), true ) ) : ?>
                                    <?php // Keep a table that was removed from settings visible so editing doesn't wipe it. ?>
                                    <option value="<?php echo esc_attr( $dinein_table ); ?>" selected><?php echo esc_html( $dinein_table ); ?></option>
                                <?php endif; ?>
                            </select>
                        <?php else : ?>
                            <input type="text" id="fmp_dinein_table" name="fmp_dinein_table" value="<?php echo esc_attr( $dinein_table ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
                        <?php endif; ?>
                    </div>
                </div>

                <div style="padding:14px 16px;background:#f9fafb;border:1px solid #f1f5f9;border-radius:8px;margin-bottom:16px;">
                    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;">
                        <div>
                            <label for="fmp_delivery_date" style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Delivery Date', 'food-menu-pro' ); ?></label>
                            <input type="text" id="fmp_delivery_date" name="fmp_delivery_date" value="<?php echo esc_attr( $delivery_date ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
                        </div>
                        <div>
                            <label for="fmp_delivery_time" style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Delivery Time', 'food-menu-pro' ); ?></label>
                            <input type="text" id="fmp_delivery_time" name="fmp_delivery_time" value="<?php echo esc_attr( $delivery_time ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
                        </div>
                        <div>
                            <label for="fmp_pickup_date" style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Pickup Date', 'food-menu-pro' ); ?></label>
                            <input type="text" id="fmp_pickup_date" name="fmp_pickup_date" value="<?php echo esc_attr( $pickup_date ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
                        </div>
                        <div>
                            <label for="fmp_pickup_time" style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Pickup Time', 'food-menu-pro' ); ?></label>
                            <input type="text" id="fmp_pickup_time" name="fmp_pickup_time" value="<?php echo esc_attr( $pickup_time ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
                        </div>
                        <div>
                            <label for="fmp_dinein_date" style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Dine In Date', 'food-menu-pro' ); ?></label>
                            <input type="text" id="fmp_dinein_date" name="fmp_dinein_date" value="<?php echo esc_attr( $dinein_date ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
                        </div>
                        <div>
                            <label for="fmp_dinein_time" style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'Dine In Time', 'food-menu-pro' ); ?></label>
                            <input type="text" id="fmp_dinein_time" name="fmp_dinein_time" value="<?php echo esc_attr( $dinein_time ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
                        </div>
                    </div>
                </div>

                <?php if ( ! empty( $tip_info['amount'] ) ) : ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#fefce8;border:1px solid #fef3c7;border-radius:8px;margin-bottom:8px;">
                        <span style="font-size:12px;color:#854d0e;text-transform:uppercase;letter-spacing:0.04em;font-weight:600;">
                            <?php esc_html_e( 'Tip', 'food-menu-pro' ); ?>
                            <?php if ( ! empty( $tip_info['prefix'] ) ) : ?>
                                <span style="font-weight:500;text-transform:none;letter-spacing:0;color:#a16207;margin-left:6px;">(<?php echo esc_html( $tip_info['prefix'] ); ?>)</span>
                            <?php endif; ?>
                        </span>
                        <span style="font-size:15px;color:#854d0e;font-weight:700;">
                            <?php Fns::print_html( wc_price( $tip_info['amount'] ) ); ?>
                        </span>
                    </div>
                    <p style="margin:0 0 16px;font-size:12px;color:#9ca3af;line-height:1.4;">
                        <?php esc_html_e( 'Tip is stored as an order fee — to change the charged amount, edit the fee line in the Items table.', 'food-menu-pro' ); ?>
                    </p>
                <?php endif; ?>

                <?php if ( ! empty( $custom_field_defs ) ) : ?>
                    <div style="border-top:1px solid #e5e7eb;padding-top:14px;">
                        <div style="<?php echo esc_attr( $label_style ); ?>margin-bottom:10px;">
                            <?php esc_html_e( 'Custom Fields', 'food-menu-pro' ); ?>
                        </div>
                        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
                            <?php foreach ( $custom_field_defs as $idx => $def ) :
                                $key      = 'custom_' . $idx;
                                $label    = ! empty( $def['label'] ) ? $def['label'] : 'Field ' . ( $idx + 1 );
                                $type     = $def['type'] ?? 'text';
                                $multiple = filter_var( $def['multiple'] ?? false, FILTER_VALIDATE_BOOLEAN );
                                $value    = $custom_fields[ $key ] ?? '';
                                $input_id = 'fmp_custom_field_' . $idx;
                                ?>
                                <div>
                                    <label for="<?php echo esc_attr( $input_id ); ?>" style="font-size:12px;color:#6b7280;margin-bottom:4px;display:block;font-weight:500;">
                                        <?php echo esc_html( $label ); ?>
                                    </label>
                                    <?php if ( 'select' === $type ) :
                                        $options = array_filter( array_map( 'trim', explode( ',', $def['options'] ?? '' ) ) );
                                        $selected_values = $multiple
                                            ? ( is_array( $value ) ? $value : array_filter( array_map( 'trim', explode( ',', (string) $value ) ) ) )
                                            : [ (string) $value ];
                                        $name = $multiple ? $input_id . '[]' : $input_id;
                                        ?>
                                        <select id="<?php echo esc_attr( $input_id ); ?>" name="<?php echo esc_attr( $name ); ?>"<?php echo $multiple ? ' multiple' : ''; ?> style="<?php echo esc_attr( $input_style ); ?><?php echo $multiple ? 'min-height:80px;' : ''; ?>">
                                            <?php if ( ! $multiple ) : ?>
                                                <option value=""><?php esc_html_e( '— Select —', 'food-menu-pro' ); ?></option>
                                            <?php endif; ?>
                                            <?php foreach ( $options as $opt ) : ?>
                                                <option value="<?php echo esc_attr( $opt ); ?>"<?php echo in_array( $opt, $selected_values, true ) ? ' selected' : ''; ?>><?php echo esc_html( $opt ); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php else :
                                        $display_value = is_array( $value ) ? implode( ', ', $value ) : $value;
                                        ?>
                                        <input type="text" id="<?php echo esc_attr( $input_id ); ?>" name="<?php echo esc_attr( $input_id ); ?>" value="<?php echo esc_attr( $display_value ); ?>" style="<?php echo esc_attr( $input_style ); ?>" />
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php
                /**
                 * Edit-mode slot for module-provided editable fields (e.g. the
                 * QR Code Table select). Shown only when the edit toggle is on.
                 *
                 * @param \WC_Order $order Order being rendered.
                 */
                do_action( 'fmp_order_info_edit', $order );
                ?>

                <p style="margin:14px 0 0;padding:10px 12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;font-size:12px;color:#1e40af;line-height:1.4;">
                    <?php esc_html_e( 'Changes are saved when you click the main "Update" button.', 'food-menu-pro' ); ?>
                </p>

            </div>

        </div>

        <script>
        (function () {
            var box = document.querySelector('#fmp_order_info_metabox .fmp-order-info');
            if (!box || box.dataset.fmpBound) return;
            box.dataset.fmpBound = '1';
            var toggle  = box.querySelector('.fmp-order-info__toggle');
            var iconE   = box.querySelector('.fmp-order-info__icon-edit');
            var iconX   = box.querySelector('.fmp-order-info__icon-close');
            var view    = box.querySelector('.fmp-order-info__view');
            var edit    = box.querySelector('.fmp-order-info__edit');
            toggle.addEventListener('click', function () {
                var editing = box.dataset.mode === 'edit';
                box.dataset.mode = editing ? 'view' : 'edit';
                view.style.display = editing ? '' : 'none';
                edit.style.display = editing ? 'none' : '';
                iconE.style.display = editing ? '' : 'none';
                iconX.style.display = editing ? 'none' : '';
                toggle.setAttribute('aria-label', editing ? '<?php echo esc_js( __( 'Edit order information', 'food-menu-pro' ) ); ?>' : '<?php echo esc_js( __( 'Cancel editing', 'food-menu-pro' ) ); ?>');
            });
        })();
        </script>
        <?php
    }

    /**
     * Save handler — runs on both HPOS and legacy CPT order saves.
     *
     * @param int                 $order_id Order ID.
     * @param \WC_Order|\WP_Post  $order    Order (HPOS) or post (legacy).
     *
     * @return void
     */
    public function save( $order_id, $order ) {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if ( empty( $_POST['fmp_order_info_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['fmp_order_info_nonce'] ) ), 'fmp_order_info_save' ) ) {
            return;
        }

        if ( ! current_user_can( 'edit_shop_orders' ) ) {
            return;
        }

        $wc_order = $order instanceof \WC_Order ? $order : wc_get_order( $order_id );
        if ( ! $wc_order ) {
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing
        $order_type    = isset( $_POST['fmp_order_time_type'] ) ? sanitize_key( wp_unslash( $_POST['fmp_order_time_type'] ) ) : '';
        $location      = isset( $_POST['fmp_location_name'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_location_name'] ) ) : '';
        $delivery_date = isset( $_POST['fmp_delivery_date'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_delivery_date'] ) ) : '';
        $delivery_time = isset( $_POST['fmp_delivery_time'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_delivery_time'] ) ) : '';
        $pickup_date   = isset( $_POST['fmp_pickup_date'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_pickup_date'] ) ) : '';
        $pickup_time   = isset( $_POST['fmp_pickup_time'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_pickup_time'] ) ) : '';
        $dinein_date   = isset( $_POST['fmp_dinein_date'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_dinein_date'] ) ) : '';
        $dinein_time   = isset( $_POST['fmp_dinein_time'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_dinein_time'] ) ) : '';
        $dinein_table  = isset( $_POST['fmp_dinein_table'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_dinein_table'] ) ) : '';
        // phpcs:enable

        $wc_order->update_meta_data( 'fmp_order_time_type', $order_type );
        $wc_order->update_meta_data( 'fmp_location_name', $location );
        $wc_order->update_meta_data( 'fmp_delivery_date', $delivery_date );
        $wc_order->update_meta_data( 'fmp_delivery_time', $delivery_time );
        $wc_order->update_meta_data( 'fmp_pickup_date', $pickup_date );
        $wc_order->update_meta_data( 'fmp_pickup_time', $pickup_time );
        $wc_order->update_meta_data( 'fmp_dinein_date', $dinein_date );
        $wc_order->update_meta_data( 'fmp_dinein_time', $dinein_time );
        $wc_order->update_meta_data( 'fmp_dinein_table', $dinein_table );

        // Rebuild custom fields from defs so we only persist known keys.
        $defs = FnsPro::get_setting( 'fmp_order_custom_fields', [] );
        if ( ! empty( $defs ) ) {
            $custom_values = [];
            foreach ( $defs as $idx => $def ) {
                $input_id = 'fmp_custom_field_' . $idx;
                $type     = $def['type'] ?? 'text';
                $multiple = filter_var( $def['multiple'] ?? false, FILTER_VALIDATE_BOOLEAN );

                if ( 'select' === $type && $multiple ) {
                    // phpcs:ignore WordPress.Security.NonceVerification.Missing
                    $raw = isset( $_POST[ $input_id ] ) && is_array( $_POST[ $input_id ] ) ? wp_unslash( $_POST[ $input_id ] ) : [];
                    $custom_values[ 'custom_' . $idx ] = array_values( array_filter( array_map( 'sanitize_text_field', $raw ) ) );
                } else {
                    // phpcs:ignore WordPress.Security.NonceVerification.Missing
                    $custom_values[ 'custom_' . $idx ] = isset( $_POST[ $input_id ] ) ? sanitize_text_field( wp_unslash( $_POST[ $input_id ] ) ) : '';
                }
            }
            $wc_order->update_meta_data( '_fmp_custom_fields', $custom_values );
        }

        $wc_order->save();
    }
}
