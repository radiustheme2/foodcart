<?php
/**
 * Product Order Limit — WooCommerce product editor tab + save.
 *
 * Adds an "Order Limits" tab to the WC product data panels
 * allowing per-product unit caps per time slot.
 *
 * Gated by the global `fmp_enable_order_slot_limits` setting.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin\Metabox;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * ProductOrderLimit class.
 */
class ProductOrderLimit {

	use SingletonTrait;

	/**
	 * Init — register hooks.
	 *
	 * @return void
	 */
	public function init() {
		$settings = FnsPro::get_settings_option();
		$fm_type  = $settings['fm_food_menu_type'] ?? 'food_menu_post';

		$pickup_on   = ( $settings['enable_pickup'] ?? 'on' ) === 'on';
		$delivery_on = ( $settings['enable_delivery'] ?? 'on' ) === 'on';

		if (
			! TLPFoodMenu()->isWcActive()
			|| 'online_ordering' !== $fm_type
			|| 'on' !== ( $settings['fmp_enable_order_slot_limits'] ?? '' )
			|| ( ! $pickup_on && ! $delivery_on )
		) {
			return;
		}

		add_action( 'woocommerce_product_write_panel_tabs', [ $this, 'render_tab' ] );
		add_action( 'woocommerce_product_data_panels', [ $this, 'render_panel' ] );
		add_action( 'woocommerce_process_product_meta', [ $this, 'save' ] );
	}

	/**
	 * Render the tab link.
	 *
	 * @return void
	 */
	public function render_tab() {
		?>
		<li class="fmp-order-limit-tab show_if_simple show_if_variable">
			<a href="#fmp-order-limit-panel">
				<span><?php esc_html_e( 'Order Limits', 'food-menu-pro' ); ?></span>
			</a>
		</li>
		<?php
	}

	/**
	 * Render the panel content.
	 *
	 * @return void
	 */
	public function render_panel() {
		global $post;

		$product = wc_get_product( $post );

		if ( ! $product ) {
			return;
		}

		$product_id = $product->get_id();
		$enabled    = $product->get_meta( '_fmp_order_limit_enable' );
		$default    = $product->get_meta( '_fmp_order_limit_per_slot' );
		$default    = '' !== $default ? (int) $default : '';
		$by_loc     = (array) $product->get_meta( '_fmp_order_limit_by_location' );
		$settings   = FnsPro::get_settings_option();
		$multi_loc  = 'on' === ( $settings['fmp_food_location_popup'] ?? '' );

		// Get assigned locations only when multi-location is active.
		// If a parent and its child are both assigned, show only the child.
		$locations = [];

		if ( $multi_loc ) {
			$terms = get_the_terms( $product_id, 'tpl-food-location' );

			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				$assigned_ids = wp_list_pluck( $terms, 'term_id' );

				foreach ( $terms as $term ) {
					// Skip parent if any of its children are also assigned.
					if ( 0 === $term->parent ) {
						$children = get_term_children( $term->term_id, 'tpl-food-location' );

						if ( ! empty( $children ) && array_intersect( $children, $assigned_ids ) ) {
							continue;
						}
					}

					$locations[] = $term;
				}
			}
		}

		wp_nonce_field( 'fmp_order_limit_save', '_fmp_order_limit_nonce' );
		?>
		<div id="fmp-order-limit-panel" class="panel woocommerce_options_panel" style="display:none;">
			<div class="options_group">
				<p class="form-field">
					<label for="_fmp_order_limit_enable">
						<?php esc_html_e( 'Enable order limit', 'food-menu-pro' ); ?>
					</label>
					<input type="checkbox" id="_fmp_order_limit_enable" name="_fmp_order_limit_enable" value="on" <?php checked( $enabled, 'on' ); ?> />
					<span class="description"><?php esc_html_e( 'Cap how many units of this product can be ordered per time slot.', 'food-menu-pro' ); ?></span>
				</p>
			</div>

			<div class="options_group fmp-order-limit-fields" style="<?php echo 'on' !== $enabled ? 'display:none;' : ''; ?>">
				<p class="form-field">
					<label for="_fmp_order_limit_per_slot">
						<?php esc_html_e( 'Default max per slot', 'food-menu-pro' ); ?>
					</label>
					<input type="number" id="_fmp_order_limit_per_slot" name="_fmp_order_limit_per_slot" value="<?php echo esc_attr( $default ); ?>" min="0" step="1" style="width:80px;" />
					<span class="description"><?php esc_html_e( 'Maximum units allowed per time slot across all order types.', 'food-menu-pro' ); ?></span>
				</p>

				<?php if ( $multi_loc && ! empty( $locations ) ) : ?>
					<?php foreach ( $locations as $term ) : ?>
						<p class="form-field">
							<label><?php echo esc_html( $term->name ); ?></label>
							<input
								type="number"
								name="_fmp_order_limit_loc[<?php echo esc_attr( $term->term_id ); ?>]"
								value="<?php echo esc_attr( $by_loc[ $term->term_id ] ?? '' ); ?>"
								min="0"
								step="1"
								style="width:80px;"
								placeholder="<?php echo esc_attr( $default ?: '' ); ?>"
							/>
							<span class="description"><?php esc_html_e( 'Leave blank to use default.', 'food-menu-pro' ); ?></span>
						</p>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>

		<script>
			jQuery(function($){
				$('#_fmp_order_limit_enable').on('change', function(){
					$('.fmp-order-limit-fields').toggle(this.checked);
				});
			});
		</script>
		<style>
			.fmp-order-limit-tab a::before { content: '\f469'; font-family: dashicons; }
		</style>
		<?php
	}

	/**
	 * Save product meta.
	 *
	 * @param int $post_id Product ID.
	 *
	 * @return void
	 */
	public function save( $post_id ) {
		if ( ! isset( $_POST['_fmp_order_limit_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_fmp_order_limit_nonce'] ) ), 'fmp_order_limit_save' )
		) {
			return;
		}

		$product = wc_get_product( $post_id );

		if ( ! $product ) {
			return;
		}

		$enabled = ! empty( $_POST['_fmp_order_limit_enable'] ) ? 'on' : '';
		$cap     = ! empty( $_POST['_fmp_order_limit_per_slot'] ) ? absint( $_POST['_fmp_order_limit_per_slot'] ) : 0;

		$product->update_meta_data( '_fmp_order_limit_enable', $enabled );
		$product->update_meta_data( '_fmp_order_limit_per_slot', $cap );

		// Per-location overrides.
		$by_loc = [];

		if ( ! empty( $_POST['_fmp_order_limit_loc'] ) && is_array( $_POST['_fmp_order_limit_loc'] ) ) {
			$assigned_ids = wp_get_post_terms( $post_id, 'tpl-food-location', [ 'fields' => 'ids' ] );

			if ( ! is_wp_error( $assigned_ids ) ) {
				foreach ( $_POST['_fmp_order_limit_loc'] as $term_id => $value ) {
					$term_id = absint( $term_id );
					$value   = absint( $value );

					// Only accept term IDs actually assigned to this product.
					if ( $value > 0 && in_array( $term_id, $assigned_ids, true ) ) {
						$by_loc[ $term_id ] = $value;
					}
				}
			}
		}

		$product->update_meta_data( '_fmp_order_limit_by_location', $by_loc );
		$product->save();
	}
}
