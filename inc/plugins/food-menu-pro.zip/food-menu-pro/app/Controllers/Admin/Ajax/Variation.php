<?php
/**
 * Variation Ajax Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin\Ajax;

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Variation Ajax Class.
 */
class Variation {
	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'wp_ajax_fmp_add_variation_action', [ $this, 'addVariation' ] );
		add_action( 'wp_ajax_fmp_remove_variation_action', [ $this, 'removeVariation' ] );
		add_action( 'wp_ajax_fmp_save_variations_action', [ $this, 'saveVariation' ] );
	}

	/**
	 * Add Variation.
	 *
	 * @return void
	 */
	public function addVariation() {
		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			return;
		}

		$parent_id = ! empty( $_POST['parent_id'] ) ? absint( $_POST['parent_id'] ) : 0;

		if ( ! $parent_id || ! current_user_can( 'edit_post', $parent_id ) ) {
			die();
		}

		$variation_id = wp_insert_post(
			[
				'post_parent' => $parent_id,
				'post_type'   => 'fmp_variation',
			]
		);

		$variation_name  = '';
		$variation_price = '';
		$flug            = 'open';

		FnsPro::renderView(
			'variation',
			[
				'flug'            => $flug,
				'variation_id'    => $variation_id,
				'variation_name'  => $variation_name,
				'variation_price' => $variation_price,
			]
		);

		die();
	}

	/**
	 * Remove Variation.
	 *
	 * @return void
	 */
	public function removeVariation() {
		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			wp_send_json_error();
		}

		$error = true;
		$id    = ! empty( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;

		// Only variations, and only on a food item the user may edit — this used to delete any post.
		if ( ! self::can_edit_variation( $id ) ) {
			wp_send_json_error();
		}

		if ( wp_delete_post( $id, true ) ) {
			$error = false;
		}

		wp_send_json( [ 'error' => $error ] );
	}

	/**
	 * Save Variation.
	 *
	 * @return void
	 */
	public function saveVariation() {

		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			wp_send_json_error();
		}

		if ( empty( $_POST['data'] ) ) {
			wp_send_json_error();
		}

		$error = true;
		parse_str( wp_unslash( $_POST['data'] ), $data ); //phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		if ( ! empty( $data['variation'] ) ) {
			$error = false;

			foreach ( $data['variation'] as $id => $field ) {
				$id = absint( $id );

				// This used to write _price on any post ID (i.e. reprice any WooCommerce product).
				if ( ! self::can_edit_variation( $id ) ) {
					continue;
				}

				$name  = ! empty( $field['name'] ) ? sanitize_text_field( $field['name'] ) : null;
				$price = ! empty( $field['name'] ) && isset( $field['price'] ) && is_numeric( $field['price'] ) ? max( 0, (float) $field['price'] ) : null;
				update_post_meta( $id, '_name', $name );
				update_post_meta( $id, '_price', $price );
			}
		}

		wp_send_json( [ 'error' => $error ] );

		die();
	}

	/**
	 * Whether the current user may change this variation: it must be an fmp_variation
	 * whose parent food item they can edit.
	 *
	 * @param int $id Variation ID.
	 * @return bool
	 */
	private static function can_edit_variation( $id ) {
		$post = $id ? get_post( $id ) : null;

		if ( ! $post || 'fmp_variation' !== $post->post_type ) {
			return false;
		}

		return $post->post_parent ? current_user_can( 'edit_post', $post->post_parent ) : current_user_can( 'edit_posts' );
	}
}
