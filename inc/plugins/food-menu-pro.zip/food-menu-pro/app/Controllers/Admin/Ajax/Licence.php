<?php
/**
 * Licence Ajax Class.
 *
 * Handles license activation / deactivation for the React settings UI
 * (`src/settings/components/sections/LicenseSettings.jsx`). The hardened EDD
 * request/response handling mirrors the Post Grid Pro LicensingController.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin\Ajax;

use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

// phpcs:disable WordPress.Security.NonceVerification.Recommended

/**
 * Licence Ajax Class.
 */
class Licence {
	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		// React settings UI endpoints.
		add_action( 'wp_ajax_fmp_license_activate', [ $this, 'activate' ] );
		add_action( 'wp_ajax_fmp_license_deactivate', [ $this, 'deactivate' ] );

		// Legacy (classic admin settings page) endpoints — kept for backwards
		// compatibility with the old jQuery admin UI (assets/js/admin.min.js).
		add_action( 'wp_ajax_rtFmpManageLicencing', [ $this, 'manageLicence' ] );
		add_action( 'wp_ajax_rtFmp_active_Licence', [ $this, 'activeLicence' ] );
	}

	/**
	 * The plugin settings option array.
	 *
	 * @return array
	 */
	private function get_settings() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return is_array( $settings ) ? $settings : [];
	}

	/**
	 * Persist the plugin settings option array.
	 *
	 * @param array $settings Settings to store.
	 *
	 * @return void
	 */
	private function save_settings( $settings ) {
		update_option( TLPFoodMenu()->options['settings'], $settings );
	}

	/**
	 * Aggressively clean a pasted license key.
	 *
	 * Keys copied from email/PDF/chat can carry non-breaking spaces (U+00A0),
	 * zero-width characters (U+200B–U+200D, U+FEFF) or other invisible code
	 * points that look identical to ASCII but fail to match on the EDD server.
	 * trim() only removes ASCII whitespace, so strip the rest here.
	 *
	 * @param string $key Raw key string.
	 *
	 * @return string
	 */
	private function clean_license_key( $key ) {
		if ( ! is_string( $key ) ) {
			return '';
		}
		$cleaned = preg_replace( '/[\s\x{00A0}\x{200B}-\x{200D}\x{FEFF}\p{Cc}\p{Cf}]+/u', '', $key );
		// preg_replace returns null on invalid UTF-8 — fall back to ASCII-safe strip.
		if ( null === $cleaned ) {
			$cleaned = preg_replace( '/[^\x21-\x7E]/', '', $key );
		}

		return is_string( $cleaned ) ? $cleaned : '';
	}

	/**
	 * Treat the EDD response as a success only when explicitly so. Some proxies
	 * / maintenance pages return 200 with an unexpected payload that lacks
	 * `success`.
	 *
	 * @param object $license_data Decoded EDD payload.
	 *
	 * @return bool
	 */
	private function is_edd_success( $license_data ) {
		if ( ! is_object( $license_data ) || ! isset( $license_data->success ) ) {
			return false;
		}

		return (bool) $license_data->success;
	}

	/**
	 * Translate EDD error codes into user-facing messages.
	 *
	 * @param object $license_data Response payload from EDD.
	 *
	 * @return string
	 */
	private function get_error_message( $license_data ) {
		$error = isset( $license_data->error ) ? $license_data->error : '';

		switch ( $error ) {
			case 'expired':
				$expires = isset( $license_data->expires ) ? strtotime( $license_data->expires ) : false;
				return $expires
					? sprintf(
						/* translators: %s: expiration date */
						esc_html__( 'Your license key expired on %s.', 'food-menu-pro' ),
						date_i18n( get_option( 'date_format' ), $expires )
					)
					: esc_html__( 'Your license key has expired.', 'food-menu-pro' );
			case 'disabled':
			case 'revoked':
				return esc_html__( 'Your license key has been disabled.', 'food-menu-pro' );
			case 'missing':
				return esc_html__( 'Invalid license. Please double-check your key.', 'food-menu-pro' );
			case 'invalid':
			case 'site_inactive':
				return esc_html__( 'Your license is not active for this URL.', 'food-menu-pro' );
			case 'item_name_mismatch':
				return sprintf(
					/* translators: %s: product name */
					esc_html__( 'This appears to be an invalid license key for %s.', 'food-menu-pro' ),
					defined( 'EDD_FOOD_MENU_PRO_ITEM_NAME' ) ? EDD_FOOD_MENU_PRO_ITEM_NAME : 'Food Menu Pro'
				);
			case 'no_activations_left':
				$limit      = isset( $license_data->license_limit ) ? (int) $license_data->license_limit : 0;
				$site_count = isset( $license_data->site_count ) ? (int) $license_data->site_count : 0;
				if ( $limit > 0 ) {
					return sprintf(
						/* translators: 1: number of sites already activated, 2: total activation limit */
						esc_html__( 'Your license key has reached its activation limit (%1$d of %2$d sites used). Please deactivate the license on a site you no longer use, or upgrade your license to add more sites.', 'food-menu-pro' ),
						$site_count,
						$limit
					);
				}
				return esc_html__( 'Your license key has reached its activation limit. Please deactivate the license on a site you no longer use, or upgrade your license to add more sites.', 'food-menu-pro' );
			default:
				return esc_html__( 'An error occurred, please try again.', 'food-menu-pro' );
		}
	}

	/**
	 * Format expiration date for display.
	 *
	 * @param object $license_data Response payload from EDD.
	 *
	 * @return string|null
	 */
	private function format_expires( $license_data ) {
		if ( ! isset( $license_data->expires ) ) {
			return null;
		}
		if ( 'lifetime' === $license_data->expires ) {
			return esc_html__( 'Lifetime', 'food-menu-pro' );
		}
		$timestamp = strtotime( $license_data->expires );

		return $timestamp ? date_i18n( get_option( 'date_format' ), $timestamp ) : null;
	}

	/**
	 * Common pre-flight checks for the React licensing endpoints. Sends a JSON
	 * error and dies when the request can't proceed.
	 *
	 * @return void
	 */
	private function authorize() {
		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			wp_send_json_error( [
				'status' => 'invalid',
				'msg'    => esc_html__( 'Session expired. Please refresh the page and try again.', 'food-menu-pro' ),
			] );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [
				'status' => 'invalid',
				'msg'    => esc_html__( 'You do not have permission to manage the license.', 'food-menu-pro' ),
			] );
		}
	}

	/**
	 * Make an EDD API request.
	 *
	 * @param string $edd_action activate_license|deactivate_license|check_license.
	 * @param string $license    License key.
	 *
	 * @return array { object|null $data, string|null $error }
	 */
	private function edd_request( $edd_action, $license ) {
		$response = wp_remote_post(
			EDD_FOOD_MENU_PRO_STORE_URL,
			[
				'timeout'    => 30,
				'sslverify'  => false,
				'user-agent' => 'FoodMenuPro/' . FOOD_MENU_PRO_VERSION . '; ' . home_url(),
				'body'       => [
					'edd_action' => $edd_action,
					'license'    => $license,
					'item_id'    => EDD_FOOD_MENU_PRO_ITEM_ID,
					'url'        => home_url(),
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			return [
				'data'  => null,
				'error' => $this->describe_http_error( $response ),
			];
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return [
				'data'  => null,
				'error' => sprintf(
					/* translators: %d: HTTP status code */
					esc_html__( 'Licensing server returned an unexpected status (HTTP %d). Please try again in a few minutes.', 'food-menu-pro' ),
					(int) $code
				),
			];
		}

		$body = wp_remote_retrieve_body( $response );
		$data = $body ? json_decode( $body ) : null;
		if ( ! is_object( $data ) ) {
			return [
				'data'  => null,
				'error' => esc_html__( 'Unexpected response from the licensing server. Please try again.', 'food-menu-pro' ),
			];
		}

		return [
			'data'  => $data,
			'error' => null,
		];
	}

	/**
	 * Build an actionable message for common HTTP transport failures
	 * (blocked outbound, DNS, timeout, SSL).
	 *
	 * @param \WP_Error $err Error object from wp_remote_post.
	 *
	 * @return string
	 */
	private function describe_http_error( $err ) {
		$code     = $err->get_error_code();
		$message  = $err->get_error_message();
		$host     = wp_parse_url( EDD_FOOD_MENU_PRO_STORE_URL, PHP_URL_HOST );
		$host     = $host ? $host : 'www.radiustheme.com';
		$haystack = strtolower( (string) $message );

		$is_blocked = ( 'http_request_not_executed' === $code )
			|| false !== strpos( $haystack, 'blocked' )
			|| false !== strpos( $haystack, 'not allowed' );

		if ( $is_blocked ) {
			return sprintf(
				/* translators: %s: licensing server hostname */
				esc_html__( 'Outbound connections to %s are being blocked by your server or a security plugin. Please ask your host (or check WP_HTTP_BLOCK_EXTERNAL / WP_ACCESSIBLE_HOSTS in wp-config.php) to allow requests to this host, then try again.', 'food-menu-pro' ),
				$host
			);
		}

		if ( false !== strpos( $haystack, 'timed out' ) || false !== strpos( $haystack, 'timeout' ) ) {
			return sprintf(
				/* translators: %s: licensing server hostname */
				esc_html__( 'The licensing server (%s) did not respond in time. Please check your internet connection and try again.', 'food-menu-pro' ),
				$host
			);
		}

		if ( false !== strpos( $haystack, 'could not resolve' ) || false !== strpos( $haystack, 'resolve host' ) || false !== strpos( $haystack, 'name or service' ) ) {
			return sprintf(
				/* translators: %s: licensing server hostname */
				esc_html__( 'Could not resolve %s. Please check your server\'s DNS configuration and try again.', 'food-menu-pro' ),
				$host
			);
		}

		if ( false !== strpos( $haystack, 'ssl' ) || false !== strpos( $haystack, 'certificate' ) ) {
			return esc_html__( 'A secure connection to the licensing server could not be established. Please ensure your server\'s CA bundle is up to date.', 'food-menu-pro' );
		}

		return $message ? $message : esc_html__( 'An error occurred, please try again.', 'food-menu-pro' );
	}

	/**
	 * Activate the license (React endpoint).
	 *
	 * Reads the key from the POST so a freshly-typed key works without first
	 * saving the settings form, then persists the cleaned key + status.
	 *
	 * @return void
	 */
	public function activate() {
		$this->authorize();

		$settings    = $this->get_settings();
		$posted_key  = isset( $_REQUEST['license_key'] ) ? $this->clean_license_key( wp_unslash( $_REQUEST['license_key'] ) ) : '';
		$stored_key  = ! empty( $settings['license_key'] ) ? $this->clean_license_key( $settings['license_key'] ) : '';
		$license     = '' !== $posted_key ? $posted_key : $stored_key;

		if ( ! $license ) {
			wp_send_json_error( [
				'status' => 'invalid',
				'msg'    => esc_html__( 'Please enter your license key.', 'food-menu-pro' ),
			] );
		}

		$result = $this->edd_request( 'activate_license', $license );
		if ( $result['error'] ) {
			wp_send_json_error( [
				'status' => ! empty( $settings['license_status'] ) ? $settings['license_status'] : 'invalid',
				'msg'    => $result['error'],
			] );
		}

		$license_data = $result['data'];

		// Validate first — never write an unvalidated key to the DB. On a
		// failed check we leave settings untouched (the typed value still lives
		// in the form field for the session), so the stored license_key is
		// always either empty or a key that genuinely activated.
		if ( ! $this->is_edd_success( $license_data ) ) {
			wp_send_json_error( [
				'status' => 'invalid',
				'msg'    => $this->get_error_message( $license_data ),
			] );
		}

		// Persist the validated key + status only after a successful check.
		$settings['license_key']    = $license;
		$settings['license_status'] = isset( $license_data->license ) ? $license_data->license : 'valid';
		$this->save_settings( $settings );

		wp_send_json_success( [
			'status'  => 'valid',
			'msg'     => esc_html__( 'License successfully activated.', 'food-menu-pro' ),
			'expires' => $this->format_expires( $license_data ),
		] );
	}

	/**
	 * Deactivate the license (React endpoint).
	 *
	 * @return void
	 */
	public function deactivate() {
		$this->authorize();

		$settings   = $this->get_settings();
		$posted_key = isset( $_REQUEST['license_key'] ) ? $this->clean_license_key( wp_unslash( $_REQUEST['license_key'] ) ) : '';
		$stored_key = ! empty( $settings['license_key'] ) ? $this->clean_license_key( $settings['license_key'] ) : '';
		$license    = '' !== $stored_key ? $stored_key : $posted_key;
		$current_st = ! empty( $settings['license_status'] ) ? $settings['license_status'] : 'invalid';

		if ( ! $license ) {
			// Nothing to deactivate — just clear local status.
			unset( $settings['license_status'] );
			$this->save_settings( $settings );

			wp_send_json_success( [
				'status' => 'invalid',
				'msg'    => esc_html__( 'License deactivated.', 'food-menu-pro' ),
			] );
		}

		$result = $this->edd_request( 'deactivate_license', $license );

		// Only a transport failure (network / blocked / timeout) keeps the
		// current state and asks the admin to retry — that's genuinely
		// inconclusive. A normal 200 response is always treated as final below.
		if ( $result['error'] ) {
			wp_send_json_error( [
				'status' => $current_st,
				'msg'    => $result['error'],
			] );
		}

		$license_data = $result['data'];

		// Clear the local activation regardless of whether EDD reports
		// 'deactivated' or 'failed'. A 'failed' result means the stored key no
		// longer matches an active remote license — typically because the key
		// was edited — so the only sane recovery is to clear it locally. This
		// guarantees the admin can never get stuck "Active" with an
		// unmatchable key, and can re-enter / re-activate the correct one.
		unset( $settings['license_status'] );
		$this->save_settings( $settings );

		$remote_matched = ! ( isset( $license_data->license ) && 'failed' === $license_data->license );

		wp_send_json_success( [
			'status' => 'invalid',
			'msg'    => $remote_matched
				? esc_html__( 'License successfully deactivated.', 'food-menu-pro' )
				: esc_html__( 'License deactivated on this site. The stored key did not match an active license on the server (it may have been changed) — re-enter your correct key to activate again.', 'food-menu-pro' ),
		] );
	}

	/**
	 * Manage Licence (legacy classic-admin endpoint).
	 *
	 * Kept for the old jQuery settings page. New UI uses activate()/deactivate().
	 *
	 * @return void
	 */
	public function manageLicence() {
		$error = true;
		$name  = $value = $class = $message = null;

		if ( current_user_can( 'manage_options' ) && wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			$settings = $this->get_settings();
			$license  = ! empty( $settings['license_key'] ) ? $this->clean_license_key( $settings['license_key'] ) : '';
			$type     = isset( $_REQUEST['type'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['type'] ) ) : '';

			if ( 'license_activate' === $type ) {
				$result = $this->edd_request( 'activate_license', $license );
				if ( $result['error'] ) {
					$message = $result['error'];
				} elseif ( ! $this->is_edd_success( $result['data'] ) ) {
					$message = $this->get_error_message( $result['data'] );
				} else {
					$settings['license_status'] = isset( $result['data']->license ) ? $result['data']->license : 'valid';
					$this->save_settings( $settings );
					$error = false;
					$name  = 'license_deactivate';
					$value = esc_html__( 'Deactivate License', 'food-menu-pro' );
					$class = 'button-primary';
				}
			} elseif ( 'license_deactivate' === $type ) {
				$result = $this->edd_request( 'deactivate_license', $license );
				if ( $result['error'] ) {
					$message = $result['error'];
				} else {
					unset( $settings['license_status'] );
					$this->save_settings( $settings );
					$error = false;
					$name  = 'license_activate';
					$value = esc_html__( 'Activate License', 'food-menu-pro' );
					$class = 'button-primary';
				}
			}
		} else {
			$message = esc_html__( 'Security Error !!', 'food-menu-pro' );
		}

		wp_send_json( [
			'error' => $error,
			'msg'   => $message,
			'name'  => $name,
			'value' => $value,
			'class' => $class,
		] );
	}

	/**
	 * Active Licence (legacy classic-admin endpoint).
	 *
	 * @return void
	 */
	public function activeLicence() {
		$error = true;
		$html  = $message = null;

		if ( current_user_can( 'manage_options' ) && wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			$settings = $this->get_settings();
			$license  = ! empty( $settings['license_key'] ) ? $this->clean_license_key( $settings['license_key'] ) : '';

			$result = $this->edd_request( 'activate_license', $license );
			if ( $result['error'] ) {
				$message = $result['error'];
			} elseif ( ! $this->is_edd_success( $result['data'] ) ) {
				$message = $this->get_error_message( $result['data'] );
			} else {
				$settings['license_status'] = isset( $result['data']->license ) ? $result['data']->license : 'valid';
				$this->save_settings( $settings );
				$error   = false;
				$message = esc_html__( 'Successfully activated', 'food-menu-pro' );
				$html    = ( 'valid' === $settings['license_status'] )
					? "<input type='submit' class='button-secondary rt-licensing-btn danger' name='license_deactivate' value='Deactivate License'/>"
					: "<input type='submit' class='button-secondary rt-licensing-btn button-primary' name='license_activate' value='Activate License'/>";
			}
		} else {
			$message = esc_html__( 'Session Error !!', 'food-menu-pro' );
		}

		wp_send_json( [
			'error' => $error,
			'msg'   => $message,
			'html'  => $html,
		] );
	}
}
