<?php
/**
 * Sorting Ajax Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin\Ajax;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;
//phpcs:disable

/**
 * Sorting Ajax Class.
 */
class Sorting {
	use \RT\FoodMenuPro\Traits\SingletonTrait;

	private $condition;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		\add_action( 'wp_ajax_fmp-logo-update-menu-order', [ $this, 'logoUpdateOrder' ] );
		\add_action( 'wp_ajax_fmp-cat-update-order', [ $this, 'catUpdateOrder' ] );
	}

	/**
	 * Logo order update.
	 *
	 * @return void|bool
	 */
	public function logoUpdateOrder_old() {
		global $wpdb;

		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			return false;
		}

		$data = ( ! empty( $_POST['post'] ) ? wp_unslash( $_POST['post'] ) : [] );

		if ( ! is_array( $data ) ) {
			return false;
		}

		$id_arr = [];

		foreach ( $data as $id ) {
			$id_arr[] = $id;
		}

		$menu_order_arr = [];

		foreach ( $id_arr as $id ) {
			$menu_order_arr[] = $wpdb->get_var( "SELECT menu_order FROM $wpdb->posts WHERE ID = " . intval( $id ) );
		}

		sort( $menu_order_arr );

		foreach ( $data as $position => $id ) {
			$wpdb->update(
				$wpdb->posts,
				[ 'menu_order' => $menu_order_arr[ $position ] ],
				[ 'ID' => intval( $id ) ]
			);
		}

		wp_send_json_success();
	}

	public function logoUpdateOrder() {
		set_time_limit( 600 );
		global $wpdb;

		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			return false;
		}

		$post_type = preg_replace( '/[^a-zA-Z0-9_\-]/', '', sanitize_text_field( wp_unslash( $_POST['post_type'] ) ) );
		$paged     = filter_var( sanitize_text_field( wp_unslash( $_POST['paged'] ) ), FILTER_SANITIZE_NUMBER_INT );

		parse_str( sanitize_text_field( wp_unslash( $_POST['order'] ) ), $data );

		if ( ! is_array( $data ) || count( $data ) < 1 ) {
			die();
		}

		// retrieve a list of all objects
		$mysql_query = $wpdb->prepare(
			'SELECT ID FROM ' . $wpdb->posts . " 
                        WHERE post_type = %s AND post_status IN ('publish', 'pending', 'draft', 'private', 'future', 'inherit')
                        ORDER BY menu_order, post_date DESC",
			$post_type
		);
		$results     = $wpdb->get_results( $mysql_query );

		if ( ! is_array( $results ) || count( $results ) < 1 ) {
			die();
		}

		// create the list of ID's
		$objects_ids = array();
		foreach ( $results as $result ) {
			$objects_ids[] = (int) $result->ID;
		}

		global $userdata;
		if ( $post_type === 'attachment' ) {
			$objects_per_page = get_user_meta( $userdata->ID, 'upload_per_page', true );
		} else {
			$objects_per_page = get_user_meta( $userdata->ID, 'edit_' . $post_type . '_per_page', true );
		}
		$objects_per_page = apply_filters( "edit_{$post_type}_per_page", $objects_per_page );
		if ( empty( $objects_per_page ) ) {
			$objects_per_page = 20;
		}

		$edit_start_at_offset = $paged * $objects_per_page - $objects_per_page; // offset
		$index                = 0;

		for ( $i = $edit_start_at_offset; $i < ( $edit_start_at_offset + $objects_per_page ); $i++ ) {
			if ( ! isset( $objects_ids[ $i ] ) ) {
				break;
			}

			$objects_ids[ $i ] = (int) $data['post'][ $index ];
			$index++;
		}

		// update the menu_order within database

		foreach ( $objects_ids as $menu_order => $id ) {
			$data = array(
				'menu_order' => $menu_order,
			);

			// Deprecated, rely on pto/save-ajax-order
			$data = apply_filters( 'post-types-order_save-ajax-order', $data, $menu_order, $id );

			$data = apply_filters( 'pto/save-ajax-order', $data, $menu_order, $id );

			$wpdb->update( $wpdb->posts, $data, array( 'ID' => $id ) );

			clean_post_cache( $id );
		}

		do_action( 'fmp_pro/order_update_complete' );

		FnsPro::site_cache_clear();
	}

	/**
	 * Category order update.
	 *
	 * @return void|bool
	 */
	public function catUpdateOrder() {

		$data = ( ! empty( $_POST['tag'] ) ? $_POST['tag'] : [] ); //phpcs:ignore

		if ( ! is_array( $data ) ) {
			return false;
		}
		// Does not need this code remove after testing.
		$order_arr = [];
		foreach ( $data as $id ) {
			$order_arr[] = get_term_meta( $id, '_order', true );
		}
		asort( $order_arr );

		foreach ( $data as $position => $id ) {
			update_term_meta( $id, '_order', $position + 1 );
		}

		wp_send_json_success();
	}
}
