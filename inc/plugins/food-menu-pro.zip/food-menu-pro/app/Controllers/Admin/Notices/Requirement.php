<?php
/**
 * Requirement Notice Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin\Notices;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Requirement Notice Class.
 */
class Requirement {
	/**
	 * Class Init.
	 *
	 * @return void
	 */
	public static function notice() {
		add_action( 'admin_init', [ __CLASS__, 'render' ] );
	}

	/**
	 * Render Notice.
	 *
	 * @return void
	 */
	public static function render() {
		$link_free = add_query_arg(
			[
				'tab'       => 'plugin-information',
				'plugin'    => 'tlp-food-menu',
				'TB_iframe' => 'true',
				'width'     => '640',
				'height'    => '500',
			],
			admin_url( 'plugin-install.php' )
		);
		$version = defined( 'FOOD_MENU_PRO_REQUIRED_FREE_VERSION' ) ? FOOD_MENU_PRO_REQUIRED_FREE_VERSION : '6.0.0';
		?>
		<div class="notice notice-warning fmp-version-notice" style="border-left: 4px solid #dba617; background: #fff; padding: 16px 20px; margin: 5px 0 15px; box-shadow: 0 1px 4px rgba(0,0,0,.08); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
			<div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
				<span style="display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; background: #fef3cd; border-radius: 50%;">
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#dba617" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
				</span>
				<strong style="font-size: 14px; color: #1d2327;">Food Menu Pro — Missing Requirement</strong>
			</div>
			<p style="margin: 0 0 12px; color: #50575e; font-size: 13px; line-height: 1.6;">
				<strong>Food Menu Pro</strong> requires the <strong>Food Menu</strong> (free) plugin version
				<code style="background: #f0f0f1; padding: 2px 6px; border-radius: 3px; font-size: 12px;"><?php echo esc_html( $version ); ?></code>
				or higher to be installed and activated.
			</p>
			<a href="<?php echo esc_url( $link_free ); ?>" class="thickbox open-plugin-details-modal" style="display: inline-block; padding: 6px 16px; background: #2271b1; color: #fff; text-decoration: none; border-radius: 4px; font-size: 13px; font-weight: 500;">Install Food Menu</a>
		</div>
		<?php
	}
}
