<?php
/**
 * CPT Admin Columns Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

//phpcs:disable PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage
/**
 * Admin Columns Class.
 */
class AdminColumns {

	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'restrict_manage_posts', [ $this, 'add_taxonomy_filters' ] );
		add_filter( 'manage_edit-food-menu_columns', [ $this, 'arrange_fmp_columns' ] );
		add_action( 'manage_food-menu_posts_custom_column', [ $this, 'manage_fmp_columns' ], 10, 2 );

		// Add cat columns.
		add_filter( 'manage_edit-food-menu-cat_columns', [ $this, 'fmp_cat_columns' ] );
		add_filter( 'manage_food-menu-cat_custom_column', [ $this, 'fmp_cat_column' ], 10, 3 );
		add_filter( 'manage_edit-food-menu-cat_sortable_columns', [ $this, 'fmp_cat_columns_sortable' ] );
		add_action( 'pre_get_terms', [ $this, 'fmp_cat_sort_terms' ] );
		add_action( 'created_term', [ $this, 'add_default_order_meta_to_term' ], 10, 3 );
	}

	/**
	 * Get the maximum _order value for a specific taxonomy.
	 *
	 * @param $taxonomy
	 *
	 * @return int|string
	 */
	public function get_max_order_value_for_taxonomy( $taxonomy ) {
		global $wpdb;

		// Query to get the maximum _order value for a specific taxonomy.

		// phpcs:disable
		$max_order = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT MAX(CAST(tm.meta_value AS UNSIGNED)) 
	            FROM {$wpdb->termmeta} tm
	            INNER JOIN {$wpdb->term_taxonomy} tt ON tm.term_id = tt.term_id
	            WHERE tt.taxonomy = %s AND tm.meta_key = %s",
				$taxonomy,
				'_order'
			)
		);
		// phpcs:enable

		// If there are no _order meta values, return 0.
		return $max_order !== null ? $max_order : 0;
	}

	/**
	 * Add default _order meta to a term.
	 *
	 * @param $term_id
	 * @param $tt_id
	 * @param $taxonomy
	 *
	 * @return void
	 */
	public function add_default_order_meta_to_term( $term_id, $tt_id, $taxonomy ) {
		// Only add the default meta for the specific taxonomy, e.g., 'category'.
		$order_n = $this->get_max_order_value_for_taxonomy( 'food-menu-cat' );
		if ( 'food-menu-cat' === $taxonomy ) {
			// Check if the term already has the _order meta key.
			$order_meta = get_term_meta( $term_id, '_order', true );
			if ( '' === $order_meta ) {
				// If the meta key doesn't exist, add it with a default value of 0.
				add_term_meta( $term_id, '_order', ( $order_n + 1 ), true );
			}
		}
	}

	public function fmp_cat_sort_terms( $query ) {
		$taxonomy_name = $query->query_vars['taxonomy'][0] ?? '';
		if ( ! is_admin() || $taxonomy_name !== 'food-menu-cat' ) {
			return;
		}

		$orderby = ! empty( $_GET['orderby'] ) ? sanitize_text_field( wp_unslash( $_GET['orderby'] ) ) : ''; //phpcs:ignore
		$order   = ! empty( $_GET['order'] ) ? sanitize_text_field( wp_unslash( $_GET['order'] ) ) : 'ASC'; //phpcs:ignore

		if ( $orderby === '_order' ) {
			if ( empty( $query->meta_query ) ) {
				$query->meta_query = new WP_Meta_Query();
			}

			$query->meta_query->queries[] = [
				'relation' => 'OR',
				[
					'key'     => '_order',
					'compare' => 'EXISTS',
				],
				[
					'key'     => '_order',
					'compare' => 'NOT EXISTS',
				],
			];

			$query->query_vars['orderby']  = 'meta_value_num';
			$query->query_vars['meta_key'] = '_order';
			$query->query_vars['order']    = strtoupper( $order );
		}
	}
	public function fmp_cat_sort_terms_old( $query ) {
		$taxonomy_name = $query->query_vars['taxonomy'][0] ?? '';

		if ( ! is_admin() ) {
			return;
		}

		if ( ! empty( $taxonomy_name ) && 'food-menu-cat' === $taxonomy_name ) {
			if ( empty( $_GET['orderby'] ) || '_order' === $_GET['orderby'] ) { //phpcs:ignore
				$query->meta_query->queries[]  = [
					'relation' => 'OR',
					[
						'key'     => '_order',
						'compare' => 'EXISTS',
					],
					[
						'key'     => '_order',
						'compare' => 'NOT EXISTS',
					],
				];
				$query->meta_query->relation   = 'OR';
				$query->query_vars['orderby']  = 'meta_value_num';
				$query->query_vars['meta_key'] = '_order'; //phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			}
		}
	}

	public function fmp_cat_columns_sortable( $columns ) {
		$columns['_fmp_order'] = '_order';

		return $columns;
	}

	public function add_taxonomy_filters() {
		global $typenow;

		// Must set this to the post type you want the filter(s) displayed on.
		if ( TLPFoodMenu()->post_type !== $typenow ) {
			return;
		}

		foreach ( TLPFoodMenu()->taxonomies as $tax_slug ) {
			 $this->build_taxonomy_filter( $tax_slug );
		}
	}

	/**
	 * Build an individual dropdown filter.
	 *
	 * @param string $tax_slug Taxonomy slug to build filter for.
	 *
	 * @return string Markup, or empty string if taxonomy has no terms.
	 */
	protected function build_taxonomy_filter( $tax_slug ) {
		$terms = get_terms( $tax_slug );

		if ( is_wp_error( $terms ) || 0 == count( $terms ) ) {
			return '';
		}

		$tax_name         = $this->get_taxonomy_name_from_slug( $tax_slug );
		$current_tax_slug = $_GET[ $tax_slug ] ?? FALSE; //phpcs:ignore
		$filter           = '<select name="' . esc_attr( $tax_slug ) . '" id="' . esc_attr( $tax_slug ) . '" class="postform">';
		$filter          .= '<option value="0">' . esc_html( $tax_name ) . '</option>';
		$filter          .= $this->build_term_options( $terms, $current_tax_slug );
		$filter          .= '</select>';

		$allowed_html = [
			'select' => [
				'name'  => [],
				'id'    => [],
				'class' => [],
			],
			'option' => [
				'value' => [],
			],
			'amp'    => [],
		];

		echo wp_kses( $filter, $allowed_html );
		// return $filter;
	}

	/**
	 * Get the friendly taxonomy name, if given a taxonomy slug.
	 *
	 * @param string $tax_slug Taxonomy slug.
	 *
	 * @return string Friendly name of taxonomy, or empty string if not a valid taxonomy.
	 */
	protected function get_taxonomy_name_from_slug( $tax_slug ) {
		$tax_obj = get_taxonomy( $tax_slug );
		if ( ! $tax_obj ) {
			return '';
		}

		return $tax_obj->labels->name;
	}

	/**
	 * Build a series of option elements from an array.
	 *
	 * Also checks to see if one of the options is selected.
	 *
	 * @param array  $terms Array of term objects.
	 * @param string $current_tax_slug Slug of currently selected term.
	 *
	 * @return string Markup.
	 */
	protected function build_term_options( $terms, $current_tax_slug ) {
		$options = '';

		foreach ( $terms as $term ) {
			$options .= sprintf(
				"<option value='%s' %s />%s</option>",
				esc_attr( $term->slug ),
				selected( $current_tax_slug, $term->slug, false ),
				esc_html( $term->name . '(' . $term->count . ')' )
			);
		}

		return $options;
	}

	public function arrange_fmp_columns( $columns ) {
		if ( isset( $columns['title'] ) ) {
			unset( $columns['title'] );
		}

		$cols          = [];
		$cols['cb']    = $columns['cb'];
		$cols['thumb'] = '<span class="fmp-image tips" data-tip="' . esc_attr__( 'Image', 'food-menu-pro' ) . '">' . esc_html__( 'Image', 'food-menu-pro' ) . '</span>';
		$cols['title'] = esc_html__( 'Name', 'food-menu-pro' );
		$cols['stock'] = esc_html__( 'Stock', 'food-menu-pro' );
		$cols['price'] = esc_html__( 'Price', 'food-menu-pro' );

		if ( isset( $columns['cb'] ) ) {
			unset( $columns['cb'] );
		}

		return array_merge( $cols, $columns );
	}

	public function manage_fmp_columns( $column, $post_id ) {
		switch ( $column ) {
			case 'thumb':
				echo get_the_post_thumbnail( $post_id, 'thumbnail' );
				break;

			case 'stock':
				echo wp_kses_post( FnsPro::getStockStatus( $post_id ) );
				break;

			case 'price':
				$price = FnsPro::fmpHtmlPrice( $post_id );
				echo ! empty( $price ) ? wp_kses_post( $price ) : '<span class="na">' . esc_html__( '–', 'food-menu-pro' ) . '</span>';
				break;
		}
	}

	/**
	 * Thumbnail column added to category admin.
	 *
	 * @param mixed $columns
	 *
	 * @return array
	 */
	public function fmp_cat_columns( $columns ) {
		$new_columns = [];

		if ( isset( $columns['cb'] ) ) {
			$new_columns['cb'] = $columns['cb'];
			unset( $columns['cb'] );
		}

		$new_columns['_fmp_thumb']       = esc_html__( 'Image', 'food-menu-pro' );
		$new_columns_order['_fmp_order'] = esc_html__( 'Order', 'food-menu-pro' );

		return array_merge( $new_columns, $columns, $new_columns_order );
	}

	/**
	 * Thumbnail column value added to category admin.
	 *
	 * @param string $columns
	 * @param string $column
	 * @param int    $id
	 *
	 * @return array
	 */
	public function fmp_cat_column( $columns, $column, $id ) {
		if ( '_fmp_thumb' == $column ) {
			$thumbnail_id = get_term_meta( $id, 'fmp_cat_thumbnail_id', true );

			if ( $thumbnail_id ) {
				$image = wp_get_attachment_thumb_url( $thumbnail_id );
			} else {
				$image = Fns::placeholder_img_src();
			}

			// Prevent esc_url from breaking spaces in urls for image embeds
			// Ref: https://core.trac.wordpress.org/ticket/23605.
			$image    = str_replace( ' ', '%20', $image );
			$columns .= '<img src="' . esc_url( $image ) . '" alt="' . esc_attr__( 'Thumbnail', 'food-menu-pro' ) . '" class="wp-post-image" height="48" width="48" />'; //phpcs:disable
		}

		if ( '_fmp_order' == $column ) {
			$columns .= absint( get_term_meta( $id, '_order', true ) );
		}

		return $columns;
	}
}
