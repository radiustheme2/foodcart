<?php
/**
 * Pro fields for the Food Menu CSV Import / Export.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Admin;

use RT\FoodMenuPro\Traits\SingletonTrait;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Adds Pro food fields to the free plugin's importer / exporter
 * (`RT\FoodMenu\Controllers\Admin\ImportExport`, free 6.0.7.1+), and Pro
 * options to the free Settings → Import / Export file.
 * On an older free plugin the filters never fire, so this does nothing.
 */
class ImportExportPro {

	use SingletonTrait;

	/**
	 * Free importer class.
	 */
	const IMPORTER = 'RT\FoodMenu\Controllers\Admin\ImportExport';

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		add_filter( 'tlp_fm_import_export_fields', [ $this, 'fields' ] );
		add_action( 'tlp_fm_after_import_row', [ $this, 'after_import_row' ], 10, 4 );
		add_filter( 'tlp_fm_settings_export_options', [ $this, 'settings_options' ] );
	}

	/**
	 * Standalone Pro options included in the Settings → Import / Export file.
	 *
	 * @param array $options Option names.
	 * @return array
	 */
	public function settings_options( $options ) {
		$options[] = 'fmp_custom_order_statuses';
		$options[] = 'fmp_default_status_overrides';

		return $options;
	}

	/**
	 * Pro fields.
	 *
	 * @param array $fields Fields.
	 * @return array
	 */
	public function fields( $fields ) {
		$taxonomies = TLPFoodMenu()->taxonomies;

		$pro = [
			'sale_price'   => [
				'label'   => esc_html__( 'Sale Price', 'food-menu-pro' ),
				'type'    => 'meta',
				'key'     => '_sale_price',
				'format'  => 'price',
				'aliases' => [ 'sale price', 'discount price', 'offer price', 'special price' ],
			],
			'stock_status' => [
				'label'   => esc_html__( 'Stock Status', 'food-menu-pro' ),
				'type'    => 'meta',
				'key'     => '_stock_status',
				'format'  => 'options',
				'options' => [
					'instock'    => true,
					'outofstock' => true,
				],
				'aliases' => [ 'stock status', 'stock', 'in stock', 'availability' ],
			],
		];

		if ( ! empty( $taxonomies['tag'] ) ) {
			$pro['tags'] = [
				'label'   => esc_html__( 'Tags', 'food-menu-pro' ),
				'type'    => 'taxonomy',
				'key'     => $taxonomies['tag'],
				'aliases' => [ 'tags', 'tag', 'labels' ],
			];
		}

		$pro['gallery'] = [
			'label'   => esc_html__( 'Gallery Images', 'food-menu-pro' ),
			'type'    => 'images',
			'key'     => '_fmp_image_gallery',
			'aliases' => [ 'gallery', 'gallery images', 'additional images' ],
		];

		if ( ! empty( $taxonomies['ingredient'] ) ) {
			$pro['ingredients'] = [
				'label'     => esc_html__( 'Ingredients', 'food-menu-pro' ),
				'type'      => 'custom',
				'key'       => '_ingredient',
				'taxonomy'  => $taxonomies['ingredient'],
				'status'    => '_ingredient_status',
				'aliases'   => [ 'ingredients', 'ingredient' ],
				'export_cb' => [ $this, 'export_list' ],
				'import_cb' => [ $this, 'import_list' ],
			];
		}

		if ( ! empty( $taxonomies['nutrition'] ) ) {
			$pro['nutrition'] = [
				'label'     => esc_html__( 'Nutrition', 'food-menu-pro' ),
				'type'      => 'custom',
				'key'       => '_nutrition',
				'taxonomy'  => $taxonomies['nutrition'],
				'status'    => '_nutrition_status',
				'aliases'   => [ 'nutrition', 'nutritions', 'nutrition facts' ],
				'export_cb' => [ $this, 'export_list' ],
				'import_cb' => [ $this, 'import_list' ],
			];
		}

		// Place Pro fields before "Featured Image" so the columns read naturally.
		$position = array_search( 'image', array_keys( $fields ), true );

		if ( false === $position ) {
			return array_merge( $fields, $pro );
		}

		return array_merge( array_slice( $fields, 0, $position, true ), $pro, array_slice( $fields, $position, null, true ) );
	}

	/**
	 * Export ingredients / nutrition as "Flour:200:g, Salt".
	 *
	 * @param \WP_Post $post Post.
	 * @param array    $field Field.
	 * @return string
	 */
	public function export_list( $post, $field ) {
		$items = get_post_meta( $post->ID, $field['key'] );
		$out   = [];

		foreach ( $items as $item ) {
			$term = ! empty( $item['id'] ) ? get_term( $item['id'], $field['taxonomy'] ) : null;

			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}

			$unit  = ! empty( $item['unit_id'] ) ? get_term( $item['unit_id'], TLPFoodMenu()->taxonomies['unit'] ) : null;
			$parts = [ $term->name ];

			if ( isset( $item['value'] ) && '' !== (string) $item['value'] ) {
				$parts[] = $item['value'];

				if ( $unit && ! is_wp_error( $unit ) ) {
					$parts[] = $unit->name;
				}
			}

			$out[] = str_replace( ',', '\\,', implode( ':', $parts ) );
		}

		return implode( ', ', $out );
	}

	/**
	 * Import ingredients / nutrition from "Flour:200:g, Salt". Replaces the list.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $value Value.
	 * @param array  $field Field.
	 * @param array  $options Import options.
	 * @return true|\WP_Error
	 */
	public function import_list( $post_id, $value, $field, $options ) {
		if ( ! class_exists( self::IMPORTER ) || ! method_exists( self::IMPORTER, 'get_term_id' ) || ! method_exists( self::IMPORTER, 'split_list' ) ) {
			return true;
		}

		$importer = call_user_func( [ self::IMPORTER, 'get_instance' ] );
		$items    = [];
		$errors   = [];

		foreach ( $importer->split_list( $value ) as $entry ) {
			$parts = array_map( 'trim', explode( ':', $entry, 3 ) );
			$term  = $importer->get_term_id( sanitize_text_field( $parts[0] ), $field['taxonomy'], $options['create_terms'] );

			if ( is_wp_error( $term ) ) {
				$errors[] = $term->get_error_message();
				continue;
			}

			$unit = null;

			if ( ! empty( $parts[2] ) && ! empty( TLPFoodMenu()->taxonomies['unit'] ) ) {
				$unit = $importer->get_term_id( sanitize_text_field( $parts[2] ), TLPFoodMenu()->taxonomies['unit'], $options['create_terms'] );

				if ( is_wp_error( $unit ) ) {
					$errors[] = $unit->get_error_message();
					$unit     = null;
				}
			}

			$items[] = [
				'id'      => $term,
				'unit_id' => $unit,
				'value'   => isset( $parts[1] ) && '' !== $parts[1] ? sanitize_text_field( $parts[1] ) : null,
			];
		}

		if ( $items ) {
			delete_post_meta( $post_id, $field['key'] );

			foreach ( $items as $item ) {
				add_post_meta( $post_id, $field['key'], $item );
			}

			// The tab only shows when enabled; turn it on unless it was switched off.
			if ( ! metadata_exists( 'post', $post_id, $field['status'] ) ) {
				update_post_meta( $post_id, $field['status'], 1 );
			}
		}

		return $errors ? new \WP_Error( 'list', implode( ' ', $errors ) ) : true;
	}

	/**
	 * New items get the same defaults the edit screen saves.
	 *
	 * @param int   $post_id Post ID.
	 * @param array $data Row data.
	 * @param array $options Options.
	 * @param bool  $is_update Whether an existing item was updated.
	 * @return void
	 */
	public function after_import_row( $post_id, $data, $options, $is_update ) {
		if ( $is_update ) {
			return;
		}

		$defaults = [
			'_fmp_type'          => 'simple',
			'_stock_status'      => 'instock',
			'_ingredient_status' => 1,
			'_nutrition_status'  => 1,
		];

		foreach ( $defaults as $key => $value ) {
			if ( ! metadata_exists( 'post', $post_id, $key ) ) {
				update_post_meta( $post_id, $key, $value );
			}
		}
	}
}
