<?php
namespace RT\FoodMenuPro\Controllers\SpecialMenu;

use RT\FoodMenuPro\Helpers\FnsPro;

defined( 'ABSPATH' ) || exit();

/**
 * Special Menu Fns class
 */
class SpecialMenuFns {

	/**
	 * Menu Settings fields
	 *
	 * @return array
	 */
	public static function settings_fields() {
		$settings          = FnsPro::get_settings_option();
		$fmp_special_menus = $settings['fmp_special_menus'] ?? [];
		return apply_filters(
			'fmp/special_menu_settings/fields',
			[
				'fmp_enable_menu'             => [
					'label'       => esc_html__( 'Enable Special Menu?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable special menu?', 'food-menu-pro' ),
					'value'       => $settings['fmp_enable_menu'] ?? 'on',
				],
				'fmp_menu_popup_duration'     => [
					'label'       => esc_html__( 'Popup End Date', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'Special menu popup available from the current date to the end date', 'food-menu-pro' ),
					'value'       => $settings['fmp_menu_popup_duration'] ?? '',
				],
				'fmp_menu_title'              => [
					'label'       => esc_html__( 'Special Menu Title', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'Special menu day title', 'food-menu-pro' ),
					'value'       => $settings['fmp_menu_title'] ?? '',
				],
				'fmp_menu_offer'              => [
					'label'       => esc_html__( 'Discount / Offer', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'Special menu discount or offer Eg: 30% off', 'food-menu-pro' ),
					'value'       => $settings['fmp_menu_offer'] ?? '',
				],
				'fmp_menu_duration'           => [
					'label'       => esc_html__( 'Special Menu Text', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'Special menu discount duration Eg: Special menu offer in 3 day', 'food-menu-pro' ),
					'value'       => $settings['fmp_menu_duration'] ?? '',
				],

				'fmp_special_menus'           => [
					'label'       => esc_html__( 'Include Menus', 'food-menu-pro' ),
					'type'        => 'select',
					'multiple'    => true,
					'class'       => 'fmp-ajax-select2',
					'post_type'   => 'product',
					'source_name' => 'post_type',
					'options'     => FnsPro::get_product_id_titles( $fmp_special_menus, 'product' ),
					'value'       => $settings['fmp_special_menus'] ?? [],
				],

				'fmp_menu_button_text'        => [
					'label'       => esc_html__( 'Button Text', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'Button text for special menu popup', 'food-menu-pro' ),
					'value'       => $settings['fmp_menu_button_text'] ?? '',
				],

				'fmp_menu_button_link'        => [
					'label'       => esc_html__( 'Button Link', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'The button serves as a link to the specified page', 'food-menu-pro' ),
					'value'       => $settings['fmp_menu_button_link'] ?? '',
				],

				'fmp_menu_modal_style'        => [
					'label' => esc_html__( 'Modal Style', 'food-menu-pro' ),
					'type'  => 'title',
				],
				'fmp_menu_modal_width'        => [
					'id'          => 'fmp_menu_modal_width',
					'type'        => 'number',
					'sanitize_fn' => 'absint',
					'description' => esc_html__( 'If you need you can enter special menu modal width', 'food-menu-pro' ),
					'label'       => esc_html__( 'Modal Min Width', 'food-menu-pro' ),
					'value'       => $settings['fmp_menu_modal_width'] ?? '',
				],
				'fmp_menu_modal_height'       => [
					'id'          => 'fmp_menu_modal_height',
					'type'        => 'number',
					'sanitize_fn' => 'absint',
					'description' => esc_html__( 'If you need you can enter special menu modal height', 'food-menu-pro' ),
					'label'       => esc_html__( 'Modal Min Height', 'food-menu-pro' ),
					'value'       => $settings['fmp_menu_modal_height'] ?? '',
				],

				'fmp_menu_modal_title_color'  => [
					'id'    => 'fmp_menu_modal_title_color',
					'label' => esc_html__( 'Special Menu Title Color', 'food-menu-pro' ),
					'type'  => 'colorpicker',
					'value' => $settings['fmp_menu_modal_title_color'] ?? '',
				],

				'fmp_menu_modal_bg'           => [
					'id'    => 'fmp_menu_modal_bg',
					'label' => esc_html__( 'Special Menu BG', 'food-menu-pro' ),
					'type'  => 'colorpicker',
					'value' => $settings['fmp_menu_modal_bg'] ?? '',
				],

				'fmp_menu_modal_btn_bg'       => [
					'id'    => 'fmp_menu_modal_btn_bg',
					'label' => esc_html__( 'Button Background', 'food-menu-pro' ),
					'type'  => 'colorpicker',
					'value' => $settings['fmp_menu_modal_btn_bg'] ?? '',
				],

				'fmp_menu_modal_btn_bg_hover' => [
					'id'    => 'fmp_menu_modal_btn_bg_hover',
					'label' => esc_html__( 'Button BG - Hover', 'food-menu-pro' ),
					'type'  => 'colorpicker',
					'value' => $settings['fmp_menu_modal_btn_bg_hover'] ?? '',
				],

			]
		);
	}
}
