<?php

namespace RT\FoodMenuPro\Controllers\SpecialMenu;

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;

//phpcs:disable PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage

/**
 * Special Menu Main class
 */
class SpecialMenu {

	use SingletonTrait;

	/**
	 * Admin settings
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		$this->options = FnsPro::get_settings_option();
		$enable_menu   = $this->options['fmp_enable_menu'] ?? 'on';
		$fm_type       = $this->options['fm_food_menu_type'] ?? 'food_menu_post';

		if ( TLPFoodMenu()->isWcActive() && 'on' === $enable_menu && 'online_ordering' === $fm_type ) {
			add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue_assets' ], 99 );
			add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
			add_action( 'wp_footer', [ $this, 'render_special_menu_popup' ] );
		}
	}

	/**
	 * Frontend enqueue
	 *
	 * @return void
	 */
	public function frontend_enqueue_assets() {
		$opt         = $this->options;
		$dynamic_css = '';

		// modal style.
		$pre = '#fmp-special-menu-modal';

		if ( ! empty( $opt['fmp_menu_modal_width'] ) ) {
			$dynamic_css .= "$pre .fmp-menu-popup-modal .modal-content {width:{$opt['fmp_menu_modal_width']}px}";
		}

		if ( ! empty( $opt['fmp_menu_modal_height'] ) ) {
			$dynamic_css .= "$pre .fmp-menu-popup-modal .modal-content .right-content {height:{$opt['fmp_menu_modal_height']}px}";
		}

		if ( ! empty( $opt['fmp_menu_modal_bg'] ) ) {
			$dynamic_css .= "$pre .fmp-menu-popup-modal .modal-content {background:{$opt['fmp_menu_modal_bg']}}";
		}

		if ( ! empty( $opt['fmp_menu_modal_title_color'] ) ) {
			$dynamic_css .= "$pre .fmp-menu-popup-modal .left-content .title {color:{$opt['fmp_menu_modal_title_color']}}";
		}

		if ( ! empty( $opt['fmp_menu_modal_btn_bg'] ) ) {
			$dynamic_css .= "$pre .fmp-menu-popup-modal a.fmp-btn.special-menu-btn::before {background:{$opt['fmp_menu_modal_btn_bg']}}";
		}

		if ( ! empty( $opt['fmp_menu_modal_btn_bg_hover'] ) ) {
			$dynamic_css .= "$pre .fmp-menu-popup-modal a.fmp-btn.special-menu-btn::after {background:{$opt['fmp_menu_modal_btn_bg_hover']}}";
		}

		if ( ! empty( $dynamic_css ) ) {
			wp_add_inline_style( 'fmp-frontend', $dynamic_css );
		}
	}

	/**
	 * Admin enqueue
	 *
	 * @return void
	 */
	public function admin_enqueue_assets() {
		// add enqueue flatpickr for date in frontend.
		wp_enqueue_script( 'fmp-flatpickr' );
		wp_enqueue_style( 'fmp-flatpickr' );
	}

	/**
	 * Special menu popup.
	 *
	 * @return void
	 */
	public function render_special_menu_popup() {
		$settings            = $this->options;
		$menu_popup_duration = $settings['fmp_menu_popup_duration'] ?? '';
		$now_date            = gmdate( TLP_FOOD_MENU_DEFAULT_DATE_FORMAT );
		if ( empty( $menu_popup_duration ) || $now_date > $menu_popup_duration ) {
			return;
		}
		$fmp_menu_title       = $settings['fmp_menu_title'] ?? '';
		$fmp_menu_offer       = $settings['fmp_menu_offer'] ?? '';
		$fmp_menu_duration    = $settings['fmp_menu_duration'] ?? '';
		$fmp_special_menus    = $settings['fmp_special_menus'] ?? [];
		$fmp_menu_button_text = $settings['fmp_menu_button_text'] ?? '';
		$fmp_menu_button_link = $settings['fmp_menu_button_link'] ?? '';
		?>

		<div id="fmp-special-menu-modal" class="fmp-menu-popup fmp-menu-popup--style-1">
			<div class="fmp-menu-popup-modal">
				<div class="modal-content">
					<div class="modal-row">
						<div class="modal-col-5 col-12">
							<div class="left-content">
								<h3 class="title"><?php echo esc_html( $fmp_menu_title ); ?></h3>

								<?php if ( ! empty( $fmp_menu_offer ) ) : ?>
									<h4 class="subtitle"><?php echo esc_html( $fmp_menu_offer ); ?></h4>
								<?php endif; ?>

								<?php if ( ! empty( $fmp_menu_duration ) ) : ?>
									<p class="description"><?php echo esc_html( $fmp_menu_duration ); ?></p>
								<?php endif; ?>

								<?php if ( ! empty( $fmp_menu_button_link ) && ! empty( $fmp_menu_button_text ) ) : ?>
									<a class="fmp-btn special-menu-btn" href="<?php echo esc_url( $fmp_menu_button_link ); ?>">
										<?php echo esc_html( $fmp_menu_button_text ); ?>
									</a>
								<?php endif; ?>
							</div>
						</div>
						<div class="modal-col-6 col-12">
							<div class="right-content">
								<?php foreach ( $fmp_special_menus as $special_menu ) : ?>
									<a href="<?php echo esc_url( get_permalink( $special_menu ) ); ?>" class="modal-product">
										<div class="product-img">
											<img src="<?php echo esc_url( wp_get_attachment_url( get_post_thumbnail_id( $special_menu ) ) ); ?>" alt="product image">
										</div>
										<div class="product-title">
											<h3 class="title"><?php echo esc_html( get_the_title( $special_menu ) ); ?></h3>
										</div>
									</a>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
					<button class="fmp-btn menu-popup-close"> X </button>
				</div>
			</div>
		</div>

		<?php
	}
}
