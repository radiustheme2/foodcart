<?php
/**
 * Main TipFns class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Tip;

defined( 'ABSPATH' ) || exit();


/**
 * Main TipFns class.
 */
class TipFns {

	/**
	 * Tip setting fields.
	 *
	 * @return array
	 */
	public static function settings_field() {

		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/tip_settings/fields',
			[
				'enable_tip'       => [
					'label'       => esc_html__( 'Enable Tip?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable tip/donation option at checkout and cart?', 'food-menu-pro' ),
					'value'       => $settings['enable_tip'] ?? 'on',
				],

				'show_tip_form'    => [
					'id'      => 'show_tip_form',
					'type'    => 'select',
					'class'   => 'fmp-select2',
					'value'   => $settings['show_tip_form'] ?? 'both',
					'label'   => esc_html__( 'Display Tip Form', 'food-menu-pro' ),
					'options' => [
						'checkout' => esc_html__( 'Checkout Page', 'food-menu-pro' ),
						'cart'     => esc_html__( 'Cart Page', 'food-menu-pro' ),
						'both'     => esc_html__( 'Both', 'food-menu-pro' ),
					],
				],

				'allow_tip_for'    => [
					'id'      => 'allow_tip_for',
					'type'    => 'select',
					'class'   => 'fmp-select2',
					'value'   => $settings['allow_tip_for'] ?? 'both',
					'label'   => esc_html__( 'Allow tip for', 'food-menu-pro' ),
					'options' => [
						'both'       => esc_html__( 'Both', 'food-menu-pro' ),
						'fixed'      => esc_html__( 'Fixed', 'food-menu-pro' ),
						'percentage' => esc_html__( 'Percentage', 'food-menu-pro' ),
					],
				],

				'tip_heading_text' => [
					'id'          => 'tip_heading_text',
					'type'        => 'text',
					'label'       => esc_html__( 'Tip Heading Text', 'food-menu-pro' ),
					'description' => esc_html__( 'Tip heading text. E.g: Do you want to provide a tip?', 'food-menu-pro' ),
					'value'       => $settings['tip_heading_text'] ?? esc_html__( 'Do you want to provide a tip?', 'food-menu-pro' ),
				],

			]
		);
	}
}
