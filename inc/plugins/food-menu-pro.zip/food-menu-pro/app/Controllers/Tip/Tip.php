<?php
/**
 * Tip main class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Tip;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;
/**
 * Tip main class
 */
class Tip {


	use SingletonTrait;

	/**
	 * Settings option
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		$this->options = FnsPro::get_settings_option();
		$enable_tip    = $this->options['enable_tip'] ?? 'on';
		$fm_type       = $this->options['fm_food_menu_type'] ?? 'food_menu_post';

		if ( TLPFoodMenu()->isWcActive() && 'on' === $enable_tip && 'online_ordering' === $fm_type ) {

			// Add form in order and cart page.
			if ( ! empty( $this->options['show_tip_form'] ) && 'both' == $this->options['show_tip_form'] ) {
				add_action( 'woocommerce_after_order_notes', [ $this, 'tip_form' ] );
				add_action( 'woocommerce_before_cart_totals', [ $this, 'tip_form' ] );
			} elseif ( ! empty( $this->options['show_tip_form'] ) && 'cart' == $this->options['show_tip_form'] ) {
				add_action( 'woocommerce_before_cart_totals', [ $this, 'tip_form' ] );
			} else {
				add_action( 'woocommerce_after_order_notes', [ $this, 'tip_form' ] );
			}

			// Add tip assets file enqueue.
			add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue_assets' ] );

			// Tip data add to session.
			add_action( 'wp_ajax_add_tip', [ $this, 'add_tip_to_session' ] );
			add_action( 'wp_ajax_nopriv_add_tip', [ $this, 'add_tip_to_session' ] );

			// Cart calculate update.
			add_action( 'woocommerce_cart_calculate_fees', [ $this, 'cart_calculate_fee_update' ] );

			// when new order the remove session.
			add_action( 'woocommerce_new_order', [ $this, 'remove_tip_session_place_order' ] );

			// Tip data remove to session.
			add_action( 'wp_ajax_remove_tip', [ $this, 'remove_tip_to_session' ] );
			add_action( 'wp_ajax_nopriv_remove_tip', [ $this, 'remove_tip_to_session' ] );

		}
	}

	/**
	 * Remove tip from session.
	 *
	 * @return void
	 */
	public function remove_tip_to_session() {
		$status = 0;
		if ( Fns::verifyNonce() ) {
			WC()->session->__unset( 'fmp_tip' );
			$status  = 1;
			$message = esc_html__( 'The Tip has been removed successfully', 'food-menu-pro' );
		} else {
			$message = esc_html__( 'Nonce is not valid! Please try again', 'food-menu-pro' );
		}
		wp_send_json(
			[
				'status'  => $status,
				'message' => $message,
			]
		);
		wp_die();
	}

	/**
	 * Remove fmp_tip session when new order.
	 *
	 * @return void
	 */
	public function remove_tip_session_place_order() {
		if ( ! is_admin() ) {
			WC()->session->__unset( 'fmp_tip' );
		}
	}

	/**
	 * Cart calculate fee update
	 *
	 * @param object $cart receive cart object.
	 */
	public function cart_calculate_fee_update( $cart ) {

		$tip_session_data = WC()->session->get( 'fmp_tip' );

		if ( ! empty( $tip_session_data ) ) {
			$tip_title  = esc_html__( 'Tip', 'food-menu-pro' );
			$tip_amount = 0;

			switch ( $tip_session_data['tip_selected_type'] ) {
				case 'fixed':
					$tip_amount = $tip_session_data['tip_fixed_amount'];
					break;

				case 'percentage':
					$sub_total  = $cart->get_subtotal();
					$tip_amount = ( $tip_session_data['tip_percentage_amount'] / 100 ) * $sub_total;
					$tip_title .= '(' . $tip_session_data['tip_percentage_amount'] . '%)';
					break;
			}

			if ( $tip_amount > 0 ) {
				$cart->add_fee( $tip_title, $tip_amount );
			}
		}
	}

	/**
	 * Tip add wc session.
	 *
	 * @return void
	 */
	public function add_tip_to_session() {
		$status = 0;
		if ( Fns::verifyNonce() ) {

            $selected_type = sanitize_text_field(wp_unslash($_POST['selectedType'])); //phpcs:ignore
            $fixed_amount = floatval(sanitize_text_field($_POST['fixedAmount'])); //phpcs:ignore
            $percentage_amount = intval(sanitize_text_field($_POST['percentageAmount']));//phpcs:ignore

			$tip_added = ( 'fixed' === $selected_type && $fixed_amount > 0 ) || ( 'percentage' === $selected_type && $percentage_amount > 0 );

			if ( $tip_added ) {
				$tip_data = [
					'tip_added'             => 1,
					'tip_selected_type'     => $selected_type,
					'tip_fixed_amount'      => $fixed_amount,
					'tip_percentage_amount' => $percentage_amount,
				];
				WC()->session->set( 'fmp_tip', $tip_data );
				$status  = 1;
				$message = esc_html__( 'The tip has been successfully added.', 'food-menu-pro' );
			} else {
				$message = esc_html__( 'Error: Invalid tip type or value selected. Please try again.', 'food-menu-pro' );
			}
		} else {
			$message = esc_html__( 'Nonce is not valid! Please try again', 'food-menu-pro' );
		}

		wp_send_json(
			[
				'status'  => $status,
				'message' => $message,
			]
		);

		wp_die();
	}

	/**
	 * Tip frontend assets enqueue
	 *
	 * @return void
	 */
	public function frontend_enqueue_assets() {
		$nonce = wp_create_nonce( Fns::nonceText() );
		// tip frontend js.
		wp_enqueue_script( 'fmp-ajax-tip' );
		\wp_localize_script(
			'fmp-ajax-tip',
			'fmpTipParamsPro',
			[
				'nonceID' => esc_attr( Fns::nonceId() ),
				'nonce'   => esc_attr( $nonce ),
				'ajaxurl' => esc_url( admin_url( 'admin-ajax.php' ) ),
			]
		);
	}

	/**
	 * Render tip form
	 *
	 * @return void
	 */
	public function tip_form() {
		Fns::render( 'tip/tip-form' );
	}
}
