<?php
defined( 'ABSPATH' ) || exit();
?>

<div class="fmp-pa-price-option-item">
	<div class="option-label">
		<input type="text"
			   name="fmp_pa_option_label[<?php echo esc_attr( $counter ); ?>][]"
			   class="rt-form-control"
			   value="<?php echo esc_attr( $option_label ); ?>"
			   placeholder="<?php esc_html_e( 'Option name', 'food-menu-pro' ); ?>"/>
		<input type="text"
			   name="fmp_pa_option_description[<?php echo esc_attr( $counter ); ?>][]"
			   class="rt-form-control fmp-option-desc-input"
			   value="<?php echo esc_attr( $option['description'] ?? '' ); ?>"
			   placeholder="<?php esc_attr_e( 'Short description (optional)', 'food-menu-pro' ); ?>"/>
	</div>

	<div class="price-type">
		<?php $price_type = [ 'quantity_based' => esc_html__( 'Quantity Based', 'food-menu-pro' ) ]; ?>
		<select name="fmp_pa_option_price_type[<?php echo esc_attr( $counter ); ?>][]"
				class="rt-form-control">
			<?php
			foreach ( $price_type as $key => $value ) {
				?>
				<option <?php selected( $key, $option_price_type ); ?>
						value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $value ); ?></option>
			<?php } ?>
		</select>
	</div>

	<div class="option-price">
		<input type="text"
			   name="fmp_pa_option_price[<?php echo esc_attr( $counter ); ?>][]"
			   class="rt-form-control"
			   value="<?php echo esc_attr( wc_format_localized_price( $option_price ) ); ?>"
			   placeholder="0"/>
	</div>

	<div class="option-image" style="<?php echo isset( $pa_type ) && 'dropdown' === $pa_type ? 'display:none' : ''; ?>">
		<?php
		$option_image_id  = ! empty( $option['image'] ) ? absint( $option['image'] ) : 0;
		$option_image_url = $option_image_id ? wp_get_attachment_image_url( $option_image_id, 'thumbnail' ) : '';
		?>
		<div class="fmp-option-image-preview">
			<?php if ( $option_image_url ) : ?>
				<img src="<?php echo esc_url( $option_image_url ); ?>" width="40" height="40" alt="" />
			<?php endif; ?>
		</div>
		<input type="hidden" name="fmp_pa_option_image[<?php echo esc_attr( $counter ); ?>][]"
			   class="fmp-option-image-id" value="<?php echo esc_attr( $option_image_id ); ?>" />
		<button type="button" class="fmp-pa-option-upload-image button button-small">
			<?php esc_html_e( 'Image', 'food-menu-pro' ); ?>
		</button>
		<?php if ( $option_image_url ) : ?>
			<button type="button" class="fmp-pa-option-remove-image button button-small">&times;</button>
		<?php endif; ?>
	</div>

	<div class="option-default">
		<input type="radio"
			   id="fmp_pa_option_default_<?php echo esc_attr( $counter ); ?>_<?php echo esc_attr( $option_key ); ?>"
			   name="fmp_pa_option_default[<?php echo esc_attr( $counter ); ?>][]"
			   value="<?php echo esc_attr( $option_key ); ?>"
			<?php checked( 1, $option_default ); ?> >
		<label for="fmp_pa_option_default_<?php echo esc_attr( $counter ); ?>_<?php echo esc_attr( $option_key ); ?>">
			<?php echo esc_html__( 'Default Selected', 'food-menu-pro' ); ?>
		</label>
	</div>

	<?php if ( intval( $option_key ) !== 0 ) : ?>
		<button type="button" class="fmp-pa-option-remove">
			<i class="dashicons dashicons-no-alt"></i>
		</button>
	<?php endif; ?>

</div>