<?php
defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Helpers\FnsPro;

$global_addon_data = FnsPro::get_settings_option( TLPFoodMenu()->options['global_addon'] );

?>

<div class="fmp-product-addon-settings">
	<h2 class="fmp-addon-settings-title">
		<?php esc_html_e( 'Product Addons', 'food-menu-pro' ); ?>
		<span class="fmp-addon-settings-note" role="note">
			<span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
			<?php esc_html_e( 'Product addons work exclusively for simple products', 'food-menu-pro' ); ?>
		</span>
	</h2>
	<form id="fmp-global-addon-settings" method="post">

		<div class="fmp-addon-settings-content-wrap">

			<?php
			$addon_section  = 'global';
			$product_addons = $global_addon_data;

			require_once __DIR__ . '/pa-fields-container.php';
			?>
		</div>
		<input type="hidden" name="fmp_product_addons" value="global_addons_save">
		<input type="submit" name="submit" class="fmp-btn fmp-global-addons-save"
			   value="<?php esc_attr_e( 'Save Changes', 'food-menu-pro' ); ?>">
	</form>

	<div class="rt-response"></div>
</div>
