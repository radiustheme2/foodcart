<?php defined( 'ABSPATH' ) || exit();

$product_addons  = $product_addons ?? [];
$counter         = 0;
$global_override = $global_override ?? '';

$className = '';
if ( empty( $global_override ) && ! isset( $addon_section ) ) {
	$className = 'fmp-hide';
}
?>

<div id="fmp-product-addons" class="panel woocommerce_options_panel">

	<div class="fmp-product-addon-header">
		<h3><?php esc_html_e( 'Extra Options (Product addon exclusively for simple products)', 'food-menu-pro' ); ?></h3>
	</div>

	<?php if ( ! isset( $addon_section ) ) : ?>
		<div class="fmp-product-addon-override">
			<div class="rt-field-wrapper">
				<div class="rt-label">
					<label for="fmp_pa_global_override"><?php esc_html_e( 'Global Addon Override ', 'food-menu-pro' ); ?></label>
				</div>
				<div class="rt-field">
					<label class="rtfm-switch">
						<input type="checkbox" class="fmp_pa_global_override"
							   id="fmp_pa_global_override"
							   name="fmp_pa_global_override" <?php checked( $global_override, 'on', true ); ?> />
						<span class="rtfm-switch-slider round"></span>
					</label>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<div class="fmp-product-addon-main-wrap <?php echo esc_attr( $className ); ?>" >
		<?php
		if ( ! empty( $product_addons ) ) {
			foreach ( $product_addons as $p_addons ) {
				include __DIR__ . '/pa-single-field.php';
				$counter++;
			}
		}
		?>
	</div>

	<div class="fmp-product-addon-action <?php echo esc_attr( $className ); ?>">
		<button type="button" class="fmp-btn fmp-pa-add-fields"
				data-pa-section="<?php echo esc_attr( $addon_section ?? '' ); ?>"
				data-pa-next-index="<?php echo esc_attr( $counter ); ?>">
			<?php esc_html_e( 'Add Group', 'food-menu-pro' ); ?>
		</button>
		<?php
		if ( ! isset( $addon_section ) ) {
			$global_url = esc_url( admin_url() . 'edit.php?post_type=food-menu&page=product_addons' );
			?>
			<a href="<?php echo esc_url( $global_url ); ?>" class="fmp-global-addon-link">
				<?php esc_html_e( 'Global addons', 'food-menu-pro' ); ?>
			</a>
			<?php
		}
		?>
	</div>

</div>

