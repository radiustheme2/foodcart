<?php
defined( 'ABSPATH' ) || exit();

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

$p_addons    = $p_addons ?? [];
$counter     = $counter ?? 0;
$pa_type     = $p_addons['type'] ?? 'checkbox';
$pa_title    = $p_addons['title'] ?? '';
$pa_required = $p_addons['required'] ?? '';

if ( ! isset( $p_addons['options'] ) ) {
	$p_addons['options'] = [
		[
			'label'      => '',
			'price_type' => 'flat_fee',
			'price'      => '',
		],
	];
}

?>

<div class="fmp-product-addon-fields">

	<div class="fmp-pa-header">
		<div class="sort-icon">
			<span class="fmp-pa-sort-handle dashicons dashicons-menu"></span>
			<?php if ( ! empty( $pa_title ) ) : ?>
				<h4><?php echo esc_html( $pa_title ); ?></h4>
			<?php endif; ?>
		</div>
		<div class="remove-icon">
			<button type="button" class="fmp-pa-remove">
				<i class="dashicons dashicons-no-alt"></i>
			</button>
			<input type="hidden" name="fmp_pa_position[<?php echo esc_attr( $counter ); ?>]" class="fmp_pa_position"
				   value="<?php echo esc_attr( $counter ); ?>"/>
		</div>
	</div>

	<div class="fmp-pa-content" style="display: none">

		<?php if ( isset( $addon_section ) && 'global' == $addon_section ) : ?>
			<div class="rt-field-wrapper">
				<div class='rt-label'>
					<label for="fmp_pa_categories_<?php echo esc_attr( $counter ); ?>"><?php echo esc_html__( 'Include Categories', 'food-menu-pro' ); ?></label>
				</div>
				<div class="rt-field">
					<select name="fmp_pa_categories[<?php echo esc_attr( $counter ); ?>][]"
							id="fmp_pa_categories_<?php echo esc_attr( $counter ); ?>" multiple="multiple"
							class="fmp-ajax-select2 rt-form-control"
							data-post-type="product_cat" data-source-name="taxonomy">
						<?php
						$a_categories  = $p_addons['categories'] ?? [];
						$a_cat_id_name = FnsPro::get_term_names( $a_categories, 'product_cat' );
						foreach ( $a_cat_id_name as $key => $category ) {
							$selected = in_array( $key, $a_categories ) ? 'selected' : '';
							?>
							<option <?php echo esc_attr( $selected ); ?>
									value="<?php echo esc_attr( $key ); ?>">
								<?php echo esc_html( $category ); ?>
							</option>
						<?php } ?>
					</select>
				</div>
			</div>

			<div class="rt-field-wrapper">
				<div class="rt-label">
					<label for="fmp_pa_menu_items_<?php echo esc_attr( $counter ); ?>"><?php esc_html_e( 'Include Menu Items', 'food-menu-pro' ); ?></label>
				</div>
				<div class="rt-field">
					<?php
					$menu_id = $p_addons['menu_items'] ?? [];
					$options = FnsPro::get_product_id_titles( $menu_id, 'product' );
					?>
					<select name="fmp_pa_menu_items[<?php echo esc_attr( $counter ); ?>][]" multiple="multiple"
							class="fmp-ajax-select2 rt-form-control"
							id="fmp_pa_menu_items_<?php echo esc_attr( $counter ); ?>"
							data-post-type="product" data-source-name="post_type">
						<?php
						foreach ( $options as $key => $value ) {
							$selected = ( in_array( $key, $menu_id ) ? 'selected' : null );
							?>
							<option <?php echo esc_attr( $selected ); ?>
									value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $value ); ?> </option>
							;
						<?php } ?>
					</select>
				</div>
			</div>

		<?php endif; ?>

		<div class="rt-field-wrapper">
			<div class="rt-label">
				<label for="fmp_pa_type_<?php echo esc_attr( $counter ); ?>"><?php esc_html_e( 'Type', 'food-menu-pro' ); ?></label>
			</div>
			<div class="rt-field">
				<?php
				$pa_types = [
					'checkbox' => esc_html__( 'Checkbox', 'food-menu-pro' ),
					'radio'    => esc_html__( 'Radio', 'food-menu-pro' ),
					'dropdown' => esc_html__( 'Dropdown', 'food-menu-pro' ),
				];
				?>
				<select id="fmp_pa_type_<?php echo esc_attr( $counter ); ?>"
						name="fmp_pa_type[<?php echo esc_attr( $counter ); ?>]"
						class="fmp-select2 fmp_pa_type_<?php echo esc_attr( $counter ); ?>">
					<?php
					foreach ( $pa_types as $key => $value ) {
						?>
						<option <?php selected( $key, $pa_type ); ?>
								value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $value ); ?></option>
						<?php
					}
					?>
				</select>
				<p class="description"><?php esc_html_e( 'Set product addons input type', 'food-menu-pro' ); ?></p>
			</div>
		</div>

		<div class="rt-field-wrapper">
			<div class="rt-label">
				<label for="fmp_pa_title_<?php echo esc_attr( $counter ); ?>">
					<?php esc_html_e( 'Title', 'food-menu-pro' ); ?>
					<span class="required">&nbsp;*</span>
				</label>
			</div>

			<div class="rt-field">
				<input type="text" id="fmp_pa_title_<?php echo esc_attr( $counter ); ?>"
					   value="<?php echo esc_attr( $pa_title ); ?>"
					   class=" fmp_pa_title_<?php echo esc_attr( $counter ); ?>"
					   name="fmp_pa_title[<?php echo esc_attr( $counter ); ?>]"
					   required="required"
					   placeholder="<?php echo esc_html__( 'Title', 'food-menu-pro' ); ?>"/>
				<p class="description"><?php esc_html_e( 'Add product addons title text', 'food-menu-pro' ); ?></p>
			</div>
		</div>

		<div class="rt-field-wrapper">
			<div class="rt-label">
				<label for="fmp_pa_required_<?php echo esc_attr( $counter ); ?>"><?php esc_html_e( 'Required', 'food-menu-pro' ); ?></label>
			</div>
			<div class="rt-field">
				<label class="rtfm-switch">
					<input type="checkbox" class="fmp_pa_required_<?php echo esc_attr( $counter ); ?>"
						   id="fmp_pa_required_<?php echo esc_attr( $counter ); ?>"
						   name="fmp_pa_required[<?php echo esc_attr( $counter ); ?>]" <?php checked( $pa_required, 1, true ); ?> />
					<span class="rtfm-switch-slider round"></span>
				</label>
			</div>
		</div>

		<div class="fmp-pa-options-main-wrap">

			<div class="fmp-pa-option-header">
				<div class="title item">
					<?php esc_html_e( 'Options', 'food-menu-pro' ); ?>
				</div>
				<div class="type item">
					<?php esc_html_e( 'Type', 'food-menu-pro' ); ?>
				</div>
				<div class="label item">
					<?php esc_html_e( 'Price', 'food-menu-pro' ); ?>
				</div>
			</div>

			<div class="fmp-pa-option-wrap">
				<?php
				$next_option = 1;
				if ( ! empty( $p_addons['options'] ) ) {
					$next_option = count( $p_addons['options'] );
					foreach ( $p_addons['options'] as $option_key => $option ) {
						$option_label      = $option['label'] ?? '';
						$option_price_type = $option['price_type'] ?? 'flat_fee';
						$option_price      = $option['price'] ?? '';
						$option_default    = $option['default'] ?? '';
						include __DIR__ . '/pa-price-option.php';
					}
				}
				?>
			</div>

			<div class="fmp-pa-option-action-btn">
				<button type="button" class="fmp-btn fmp-pa-add-options"
						data-current-counter-index="<?php echo esc_attr( $counter ); ?>" data-next-option-index="<?php echo esc_attr( ( $next_option + 1 ) - 1 ); ?>">
					<?php esc_html_e( 'Add Option', 'food-menu-pro' ); ?>
				</button>
			</div>

		</div>
	</div>

</div>