<?php
defined( 'ABSPATH' ) || exit();

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

$p_addons    = $p_addons ?? [];
$counter     = $counter ?? 0;
$pa_type     = $p_addons['type'] ?? 'checkbox';
$pa_title    = $p_addons['title'] ?? '';
$pa_required      = $p_addons['required'] ?? '';
$pa_min_selection = $p_addons['min_selection'] ?? '';
$pa_max_selection = $p_addons['max_selection'] ?? '';
$pa_option_qty    = $p_addons['option_qty'] ?? '';
$pa_free_label    = $p_addons['free_label'] ?? '';

if ( ! isset( $p_addons['options'] ) ) {
	$p_addons['options'] = [
		[
			'label'      => '',
			'price_type' => 'flat_fee',
			'price'      => '',
		],
	];
}

?>

<div class="fmp-product-addon-fields">

	<div class="fmp-pa-header">
		<div class="sort-icon">
			<span class="fmp-pa-sort-handle dashicons dashicons-menu"></span>
			<?php if ( ! empty( $pa_title ) ) : ?>
				<h4><?php echo esc_html( $pa_title ); ?></h4>
			<?php endif; ?>
		</div>
		<div class="remove-icon">
			<button type="button" class="fmp-pa-remove">
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
			</button>
			<input type="hidden" name="fmp_pa_position[<?php echo esc_attr( $counter ); ?>]" class="fmp_pa_position"
				   value="<?php echo esc_attr( $counter ); ?>"/>
		</div>
	</div>

	<div class="fmp-pa-content" style="display: none">

		<?php if ( isset( $addon_section ) && 'global' == $addon_section ) : ?>
			<div class="rt-field-wrapper">
				<div class='rt-label'>
					<label for="fmp_pa_categories_<?php echo esc_attr( $counter ); ?>"><?php echo esc_html__( 'Include Categories', 'food-menu-pro' ); ?></label>
				</div>
				<div class="rt-field">
					<select name="fmp_pa_categories[<?php echo esc_attr( $counter ); ?>][]"
							id="fmp_pa_categories_<?php echo esc_attr( $counter ); ?>" multiple="multiple"
							class="fmp-ajax-select2 rt-form-control"
							data-post-type="product_cat" data-source-name="taxonomy">
						<?php
						$a_categories  = $p_addons['categories'] ?? [];
						$a_cat_id_name = FnsPro::get_term_names( $a_categories, 'product_cat' );
						foreach ( $a_cat_id_name as $key => $category ) {
							$selected = in_array( $key, $a_categories ) ? 'selected' : '';
							?>
							<option <?php echo esc_attr( $selected ); ?>
									value="<?php echo esc_attr( $key ); ?>">
								<?php echo esc_html( $category ); ?>
							</option>
						<?php } ?>
					</select>
				</div>
			</div>

			<div class="rt-field-wrapper">
				<div class="rt-label">
					<label for="fmp_pa_menu_items_<?php echo esc_attr( $counter ); ?>"><?php esc_html_e( 'Include Menu Items', 'food-menu-pro' ); ?></label>
				</div>
				<div class="rt-field">
					<?php
					$menu_id = $p_addons['menu_items'] ?? [];
					$options = FnsPro::get_product_id_titles( $menu_id, 'product' );

					// Product Addons only support simple products — drop any
					// non-simple items from the pre-selected list (single query).
					if ( ! empty( $options ) && function_exists( 'wc_get_products' ) ) {
						$simple_ids = wc_get_products(
							[
								'include' => array_map( 'absint', array_keys( $options ) ),
								'type'    => 'simple',
								'limit'   => count( $options ),
								'return'  => 'ids',
							]
						);
						$options = array_intersect_key( $options, array_flip( array_map( 'absint', $simple_ids ) ) );
					}
					?>
					<select name="fmp_pa_menu_items[<?php echo esc_attr( $counter ); ?>][]" multiple="multiple"
							class="fmp-ajax-select2 rt-form-control"
							id="fmp_pa_menu_items_<?php echo esc_attr( $counter ); ?>"
							data-post-type="product" data-product-type="simple" data-source-name="post_type">
						<?php
						foreach ( $options as $key => $value ) {
							$selected = ( in_array( $key, $menu_id ) ? 'selected' : null );
							?>
							<option <?php echo esc_attr( $selected ); ?>
									value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $value ); ?> </option>
							;
						<?php } ?>
					</select>
				</div>
			</div>

		<?php endif; ?>

		<div class="rt-field-wrapper">
			<div class="rt-label">
				<label for="fmp_pa_type_<?php echo esc_attr( $counter ); ?>"><?php esc_html_e( 'Type', 'food-menu-pro' ); ?></label>
			</div>
			<div class="rt-field">
				<?php
				$pa_types = [
					'checkbox' => esc_html__( 'Checkbox', 'food-menu-pro' ),
					'radio'    => esc_html__( 'Radio', 'food-menu-pro' ),
					'dropdown' => esc_html__( 'Dropdown', 'food-menu-pro' ),
					'text'     => esc_html__( 'Text', 'food-menu-pro' ),
					'textarea' => esc_html__( 'Textarea', 'food-menu-pro' ),
				];
				?>
				<select id="fmp_pa_type_<?php echo esc_attr( $counter ); ?>"
						name="fmp_pa_type[<?php echo esc_attr( $counter ); ?>]"
						class="fmp-select2 fmp_pa_type_<?php echo esc_attr( $counter ); ?>">
					<?php
					foreach ( $pa_types as $key => $value ) {
						?>
						<option <?php selected( $key, $pa_type ); ?>
								value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $value ); ?></option>
						<?php
					}
					?>
				</select>
				<p class="description"><?php esc_html_e( 'Set product addons input type', 'food-menu-pro' ); ?></p>
			</div>
		</div>

		<div class="rt-field-wrapper">
			<div class="rt-label">
				<label for="fmp_pa_title_<?php echo esc_attr( $counter ); ?>">
					<?php esc_html_e( 'Title', 'food-menu-pro' ); ?>
					<span class="required">&nbsp;*</span>
				</label>
			</div>

			<div class="rt-field">
				<input type="text" id="fmp_pa_title_<?php echo esc_attr( $counter ); ?>"
					   value="<?php echo esc_attr( $pa_title ); ?>"
					   class=" fmp_pa_title_<?php echo esc_attr( $counter ); ?>"
					   name="fmp_pa_title[<?php echo esc_attr( $counter ); ?>]"
					   required="required"
					   placeholder="<?php echo esc_html__( 'Title', 'food-menu-pro' ); ?>"/>
				<p class="description"><?php esc_html_e( 'Add product addons title text', 'food-menu-pro' ); ?></p>
			</div>
		</div>

		<div class="rt-field-wrapper">
			<div class="rt-label">
				<label for="fmp_pa_description_<?php echo esc_attr( $counter ); ?>">
					<?php esc_html_e( 'Description', 'food-menu-pro' ); ?>
				</label>
			</div>
			<div class="rt-field">
				<textarea id="fmp_pa_description_<?php echo esc_attr( $counter ); ?>"
						  name="fmp_pa_description[<?php echo esc_attr( $counter ); ?>]"
						  rows="2"
						  placeholder="<?php esc_attr_e( 'Help text or description', 'food-menu-pro' ); ?>"
				><?php echo esc_textarea( $p_addons['description'] ?? '' ); ?></textarea>
				<p class="description"><?php esc_html_e( 'Optional description shown below addon title', 'food-menu-pro' ); ?></p>
			</div>
		</div>

		<div class="rt-field-wrapper">
			<div class="rt-label">
				<label for="fmp_pa_required_<?php echo esc_attr( $counter ); ?>"><?php esc_html_e( 'Required', 'food-menu-pro' ); ?></label>
			</div>
			<div class="rt-field">
				<label class="rtfm-switch">
					<input type="checkbox" class="fmp_pa_required_<?php echo esc_attr( $counter ); ?>"
						   id="fmp_pa_required_<?php echo esc_attr( $counter ); ?>"
						   name="fmp_pa_required[<?php echo esc_attr( $counter ); ?>]" <?php checked( $pa_required, 1, true ); ?> />
					<span class="rtfm-switch-slider round"></span>
				</label>
			</div>
		</div>

		<?php $is_checkbox_type = ( 'checkbox' === $pa_type ); ?>

		<div class="fmp-pa-checkbox-fields" style="<?php echo esc_attr( $is_checkbox_type ? '' : 'display:none' ); ?>">
			<div class="rt-field-wrapper">
				<div class="rt-label">
					<label for="fmp_pa_min_selection_<?php echo esc_attr( $counter ); ?>">
						<?php esc_html_e( 'Min Selection', 'food-menu-pro' ); ?>
					</label>
				</div>
				<div class="rt-field">
					<input type="number" id="fmp_pa_min_selection_<?php echo esc_attr( $counter ); ?>"
						   name="fmp_pa_min_selection[<?php echo esc_attr( $counter ); ?>]"
						   value="<?php echo esc_attr( $pa_min_selection ); ?>"
						   min="0" placeholder="0"/>
					<p class="description"><?php esc_html_e( 'Leave empty or 0 for no minimum', 'food-menu-pro' ); ?></p>
				</div>
			</div>
			<div class="rt-field-wrapper">
				<div class="rt-label">
					<label for="fmp_pa_max_selection_<?php echo esc_attr( $counter ); ?>">
						<?php esc_html_e( 'Max Selection', 'food-menu-pro' ); ?>
					</label>
				</div>
				<div class="rt-field">
					<input type="number" id="fmp_pa_max_selection_<?php echo esc_attr( $counter ); ?>"
						   name="fmp_pa_max_selection[<?php echo esc_attr( $counter ); ?>]"
						   value="<?php echo esc_attr( $pa_max_selection ); ?>"
						   min="0" placeholder="0"/>
					<p class="description"><?php esc_html_e( 'Leave empty or 0 for no maximum', 'food-menu-pro' ); ?></p>
				</div>
			</div>
		</div>

		<?php $is_qty_type = in_array( $pa_type, [ 'checkbox', 'radio' ], true ); ?>

		<div class="fmp-pa-option-qty-fields" style="<?php echo esc_attr( $is_qty_type ? '' : 'display:none' ); ?>">
			<div class="rt-field-wrapper">
				<div class="rt-label">
					<label for="fmp_pa_option_qty_<?php echo esc_attr( $counter ); ?>"><?php esc_html_e( 'Enable Option Quantity', 'food-menu-pro' ); ?></label>
				</div>
				<div class="rt-field">
					<label class="rtfm-switch">
						<input type="checkbox" class="fmp_pa_option_qty_<?php echo esc_attr( $counter ); ?>"
							   id="fmp_pa_option_qty_<?php echo esc_attr( $counter ); ?>"
							   name="fmp_pa_option_qty[<?php echo esc_attr( $counter ); ?>]" <?php checked( $pa_option_qty, 1, true ); ?> />
						<span class="rtfm-switch-slider round"></span>
					</label>
				</div>
			</div>
		</div>

		<?php $is_option_type = in_array( $pa_type, [ 'checkbox', 'radio', 'dropdown' ], true ); ?>

		<div class="fmp-pa-free-label-fields" style="<?php echo esc_attr( $is_option_type ? '' : 'display:none' ); ?>">
			<div class="rt-field-wrapper">
				<div class="rt-label">
					<label for="fmp_pa_free_label_<?php echo esc_attr( $counter ); ?>">
						<?php esc_html_e( '"Free" Badge', 'food-menu-pro' ); ?>
					</label>
				</div>
				<div class="rt-field">
					<select id="fmp_pa_free_label_<?php echo esc_attr( $counter ); ?>"
							name="fmp_pa_free_label[<?php echo esc_attr( $counter ); ?>]">
						<option value="" <?php selected( $pa_free_label, '' ); ?>>
							<?php esc_html_e( 'Use global setting', 'food-menu-pro' ); ?>
						</option>
						<option value="show" <?php selected( $pa_free_label, 'show' ); ?>>
							<?php esc_html_e( 'Always show', 'food-menu-pro' ); ?>
						</option>
						<option value="hide" <?php selected( $pa_free_label, 'hide' ); ?>>
							<?php esc_html_e( 'Always hide', 'food-menu-pro' ); ?>
						</option>
					</select>
					<p class="description">
						<?php esc_html_e( 'Show the "Free" badge on options in this group that have no price. Overrides Settings → Product Addons.', 'food-menu-pro' ); ?>
					</p>
				</div>
			</div>
		</div>

		<?php $is_text_type = in_array( $pa_type, [ 'text', 'textarea' ], true ); ?>

		<div class="fmp-pa-text-fields" style="<?php echo esc_attr( $is_text_type ? '' : 'display:none' ); ?>">
			<div class="rt-field-wrapper">
				<div class="rt-label">
					<label for="fmp_pa_placeholder_<?php echo esc_attr( $counter ); ?>">
						<?php esc_html_e( 'Placeholder', 'food-menu-pro' ); ?>
					</label>
				</div>
				<div class="rt-field">
					<input type="text" id="fmp_pa_placeholder_<?php echo esc_attr( $counter ); ?>"
						   name="fmp_pa_placeholder[<?php echo esc_attr( $counter ); ?>]"
						   value="<?php echo esc_attr( $p_addons['placeholder'] ?? '' ); ?>"
						   placeholder="<?php esc_attr_e( 'Enter placeholder text', 'food-menu-pro' ); ?>"/>
				</div>
			</div>
			<div class="rt-field-wrapper">
				<div class="rt-label">
					<label for="fmp_pa_char_limit_<?php echo esc_attr( $counter ); ?>">
						<?php esc_html_e( 'Character Limit', 'food-menu-pro' ); ?>
					</label>
				</div>
				<div class="rt-field">
					<input type="number" id="fmp_pa_char_limit_<?php echo esc_attr( $counter ); ?>"
						   name="fmp_pa_char_limit[<?php echo esc_attr( $counter ); ?>]"
						   value="<?php echo esc_attr( $p_addons['char_limit'] ?? '' ); ?>"
						   min="0" placeholder="0"/>
					<p class="description"><?php esc_html_e( 'Leave empty or 0 for no limit', 'food-menu-pro' ); ?></p>
				</div>
			</div>
		</div>

		<div class="fmp-pa-options-main-wrap" style="<?php echo esc_attr( $is_text_type ? 'display:none' : '' ); ?>">

			<div class="fmp-pa-option-header">
				<div class="title item">
					<?php esc_html_e( 'Options', 'food-menu-pro' ); ?>
				</div>
				<div class="type item">
					<?php esc_html_e( 'Type', 'food-menu-pro' ); ?>
				</div>
				<div class="label item">
					<?php esc_html_e( 'Price', 'food-menu-pro' ); ?>
				</div>
				<div class="image item" style="<?php echo 'dropdown' === $pa_type ? 'display:none' : ''; ?>">
					<?php esc_html_e( 'Image', 'food-menu-pro' ); ?>
				</div>
			</div>

			<div class="fmp-pa-option-wrap">
				<?php
				$next_option = 1;
				if ( ! empty( $p_addons['options'] ) ) {
					$next_option = count( $p_addons['options'] );
					foreach ( $p_addons['options'] as $option_key => $option ) {
						$option_label      = $option['label'] ?? '';
						$option_price_type = $option['price_type'] ?? 'flat_fee';
						$option_price      = $option['price'] ?? '';
						$option_default    = $option['default'] ?? '';
						include __DIR__ . '/pa-price-option.php';
					}
				}
				?>
			</div>

			<div class="fmp-pa-option-action-btn">
				<button type="button" class="fmp-btn fmp-pa-add-options"
						data-current-counter-index="<?php echo esc_attr( $counter ); ?>" data-next-option-index="<?php echo esc_attr( ( $next_option + 1 ) - 1 ); ?>">
					<?php esc_html_e( 'Add Option', 'food-menu-pro' ); ?>
				</button>
			</div>

		</div>
	</div>

</div>