<?php

namespace RT\FoodMenuPro\Controllers\ProductAddons\Admin;

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Admin Product Addons Manin class
 */
class AdminPAddons {

	use SingletonTrait;

	/**
	 * Settings option
	 *
	 * @var array
	 */
	private $settings;

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		$this->settings = FnsPro::get_settings_option();
		$fm_type        = $this->settings['fm_food_menu_type'] ?? 'food_menu_post';
		if ( TLPFoodMenu()->isWcActive() && 'online_ordering' === $fm_type ) {
			add_filter( 'fmp/sub_menu/product_addons', [ $this, 'setting_global_addon' ] );
			add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
			add_action( 'woocommerce_product_write_panel_tabs', [ $this, 'product_addon_tab' ] );
			add_action( 'woocommerce_product_data_panels', [ $this, 'product_addon_content' ] );
			add_action( 'woocommerce_process_product_meta', [ $this, 'save_product_meta_data' ] );
			add_action( 'wp_ajax_add_product_addon', [ $this, 'add_product_addon' ] );
			add_action( 'wp_ajax_fmpGlobalAddonUpdate', [ $this, 'global_addon_setting' ] );
		}
	}

	/**
	 * Global Addon setting options.
	 */
	public function global_addon_setting() {
		$error = true;

		// Global addons price every product's add-ons — the public nonce alone let any customer rewrite them.
		if ( current_user_can( 'manage_options' ) && Fns::verifyNonce() ) {
			$request = filter_input_array( INPUT_POST, FILTER_SANITIZE_SPECIAL_CHARS );
			$data    = $this->product_addon_data( $request );
			update_option( TLPFoodMenu()->options['global_addon'], $data );
			$error = false;
			$msg   = esc_html__( 'Product addon successfully updated', 'food-menu-pro' );
		} else {
			$msg = esc_html__( 'Security Error !!', 'food-menu-pro' );
		}

		$response = [
			'error' => $error,
			'msg'   => $msg,
		];

		wp_send_json( $response );

		die();
	}

	/**
	 * Product addon sub menu settings page
	 *
	 * @return void
	 */
	public function setting_global_addon() {
		if ( file_exists( __DIR__ . '/templates/pa-settings-page.php' ) ) {
			include_once __DIR__ . '/templates/pa-settings-page.php';
		}
	}

	/**
	 * Ajax - Add product addon callback from settings page
	 *
	 * @return void
	 */
	public function add_product_addon() {
		if ( ! current_user_can( 'edit_products' ) || ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			wp_send_json(
				[
					'statusCode' => 0,
					'message'    => esc_attr__( 'Invalid nonce. Please retry.', 'food-menu-pro' ),
					'content'    => '',
				]
			);

			return;
		}

		ob_start();
		$counter       = isset( $_POST['PANextIndex'] ) ? absint( $_POST['PANextIndex'] ) : 0;
		$addon_section = isset( $_POST['PASection'] ) ? sanitize_text_field( wp_unslash( $_POST['PASection'] ) ) : '';
		include __DIR__ . '/templates/pa-single-field.php';
		$content = ob_get_clean();

		wp_send_json(
			[
				'statusCode' => 1,
				'message'    => esc_attr__( 'Fields added successfully.', 'food-menu-pro' ),
				'content'    => $content,
			]
		);
	}

	/**
	 * Add product panel tab in admin
	 *
	 * @return void
	 */
	public function product_addon_tab() {
		?>
		<li class="fmp-product-addon-tab  show_if_simple">
			<a href="#fmp-product-addons">
				<span><?php esc_html_e( 'Product Addons', 'food-menu-pro' ); ?></span>
			</a>
		</li>
		<?php
	}

	/**
	 * Product addon content
	 *
	 * @return void
	 */
	public function product_addon_content() {
		global $post;
		$product         = wc_get_product( $post );
		$product_addons  = $product ? (array) $product->get_meta( '_fmp_product_addons' ) : [];
		$global_override = $product ? $product->get_meta( '_fmp_pa_global_override' ) : '';
		// remove empty addons.
		$product_addons = array_filter( $product_addons );
		$product_addons = ! empty( $product_addons ) ? $product_addons : [];
		wp_nonce_field( Fns::nonceText(), Fns::nonceId() );
		include __DIR__ . '/templates/pa-fields-container.php';
	}

	/**
	 * Save product meta data
	 *
	 * @param number $post_id .
	 *
	 * @return void
	 */
	public function save_product_meta_data( $post_id ) {
		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			return;
		}
		$pa_data = $this->product_addon_data( $_POST );
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$global_override = ! empty( $_POST['fmp_pa_global_override'] ) ? wp_unslash( $_POST['fmp_pa_global_override'] ) : '';
		$product         = wc_get_product( $post_id );
		$product->update_meta_data( '_fmp_product_addons', $pa_data );
		$product->update_meta_data( '_fmp_pa_global_override', $global_override );
		$product->save();
	}

	/**
	 * Prepare Product addon data for save
	 *
	 * @param array $requestData .
	 *
	 * @return array
	 */
	public function product_addon_data( $requestData = [] ) {
		$pa_data = [];

		if ( isset( $requestData['fmp_pa_title'] ) ) {
			$pa_title      = $requestData['fmp_pa_title'];
			$pa_type       = $requestData['fmp_pa_type'] ?? [];
			$pa_categories = $requestData['fmp_pa_categories'] ?? [];
			$pa_menu_items = $requestData['fmp_pa_menu_items'] ?? [];
			$pa_position   = $requestData['fmp_pa_position'] ?? [];
			$pa_required    = $requestData['fmp_pa_required'] ?? [];
			$pa_placeholder    = $requestData['fmp_pa_placeholder'] ?? [];
			$pa_char_limit     = $requestData['fmp_pa_char_limit'] ?? [];
			$pa_min_selection  = $requestData['fmp_pa_min_selection'] ?? [];
			$pa_max_selection  = $requestData['fmp_pa_max_selection'] ?? [];
			$pa_option_qty     = $requestData['fmp_pa_option_qty'] ?? [];
			$pa_free_label     = $requestData['fmp_pa_free_label'] ?? [];
			$pa_description    = $requestData['fmp_pa_description'] ?? [];

			$pa_option_label      = $requestData['fmp_pa_option_label'] ?? [];
			$pa_option_price_type = $requestData['fmp_pa_option_price_type'] ?? [];
			$pa_option_price      = $requestData['fmp_pa_option_price'] ?? [];
			$pa_option_default    = $requestData['fmp_pa_option_default'] ?? [];
			$pa_option_image       = $requestData['fmp_pa_option_image'] ?? [];
			$pa_option_description = $requestData['fmp_pa_option_description'] ?? [];

			foreach ( $pa_title as $n => $title ) {
				if ( empty( $pa_title[ $n ] ) ) {
					continue;
				}

				$data               = [];
				$data['title']      = $this->sanitize_field( $pa_title[ $n ] );
				$data['type']       = $this->sanitize_field( $pa_type[ $n ] );
				$data['categories'] = $pa_categories[ $n ] ?? [];
				$data['menu_items'] = $pa_menu_items[ $n ] ?? [];
				$data['position']   = absint( $pa_position[ $n ] ) ?? 0;
				$data['required']    = ! empty( $pa_required[ $n ] ) ? 1 : 0;
				$data['placeholder'] = $this->sanitize_field( $pa_placeholder[ $n ] ?? '' );
				$data['char_limit']     = absint( $pa_char_limit[ $n ] ?? 0 );
				$data['min_selection']  = absint( $pa_min_selection[ $n ] ?? 0 );
				$data['max_selection']  = absint( $pa_max_selection[ $n ] ?? 0 );
				$data['option_qty']     = ! empty( $pa_option_qty[ $n ] ) ? 1 : 0;
				// '' = inherit the global setting, 'show' / 'hide' = per-group override.
				$free_label             = $this->sanitize_field( $pa_free_label[ $n ] ?? '' );
				$data['free_label']     = in_array( $free_label, [ 'show', 'hide' ], true ) ? $free_label : '';
				$data['description']    = sanitize_textarea_field( wp_unslash( $pa_description[ $n ] ?? '' ) );

				// Addon price options.
				$pa_options = [];
				if ( isset( $pa_option_label[ $n ] ) ) {
					$option_label      = $pa_option_label[ $n ];
					$option_price      = $pa_option_price[ $n ];
					$option_price_type = $pa_option_price_type[ $n ];
					$option_default    = $pa_option_default[ $n ] ?? [];
					$total_options     = count( $option_label );

					$option_image       = $pa_option_image[ $n ] ?? [];
					$option_description = $pa_option_description[ $n ] ?? [];

				for ( $opn = 0; $total_options > $opn; $opn++ ) {
						$label = $this->sanitize_field( $option_label[ $opn ] );
						if ( ! empty( $label ) ) {
							$image_id     = ! empty( $option_image[ $opn ] ) ? $this->validate_option_image( $option_image[ $opn ] ) : 0;
							$pa_options[] = [
								'label'       => $label,
								'price'       => $this->sanitize_field( $option_price[ $opn ] ),
								'price_type'  => $this->sanitize_field( $option_price_type[ $opn ] ),
								'default'     => in_array( $opn, $option_default ) ? 1 : 0,
								'image'       => $image_id,
								'description' => $this->sanitize_field( $option_description[ $opn ] ?? '' ),
							];
						}
					}
				}

				if ( ! empty( $pa_options ) || in_array( $data['type'], [ 'text', 'textarea' ], true ) ) {
					$data['options'] = $pa_options;
				}

				$pa_data[] = $data;
			}
		}

		uasort( $pa_data, [ $this, 'addon_rows_position_compare' ] );

		return $pa_data;
	}

	/**
	 * Sanitize input data
	 *
	 * @param string $field param.
	 *
	 * @return string
	 */
	public function sanitize_field( $field ) {
		return sanitize_text_field( wp_unslash( $field ) );
	}

	/**
	 * Product addons row position compare
	 *
	 * @param array $a .
	 * @param array $b .
	 *
	 * @return int
	 */
	public function addon_rows_position_compare( $a, $b ) {
		if ( $a['position'] == $b['position'] ) {
			return 0;
		}

		return ( $a['position'] < $b['position'] ) ? - 1 : 1;
	}

	/**
	 * Validate an attachment ID is a safe, allowed image.
	 *
	 * @param int $attachment_id Attachment post ID.
	 *
	 * @return int Validated attachment ID, or 0 if invalid.
	 */
	private function validate_option_image( $attachment_id ) {
		$attachment_id = absint( $attachment_id );

		if ( ! $attachment_id ) {
			return 0;
		}

		// Must be a real attachment in the media library.
		if ( 'attachment' !== get_post_type( $attachment_id ) ) {
			return 0;
		}

		// Must be an image MIME type.
		$allowed_types = [ 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml' ];
		$mime_type     = get_post_mime_type( $attachment_id );

		if ( ! in_array( $mime_type, $allowed_types, true ) ) {
			return 0;
		}

		// File must exist and not exceed 2 MB.
		$file_path = get_attached_file( $attachment_id );

		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return 0;
		}

		$max_size = 2 * MB_IN_BYTES; // 2 MB.

		if ( filesize( $file_path ) > $max_size ) {
			return 0;
		}

		return $attachment_id;
	}

	/**
	 * Admin enqueue assets
	 *
	 * @return void
	 */
	public function admin_enqueue_assets() {
		global $pagenow, $typenow;

		$global_addon_page = $_GET['page'] ?? ''; //phpcs:ignore
		$productPage       = in_array( $pagenow, [ 'edit.php', 'post.php', 'post-new.php' ], true );

		if ( ( TLPFoodMenu()->post_type == $typenow && 'product_addons' == $global_addon_page ) || ( 'product' == $typenow && $productPage ) ) {
			wp_enqueue_media();
			\wp_enqueue_script( 'fmp-admin-addon' );
		}
	}
}
