<?php

use \RT\FoodMenuPro\Controllers\ProductAddons\Frontend\AddonHelper;

$field_name = ! empty( $p_addon['field_name'] ) ? sanitize_text_field( $p_addon['field_name'] ) : '';
$required   = $p_addon['required'] ?? '';

if ( $required ) { ?>
	<div class="fmp-required-addon-opt" data-option-type="radio">
	<?php
}

$addon_options = $p_addon['options'] ?? [];

foreach ( $addon_options as $i => $option ) {
	$data          = AddonHelper::get_view_option_data( $option );
	$label         = $data['label'];
	$price_type    = $data['price_type'];
	$price         = $data['price'];
	$price_display = $data['price_display'];
	$default       = $data['default'];
	$has_price = $price ? 'has-price' : 'no-price';
	?>
	<div class="fmp-addon-radio fmp-addon-<?php echo esc_attr( $field_name . '-' . $i ); ?>">
		<label>
			<input type="radio" <?php echo ( $required ) ? 'required' : ''; ?>
				   class="fmp-radio fmp-addon-field"
				   name="fmp_addon_<?php echo esc_attr( $field_name ); ?>[]"
				   value="<?php echo esc_attr( $label ); ?>"
				   data-price-type="<?php echo esc_attr( $price_type ); ?>"
				   data-price="<?php echo esc_attr( $price ); ?>"
				   data-label="<?php echo esc_attr( wptexturize( $label ) ); ?>" <?php checked( 1, $default ); ?> />

            <span class="fmp-label <?php echo esc_attr( $has_price ) ?>">
				<span class="label-text"><?php echo wp_kses_post( wptexturize( $label ) ); ?></span>
				<span class="item-price-wrap"><?php echo wp_kses_post( wptexturize( $price_display ) ); ?></span>
			</span>
		</label>
	</div>
	<?php
}

if ( $required ) {
	?>
	</div>
	<?php
}
