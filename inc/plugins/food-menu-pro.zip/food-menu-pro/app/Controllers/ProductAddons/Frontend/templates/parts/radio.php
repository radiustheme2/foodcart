<?php

use \RT\FoodMenuPro\Controllers\ProductAddons\Frontend\AddonHelper;

$field_name = ! empty( $p_addon['field_name'] ) ? sanitize_text_field( $p_addon['field_name'] ) : '';
$required   = $p_addon['required'] ?? '';
$option_qty = ! empty( $p_addon['option_qty'] ) ? 1 : 0;

if ( $required ) { ?>
	<div class="fmp-required-addon-opt" data-option-type="radio">
	<?php
}
?>
<div class="fmp-radio-group" data-option-qty="<?php echo esc_attr( $option_qty ); ?>">
<?php

$addon_options = $p_addon['options'] ?? [];

foreach ( $addon_options as $i => $option ) {
	$data          = AddonHelper::get_view_option_data( $option, $p_addon );
	$label         = $data['label'];
	$price_type    = $data['price_type'];
	$price         = $data['price'];
	$price_display = $data['price_display'];
	$default       = $data['default'];
	$has_price = ! empty( $data['is_free'] ) ? 'no-price' : ( $price ? 'has-price' : 'no-price' );
	$qty_class = $option_qty ? ' fmp-has-option-qty' : '';
	?>
	<div class="fmp-addon-radio fmp-addon-<?php echo esc_attr( $field_name . '-' . $i ); ?><?php echo esc_attr( $qty_class ); ?>">
		<label<?php echo ! empty( $data['image_url'] ) ? ' class="fmp-has-addon-img"' : ''; ?>>
			<input type="radio" <?php echo ( $required ) ? 'required' : ''; ?>
				   class="fmp-radio fmp-addon-field"
				   name="fmp_addon_<?php echo esc_attr( $field_name ); ?>[]"
				   value="<?php echo esc_attr( $label ); ?>"
				   data-price-type="<?php echo esc_attr( $price_type ); ?>"
				   data-price="<?php echo esc_attr( $price ); ?>"
				   data-label="<?php echo esc_attr( wptexturize( $label ) ); ?>" <?php checked( 1, $default ); ?> />

            <span class="fmp-label <?php echo esc_attr( $has_price ) ?>">
				<?php if ( ! empty( $data['image_url'] ) ) : ?>
					<img src="<?php echo esc_url( $data['image_url'] ); ?>"
						 data-full-src="<?php echo esc_url( $data['image_full_url'] ); ?>"
						 class="fmp-addon-option-img"
						 width="40" height="40"
						 alt="<?php echo esc_attr( $label ); ?>" />
				<?php endif; ?>
				<span class="label-text"><?php echo wp_kses_post( wptexturize( $label ) ); ?></span>
				<?php if ( '' !== $price_display ) : ?>
					<span class="item-price-wrap<?php echo ! empty( $data['is_free'] ) ? ' fmp-free-label' : ''; ?>"><?php echo wp_kses_post( wptexturize( $price_display ) ); ?></span>
				<?php endif; ?>
			</span>
			<?php if ( ! empty( $data['description'] ) ) : ?>
				<span class="fmp-option-description"><?php echo esc_html( $data['description'] ); ?></span>
			<?php endif; ?>
		</label>
		<?php if ( $option_qty ) { ?>
			<div class="fmp-qty-wrap" style="display:none">
				<button type="button" class="fmp-qty-btn fmp-qty-minus" aria-label="<?php esc_attr_e( 'Decrease quantity', 'food-menu-pro' ); ?>">-</button>
				<input type="number" class="fmp-addon-option-qty"
					   name="fmp_addon_qty_<?php echo esc_attr( $field_name ); ?>[<?php echo esc_attr( $i ); ?>]"
					   value="1" min="1" max="10" step="1"
					   data-option-index="<?php echo esc_attr( $i ); ?>" readonly />
				<button type="button" class="fmp-qty-btn fmp-qty-plus" aria-label="<?php esc_attr_e( 'Increase quantity', 'food-menu-pro' ); ?>">+</button>
			</div>
		<?php } ?>
	</div>
	<?php
}
?>
</div>
<?php

if ( $required ) {
	?>
	</div>
	<?php
}
