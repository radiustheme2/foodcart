<?php

namespace RT\FoodMenuPro\Controllers\ProductAddons\Frontend;

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenu\Helpers\Fns;

/**
 * Product addon frontend main class
 */
class FrontendPAddon {

	use SingletonTrait;

	/**
	 * Plugin settings
	 *
	 * @var array $settings
	 */
	private $settings;

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		$this->settings = FnsPro::get_settings_option();
		$fm_type        = $this->settings['fm_food_menu_type'] ?? 'food_menu_post';

		if ( TLPFoodMenu()->isWcActive() && 'online_ordering' === $fm_type ) {
			add_action( 'woocommerce_before_add_to_cart_button', [ $this, 'display_product_addons' ] );
		}

		if ( TLPFoodMenu()->isWcActive() ) {
			add_action( 'wp_enqueue_scripts', [ $this, 'addon_scripts' ] );
		}
	}

	/**
	 * Display Product addon in product details page
	 *
	 * @return void
	 */
	public function display_product_addons() {
		global $product;

		$product_type_support = [
			'simple',
			// 'variable',
		];

		if ( ! in_array( $product->get_type(), $product_type_support, true ) ) {
			return;
		}

        //Display product addon on the front-end
		$product_addons = $this->addon_lists( $product->get_id() );

		if ( is_array( $product_addons ) && count( $product_addons ) > 0 ) {
			echo '<div class="fmp-product-addons-wrap">';
			$counter = 0;
			foreach ( $product_addons as $p_addon ) {
				$p_addon['field_name'] = sanitize_title( $product->get_id() . '-' . $p_addon['title'] . '-' . $counter );
				wc_get_template(
					'templates/pa-start.php',
					[ 'p_addon' => $p_addon ],
					'food-menu-pro',
					__DIR__ . '/'
				);
				//phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $this->get_addon_option( $p_addon );
				wc_get_template(
					'templates/pa-end.php',
					[ 'p_addon' => $p_addon ],
					'food-menu-pro',
					__DIR__ . '/'
				);
				$counter ++;
			}

			$this->calculate_total_addon();

			echo '</div>';
		}
	}

	/**
	 * Product Single Page Addon Price calculate
	 *
	 * @return void
	 */
	private function calculate_total_addon() {
		global $product;
		$product_id          = $product->get_id();
		$product_price       = wc_get_price_to_display( $product );
		$product_type        = $product->get_type();
		$is_discount         = false;
		$discount_percentage = 0;

		$discount_price_args = [
			'product_id'    => $product_id,
			'data'          => 'single_page_data',
			'product_price' => null,
		];

		$discount_price_data = FnsPro::discount_price( $discount_price_args );

		if ( ! empty( $discount_price_data['main_price'] ) && ! empty( $discount_price_data['price_after_discount'] )
		     && $product->get_type() !== 'variable' ) {
			$is_discount         = true;
			$discount_percentage = $discount_price_data['discount_percentage'];
			$product_price       = $discount_price_data['new_price'];
		}

		$currency_position = get_option( 'woocommerce_currency_pos' );
		$symbol_html       = get_woocommerce_currency_symbol();
		$print_left        = str_contains( $currency_position, 'left' );
		$discount_apply_to = $this->settings['fmp_applicable_discount'] ?? '';
		?>


        <div class="fmp-product-addon-total"
             data-prod-price="<?php echo esc_attr( $product_price ); ?>"
             data-prod-type="<?php echo esc_attr( $product_type ); ?>"
             data-prod-id="<?php echo esc_attr( $product_id ); ?>"
             data-prod-discount="<?php echo esc_attr( $is_discount ); ?>"
             data-discount-percentage="<?php echo esc_attr( $discount_percentage ); ?>"
             data-discount-apply-to="<?php echo esc_attr( $discount_apply_to ); ?>"
             data-price-decimal-number="<?php echo esc_attr( wc_get_price_decimals() ); ?>"
             data-decimal-separator="<?php echo esc_attr( wc_get_price_decimal_separator() ); ?>"
             data-thousand-separator="<?php echo esc_attr( wc_get_price_thousand_separator() ); ?>"
             data-currency-symbol="<?php echo esc_attr( $symbol_html ); ?>"
        >
            <div class="fmp-price-item">
                <label><?php esc_html_e( 'Product Total', 'food-menu-pro' ); ?></label>
                <span class="amount">
					 <?php echo esc_html( $print_left ? $symbol_html : '' ); ?>
					 <span class="total fmp-product-total">
						 <?php
						 // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						 echo wc_format_decimal( $product_price, wc_get_price_decimals() );
						 //echo wc_price( $product_price )
						 ?>
					 </span>
					<?php echo esc_html( ! $print_left ? $symbol_html : '' ); ?>
				</span>
            </div>

            <div class="fmp-price-item">
                <label><?php esc_html_e( 'Addons Total', 'food-menu-pro' ); ?></label>
                <span class="amount">
					<?php echo esc_html( $print_left ? $symbol_html : '' ); ?>
					<span class="total fmp-addon-option-total">0</span>
					<?php echo esc_html( ! $print_left ? $symbol_html : '' ); ?>
				</span>
            </div>

            <div class="fmp-price-item grand-total">
                <label><?php esc_html_e( 'Totals', 'food-menu-pro' ); ?></label>
                <span class="amount">
				<?php echo esc_html( $print_left ? $symbol_html : '' ); ?>
					 <span class="total fmp-grand-total">
						 <?php
						 /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */
						 echo wc_format_decimal( $product_price, wc_get_price_decimals() );
						 //echo wc_price( $product_price )
						 ?>
					 </span>
					<?php echo esc_html( ! $print_left ? $symbol_html : '' ); ?>
				</span>
            </div>
        </div>
		<?php
	}

	/**
	 * Get global and product addon lists.
	 *
	 * @param number $product_id .
	 *
	 * @return array;
	 */
	public function addon_lists( $product_id ) {
        //Overwrite addon from details page
		$global_override = get_post_meta( $product_id, '_fmp_pa_global_override', true );

		if ( ! empty( $global_override ) ) {
			$product_addons = AddonHelper::get_product_addon_data( $product_id ); //overwrite addon
		} else {
			$product_addons = AddonHelper::get_global_addon_data( $product_id ); //global addons
		}

		return $product_addons;
	}

	/**
	 * Get addon options
	 *
	 * @param array $p_addon .
	 *
	 * @return false|string
	 */
	public function get_addon_option( $p_addon ) {
		ob_start();

		$method_name = 'get_addon_' . $p_addon['type'] . '_option';

		wp_nonce_field( Fns::nonceText(), Fns::nonceId() );

		if ( method_exists( $this, $method_name ) ) {
			$this->$method_name( $p_addon );
		}

		return ob_get_clean();
	}

	/**
	 * Get checkbox option.
	 *
	 * @param array $p_addon .
	 *
	 * @return void
	 */
	public function get_addon_checkbox_option( $p_addon ) {
		wc_get_template(
			'templates/parts/checkbox.php',
			[ 'p_addon' => $p_addon ],
			'food-menu-pro',
			__DIR__ . '/'
		);
	}

	/**
	 * Get dropdown option.
	 *
	 * @param array $p_addon .
	 *
	 * @return void
	 */
	public function get_addon_dropdown_option( $p_addon ) {
		wc_get_template(
			'templates/parts/dropdown.php',
			[ 'p_addon' => $p_addon ],
			'food-menu-pro',
			__DIR__ . '/'
		);
	}

	/**
	 * Get radio option template.
	 *
	 * @param array $p_addon .
	 *
	 * @return void
	 */
	public function get_addon_radio_option( $p_addon ) {
		wc_get_template(
			'templates/parts/radio.php',
			[ 'p_addon' => $p_addon ],
			'food-menu-pro',
			__DIR__ . '/'
		);
	}

	/**
	 * Get text input option template.
	 *
	 * @param array $p_addon .
	 *
	 * @return void
	 */
	public function get_addon_text_option( $p_addon ) {
		wc_get_template(
			'templates/parts/text.php',
			[ 'p_addon' => $p_addon ],
			'food-menu-pro',
			__DIR__ . '/'
		);
	}

	/**
	 * Get textarea option template.
	 *
	 * @param array $p_addon .
	 *
	 * @return void
	 */
	public function get_addon_textarea_option( $p_addon ) {
		wc_get_template(
			'templates/parts/textarea.php',
			[ 'p_addon' => $p_addon ],
			'food-menu-pro',
			__DIR__ . '/'
		);
	}

	/**
	 * Enqueue addon script
	 *
	 * @return void
	 */
	public function addon_scripts() {
		wp_enqueue_script( 'fmp-addon' );

		$fm_type = $this->settings['fm_food_menu_type'] ?? 'food_menu_post';

		/**
		 * AJAX add to cart is always on for online ordering — the old
		 * `single_add_to_cart_ajax` setting is gone, because simple products were
		 * already added over AJAX regardless of it, and having variable/add-on
		 * products behave differently only confused stores. Menu-display installs
		 * ('food_menu_post') keep WooCommerce's default form submit.
		 *
		 * Filterable so a store can opt back out.
		 */
		$ajax_add_to_cart = apply_filters(
			'fmp_ajax_single_add_to_cart',
			'online_ordering' === $fm_type ? 'on' : 'off'
		);

		$nonce = wp_create_nonce( Fns::nonceText() );

		\wp_localize_script(
			'fmp-addon',
			'fmpAddonVar',
			[
				'nonceID'                => esc_attr( Fns::nonceId() ),
				'nonce'                  => esc_attr( $nonce ),
				'ajaxurl'                => esc_url( admin_url( 'admin-ajax.php' ) ),
				'ajaxAddToCart'          => $ajax_add_to_cart,
				// Kept for backward compatibility with any custom script reading the old key.
				'singleAddToCartAjax'    => $ajax_add_to_cart,
				'productSingleScrollTop' => apply_filters( 'product_single_scroll_top', true ),
			]
		);
	}

}
