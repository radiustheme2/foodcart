<?php

namespace RT\FoodMenuPro\Controllers\ProductAddons\Frontend;

use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Product addon frontend helper function class
 */
class AddonHelper {

	/**
	 * Get Product addon
	 *
	 * @param number $product_id .
	 * @return array
	 */
	public static function get_product_addon_data( $product_id ) {

		if ( ! $product_id ) {
			return [];
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return [];
		}

		return array_filter( (array) $product->get_meta( '_fmp_product_addons' ) );
	}

	/**
	 * Get global product addon data
	 *
	 * @param number $product_id .
	 * @return array;
	 */
	public static function get_global_addon_data( $product_id ) {

		$settings        = FnsPro::get_settings_option( TLPFoodMenu()->options['global_addon'] );
		$addons          = [];
		$is_global_addon = false;

		if ( empty( $settings ) ) {
			return [];
		}

		foreach ( $settings as $key => $setting ) {

			$pa_menu_items = $setting['menu_items'] ?? [];
			$pa_categories = $setting['categories'] ?? [];

			if ( empty( $pa_menu_items ) && empty( $pa_categories ) ) {
				$is_global_addon = true;
			} elseif ( in_array( $product_id, $pa_menu_items ) && ( wp_doing_ajax() || ! is_admin() ) ) {
				$is_global_addon = true;
			} else {
				$product_terms = get_the_terms( $product_id, 'product_cat' );
				if ( is_array( $product_terms ) ) {
					foreach ( $product_terms as $term ) {
						if ( in_array( $term->term_id, $pa_categories ) ) {
							$is_global_addon = true;
						}
					}
				}
			}

			if ( $is_global_addon ) {
				$addons[ $key ] = $setting;
			}
			$is_global_addon = false;
		}

		return $addons;
	}

	/**
	 * Making Option Data.
	 *
	 * @param array $option .
	 * @return array
	 */
	public static function get_view_option_data( $option = [] ) {

		$label         = $option['label'] ?? '';
		$price_type    = $option['price_type'] ?? '';
		$price         = $option['price'] ?? '';
		$price_display = '(' . wc_price( $price ) . ')';
		$default       = isset( $option['default'] ) && $option['default'] == 1 ? 1 : 0;

		return [
			'label'         => $label,
			'price_type'    => $price_type,
			'price'         => $price,
			'price_display' => $price_display,
			'default'       => $default,
		];
	}
}
