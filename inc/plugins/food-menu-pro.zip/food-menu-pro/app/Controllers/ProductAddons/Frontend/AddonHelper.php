<?php

namespace RT\FoodMenuPro\Controllers\ProductAddons\Frontend;

use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Product addon frontend helper function class
 */
class AddonHelper {

	/**
	 * Get Product addon
	 *
	 * @param number $product_id .
	 * @return array
	 */
	public static function get_product_addon_data( $product_id ) {

		if ( ! $product_id ) {
			return [];
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return [];
		}

		return array_filter( (array) $product->get_meta( '_fmp_product_addons' ) );
	}

	/**
	 * Get global product addon data
	 *
	 * @param number $product_id .
	 * @return array;
	 */
	public static function get_global_addon_data( $product_id ) {

		$settings        = FnsPro::get_settings_option( TLPFoodMenu()->options['global_addon'] );
		$addons          = [];
		$is_global_addon = false;

		if ( empty( $settings ) ) {
			return [];
		}

		foreach ( $settings as $key => $setting ) {

			$pa_menu_items = $setting['menu_items'] ?? [];
			$pa_categories = $setting['categories'] ?? [];

			if ( empty( $pa_menu_items ) && empty( $pa_categories ) ) {
				$is_global_addon = true;
			} elseif ( in_array( $product_id, $pa_menu_items ) && ( wp_doing_ajax() || ! is_admin() ) ) {
				$is_global_addon = true;
			} else {
				$product_terms = get_the_terms( $product_id, 'product_cat' );
				if ( is_array( $product_terms ) ) {
					foreach ( $product_terms as $term ) {
						if ( in_array( $term->term_id, $pa_categories ) ) {
							$is_global_addon = true;
						}
					}
				}
			}

			if ( $is_global_addon ) {
				$addons[ $key ] = $setting;
			}
			$is_global_addon = false;
		}

		return $addons;
	}

	/**
	 * Whether the "Free" badge should be printed on zero-priced options of an addon group.
	 *
	 * The group's own "free_label" wins when it is set to 'show' or 'hide'; an empty value
	 * (the default, and what every pre-existing addon holds) inherits the global setting.
	 *
	 * @param array $p_addon Addon group the option belongs to.
	 * @return bool
	 */
	public static function show_free_label( $p_addon = [] ) {
		$group = $p_addon['free_label'] ?? '';

		if ( 'show' === $group ) {
			return true;
		}

		if ( 'hide' === $group ) {
			return false;
		}

		// Resolved once per request — this runs for every option of every addon group.
		static $global = null;

		if ( null === $global ) {
			// Default on, so installs that never touch the setting keep the current badge.
			$global = ( 'on' === Fns::get_setting( 'fmp_addon_show_free_label', 'on' ) );
		}

		return $global;
	}

	/**
	 * Making Option Data.
	 *
	 * @param array $option .
	 * @param array $p_addon Addon group the option belongs to, for the per-group "Free" badge rule.
	 * @return array
	 */
	public static function get_view_option_data( $option = [], $p_addon = [] ) {

		$label      = $option['label'] ?? '';
		$price_type = $option['price_type'] ?? '';
		$price      = $option['price'] ?? '';
		// Price is stored as free text, so it can hold things like "-" or "N/A" that mean
		// "no charge". Normalize to a number here so the data-price attribute is always
		// numeric — a non-numeric one becomes NaN in JS and wipes out the addon/grand total.
		$price          = is_numeric( $price ) ? (float) $price : 0;
		$is_free = ( 0.0 === (float) $price );

		if ( $is_free ) {
			$price_display = self::show_free_label( $p_addon ) ? esc_html__( 'Free', 'food-menu-pro' ) : '';
		} else {
			$price_display = '(' . wc_price( $price ) . ')';
		}

		$default        = isset( $option['default'] ) && $option['default'] == 1 ? 1 : 0;
		$image_id       = ! empty( $option['image'] ) ? absint( $option['image'] ) : 0;
		$image_url      = $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '';
		$image_full_url = $image_id ? wp_get_attachment_image_url( $image_id, 'full' ) : '';

		return [
			'label'          => $label,
			'price_type'     => $price_type,
			'price'          => $price,
			'price_display'  => $price_display,
			'default'        => $default,
			'is_free'        => $is_free,
			'description'    => $option['description'] ?? '',
			'image_url'      => $image_url,
			'image_full_url' => $image_full_url,
		];
	}
}
