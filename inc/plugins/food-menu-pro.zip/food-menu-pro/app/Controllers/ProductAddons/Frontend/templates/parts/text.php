<?php

$field_name  = ! empty( $p_addon['field_name'] ) ? sanitize_text_field( $p_addon['field_name'] ) : '';
$required    = $p_addon['required'] ?? '';
$placeholder = $p_addon['placeholder'] ?? '';
$char_limit  = ! empty( $p_addon['char_limit'] ) ? absint( $p_addon['char_limit'] ) : 0;
$price       = ! empty( $p_addon['options'][0]['price'] ) ? floatval( $p_addon['options'][0]['price'] ) : 0;
$price_type  = $p_addon['options'][0]['price_type'] ?? 'flat_fee';

if ( $required ) { ?>
	<div class="fmp-required-addon-opt" data-option-type="text">
	<?php
}
?>
	<div class="fmp-addon-text fmp-addon-<?php echo esc_attr( $field_name ); ?>">
		<input type="text"
			   class="fmp-addon-field fmp-addon-field-text"
			   name="fmp_addon_<?php echo esc_attr( $field_name ); ?>"
			   placeholder="<?php echo esc_attr( $placeholder ); ?>"
			   data-price="<?php echo esc_attr( $price ); ?>"
			   data-price-type="<?php echo esc_attr( $price_type ); ?>"
			   <?php echo $char_limit > 0 ? 'maxlength="' . esc_attr( $char_limit ) . '"' : ''; ?>
			   <?php echo ( $required ) ? 'required' : ''; ?> />
	</div>
<?php

if ( $required ) {
	?>
	</div>
	<?php
}
