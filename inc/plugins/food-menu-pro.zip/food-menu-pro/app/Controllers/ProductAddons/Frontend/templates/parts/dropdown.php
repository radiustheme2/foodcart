<?php

use \RT\FoodMenuPro\Controllers\ProductAddons\Frontend\AddonHelper;

$field_name     = ! empty( $p_addon['field_name'] ) ? sanitize_text_field( $p_addon['field_name'] ) : '';
$required       = $p_addon['required'] ?? '';
$default_option = $required ? esc_html__( 'Select option', 'food-menu-pro' ) : esc_html__( 'None', 'food-menu-pro' );
$counter        = 0;
if ( $required ) { ?>
    <div class="fmp-required-addon-opt" data-option-type="dropdown">
	<?php
}
?>
    <div class=" fmp-addon-select fmp-addon-<?php echo esc_attr( $field_name ); ?>">
        <select name="fmp_addon_<?php echo esc_attr( $field_name ); ?>" class="fmp-select fmp-addon-field">
            <option value="" data-price="0"><?php echo esc_html( $default_option ); ?></option>
			<?php
			foreach ( $p_addon['options'] as $i => $option ) {
				$counter ++;
				$data = AddonHelper::get_view_option_data( $option, $p_addon );

				$label         = $data['label'];
				$price_type    = $data['price_type'];
				$price         = $data['price'];
				$price_display = $data['price_display'];
				$default       = $data['default'];
				$has_price     = ! empty( $data['is_free'] ) ? 'no-price' : ( $price ? 'has-price' : 'no-price' );
				?>
                <option value="<?php echo esc_attr( $label . '-' . $counter ); ?>" <?php selected( 1, $default ); ?>
                        data-label="<?php echo esc_attr( wptexturize( $label ) ); ?>"
                        data-price-type="<?php echo esc_attr( $price_type ); ?>"
                        data-price="<?php echo esc_attr( $price ); ?>">
					 <span class="fmp-label <?php echo esc_attr( $has_price ) ?>">
                        <span class="label-text"><?php echo wp_kses_post( wptexturize( $label ) ); ?></span>
						<?php if ( '' !== $price_display ) : ?>
							<span class="item-price-wrap"><?php echo wp_kses_post( wptexturize( $price_display ) ); ?></span>
						<?php endif; ?>
                    </span>
                </option>
				<?php
			}
			?>

        </select>
    </div>
<?php
if ( $required ) {
	?>
    </div>
	<?php
}
