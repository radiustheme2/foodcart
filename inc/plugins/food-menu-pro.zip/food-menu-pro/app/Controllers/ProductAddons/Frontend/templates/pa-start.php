<?php

use RT\FoodMenu\Helpers\Fns;

// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
$title    = $p_addon['title'] ?? '';
$required = $p_addon['required'] ?? '';

$required_html = $required ? '<span class="required" title="' . esc_attr( 'Required Fields' ) . '">&nbsp;*</span>' : ''
?>
<div class="fmp-addon-inner-content">
	<h3>
		<?php
			echo esc_html( $title );
			echo wp_kses( $required_html, Fns::allowedHtml() );
		?>
	</h3>
