<?php

namespace RT\FoodMenuPro\Controllers\ProductAddons\Frontend;

/**
 * Making addon fields option
 */
class AddonFields {

	/**
	 * Addon
	 *
	 * @var array
	 */
	public $addon;

	/**
	 * Addon value
	 *
	 * @var mixed
	 */
	public $value;

	/**
	 * Addon Type
	 *
	 * @var mixed
	 */
	public $option_type;

	/**
	 * Constructor function set data
	 *
	 * @param array $params .
	 */
	public function __construct( $params ) {
		$this->option_type = $params['type'];
		$this->value       = $params['value'];
		$this->addon       = $params['addon'];
	}

	/**
	 * Get option type by value
	 *
	 * @return array;
	 */
	public function get_cart_item_content() {
		if ( 'dropdown' == $this->option_type ) {
			$cart_item_data = $this->get_dropdown_options_data();
		} elseif ( 'checkbox' == $this->option_type || 'radio' == $this->option_type ) {
			$cart_item_data = $this->get_checkbox_options_data();
		} else {
			$cart_item_data = [];
		}

		return $cart_item_data;
	}

	/**
	 * Get checkbox option data
	 *
	 * @return array|false
	 */
	public function get_checkbox_options_data() {
		$cart_item_data = [];
		$value          = $this->value;

		if ( empty( $value ) || ! is_array( $value ) ) {
			return false;
		}

		if ( is_array( current( $value ) ) ) {
			$value = current( $value );
		}

		$values = array_map( 'strtolower', array_values( $value ) );

		foreach ( $this->addon['options'] as $option ) {
			$label = strtolower( esc_html( $option['label'] ) );

			if ( in_array( $label, $values ) ) {
				$cart_item_data[] = [
					'name'       => sanitize_text_field( $this->addon['title'] ),
					'value'      => $option['label'],
					'price'      => floatval( sanitize_text_field( $option['price'] ) ),
					'field_name' => $this->addon['field_name'],
					'field_type' => $this->addon['type'],
					'price_type' => $option['price_type'],
				];
			}
		}

		return $cart_item_data;
	}

	/**
	 * Get dropdown option data
	 *
	 * @return mixed
	 */
	public function get_dropdown_options_data() {
		$cart_item_data = [];

		if ( empty( $this->value ) || ! is_array( $this->addon['options'] ) ) {
			return false;
		}

		$dropdown_option = null;
		$counter         = 0;

		foreach ( $this->addon['options'] as $option ) {
			$counter ++;

			$lable_val =  html_entity_decode( $option['label'], ENT_QUOTES ) . '-' . $counter;

			if ( $lable_val == $this->value ) {
				$dropdown_option = $option;
				break;
			}
		}

		if ( ! $dropdown_option ) {
			return false;
		}

		$cart_item_data[] = [
			'name'       => sanitize_text_field( $this->addon['title'] ),
			'value'      => $dropdown_option['label'],
			'price'      => floatval( sanitize_text_field( $dropdown_option['price'] ) ),
			'field_name' => $this->addon['field_name'],
			'field_type' => $this->addon['type'],
			'price_type' => $dropdown_option['price_type'],
		];

		return $cart_item_data;
	}

}
