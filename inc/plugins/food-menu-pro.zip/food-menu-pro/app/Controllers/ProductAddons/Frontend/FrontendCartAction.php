<?php

namespace RT\FoodMenuPro\Controllers\ProductAddons\Frontend;

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenu\Helpers\Fns;

/**
 * Frontend Cart all action hooks
 */
class FrontendCartAction {

	use SingletonTrait;

	/**
	 * Plugin settings
	 *
	 * @var array $settings
	 */
	private $settings;

	/**
	 * Init function fire when create instance
	 */
	public function init() {
		$this->settings = FnsPro::get_settings_option();
		$fm_type        = $this->settings['fm_food_menu_type'] ?? 'food_menu_post';

		if ( TLPFoodMenu()->isWcActive() && 'online_ordering' === $fm_type ) {
			// data insert in cart item data.
			add_filter( 'woocommerce_add_cart_item_data', [ $this, 'add_data_to_cart' ], 20, 2 );
			// display data in cart.
			add_filter( 'woocommerce_get_item_data', [ $this, 'display_addon_data_in_cart' ], 10, 2 );

			// add to cart item price update.
			add_filter( 'woocommerce_add_cart_item', [ $this, 'price_update_cart_item' ], 20 );

			// price update in cart.
			add_filter( 'woocommerce_get_cart_item_from_session', [ $this, 'get_cart_item_from_session' ], 20, 2 );
			add_action( 'woocommerce_checkout_create_order_line_item', [ $this, 'display_checkout_order_line_item' ], 10, 3 );
			add_filter( 'woocommerce_hidden_order_itemmeta', [ $this, 'hide_admin_order_details' ], 10, 1 );
			add_action( 'woocommerce_new_order_item', [ $this, 'add_discount_in_checkout_admin_order' ], 1, 2 );
		}
	}

	/**
	 * Add discount checkout thank you and admin order
	 *
	 * @param number $item_id .
	 * @param array $values .
	 *
	 * @return void
	 */
	public function add_discount_in_checkout_admin_order( $item_id, $values ) {
		$addons_price = absint( wc_get_order_item_meta( $item_id, '_addons_price' ) );

		$discount_price_args = [
			'product_id'    => $values['product_id'],
			'data'          => 'thank_you_order_details',
			'product_price' => null,
			'addons_price'  => $addons_price,
		];

		$fmp_data = FnsPro::discount_price( $discount_price_args );

		if ( ! empty( $fmp_data['main_price'] ) && ! empty( $fmp_data['price_after_discount'] ) ) {
			if ( $addons_price > 0 ) {
				wc_add_order_item_meta(
					$item_id,
					esc_html__( 'Addons price', 'food-menu-pro' ),
					wc_price( $addons_price )
				);
				wc_add_order_item_meta(
					$item_id,
					esc_html__( 'Addon Price after discount', 'food-menu-pro' ),
					wc_price( $fmp_data['addons_new_price'] ),
				);
			}
		}
	}

	/**
	 * Display checkout and order
	 *
	 * @param array $item .
	 * @param array $cart_key .
	 * @param array $values .
	 *
	 * @return void
	 */
	public function display_checkout_order_line_item( $item, $cart_key, $values ) {
		if ( empty( $values['fmp_addons'] ) ) {
			return;
		}

		$addons_total_price = 0;
		foreach ( $values['fmp_addons'] as $addon ) {
			$addon_price        = $addon['price'] ?? 0;
			$addons_total_price += $addon_price;

			$value = $addon['value'];
			if ( $addon_price ) {
				$price = wc_price( $addon_price );
				$value .= " ($price)";
			}

			$item->add_meta_data( $addon['name'], $value );
		}

		if ( $addons_total_price > 0 ) {
			$item->add_meta_data( '_addons_price', $addons_total_price );
		}
	}

	/**
	 * Update price from cart data session
	 *
	 * @param array $cart_item .
	 * @param array $values .
	 *
	 * @return array|mixed
	 */
	public function get_cart_item_from_session( $cart_item, $values ) {
		// Update prices.
		$prices = [
			'price'         => (float) $cart_item['data']->get_price( 'edit' ),
			'regular_price' => (float) $cart_item['data']->get_regular_price( 'edit' ),
			'sale_price'    => (float) $cart_item['data']->get_sale_price( 'edit' ),
		];

		// Update addons.
		if ( isset( $values['fmp_addons'] ) ) {
			$cart_item['fmp_addons'] = $values['fmp_addons'];
		}

		// Update product price with addons.
		return $this->update_product_price( $cart_item, $cart_item['quantity'], $prices );
	}

	/**
	 * Price update cart item.
	 *
	 * @param array $cart_item_data .
	 *
	 * @return array
	 */
	public function price_update_cart_item( $cart_item_data ) {
		$prices = [
			'regular_price' => (float) $cart_item_data['data']->get_regular_price( 'edit' ),
			'sale_price'    => (float) $cart_item_data['data']->get_sale_price( 'edit' ),
			'price'         => (float) $cart_item_data['data']->get_price( 'edit' ),
		];

		return $this->update_product_price( $cart_item_data, $cart_item_data['quantity'], $prices );
	}

	/**
	 * Price Calculation
	 *
	 * @param array $cart_data .
	 * @param array $prices .
	 *
	 * @return array
	 */
	public function price_calculate( $cart_data, $prices ) {
		$price        = $prices['price'];
		$addons_price = 0;

		if ( ! empty( $cart_data['fmp_addons'] ) ) {
			foreach ( $cart_data['fmp_addons'] as $addon ) {
				$addon_price  = $addon['price'];
				$addons_price += $addon_price;
			}
		}

		// If discount exists.
		$settings = FnsPro::get_settings_option();
		if ( ! empty( $settings['fmp_discount_percentage'] ) && '0' !== $settings['fmp_discount_percentage'] ) {
			$discount_price_args = [
				'product_id'    => $cart_data['product_id'],
				'data'          => 'fmp_cart',
				'product_price' => $price,
				'addons_price'  => $addons_price,
			];
			$discount_price_data = FnsPro::discount_price( $discount_price_args );
			if ( ! empty( $discount_price_data['new_price'] ) ) {
				$price = (float) ( $discount_price_data['new_price'] + $discount_price_data['addons_new_price'] );
			} else {
				$price = (float) ( $price + $addons_price );
			}
		} else {
			$price = (float) ( $price + $addons_price );
		}

		// Set regular and sale prices.
		$regular_price = $price;
		$sale_price    = $price;

		return compact( 'price', 'regular_price', 'sale_price', 'addons_price' );
	}

	/**
	 * Update product price.
	 *
	 * @param array $cart_item_data .
	 * @param array $qty .
	 * @param array $prices .
	 *
	 * @return array
	 */
	public function update_product_price( $cart_item_data, $qty, $prices ) {
		$result_data = $this->price_calculate( $cart_item_data, $prices );

		// Set updated prices directly to the product data object .
		$cart_item_data['data']->set_price( $result_data['price'] );
		$cart_item_data['data']->set_regular_price( $result_data['regular_price'] );
		$cart_item_data['data']->set_sale_price( $result_data['sale_price'] );

		return $cart_item_data;
	}

	/**
	 * Add data in cart item
	 *
	 * @param array $cart_item_data .
	 * @param number $product_id .
	 *
	 * @return array;
	 */
	public function add_data_to_cart( $cart_item_data, $product_id ) {
		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			return;
		}

		if ( empty( $_POST ) && empty( $product_id ) ) {
			return;
		}

		$global_override = get_post_meta( $product_id, '_fmp_pa_global_override', true );
		if ( ! empty( $global_override ) ) {
			$product_addons = AddonHelper::get_product_addon_data( $product_id );
		} else {
			$product_addons = AddonHelper::get_global_addon_data( $product_id );
		}

		if ( empty( $cart_item_data['fmp_addons'] ) ) {
			$cart_item_data['fmp_addons'] = [];
		}

		$counter     = 0;
		foreach ( $product_addons as $addon ) {
			$addon['field_name'] = sanitize_title( $product_id . '-' . $addon['title'] . '-' . $counter );

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$value         = wp_unslash( $_POST[ 'fmp_addon_' . $addon['field_name'] ] ?? '' );
			$content       = new AddonFields(
				[
					'type'  => $addon['type'],
					'value' => $value,
					'addon' => $addon,
				]
			);
			$data          = $content->get_cart_item_content();

			if ( ! is_wp_error( $data ) && ! empty( $data ) ) {
				$cart_item_data['fmp_addons'] = array_merge( $cart_item_data['fmp_addons'], $data );
			}
			$counter ++;
		}

		return $cart_item_data;
	}

	/**
	 * Display addon data
	 *
	 * @param array $show_data .
	 * @param array $cart_item .
	 *
	 * @return array
	 */
	public function display_addon_data_in_cart( $show_data, $cart_item ) {
		$addons_price = 0;
		$extra_data   = [];

		if ( ! empty( $cart_item['fmp_addons'] ) ) {
			foreach ( $cart_item['fmp_addons'] as $addon ) {
				$addons_price += absint( $addon['price'] );
				$extra_data[] = [
					'name'  => $addon['name'],
					'value' => $addon['value'],
				];
			}
			$show_data = array_merge( $show_data, $extra_data );
		}

		$product             = wc_get_product( $cart_item['product_id'] );
		$product_price       = $product->get_type() == 'variable' ? get_post_meta( $cart_item['variation_id'], '_price', true ) : FnsPro::product_price_by_tax( $product );
		$discount_price_args = [
			'product_id'    => $cart_item['product_id'],
			'data'          => '',
			'product_price' => $product_price,
			'addons_price'  => $addons_price,
		];

		$discount_price_data = FnsPro::discount_price( $discount_price_args );

		if ( ! empty( $discount_price_data['main_price'] ) && ! empty( $discount_price_data['price_after_discount'] ) ) {
			$show_data[] = [
				'name'    => esc_html__( 'Product price', 'food-menu-pro' ),
				'display' => wc_price( $discount_price_data['main_price'] ),
			];

			if ( $addons_price > 0 ) {
				$show_data[] = [
					'name'    => esc_html__( 'Addons price', 'food-menu-pro' ),
					'display' => wc_price( $addons_price ),
				];

				// Determine the discount application.
				$discount_applied_on = ( 'addon_total' == $discount_price_data['discount_apply_to'] ) ? 'product and addons' : 'product';

				// Construct the discount message.
				$discount_final_msg = sprintf(
				// translators: %1$s: discount applied on.
					__( 'Total price %1$s', 'food-menu-pro' ),
					$discount_applied_on
				);

				// Add the data to show.
				$show_data[] = [
					// translators: %1$s: discount percentage.
					'name'    => ( is_cart() || is_checkout() ) ? $discount_final_msg : sprintf( __( 'After %s%% discount', 'food-menu-pro' ), $discount_price_data['discount_percentage'] ),
					'display' => wc_price( $discount_price_data['new_price'] ) . '+' . wc_price( $discount_price_data['addons_new_price'] ),
				];
			}
		}

		return $show_data;
	}

	/**
	 * Hider meta data in admin order details
	 *
	 * @param array $hidden_meta_data .
	 *
	 * @return array
	 */
	public function hide_admin_order_details( $hidden_meta_data ) {
		array_push( $hidden_meta_data, '_addons_price' );

		return $hidden_meta_data;
	}

}
