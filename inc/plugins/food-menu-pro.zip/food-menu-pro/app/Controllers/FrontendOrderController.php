<?php
/**
 * Elementor Filter Hook Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers;

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\FrontendOrderManagement\CheckoutFields;
use RT\FoodMenuPro\Controllers\FrontendOrderManagement\OrderDeliverStatus;
use RT\FoodMenuPro\Controllers\FrontendOrderManagement\OrdersTableManagement;
use RT\FoodMenuPro\Controllers\FrontendOrderManagement\CRUD_Order;


class FrontendOrderController {
	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Class constructor.
	 */

	private static $settings;


	public function __construct() {
		$settings       = get_option( TLPFoodMenu()->options['settings'] );
		self::$settings = $settings;

		$is_enable_order = $settings['fmp_enable_frontend_order'] ?? false;
		if ( ! $is_enable_order ) {
			return false;
		}

		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

		CheckoutFields::get_instance();
		OrderDeliverStatus::get_instance();
		OrdersTableManagement::get_instance();
		CRUD_Order::get_instance();
	}

	public function enqueue_scripts() {
		if ( is_page( FnsPro::get_frontend_order_page() ) ) {
			wp_enqueue_style( 'fmp-flatpickr' );
			wp_enqueue_style( 'select2' );
			wp_enqueue_script( 'fm-order-manager', FMP()->assets_url() . 'js/order-manager.min.js', [ 'jquery', 'fmp-flatpickr', 'select2' ], '1.0', true );
			$localize_data = [
				'nonce'   => wp_create_nonce( 'fm_order_update_nonce' ),
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
			];

			// POS Printing data.
			$pos_enabled = self::$settings['fmp_enable_pos_printing'] ?? '';
			if ( 'on' === $pos_enabled ) {
				$localize_data['pos_printing']       = true;
				$localize_data['pos_nonce']           = wp_create_nonce( 'fmp_pos_printing_nonce' );
				$localize_data['default_slip_type']   = self::$settings['fmp_default_slip_type'] ?? 'order_confirmation';
			}

			wp_localize_script( 'fm-order-manager', 'fm_order_manager', $localize_data );
		}
	}
}
