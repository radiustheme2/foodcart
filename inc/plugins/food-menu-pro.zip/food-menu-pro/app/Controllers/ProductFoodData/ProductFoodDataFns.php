<?php
/**
 * Helpers for ingredient and nutrition data stored on WooCommerce products.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\ProductFoodData;

use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Reads the food data a product carries.
 *
 * The storage format is deliberately **identical** to the one the food-menu
 * post type already uses: repeated `_ingredient` / `_nutrition` post meta
 * rows, each an array of `id`, `unit_id` and `value`. Keeping the shape the
 * same means `FnsPro::get_fm_ingredient_list()` and anything else already
 * reading those keys works on a product without being touched.
 */
class ProductFoodDataFns {

	const INGREDIENT_META = '_ingredient';
	const NUTRITION_META  = '_nutrition';

	/**
	 * Whether food data applies to products on this site.
	 *
	 * Only in online-ordering mode, where the menu is built from products.
	 * A site using food-menu posts is unaffected by everything in this class.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return TLPFoodMenu()->isWcActive()
			&& 'online_ordering' === Fns::get_setting( 'fm_food_menu_type' );
	}

	/**
	 * Ingredients on a post, resolved to display values.
	 *
	 * @param int $post_id Post ID.
	 *
	 * @return array List of [ 'id', 'name', 'value', 'unit' ].
	 */
	public static function get_ingredients( $post_id ) {
		return self::resolve(
			$post_id,
			self::INGREDIENT_META,
			TLPFoodMenu()->taxonomies['ingredient']
		);
	}

	/**
	 * Nutrition facts on a post, resolved to display values.
	 *
	 * @param int $post_id Post ID.
	 *
	 * @return array List of [ 'id', 'name', 'value', 'unit' ].
	 */
	public static function get_nutrition( $post_id ) {
		return self::resolve(
			$post_id,
			self::NUTRITION_META,
			TLPFoodMenu()->taxonomies['nutrition']
		);
	}

	/**
	 * Turns stored rows into term names and unit labels.
	 *
	 * Rows whose term has since been deleted are skipped rather than rendered
	 * as a blank line, which is what a stale id would otherwise produce.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $meta_key Meta key to read.
	 * @param string $taxonomy Taxonomy the row ids belong to.
	 *
	 * @return array
	 */
	private static function resolve( $post_id, $meta_key, $taxonomy ) {
		// false: these are repeated meta rows, not one value.
		$rows = get_post_meta( absint( $post_id ), $meta_key, false );

		if ( empty( $rows ) || ! is_array( $rows ) ) {
			return [];
		}

		$unit_taxonomy = TLPFoodMenu()->taxonomies['unit'];
		$resolved      = [];

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || empty( $row['id'] ) ) {
				continue;
			}

			$term = get_term( absint( $row['id'] ), $taxonomy );

			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}

			$unit_name = '';

			if ( ! empty( $row['unit_id'] ) ) {
				$unit = get_term( absint( $row['unit_id'] ), $unit_taxonomy );

				if ( $unit && ! is_wp_error( $unit ) ) {
					$unit_name = $unit->name;
				}
			}

			$resolved[] = [
				'id'    => (int) $term->term_id,
				'name'  => $term->name,
				'value' => isset( $row['value'] ) ? (string) $row['value'] : '',
				'unit'  => $unit_name,
			];
		}

		return $resolved;
	}
}
