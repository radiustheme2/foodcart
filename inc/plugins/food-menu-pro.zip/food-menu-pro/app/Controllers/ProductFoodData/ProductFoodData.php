<?php
/**
 * Ingredient and nutrition fields on the WooCommerce product screen.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\ProductFoodData;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Adds a Food Data box to products, in online-ordering mode only.
 *
 * Self-contained on purpose. The food-menu post type's Food Data metabox
 * lives in `Admin\Metabox\PostMeta`, whose save handler is guarded with
 * `TLPFoodMenu()->post_type !== $post->post_type` and whose other fields
 * (gallery, variations, food general options) have no meaning on a product.
 * Relaxing that guard would run the whole `singleFoodMetaFields()` loop on
 * every product save, writing and deleting food-menu meta on products. So
 * this class brings its own box, its own nonce and its own save, and changes
 * nothing that already works.
 */
class ProductFoodData {

	use \RT\FoodMenuPro\Traits\SingletonTrait;

	const NONCE_ACTION = 'fmp_product_food_data';
	const NONCE_NAME   = 'fmp_product_food_data_nonce';

	/**
	 * Class init.
	 *
	 * @return void
	 */
	protected function init() {
		if ( ! ProductFoodDataFns::is_enabled() ) {
			return;
		}

		add_action( 'add_meta_boxes', [ $this, 'add_meta_box' ] );
		add_action( 'save_post_product', [ $this, 'save' ], 10, 2 );
	}

	/**
	 * Registers the box on the product edit screen.
	 *
	 * @return void
	 */
	public function add_meta_box() {
		add_meta_box(
			'fmp-product-food-data',
			esc_html__( 'Food Data', 'food-menu-pro' ),
			[ $this, 'render' ],
			'product',
			'normal',
			'default'
		);
	}

	/**
	 * Renders the ingredient and nutrition pickers.
	 *
	 * @param \WP_Post $post Post object.
	 *
	 * @return void
	 */
	public function render( $post ) {
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME );

		$units = get_terms(
			[
				'taxonomy'   => TLPFoodMenu()->taxonomies['unit'],
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);

		if ( is_wp_error( $units ) ) {
			$units = [];
		}

		$this->render_section(
			$post,
			ProductFoodDataFns::INGREDIENT_META,
			TLPFoodMenu()->taxonomies['ingredient'],
			esc_html__( 'Ingredients', 'food-menu-pro' ),
			esc_html__( 'No ingredients have been created yet.', 'food-menu-pro' ),
			$units
		);

		echo '<hr style="margin:18px 0;border:0;border-top:1px solid #dcdcde">';

		$this->render_section(
			$post,
			ProductFoodDataFns::NUTRITION_META,
			TLPFoodMenu()->taxonomies['nutrition'],
			esc_html__( 'Nutrition Facts', 'food-menu-pro' ),
			esc_html__( 'No nutrition facts have been created yet.', 'food-menu-pro' ),
			$units
		);
	}

	/**
	 * One tick-list section: every term, with a value and a unit.
	 *
	 * Plain checkboxes rather than the drag-and-drop dual list the food-menu
	 * screen uses, because that UI is bound to `admin-food.js` and the tabbed
	 * panel markup of the other metabox. The stored result is identical.
	 *
	 * @param \WP_Post $post      Post object.
	 * @param string   $meta_key  Meta key to write.
	 * @param string   $taxonomy  Taxonomy to list.
	 * @param string   $heading   Section heading.
	 * @param string   $empty_msg Shown when the taxonomy has no terms.
	 * @param array    $units     Unit terms.
	 *
	 * @return void
	 */
	private function render_section( $post, $meta_key, $taxonomy, $heading, $empty_msg, $units ) {
		$terms = get_terms(
			[
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);

		if ( is_wp_error( $terms ) ) {
			$terms = [];
		}

		// Existing rows, keyed by term id for lookup while rendering.
		$selected = [];

		foreach ( (array) get_post_meta( $post->ID, $meta_key, false ) as $row ) {
			if ( is_array( $row ) && ! empty( $row['id'] ) ) {
				$selected[ (int) $row['id'] ] = $row;
			}
		}

		echo '<h4 style="margin:0 0 8px">' . esc_html( $heading ) . '</h4>';

		if ( empty( $terms ) ) {
			$taxonomy_link = add_query_arg(
				[
					'taxonomy'  => $taxonomy,
					'post_type' => TLPFoodMenu()->post_type,
				],
				admin_url( 'edit-tags.php' )
			);

			printf(
				'<p class="description">%s <a href="%s">%s</a></p>',
				esc_html( $empty_msg ),
				esc_url( $taxonomy_link ),
				esc_html__( 'Add some', 'food-menu-pro' )
			);

			return;
		}

		echo '<table class="widefat striped" style="margin-bottom:4px"><tbody>';

		foreach ( $terms as $term ) {
			$term_id = (int) $term->term_id;
			$row     = $selected[ $term_id ] ?? null;
			$checked = null !== $row;
			$value   = $checked && isset( $row['value'] ) ? (string) $row['value'] : '';
			$unit_id = $checked && ! empty( $row['unit_id'] ) ? (int) $row['unit_id'] : 0;

			$field = $meta_key . '[' . $term_id . ']';

			echo '<tr>';

			printf(
				'<td style="width:34px"><input type="checkbox" name="%s[enabled]" value="1"%s></td>',
				esc_attr( $field ),
				checked( $checked, true, false )
			);

			printf( '<td><label>%s</label></td>', esc_html( $term->name ) );

			printf(
				'<td style="width:110px"><input type="text" name="%s[value]" value="%s" placeholder="%s" style="width:100%%"></td>',
				esc_attr( $field ),
				esc_attr( $value ),
				esc_attr__( 'Amount', 'food-menu-pro' )
			);

			echo '<td style="width:140px"><select name="' . esc_attr( $field ) . '[unit_id]" style="width:100%">';
			echo '<option value="">' . esc_html__( 'Unit', 'food-menu-pro' ) . '</option>';

			foreach ( $units as $unit ) {
				printf(
					'<option value="%d"%s>%s</option>',
					(int) $unit->term_id,
					selected( $unit_id, (int) $unit->term_id, false ),
					esc_html( $unit->name )
				);
			}

			echo '</select></td></tr>';
		}

		echo '</tbody></table>';
	}

	/**
	 * Saves the submitted rows.
	 *
	 * Writes only when this box was actually on the submitted screen, checked
	 * by its own nonce. Without that, a programmatic or REST-driven product
	 * update would look like an empty form and wipe existing rows.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 *
	 * @return void
	 */
	public function save( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( 'product' !== $post->post_type ) {
			return;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$nonce = $_POST[ self::NONCE_NAME ] ?? '';

		if ( ! $nonce || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $nonce ) ), self::NONCE_ACTION ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$this->save_section( $post_id, ProductFoodDataFns::INGREDIENT_META );
		$this->save_section( $post_id, ProductFoodDataFns::NUTRITION_META );
	}

	/**
	 * Replaces the stored rows for one meta key.
	 *
	 * Rows are written as repeated meta entries of `id`, `unit_id` and
	 * `value`, matching the food-menu post type exactly.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $meta_key Meta key to write.
	 *
	 * @return void
	 */
	private function save_section( $post_id, $meta_key ) {
		// Nonce is verified in save() before this is reached; PHPCS cannot
		// follow that across methods.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$submitted = isset( $_POST[ $meta_key ] ) ? wp_unslash( $_POST[ $meta_key ] ) : [];

		delete_post_meta( $post_id, $meta_key );

		if ( empty( $submitted ) || ! is_array( $submitted ) ) {
			return;
		}

		foreach ( $submitted as $term_id => $row ) {
			if ( ! is_array( $row ) || empty( $row['enabled'] ) ) {
				continue;
			}

			$term_id = absint( $term_id );

			if ( ! $term_id ) {
				continue;
			}

			add_post_meta(
				$post_id,
				$meta_key,
				[
					'id'      => $term_id,
					'unit_id' => ! empty( $row['unit_id'] ) ? absint( $row['unit_id'] ) : null,
					'value'   => isset( $row['value'] ) && '' !== $row['value']
						? sanitize_text_field( $row['value'] )
						: null,
				]
			);
		}
	}
}
