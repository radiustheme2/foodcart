<?php
/**
 * Order Confirmation Slip Template.
 *
 * Full order details: items, prices, totals, customer info.
 *
 * @package RT_FoodMenuPro
 *
 * @var string $logo_url
 * @var string $site_name
 * @var string $site_url
 * @var string $footer_text
 * @var string $order_number
 * @var string $order_date
 * @var string $order_time
 * @var string $status
 * @var array  $items
 * @var float  $subtotal
 * @var float  $tax_total
 * @var float  $discount_total
 * @var float  $total
 * @var string $payment_method
 * @var string $customer_note
 * @var string $currency
 * @var string $billing_first_name
 * @var string $billing_last_name
 * @var string $billing_phone
 * @var string $billing_address
 * @var string $order_type
 * @var string $pickup_date
 * @var string $pickup_time
 * @var string $delivery_date
 * @var string $delivery_time
 * @var string $room_number
 * @var string $location_name
 */

defined( 'ABSPATH' ) || exit();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php printf( '%s #%s', esc_html__( 'Order', 'food-menu-pro' ), esc_html( $order_number ) ); ?></title>
<style>
	@page { margin: 2mm; }
	* { margin: 0; padding: 0; box-sizing: border-box; }
	body { font-family: sans-serif; font-size: 12px; width: 76mm; max-width: 100%; margin: 0 auto; color: #000; line-height: 1.4; word-wrap: break-word; overflow-wrap: break-word; }
	.slip { padding: 4mm 2mm; overflow: hidden; }
	.header { text-align: center; margin-bottom: 4mm; }
	.header img { max-width: 50mm; max-height: 20mm; margin-bottom: 2mm; }
	.header .site-name { font-size: 16px; font-weight: bold; margin-bottom: 1mm; }
	.divider { border-top: 1px dashed #000; margin: 3mm 0; }
	.info-row { display: flex; justify-content: space-between; margin-bottom: 1mm; }
	.info-row .label { font-weight: bold; }
	.items-table { width: 100%; border-collapse: collapse; margin: 2mm 0; }
	.items-table th { text-align: left; font-size: 11px; border-bottom: 1px solid #000; padding: 1mm 0; }
	.items-table th:last-child { text-align: right; }
	.items-table td { padding: 1.5mm 0; vertical-align: top; font-size: 12px; }
	.items-table td:last-child { text-align: right; white-space: nowrap; }
	.addon { font-size: 10px; color: #444; padding-left: 3mm; word-wrap: break-word; overflow-wrap: break-word; }
	.items-table { table-layout: fixed; }
	.totals { margin-top: 2mm; }
	.totals .row { display: flex; justify-content: space-between; margin-bottom: 1mm; }
	.totals .total-row { font-weight: bold; font-size: 14px; border-top: 1px solid #000; padding-top: 2mm; margin-top: 2mm; }
	.note { font-style: italic; font-size: 11px; margin-top: 2mm; }
	.footer { text-align: center; margin-top: 4mm; font-size: 11px; }
	.footer .thank-you { font-weight: bold; margin-bottom: 1mm; }
</style>
</head>
<body>
<div class="slip">
	<div class="header">
		<?php if ( $logo_url ) : ?>
			<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $site_name ); ?>">
		<?php endif; ?>
		<div class="site-name"><?php echo esc_html( $site_name ); ?></div>
	</div>

	<div class="divider"></div>

	<div class="info-row">
		<span class="label"><?php esc_html_e( 'Order:', 'food-menu-pro' ); ?></span>
		<span>#<?php echo esc_html( $order_number ); ?></span>
	</div>
	<div class="info-row">
		<span class="label"><?php esc_html_e( 'Date:', 'food-menu-pro' ); ?></span>
		<span><?php echo esc_html( $order_date ); ?></span>
	</div>
	<div class="info-row">
		<span class="label"><?php esc_html_e( 'Status:', 'food-menu-pro' ); ?></span>
		<span><?php echo esc_html( $status ); ?></span>
	</div>

	<?php if ( $billing_first_name || $billing_last_name ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Customer:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( trim( $billing_first_name . ' ' . $billing_last_name ) ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( $billing_phone ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Phone:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $billing_phone ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $qr_table_name ) ) : ?>
		<div class="info-row" style="font-weight:bold;background:#f0f9ff;padding:4px 0;">
			<span class="label"><?php esc_html_e( 'Table:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $qr_table_name ); ?> (<?php esc_html_e( 'QR Code Order', 'food-menu-pro' ); ?>)</span>
		</div>
	<?php endif; ?>

	<?php if ( $location_name ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Location:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $location_name ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( $order_type ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Type:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $order_type_label ?: ucfirst( $order_type ) ); ?></span>
		</div>
		<?php if ( 'delivery' === $order_type && $delivery_date ) : ?>
			<div class="info-row">
				<span class="label"><?php esc_html_e( 'Delivery:', 'food-menu-pro' ); ?></span>
				<span><?php echo esc_html( $delivery_date . ' ' . $delivery_time ); ?></span>
			</div>
		<?php elseif ( 'pickup' === $order_type && $pickup_date ) : ?>
			<div class="info-row">
				<span class="label"><?php esc_html_e( 'Pickup:', 'food-menu-pro' ); ?></span>
				<span><?php echo esc_html( $pickup_date . ' ' . $pickup_time ); ?></span>
			</div>
		<?php elseif ( 'dinein' === $order_type ) : ?>
			<?php if ( $dinein_table ) : ?>
				<div class="info-row">
					<span class="label"><?php esc_html_e( 'Table:', 'food-menu-pro' ); ?></span>
					<span><?php echo esc_html( $dinein_table ); ?></span>
				</div>
			<?php endif; ?>
			<?php if ( $dinein_date ) : ?>
				<div class="info-row">
					<span class="label"><?php esc_html_e( 'Dine In:', 'food-menu-pro' ); ?></span>
					<span><?php echo esc_html( $dinein_date . ' ' . $dinein_time ); ?></span>
				</div>
			<?php endif; ?>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ( $room_number ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Room:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $room_number ); ?></span>
		</div>
	<?php endif; ?>

	<div class="divider"></div>

	<table class="items-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Item', 'food-menu-pro' ); ?></th>
				<th style="text-align:center;"><?php esc_html_e( 'Qty', 'food-menu-pro' ); ?></th>
				<th><?php esc_html_e( 'Price', 'food-menu-pro' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $items as $item ) : ?>
				<tr>
					<td><?php echo esc_html( $item['name'] ); ?></td>
					<td style="text-align:center;"><?php echo esc_html( $item['qty'] ); ?></td>
					<td><?php echo wc_price( $item['total'], [ 'currency' => $currency ] ); ?></td>
				</tr>
				<?php if ( ! empty( $item['addons'] ) ) : ?>
					<?php foreach ( $item['addons'] as $addon ) : ?>
						<tr>
							<td colspan="3" class="addon">+ <?php echo esc_html( $addon['name'] . ': ' . $addon['value'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			<?php endforeach; ?>
		</tbody>
	</table>

	<div class="divider"></div>

	<div class="totals">
		<div class="row">
			<span><?php esc_html_e( 'Subtotal:', 'food-menu-pro' ); ?></span>
			<span><?php echo wc_price( $subtotal, [ 'currency' => $currency ] ); ?></span>
		</div>
		<?php if ( $discount_total > 0 ) : ?>
			<div class="row">
				<span><?php esc_html_e( 'Discount:', 'food-menu-pro' ); ?></span>
				<span>-<?php echo wc_price( $discount_total, [ 'currency' => $currency ] ); ?></span>
			</div>
		<?php endif; ?>
		<?php if ( $tax_total > 0 ) : ?>
			<div class="row">
				<span><?php esc_html_e( 'Tax:', 'food-menu-pro' ); ?></span>
				<span><?php echo wc_price( $tax_total, [ 'currency' => $currency ] ); ?></span>
			</div>
		<?php endif; ?>
		<div class="row total-row">
			<span><?php esc_html_e( 'Total:', 'food-menu-pro' ); ?></span>
			<span><?php echo wc_price( $total, [ 'currency' => $currency ] ); ?></span>
		</div>
	</div>

	<?php if ( $payment_method ) : ?>
		<div class="info-row" style="margin-top:2mm;">
			<span class="label"><?php esc_html_e( 'Payment:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $payment_method ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( $customer_note ) : ?>
		<div class="divider"></div>
		<div class="note">
			<strong><?php esc_html_e( 'Note:', 'food-menu-pro' ); ?></strong>
			<?php echo esc_html( $customer_note ); ?>
		</div>
	<?php endif; ?>

	<div class="divider"></div>

	<div class="footer">
		<?php if ( $footer_text ) : ?>
			<div class="thank-you"><?php echo esc_html( $footer_text ); ?></div>
		<?php endif; ?>
		<div><?php echo esc_html( $site_url ); ?></div>
	</div>
</div>
</body>
</html>
