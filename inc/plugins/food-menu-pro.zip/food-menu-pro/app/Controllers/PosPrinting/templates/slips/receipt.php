<?php
/**
 * Receipt Slip Template.
 *
 * Customer-facing store receipt: store branding, order number, items, tip, total, cashier.
 *
 * @package RT_FoodMenuPro
 *
 * @var string $logo_url
 * @var string $site_name
 * @var string $store_address
 * @var string $store_phone
 * @var string $footer_text
 * @var string $order_number
 * @var string $order_date
 * @var string $cashier_name
 * @var array  $items
 * @var float  $subtotal
 * @var float  $tax_total
 * @var float  $discount_total
 * @var float  $tip_total
 * @var float  $total
 * @var string $payment_method
 * @var string $currency
 */

defined( 'ABSPATH' ) || exit();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php printf( '%s #%s', esc_html__( 'Receipt', 'food-menu-pro' ), esc_html( $order_number ) ); ?></title>
<style>
	@page { margin: 2mm; }
	* { margin: 0; padding: 0; box-sizing: border-box; }
	body { font-family: sans-serif; font-size: 12px; width: 76mm; max-width: 100%; margin: 0 auto; color: #000; line-height: 1.4; word-wrap: break-word; overflow-wrap: break-word; }
	.slip { padding: 4mm 2mm; overflow: hidden; }
	.header { text-align: center; margin-bottom: 3mm; }
	.header img { max-width: 50mm; max-height: 20mm; margin-bottom: 2mm; }
	.header .site-name { font-size: 16px; font-weight: bold; margin-bottom: 1mm; }
	.header .store-meta { font-size: 11px; color: #222; white-space: pre-line; }
	.receipt-title { text-align: center; font-size: 13px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin: 2mm 0; }
	.divider { border-top: 1px dashed #000; margin: 3mm 0; }
	.info-row { display: flex; justify-content: space-between; margin-bottom: 1mm; }
	.info-row .label { font-weight: bold; }
	.items-table { width: 100%; border-collapse: collapse; margin: 2mm 0; table-layout: fixed; }
	.items-table th { text-align: left; font-size: 11px; border-bottom: 1px solid #000; padding: 1mm 0; }
	.items-table th:last-child { text-align: right; }
	.items-table td { padding: 1.5mm 0; vertical-align: top; font-size: 12px; }
	.items-table td:last-child { text-align: right; white-space: nowrap; }
	.addon { font-size: 10px; color: #444; padding-left: 3mm; }
	.totals { margin-top: 2mm; }
	.totals .row { display: flex; justify-content: space-between; margin-bottom: 1mm; }
	.totals .total-row { font-weight: bold; font-size: 14px; border-top: 1px solid #000; padding-top: 2mm; margin-top: 2mm; }
	.totals .row.manual-row { align-items: flex-end; }
	.manual-line { flex: 0 0 40%; border-bottom: 1px dotted #000; height: 4mm; margin-left: 4mm; }
	.manual-hint { text-align: right; font-size: 9px; color: #555; margin: 0 0 1mm; }
	.footer { text-align: center; margin-top: 4mm; font-size: 11px; }
	.footer .thank-you { font-weight: bold; margin-bottom: 1mm; }
</style>
</head>
<body>
<div class="slip">
	<div class="header">
		<?php if ( $logo_url ) : ?>
			<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $site_name ); ?>">
		<?php endif; ?>
		<div class="site-name"><?php echo esc_html( $site_name ); ?></div>
		<?php if ( ! empty( $store_address ) ) : ?>
			<div class="store-meta"><?php echo esc_html( $store_address ); ?></div>
		<?php endif; ?>
		<?php if ( ! empty( $store_phone ) ) : ?>
			<div class="store-meta"><?php printf( '%s %s', esc_html__( 'Tel:', 'food-menu-pro' ), esc_html( $store_phone ) ); ?></div>
		<?php endif; ?>
	</div>

	<div class="receipt-title"><?php esc_html_e( 'Receipt', 'food-menu-pro' ); ?></div>

	<div class="divider"></div>

	<div class="info-row">
		<span class="label"><?php esc_html_e( 'Order:', 'food-menu-pro' ); ?></span>
		<span>#<?php echo esc_html( $order_number ); ?></span>
	</div>
	<div class="info-row">
		<span class="label"><?php esc_html_e( 'Date:', 'food-menu-pro' ); ?></span>
		<span><?php echo esc_html( $order_date ); ?></span>
	</div>
	<?php if ( ! empty( $cashier_name ) ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Cashier:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $cashier_name ); ?></span>
		</div>
	<?php endif; ?>
	<?php if ( 'dinein' === $order_type && ! empty( $dinein_table ) ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Table:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $dinein_table ); ?></span>
		</div>
	<?php endif; ?>

	<div class="divider"></div>

	<table class="items-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Item', 'food-menu-pro' ); ?></th>
				<th style="text-align:center;"><?php esc_html_e( 'Qty', 'food-menu-pro' ); ?></th>
				<th><?php esc_html_e( 'Price', 'food-menu-pro' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $items as $item ) : ?>
				<tr>
					<td><?php echo esc_html( $item['name'] ); ?></td>
					<td style="text-align:center;"><?php echo esc_html( $item['qty'] ); ?></td>
					<td><?php echo wc_price( $item['total'], [ 'currency' => $currency ] ); ?></td>
				</tr>
				<?php if ( ! empty( $item['addons'] ) ) : ?>
					<?php foreach ( $item['addons'] as $addon ) : ?>
						<tr>
							<td colspan="3" class="addon">+ <?php echo esc_html( $addon['name'] . ': ' . $addon['value'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			<?php endforeach; ?>
		</tbody>
	</table>

	<div class="divider"></div>

	<div class="totals">
		<div class="row">
			<span><?php esc_html_e( 'Subtotal:', 'food-menu-pro' ); ?></span>
			<span><?php echo wc_price( $subtotal, [ 'currency' => $currency ] ); ?></span>
		</div>
		<?php if ( $discount_total > 0 ) : ?>
			<div class="row">
				<span><?php esc_html_e( 'Discount:', 'food-menu-pro' ); ?></span>
				<span>-<?php echo wc_price( $discount_total, [ 'currency' => $currency ] ); ?></span>
			</div>
		<?php endif; ?>
		<?php if ( $tax_total > 0 ) : ?>
			<div class="row">
				<span><?php esc_html_e( 'Tax:', 'food-menu-pro' ); ?></span>
				<span><?php echo wc_price( $tax_total, [ 'currency' => $currency ] ); ?></span>
			</div>
		<?php endif; ?>
		<?php if ( $tip_total > 0 ) : ?>
			<div class="row">
				<span><?php esc_html_e( 'Tip:', 'food-menu-pro' ); ?></span>
				<span><?php echo wc_price( $tip_total, [ 'currency' => $currency ] ); ?></span>
			</div>
			<div class="row total-row">
				<span><?php esc_html_e( 'Total:', 'food-menu-pro' ); ?></span>
				<span><?php echo wc_price( $total, [ 'currency' => $currency ] ); ?></span>
			</div>
		<?php elseif ( ! empty( $manual_tip ) ) : ?>
			<div class="row manual-row">
				<span><?php esc_html_e( 'Tip:', 'food-menu-pro' ); ?></span>
				<span class="manual-line"></span>
			</div>
			<div class="manual-hint"><?php esc_html_e( 'write tip amount', 'food-menu-pro' ); ?></div>
			<div class="row total-row manual-row">
				<span><?php esc_html_e( 'Total:', 'food-menu-pro' ); ?></span>
				<span class="manual-line"></span>
			</div>
			<div class="manual-hint">
				<?php
				printf(
					/* translators: %s: order total amount before a handwritten tip. */
					esc_html__( '%s + tip', 'food-menu-pro' ),
					wp_kses_post( wc_price( $total, [ 'currency' => $currency ] ) )
				);
				?>
			</div>
		<?php else : ?>
			<div class="row total-row">
				<span><?php esc_html_e( 'Total:', 'food-menu-pro' ); ?></span>
				<span><?php echo wc_price( $total, [ 'currency' => $currency ] ); ?></span>
			</div>
		<?php endif; ?>
	</div>

	<?php if ( $payment_method ) : ?>
		<div class="info-row" style="margin-top:2mm;">
			<span class="label"><?php esc_html_e( 'Payment:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $payment_method ); ?></span>
		</div>
	<?php endif; ?>

	<div class="divider"></div>

	<div class="footer">
		<?php if ( $footer_text ) : ?>
			<div class="thank-you"><?php echo esc_html( $footer_text ); ?></div>
		<?php endif; ?>
		<div><?php echo esc_html( $site_url ); ?></div>
	</div>
</div>
</body>
</html>
