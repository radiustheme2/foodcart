<?php
/**
 * Packing Slip Template.
 *
 * Items, quantities, customer name, delivery address, order #.
 *
 * @package RT_FoodMenuPro
 *
 * @var string $logo_url
 * @var string $site_name
 * @var string $site_url
 * @var string $footer_text
 * @var string $order_number
 * @var string $order_date
 * @var array  $items
 * @var string $customer_note
 * @var string $billing_first_name
 * @var string $billing_last_name
 * @var string $billing_phone
 * @var string $shipping_address
 * @var string $billing_address
 * @var string $order_type
 * @var string $delivery_date
 * @var string $delivery_time
 * @var string $location_name
 */

defined( 'ABSPATH' ) || exit();

$delivery_address = $shipping_address ?: $billing_address;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php printf( '%s #%s', esc_html__( 'Packing Slip', 'food-menu-pro' ), esc_html( $order_number ) ); ?></title>
<style>
	@page { margin: 2mm; }
	* { margin: 0; padding: 0; box-sizing: border-box; }
	body { font-family: sans-serif; font-size: 12px; width: 76mm; max-width: 100%; margin: 0 auto; color: #000; line-height: 1.4; word-wrap: break-word; overflow-wrap: break-word; }
	.slip { padding: 4mm 2mm; overflow: hidden; }
	.header { text-align: center; margin-bottom: 4mm; }
	.header img { max-width: 50mm; max-height: 20mm; margin-bottom: 2mm; }
	.header .site-name { font-size: 16px; font-weight: bold; margin-bottom: 1mm; }
	.header .slip-title { font-size: 16px; font-weight: bold; text-transform: uppercase; }
	.divider { border-top: 1px dashed #000; margin: 3mm 0; }
	.info-row { display: flex; justify-content: space-between; margin-bottom: 1mm; }
	.info-row .label { font-weight: bold; }
	.address { font-size: 12px; margin: 2mm 0; padding-left: 2mm; }
	.items-table { width: 100%; border-collapse: collapse; margin: 2mm 0; }
	.items-table th { text-align: left; font-size: 11px; border-bottom: 1px solid #000; padding: 1mm 0; }
	.items-table th:last-child { text-align: center; }
	.items-table td { padding: 1.5mm 0; vertical-align: top; font-size: 12px; }
	.items-table td:last-child { text-align: center; }
	.addon { font-size: 10px; color: #444; padding-left: 3mm; word-wrap: break-word; overflow-wrap: break-word; }
	.items-table { table-layout: fixed; }
	.note { font-style: italic; font-size: 11px; margin-top: 2mm; }
	.footer { text-align: center; margin-top: 4mm; font-size: 11px; }
	.footer .thank-you { font-weight: bold; margin-bottom: 1mm; }
</style>
</head>
<body>
<div class="slip">
	<div class="header">
		<?php if ( $logo_url ) : ?>
			<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $site_name ); ?>">
		<?php endif; ?>
		<div class="site-name"><?php echo esc_html( $site_name ); ?></div>
		<div class="slip-title"><?php esc_html_e( 'Packing Slip', 'food-menu-pro' ); ?></div>
	</div>

	<div class="divider"></div>

	<div class="info-row">
		<span class="label"><?php esc_html_e( 'Order:', 'food-menu-pro' ); ?></span>
		<span>#<?php echo esc_html( $order_number ); ?></span>
	</div>
	<div class="info-row">
		<span class="label"><?php esc_html_e( 'Date:', 'food-menu-pro' ); ?></span>
		<span><?php echo esc_html( $order_date ); ?></span>
	</div>

	<?php if ( $billing_first_name || $billing_last_name ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Customer:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( trim( $billing_first_name . ' ' . $billing_last_name ) ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( $billing_phone ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Phone:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $billing_phone ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( $location_name ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Location:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $location_name ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( $delivery_address ) : ?>
		<div style="margin-top:2mm;">
			<strong><?php esc_html_e( 'Delivery Address:', 'food-menu-pro' ); ?></strong>
			<div class="address"><?php echo wp_kses_post( $delivery_address ); ?></div>
		</div>
	<?php endif; ?>

	<?php if ( 'delivery' === $order_type && $delivery_date ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Delivery Time:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $delivery_date . ' ' . $delivery_time ); ?></span>
		</div>
	<?php endif; ?>

	<div class="divider"></div>

	<table class="items-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Item', 'food-menu-pro' ); ?></th>
				<th><?php esc_html_e( 'Qty', 'food-menu-pro' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $items as $item ) : ?>
				<tr>
					<td><?php echo esc_html( $item['name'] ); ?></td>
					<td><?php echo esc_html( $item['qty'] ); ?></td>
				</tr>
				<?php if ( ! empty( $item['addons'] ) ) : ?>
					<?php foreach ( $item['addons'] as $addon ) : ?>
						<tr>
							<td colspan="2" class="addon">+ <?php echo esc_html( $addon['name'] . ': ' . $addon['value'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			<?php endforeach; ?>
		</tbody>
	</table>

	<?php if ( $customer_note ) : ?>
		<div class="divider"></div>
		<div class="note">
			<strong><?php esc_html_e( 'Note:', 'food-menu-pro' ); ?></strong>
			<?php echo esc_html( $customer_note ); ?>
		</div>
	<?php endif; ?>

	<div class="divider"></div>

	<div class="footer">
		<?php if ( $footer_text ) : ?>
			<div class="thank-you"><?php echo esc_html( $footer_text ); ?></div>
		<?php endif; ?>
		<div><?php echo esc_html( $site_url ); ?></div>
	</div>
</div>
</body>
</html>
