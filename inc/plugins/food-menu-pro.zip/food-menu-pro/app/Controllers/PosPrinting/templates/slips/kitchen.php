<?php
/**
 * Kitchen Slip Template.
 *
 * Items only (name, qty, addons/notes), order #, table/room — NO PRICES.
 *
 * @package RT_FoodMenuPro
 *
 * @var string $logo_url
 * @var string $site_name
 * @var string $site_url
 * @var string $footer_text
 * @var string $order_number
 * @var string $order_date
 * @var string $order_time
 * @var array  $items
 * @var string $customer_note
 * @var string $room_number
 * @var string $location_name
 * @var string $order_type
 */

defined( 'ABSPATH' ) || exit();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php printf( '%s #%s', esc_html__( 'Kitchen', 'food-menu-pro' ), esc_html( $order_number ) ); ?></title>
<style>
	@page { margin: 2mm; }
	* { margin: 0; padding: 0; box-sizing: border-box; }
	body { font-family: sans-serif; font-size: 12px; width: 76mm; max-width: 100%; margin: 0 auto; color: #000; line-height: 1.4; word-wrap: break-word; overflow-wrap: break-word; }
	.slip { padding: 4mm 2mm; overflow: hidden; }
	.header { text-align: center; margin-bottom: 4mm; }
	.header img { max-width: 50mm; max-height: 20mm; margin-bottom: 2mm; }
	.header .site-name { font-size: 16px; font-weight: bold; margin-bottom: 1mm; }
	.header .slip-title { font-size: 20px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; }
	.order-number { text-align: center; font-size: 24px; font-weight: bold; margin: 3mm 0; }
	.divider { border-top: 1px dashed #000; margin: 3mm 0; }
	.info-row { display: flex; justify-content: space-between; margin-bottom: 1mm; }
	.info-row .label { font-weight: bold; }
	.item { padding: 2mm 0; border-bottom: 1px dotted #ccc; }
	.item:last-child { border-bottom: none; }
	.item-header { display: flex; justify-content: space-between; font-weight: bold; font-size: 14px; }
	.item-qty { font-size: 16px; font-weight: bold; }
	.addon { font-size: 11px; color: #444; padding-left: 3mm; margin-top: 1mm; word-wrap: break-word; overflow-wrap: break-word; }
	.note { font-style: italic; font-size: 12px; margin-top: 2mm; padding: 2mm; border: 1px solid #000; }
	.footer { text-align: center; margin-top: 4mm; font-size: 11px; }
	.footer .thank-you { font-weight: bold; margin-bottom: 1mm; }
</style>
</head>
<body>
<div class="slip">
	<div class="header">
		<?php if ( $logo_url ) : ?>
			<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $site_name ); ?>">
		<?php endif; ?>
		<div class="site-name"><?php echo esc_html( $site_name ); ?></div>
		<div class="slip-title"><?php esc_html_e( 'Kitchen', 'food-menu-pro' ); ?></div>
	</div>

	<div class="order-number">#<?php echo esc_html( $order_number ); ?></div>

	<div class="info-row">
		<span class="label"><?php esc_html_e( 'Time:', 'food-menu-pro' ); ?></span>
		<span><?php echo esc_html( $order_date . ' ' . $order_time ); ?></span>
	</div>

	<?php if ( ! empty( $qr_table_name ) ) : ?>
		<div class="info-row" style="font-weight:bold;background:#f0f9ff;padding:4px 0;">
			<span class="label"><?php esc_html_e( 'Table:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $qr_table_name ); ?> (<?php esc_html_e( 'QR Code Order', 'food-menu-pro' ); ?>)</span>
		</div>
	<?php endif; ?>

	<?php if ( $location_name ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Location:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $location_name ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( $room_number ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Room:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $room_number ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( $order_type ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Type:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $order_type_label ?: ucfirst( $order_type ) ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( 'dinein' === $order_type && $dinein_table ) : ?>
		<div class="info-row">
			<span class="label"><?php esc_html_e( 'Table:', 'food-menu-pro' ); ?></span>
			<span><?php echo esc_html( $dinein_table ); ?></span>
		</div>
	<?php endif; ?>

	<div class="divider"></div>

	<?php foreach ( $items as $item ) : ?>
		<div class="item">
			<div class="item-header">
				<span><?php echo esc_html( $item['name'] ); ?></span>
				<span class="item-qty">x<?php echo esc_html( $item['qty'] ); ?></span>
			</div>
			<?php if ( ! empty( $item['addons'] ) ) : ?>
				<?php foreach ( $item['addons'] as $addon ) : ?>
					<div class="addon">+ <?php echo esc_html( $addon['name'] . ': ' . $addon['value'] ); ?></div>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>

	<?php if ( $customer_note ) : ?>
		<div class="divider"></div>
		<div class="note">
			<strong><?php esc_html_e( 'NOTE:', 'food-menu-pro' ); ?></strong>
			<?php echo esc_html( $customer_note ); ?>
		</div>
	<?php endif; ?>

	<div class="divider"></div>

	<div class="footer">
		<?php if ( $footer_text ) : ?>
			<div class="thank-you"><?php echo esc_html( $footer_text ); ?></div>
		<?php endif; ?>
		<div><?php echo esc_html( $site_url ); ?></div>
	</div>
</div>
</body>
</html>
