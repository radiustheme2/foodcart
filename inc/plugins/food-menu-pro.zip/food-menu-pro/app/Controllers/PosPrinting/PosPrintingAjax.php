<?php
/**
 * POS Printing AJAX handler.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\PosPrinting;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * POS Printing AJAX handler class.
 */
class PosPrintingAjax {

	use SingletonTrait;

	/**
	 * Init — register AJAX actions.
	 *
	 * @return void
	 */
	protected function init() {
		add_action( 'wp_ajax_fmp_get_slip_content', [ $this, 'get_slip_content' ] );
	}

	/**
	 * AJAX: Generate slip HTML for printing.
	 *
	 * @return void
	 */
	public function get_slip_content() {
		check_ajax_referer( 'fmp_pos_printing_nonce', '_ajax_nonce' );

		if ( ! FnsPro::has_order_manage_capability() && ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'food-menu-pro' ) ] );
		}

		$order_id  = absint( $_POST['order_id'] ?? 0 );
		$slip_type = sanitize_text_field( wp_unslash( $_POST['slip_type'] ?? 'order_confirmation' ) );

		if ( ! $order_id ) {
			wp_send_json_error( [ 'message' => __( 'Invalid order ID.', 'food-menu-pro' ) ] );
		}

		$order = wc_get_order( $order_id );

		// Slips carry the customer's name, address and phone — keep branch staff to their own locations.
		if ( ! $order || ( ! current_user_can( 'manage_woocommerce' ) && ! FnsPro::order_matches_allowed_locations( $order, FnsPro::get_user_allowed_locations() ) ) ) {
			wp_send_json_error( [ 'message' => __( 'Order not found.', 'food-menu-pro' ) ] );
		}

		$valid_types = array_keys( PosPrintingFns::slip_types() );

		if ( ! in_array( $slip_type, $valid_types, true ) ) {
			$slip_type = 'order_confirmation';
		}

		$data = $this->gather_order_data( $order );
		$html = $this->render_slip( $slip_type, $data );

		wp_send_json_success( [ 'html' => $html ] );
	}

	/**
	 * Gather all order data needed by slip templates.
	 *
	 * @param \WC_Order $order The order.
	 *
	 * @return array
	 */
	private function gather_order_data( $order ) {
		$settings    = get_option( TLPFoodMenu()->options['settings'] );
		$footer_text = $settings['fmp_pos_footer_text'] ?? __( 'Thank you for your order!', 'food-menu-pro' );

		// Company logo (shared setting) — falls back to the theme custom logo.
		$logo_url      = '';
		$company_logo  = $settings['fmp_frontend_dashboard_logo'] ?? [];

		if ( ! empty( $company_logo['id'] ) ) {
			$logo_url = wp_get_attachment_image_url( (int) $company_logo['id'], 'full' );
		} elseif ( ! empty( $company_logo['url'] ) ) {
			$logo_url = $company_logo['url'];
		}

		if ( ! $logo_url ) {
			$custom_logo_id = get_theme_mod( 'custom_logo' );
			if ( $custom_logo_id ) {
				$logo_url = wp_get_attachment_image_url( $custom_logo_id, 'medium' );
			}
		}

		// Store contact details for the receipt slip.
		$store_phone   = $settings['fmp_pos_store_phone'] ?? '';
		$store_address = trim( (string) ( $settings['fmp_pos_store_address'] ?? '' ) );

		if ( '' === $store_address && function_exists( 'WC' ) && WC()->countries ) {
			$store_address = wp_strip_all_tags( WC()->countries->get_base_address() . "\n" . WC()->countries->get_base_address_2() . "\n" . WC()->countries->get_base_city() . ' ' . WC()->countries->get_base_postcode() );
			$store_address = trim( preg_replace( "/\n{2,}/", "\n", $store_address ) );
		}

		// Cashier / administrator generating the slip.
		$current_user = wp_get_current_user();
		$cashier_name = $current_user && $current_user->exists() ? $current_user->display_name : '';

		// Tip total — the Tip feature adds a WC fee labelled "Tip".
		$tip_total = 0.0;
		foreach ( $order->get_fees() as $fee ) {
			if ( false !== stripos( $fee->get_name(), 'tip' ) ) {
				$tip_total += (float) $fee->get_total();
			}
		}

		// Order items with addons.
		$items = [];

		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			$addons  = [];

			foreach ( $item->get_meta_data() as $meta ) {
				// Skip all internal/hidden meta (prefixed with _).
				if ( str_starts_with( $meta->key, '_' ) ) {
					continue;
				}

				// Strip HTML tags from value (wc_price() stores formatted HTML).
				$addons[] = [
					'name'  => wp_strip_all_tags( $meta->key ),
					'value' => wp_strip_all_tags( $meta->value ),
				];
			}

			$items[] = [
				'name'     => $item->get_name(),
				'qty'      => $item->get_quantity(),
				'total'    => $item->get_total(),
				'subtotal' => $item->get_subtotal(),
				'addons'   => $addons,
				'sku'      => $product ? $product->get_sku() : '',
			];
		}

		// Pickup/delivery/dine in meta.
		$order_type    = $order->get_meta( 'fmp_order_time_type' );
		$pickup_date   = $order->get_meta( 'fmp_pickup_date' );
		$pickup_time   = $order->get_meta( 'fmp_pickup_time' );
		$delivery_date = $order->get_meta( 'fmp_delivery_date' );
		$delivery_time = $order->get_meta( 'fmp_delivery_time' );
		$dinein_date   = $order->get_meta( 'fmp_dinein_date' );
		$dinein_time   = $order->get_meta( 'fmp_dinein_time' );
		$dinein_table  = $order->get_meta( 'fmp_dinein_table' );
		$room_number   = $order->get_meta( '_hotel_room_number' );
		$location_name = $order->get_meta( 'fmp_location_name' );

		// QR Code Table Ordering.
		$qr_table_name = $order->get_meta( 'fmp_qr_table_name' );

		return [
			'order'          => $order,
			'order_id'       => $order->get_id(),
			'order_number'   => $order->get_order_number(),
			'order_date'     => wc_format_datetime( $order->get_date_created() ),
			'order_time'     => $order->get_date_created() ? $order->get_date_created()->date_i18n( 'H:i' ) : '',
			'status'         => wc_get_order_status_name( $order->get_status() ),
			'items'          => $items,
			'subtotal'       => $order->get_subtotal(),
			'tax_total'      => $order->get_total_tax(),
			'discount_total' => $order->get_discount_total(),
			'tip_total'      => $tip_total,
			'manual_tip'     => ( $settings['fmp_pos_receipt_manual_tip'] ?? 'on' ) === 'on',
			'total'          => $order->get_total(),
			'payment_method' => $order->get_payment_method_title(),
			'customer_note'  => $order->get_customer_note(),
			'currency'       => $order->get_currency(),

			// Customer info.
			'billing_first_name' => $order->get_billing_first_name(),
			'billing_last_name'  => $order->get_billing_last_name(),
			'billing_phone'      => $order->get_billing_phone(),
			'billing_email'      => $order->get_billing_email(),
			'billing_address'    => $order->get_formatted_billing_address(),
			'shipping_address'   => $order->get_formatted_shipping_address(),

			// Pickup/delivery/dine in.
			'order_type'       => $order_type,
			'order_type_label' => FnsPro::get_order_type_label( $order_type ),
			'pickup_date'      => $pickup_date,
			'pickup_time'      => $pickup_time,
			'delivery_date'    => $delivery_date,
			'delivery_time'    => $delivery_time,
			'dinein_date'      => $dinein_date,
			'dinein_time'      => $dinein_time,
			'dinein_table'     => $dinein_table,
			'room_number'      => $room_number,
			'location_name'    => $location_name,

			// QR Table Ordering.
			'qr_table_name' => $qr_table_name,

			// Branding.
			'site_name'     => get_bloginfo( 'name' ),
			'site_url'      => home_url(),
			'logo_url'      => $logo_url,
			'footer_text'   => $footer_text,
			'store_phone'   => $store_phone,
			'store_address' => $store_address,
			'cashier_name'  => $cashier_name,
		];
	}

	/**
	 * Render a slip template and return HTML.
	 *
	 * @param string $slip_type Slip type slug.
	 * @param array  $data      Order data.
	 *
	 * @return string
	 */
	private function render_slip( $slip_type, $data ) {
		$template_map = [
			'order_confirmation' => 'order-confirmation',
			'kitchen'            => 'kitchen',
			'packing'            => 'packing',
			'delivery_driver'    => 'delivery-driver',
			'receipt'            => 'receipt',
		];

		$template_file = $template_map[ $slip_type ] ?? 'order-confirmation';
		$template_path = __DIR__ . '/templates/slips/' . $template_file . '.php';

		if ( ! file_exists( $template_path ) ) {
			return '<p>' . esc_html__( 'Slip template not found.', 'food-menu-pro' ) . '</p>';
		}

		// Extract data for template use.
		extract( $data ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract

		ob_start();
		include $template_path;

		return ob_get_clean();
	}
}
