<?php
/**
 * POS Printing main class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\PosPrinting;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use WC_Order;

/**
 * POS Printing main class.
 */
class PosPrinting {

	use SingletonTrait;

	/**
	 * Settings option.
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Default slip type.
	 *
	 * @var string
	 */
	private $default_slip;

	/**
	 * Init function — hooks if conditions are met.
	 *
	 * @return void
	 */
	protected function init() {
		$this->options = FnsPro::get_settings_option();

		$fm_type = $this->options['fm_food_menu_type'] ?? 'food_menu_post';
		$enabled = $this->options['fmp_enable_pos_printing'] ?? '';

		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type ) {
			return;
		}

		if ( 'on' !== $enabled ) {
			return;
		}

		$this->default_slip = $this->options['fmp_default_slip_type'] ?? 'order_confirmation';

		// AJAX handler.
		PosPrintingAjax::get_instance();

		// WooCommerce admin order list columns (legacy + HPOS).
		add_filter( 'manage_edit-shop_order_columns', [ $this, 'add_print_column' ] );
		add_filter( 'manage_woocommerce_page_wc-orders_columns', [ $this, 'add_print_column' ] );
		add_action( 'manage_shop_order_posts_custom_column', [ $this, 'render_print_column' ], 25, 2 );
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', [ $this, 'render_print_column' ], 25, 2 );

		// WooCommerce admin order edit — top area after order details.
		add_action( 'fmp_order_info_header', [ $this, 'render_order_edit_print_bar' ] );

		// Admin assets — JS via enqueue, CSS via admin_head for reliability.
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue' ] );
		add_action( 'admin_head', [ $this, 'admin_head_css' ] );

		// Add POS data to the React admin dashboard localized script.
		add_filter( 'fmp/admin_panel_localize', [ $this, 'add_dashboard_pos_data' ] );
	}

	/**
	 * Add print column to WooCommerce orders list.
	 *
	 * @param array $columns Existing columns.
	 *
	 * @return array
	 */
	public function add_print_column( $columns ) {
		$new_columns = [];

		foreach ( $columns as $key => $label ) {
			$new_columns[ $key ] = $label;

			if ( 'order_status' === $key ) {
				$new_columns['fmp_print_slips'] = esc_html__( 'Print Slips', 'food-menu-pro' );
			}
		}

		return $new_columns;
	}

	/**
	 * Render print column content.
	 *
	 * @param string       $column      Column key.
	 * @param WC_Order|int $order_or_id Order object or ID.
	 *
	 * @return void
	 */
	public function render_print_column( $column, $order_or_id ) {
		if ( 'fmp_print_slips' !== $column ) {
			return;
		}

		$order = $order_or_id instanceof WC_Order ? $order_or_id : wc_get_order( $order_or_id );

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$order_id = $order->get_id();
		$types    = PosPrintingFns::slip_types();
		?>
		<div class="fmp-slip-buttons" data-order-id="<?php echo esc_attr( $order_id ); ?>">
			<?php foreach ( $types as $slug => $label ) : ?>
				<button type="button"
					class="button fmp-print-slip<?php echo $slug === $this->default_slip ? ' active' : ''; ?>"
					data-slip="<?php echo esc_attr( $slug ); ?>"
					title="<?php echo esc_attr( $label ); ?>">
					<span class="dashicons <?php echo esc_attr( self::slip_dashicon( $slug ) ); ?>"></span>
				</button>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Get short text label for slip type.
	 *
	 * @param string $slug Slip slug.
	 *
	 * @return string
	 */
	/**
	 * Get short text label for slip type.
	 *
	 * @param string $slug Slip slug.
	 *
	 * @return string
	 */
	public static function slip_short_label( $slug ) {
		$labels = [
			'order_confirmation' => 'OC',
			'kitchen'            => 'K',
			'packing'            => 'P',
			'delivery_driver'    => 'D',
			'receipt'            => 'R',
		];

		return $labels[ $slug ] ?? strtoupper( substr( $slug, 0, 2 ) );
	}

	/**
	 * Get dashicon class for slip type.
	 *
	 * @param string $slug Slip slug.
	 *
	 * @return string
	 */
	public static function slip_dashicon( $slug ) {
		$icons = [
			'order_confirmation' => 'dashicons-media-text',
			'kitchen'            => 'dashicons-food',
			'packing'            => 'dashicons-archive',
			'delivery_driver'    => 'dashicons-car',
			'receipt'            => 'dashicons-money-alt',
		];

		return $icons[ $slug ] ?? 'dashicons-printer';
	}

	/**
	 * Get SVG icon for slip type — includes inline width/height for reliable rendering.
	 *
	 * @param string $slug Slip slug.
	 *
	 * @return string
	 */
	public static function slip_icon( $slug ) {
		$icons = [
			'order_confirmation' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM6 20V4h7v5h5v11H6zm2-8h8v2H8v-2zm0 4h5v2H8v-2z"/></svg>',
			'kitchen'            => '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M8.1 13.34l2.83-2.83L3.91 3.5a4.008 4.008 0 0 0 0 5.66l4.19 4.18zm6.78-1.81c1.53.71 3.68.21 5.27-1.38 1.91-1.91 2.28-4.65.81-6.12-1.46-1.46-4.2-1.1-6.12.81-1.59 1.59-2.09 3.74-1.38 5.27L3.7 19.87l1.41 1.41L12 14.41l6.88 6.88 1.41-1.41L13.41 13l1.47-1.47z"/></svg>',
			'packing'            => '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M20 2H4c-1.1 0-2 .9-2 2v3c0 .55.45 1 1 1h1v11c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8h1c.55 0 1-.45 1-1V4c0-1.1-.9-2-2-2zm-5 12H9v-2h6v2zm5-7H4V4h16v3z"/></svg>',
			'delivery_driver'    => '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5H15V3H9v2H6.5c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/></svg>',
			'receipt'            => '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M18 2l-1.5 1.5L15 2l-1.5 1.5L12 2l-1.5 1.5L9 2 7.5 3.5 6 2v18l1.5-1.5L9 20l1.5-1.5L12 20l1.5-1.5L15 20l1.5-1.5L18 20V2zm-2 12H8v-2h8v2zm0-3H8V9h8v2zm0-3H8V6h8v2z"/></svg>',
		];

		return $icons[ $slug ] ?? '';
	}

	/**
	 * Render print bar on WooCommerce order edit page (after order details).
	 *
	 * @param WC_Order $order The order object.
	 *
	 * @return void
	 */
	public function render_order_edit_print_bar( $order ) {
		$order_id = $order->get_id();
		$types    = PosPrintingFns::slip_types();
		?>
		<p class="form-field form-field-wide fmp-order-print-bar" style="padding-top: 0;border:none">
			<span class="fmp-print-bar-label"><?php esc_html_e( 'Print Slips:', 'food-menu-pro' ); ?></span>
			<span class="fmp-slip-buttons" data-order-id="<?php echo esc_attr( $order_id ); ?>">
				<?php foreach ( $types as $slug => $label ) : ?>
					<button type="button"
						class="button fmp-print-slip<?php echo $slug === $this->default_slip ? ' active' : ''; ?>"
						data-slip="<?php echo esc_attr( $slug ); ?>"
						title="<?php echo esc_attr( $label ); ?>">
						<span class="dashicons <?php echo esc_attr( self::slip_dashicon( $slug ) ); ?>"></span>
						<span class="fmp-slip-label"><?php echo esc_html( $label ); ?></span>
					</button>
				<?php endforeach; ?>
			</span>
		</p>
		<?php
	}

	/**
	 * Enqueue admin JS on WooCommerce order screens.
	 *
	 * @param string $hook Current admin page hook.
	 *
	 * @return void
	 */
	public function admin_enqueue( $hook ) {
		if ( ! $this->is_pos_admin_screen() ) {
			return;
		}

		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : FMP()->options['version'];

		wp_enqueue_script(
			'fmp-pos-printing-admin',
			FMP()->assets_url() . 'js/pos-printing-admin.min.js',
			[ 'jquery' ],
			$version,
			true
		);

		wp_localize_script(
			'fmp-pos-printing-admin',
			'fmp_pos_printing',
			[
				'ajaxurl'           => admin_url( 'admin-ajax.php' ),
				'nonce'             => wp_create_nonce( 'fmp_pos_printing_nonce' ),
				'default_slip_type' => $this->default_slip,
			]
		);
	}

	/**
	 * Output admin CSS directly in <head> — reliable on all WC screens.
	 *
	 * @return void
	 */
	public function admin_head_css() {
		if ( ! $this->is_pos_admin_screen() ) {
			return;
		}
		?>
		<style id="fmp-pos-printing-css">
			.fmp-slip-buttons { display: inline-flex; gap: 4px; flex-wrap: wrap; align-items: center; }
			.fmp-slip-buttons .fmp-print-slip {
				display: inline-flex; align-items: center; justify-content: center; gap: 5px;
				padding: 4px 8px !important; min-height: 28px !important;
				border: 1px solid #e2e8f0 !important; border-radius: 6px !important;
				background: #f8fafc !important; color: #64748b !important;
				cursor: pointer; transition: all 0.15s ease; font-size: 12px !important; font-weight: 500;
				line-height: 1 !important;
			}
			.fmp-slip-buttons .fmp-print-slip .dashicons { font-size: 16px; width: 16px; height: 16px; line-height: 16px; }
			.fmp-slip-buttons .fmp-print-slip .fmp-slip-label { display: none; }
			.fmp-slip-buttons .fmp-print-slip:hover {
				background: #eff6ff !important; border-color: #93c5fd !important; color: #2563eb !important;
			}
			.fmp-slip-buttons .fmp-print-slip.active {
				background: #2563eb !important; border-color: #2563eb !important; color: #fff !important;
			}
            .fmp-slip-buttons .fmp-print-slip.active > * {
                color: #FFFFFF !important;
            }
			.fmp-slip-buttons .fmp-print-slip.active:hover {
				background: #1d4ed8 !important; border-color: #1d4ed8 !important;
			}
			.fmp-slip-buttons .fmp-print-slip.fmp-printing {
				pointer-events: none; color: transparent !important; position: relative;
			}
			.fmp-slip-buttons .fmp-print-slip.fmp-printing .dashicons { visibility: hidden; }
			.fmp-slip-buttons .fmp-print-slip.fmp-printing .fmp-slip-label { visibility: hidden; }
			.fmp-slip-buttons .fmp-print-slip.fmp-printing::after {
				content: ""; position: absolute; top: 50%; left: 50%;
				width: 14px; height: 14px; margin: -7px 0 0 -7px;
				border: 2px solid #cbd5e1; border-top-color: #2563eb;
				border-radius: 50%; animation: fmpSpin 0.6s linear infinite;
			}
			.fmp-slip-buttons .fmp-print-slip.active.fmp-printing::after {
				border-color: rgba(255,255,255,0.3); border-top-color: #fff;
			}
			@keyframes fmpSpin { to { transform: rotate(360deg); } }

			/* Order edit print bar */
			.fmp-order-print-bar {
				border-top: 1px solid #e2e8f0; padding-top: 12px !important; margin-top: 12px !important;
				display: flex !important; align-items: center; gap: 10px; flex-wrap: wrap;
			}
			.fmp-order-print-bar .fmp-print-bar-label { font-weight: 600; color: #374151; font-size: 13px; }
			.fmp-order-print-bar .fmp-slip-buttons .fmp-print-slip { padding: 5px 12px !important; min-height: 32px !important; }
			.fmp-order-print-bar .fmp-slip-buttons .fmp-print-slip .fmp-slip-label { display: inline; }

			#fmp-print-frame { display: none; position: absolute; width: 0; height: 0; }
		</style>
		<?php
	}

	/**
	 * Check if current screen is a WooCommerce order screen.
	 *
	 * @return bool
	 */
	/**
	 * Add POS printing data to admin dashboard React localized script.
	 *
	 * @param array $data Existing localized data.
	 *
	 * @return array
	 */
	public function add_dashboard_pos_data( $data ) {
		$data['posPrinting'] = [
			'enabled'         => true,
			'defaultSlipType' => $this->default_slip,
			'nonce'           => wp_create_nonce( 'fmp_pos_printing_nonce' ),
			'slipTypes'       => PosPrintingFns::slip_types(),
		];

		return $data;
	}

	private function is_pos_admin_screen() {
		$screen = get_current_screen();

		if ( ! $screen ) {
			return false;
		}

		$valid_screens = [
			'edit-shop_order',
			'woocommerce_page_wc-orders',
			'shop_order',
			'food-menu_page_fmp_dashboard',
		];

		if ( function_exists( 'wc_get_page_screen_id' ) ) {
			$valid_screens[] = wc_get_page_screen_id( 'shop-order' );
		}

		return in_array( $screen->id, $valid_screens, true );
	}
}
