<?php
/**
 * POS Printing settings fields.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\PosPrinting;

defined( 'ABSPATH' ) || exit();

/**
 * POS Printing settings fields class.
 */
class PosPrintingFns {

	/**
	 * POS Printing setting fields.
	 *
	 * @return array
	 */
	public static function settings_field() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/pos_printing_settings/fields',
			[
				'fmp_enable_pos_printing' => [
					'type'        => 'switch',
					'label'       => esc_html__( 'Enable POS Printing', 'food-menu-pro' ),
					'description' => esc_html__( 'Enable printing order slips from the order management page and WooCommerce orders.', 'food-menu-pro' ),
					'value'       => $settings['fmp_enable_pos_printing'] ?? '',
				],
				'fmp_default_slip_type'   => [
					'type'        => 'select',
					'label'       => esc_html__( 'Default Slip Type', 'food-menu-pro' ),
					'description' => esc_html__( 'The slip type that prints by default when clicking the print button.', 'food-menu-pro' ),
					'options'     => self::slip_types(),
					'value'       => $settings['fmp_default_slip_type'] ?? 'order_confirmation',
				],
				'fmp_pos_footer_text'     => [
					'type'        => 'text',
					'label'       => esc_html__( 'Slip Footer Text', 'food-menu-pro' ),
					'description' => esc_html__( 'Custom text shown at the bottom of printed slips.', 'food-menu-pro' ),
					'value'       => $settings['fmp_pos_footer_text'] ?? __( 'Thank you for your order!', 'food-menu-pro' ),
				],
				'fmp_pos_store_phone'     => [
					'type'        => 'text',
					'label'       => esc_html__( 'Store Phone', 'food-menu-pro' ),
					'description' => esc_html__( 'Telephone number shown on the Receipt slip.', 'food-menu-pro' ),
					'value'       => $settings['fmp_pos_store_phone'] ?? '',
				],
				'fmp_pos_store_address'   => [
					'type'        => 'textarea',
					'label'       => esc_html__( 'Store Address', 'food-menu-pro' ),
					'description' => esc_html__( 'Physical address shown on the Receipt slip. Leave empty to use the WooCommerce store address.', 'food-menu-pro' ),
					'value'       => $settings['fmp_pos_store_address'] ?? '',
				],
				'fmp_pos_receipt_manual_tip' => [
					'type'        => 'switch',
					'label'       => esc_html__( 'Manual tip line on receipt', 'food-menu-pro' ),
					'description' => esc_html__( 'When an order has no tip, print blank dotted lines for Tip and Total on the Receipt slip so customers can add a tip and final amount by hand.', 'food-menu-pro' ),
					'value'       => $settings['fmp_pos_receipt_manual_tip'] ?? 'on',
				],
			]
		);
	}

	/**
	 * Get available slip types.
	 *
	 * @return array
	 */
	public static function slip_types() {
		return [
			'order_confirmation' => esc_html__( 'Order Confirmation', 'food-menu-pro' ),
			'kitchen'            => esc_html__( 'Kitchen Slip', 'food-menu-pro' ),
			'packing'            => esc_html__( 'Packing Slip', 'food-menu-pro' ),
			'delivery_driver'    => esc_html__( 'Delivery Driver Slip', 'food-menu-pro' ),
			'receipt'            => esc_html__( 'Receipt Slip', 'food-menu-pro' ),
		];
	}
}
