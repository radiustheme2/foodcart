<?php
/**
 * Order Status Email - Plain text template.
 *
 * @package RT_FoodMenuPro
 *
 * @var WC_Order $order
 * @var string   $email_heading
 * @var string   $custom_body
 * @var bool     $sent_to_admin
 * @var bool     $plain_text
 * @var WC_Email $email
 */

defined( 'ABSPATH' ) || exit();

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html( wp_strip_all_tags( $email_heading ) );
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

if ( ! empty( $custom_body ) ) {
	echo esc_html( wp_strip_all_tags( $custom_body ) ) . "\n\n";
} else {
	printf(
		/* translators: %s: customer first name */
		esc_html__( 'Hi %s,', 'food-menu-pro' ),
		esc_html( $order->get_billing_first_name() )
	);
	echo "\n\n";

	printf(
		/* translators: %s: order number */
		esc_html__( 'Your order #%s status has been updated.', 'food-menu-pro' ),
		esc_html( $order->get_order_number() )
	);
	echo "\n\n";
}

do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

echo "\n----------------------------------------\n\n";

do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email );

do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email );

do_action( 'woocommerce_email_footer', $email );
