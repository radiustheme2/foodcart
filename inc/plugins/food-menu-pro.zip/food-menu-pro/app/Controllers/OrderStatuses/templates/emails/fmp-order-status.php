<?php
/**
 * Order Status Email - HTML template.
 *
 * @package RT_FoodMenuPro
 *
 * @var WC_Order $order
 * @var string   $email_heading
 * @var string   $custom_body
 * @var bool     $sent_to_admin
 * @var bool     $plain_text
 * @var WC_Email $email
 */

defined( 'ABSPATH' ) || exit();

do_action( 'woocommerce_email_header', $email_heading, $email );
?>

<?php if ( ! empty( $custom_body ) ) : ?>
	<p><?php echo wp_kses_post( nl2br( $custom_body ) ); ?></p>
<?php else : ?>
	<p>
		<?php
		printf(
			/* translators: %s: customer first name */
			esc_html__( 'Hi %s,', 'food-menu-pro' ),
			esc_html( $order->get_billing_first_name() )
		);
		?>
	</p>
	<p>
		<?php
		printf(
			/* translators: %s: order number */
			esc_html__( 'Your order #%s status has been updated.', 'food-menu-pro' ),
			esc_html( $order->get_order_number() )
		);
		?>
	</p>
<?php endif; ?>

<?php

do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email );

do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email );

do_action( 'woocommerce_email_footer', $email );
