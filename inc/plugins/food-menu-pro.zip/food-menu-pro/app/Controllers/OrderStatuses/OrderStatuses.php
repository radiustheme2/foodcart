<?php
/**
 * Order Statuses main class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\OrderStatuses;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Api\OrderStatuses\OrderStatusesApi;

/**
 * Order Statuses main class.
 */
class OrderStatuses {

	use SingletonTrait;

	/**
	 * Settings option.
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Custom statuses.
	 *
	 * @var array
	 */
	private $statuses;

	/**
	 * Init function — hooks if conditions are met.
	 *
	 * @return void
	 */
	protected function init() {
		$this->options = FnsPro::get_settings_option();

		$fm_type = $this->options['fm_food_menu_type'] ?? 'food_menu_post';
		$enabled = $this->options['fmp_enable_custom_order_statuses'] ?? '';

		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type ) {
			return;
		}

		$this->statuses = get_option( 'fmp_custom_order_statuses', [] );

		if ( ! is_array( $this->statuses ) ) {
			$this->statuses = [];
		}

		// Always register post statuses so existing orders display correctly,
		// even when the feature toggle is OFF.
		if ( ! empty( $this->statuses ) ) {
			add_action( 'init', [ $this, 'register_statuses' ], 20 );
			add_action( 'woocommerce_my_account_my_orders_column_order-status', [ $this, 'frontend_order_status' ] );
			add_filter( 'woocommerce_order_details_status', [ $this, 'frontend_view_order_status' ], 10, 2 );
			add_action( 'wp_head', [ $this, 'frontend_badge_styles' ] );
			add_action( 'admin_head', [ $this, 'badge_styles' ] );
		}

		if ( 'on' !== $enabled ) {
			return;
		}

		// REST API.
		OrderStatusesApi::get_instance();

		// Admin submenu.
		add_action( 'admin_menu', [ $this, 'register_submenu' ], 15 );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue' ] );

		// WooCommerce integration — add to dropdowns and bulk actions only when enabled.
		add_filter( 'wc_order_statuses', [ $this, 'add_order_statuses' ] );

		// Bulk actions (both legacy + HPOS).
		add_filter( 'bulk_actions-edit-shop_order', [ $this, 'add_bulk_actions' ] );
		add_filter( 'bulk_actions-woocommerce_page_wc-orders', [ $this, 'add_bulk_actions' ] );
		add_filter( 'handle_bulk_actions-edit-shop_order', [ $this, 'handle_bulk_actions' ], 10, 3 );
		add_filter( 'handle_bulk_actions-woocommerce_page_wc-orders', [ $this, 'handle_bulk_actions' ], 10, 3 );

		// Email trigger + registration.
		add_action( 'woocommerce_order_status_changed', [ $this, 'trigger_email' ], 10, 4 );
		add_filter( 'woocommerce_email_classes', [ $this, 'register_email_class' ] );
	}

	/**
	 * Register submenu page.
	 *
	 * @return void
	 */
	public function register_submenu() {
		add_submenu_page(
			'edit.php?post_type=' . TLPFoodMenu()->post_type,
			esc_html__( 'Order Statuses', 'food-menu-pro' ),
			esc_html__( 'Order Statuses', 'food-menu-pro' ),
			'manage_woocommerce',
			'fmp_order_statuses',
			[ $this, 'render_page' ],
			11
		);
	}

	/**
	 * Render the React mount point.
	 *
	 * @return void
	 */
	public function render_page() {
		echo '<div class="wrap"><div id="fmp-order-statuses"></div></div>';
	}

	/**
	 * Enqueue React app script on the order statuses page.
	 *
	 * @param string $hook Current admin page hook.
	 *
	 * @return void
	 */
	public function admin_enqueue( $hook ) {
		$screen = get_current_screen();

		if ( ! $screen || 'food-menu_page_fmp_order_statuses' !== $screen->id ) {
			return;
		}

		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : FMP()->options['version'];

		wp_enqueue_script(
			'fmp-order-statuses',
			FMP()->assets_url() . 'js/order-statuses.min.js',
			[ 'wp-element', 'wp-api-fetch', 'wp-i18n' ],
			$version,
			true
		);
		wp_set_script_translations( 'fmp-order-statuses', 'food-menu-pro', FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages' );

		wp_localize_script(
			'fmp-order-statuses',
			'fmpOrderStatuses',
			[
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'restRoot'  => esc_url_raw( rest_url() ),
				'apiUrl'    => esc_url( rest_url( 'fmp/v1' ) ),
				'pluginUrl'    => esc_url( FOOD_MENU_PRO_PLUGIN_URL ),
				'primaryColor' => \RT\FoodMenu\Helpers\Fns::get_setting( 'fm_primary_color', '#fc202e' ),
			]
		);
	}

	/**
	 * Register custom post statuses for each enabled status.
	 *
	 * @return void
	 */
	public function register_statuses() {
		if ( empty( $this->statuses ) ) {
			return;
		}

		foreach ( $this->statuses as $status ) {
			if ( empty( $status['enabled'] ) ) {
				continue;
			}

			$slug = $status['slug'] ?? '';

			if ( empty( $slug ) ) {
				continue;
			}

			$label = $status['label'] ?? $slug;

			register_post_status(
				$slug,
				[
					'label'                     => $label,
					'public'                    => true,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: Number of orders with this status. */
					'label_count'               => _n_noop(
						$label . ' <span class="count">(%s)</span>',
						$label . ' <span class="count">(%s)</span>',
						'food-menu-pro'
					),
				]
			);
		}
	}

	/**
	 * Add custom statuses to WooCommerce order statuses.
	 *
	 * @param array $statuses WC order statuses.
	 *
	 * @return array
	 */
	public function add_order_statuses( $statuses ) {
		if ( empty( $this->statuses ) ) {
			return $statuses;
		}

		foreach ( $this->statuses as $status ) {
			if ( empty( $status['enabled'] ) ) {
				continue;
			}

			$slug = $status['slug'] ?? '';

			if ( empty( $slug ) ) {
				continue;
			}

			$statuses[ $slug ] = $status['label'] ?? $slug;
		}

		return $statuses;
	}

	/**
	 * Add custom statuses to bulk actions dropdown.
	 *
	 * @param array $actions Bulk actions.
	 *
	 * @return array
	 */
	public function add_bulk_actions( $actions ) {
		if ( empty( $this->statuses ) ) {
			return $actions;
		}

		foreach ( $this->statuses as $status ) {
			if ( empty( $status['enabled'] ) ) {
				continue;
			}

			$slug = $status['slug'] ?? '';

			if ( empty( $slug ) ) {
				continue;
			}

			$slug_without_prefix = str_replace( 'wc-', '', $slug );

			$actions[ 'mark_' . $slug_without_prefix ] = sprintf(
				/* translators: %s: order status label */
				esc_html__( 'Change status to %s', 'food-menu-pro' ),
				$status['label']
			);
		}

		return $actions;
	}

	/**
	 * Process bulk status-change actions on the orders list.
	 *
	 * @param string $redirect_to Redirect URL after processing.
	 * @param string $doaction    The action being taken.
	 * @param int[]  $order_ids   Array of order IDs.
	 *
	 * @return string
	 */
	public function handle_bulk_actions( $redirect_to, $doaction, $order_ids ) {
		if ( empty( $this->statuses ) || empty( $order_ids ) ) {
			return $redirect_to;
		}

		foreach ( $this->statuses as $status ) {
			if ( empty( $status['enabled'] ) ) {
				continue;
			}

			$slug                = $status['slug'] ?? '';
			$slug_without_prefix = str_replace( 'wc-', '', $slug );

			if ( 'mark_' . $slug_without_prefix !== $doaction ) {
				continue;
			}

			$changed = 0;

			foreach ( $order_ids as $order_id ) {
				$order = wc_get_order( absint( $order_id ) );

				if ( ! $order ) {
					continue;
				}

				$order->update_status(
					$slug_without_prefix,
					sprintf(
						/* translators: %s: new order status label */
						__( 'Order status changed to %s via bulk action.', 'food-menu-pro' ),
						$status['label'] ?? $slug_without_prefix
					)
				);

				++$changed;
			}

			$redirect_to = add_query_arg(
				[
					'fmp_bulk_status_changed' => $changed,
					'fmp_new_status'          => urlencode( $status['label'] ?? $slug_without_prefix ),
				],
				$redirect_to
			);

			break;
		}

		return $redirect_to;
	}

	/**
	 * Output colored badge CSS on order list screens.
	 *
	 * @return void
	 */
	public function badge_styles() {
		$screen = get_current_screen();

		if ( ! $screen ) {
			return;
		}

		$valid_screens = [ 'edit-shop_order', 'woocommerce_page_wc-orders' ];

		if ( ! in_array( $screen->id, $valid_screens, true ) ) {
			return;
		}

		if ( empty( $this->statuses ) ) {
			return;
		}

		echo '<style>';

		foreach ( $this->statuses as $status ) {
			if ( empty( $status['enabled'] ) ) {
				continue;
			}

			$slug  = str_replace( 'wc-', '', $status['slug'] ?? '' );
			$color = sanitize_hex_color( $status['color'] ?? '#999999' );

			if ( empty( $slug ) || empty( $color ) ) {
				continue;
			}

			printf(
				'mark.order-status.status-%s { background-color: %s; color: #fff; }' . "\n",
				esc_attr( $slug ),
				esc_attr( $color )
			);
		}

		echo '</style>';
	}

	/**
	 * Render colored status badge on My Account orders page.
	 *
	 * @param \WC_Order $order Order object.
	 *
	 * @return void
	 */
	public function frontend_order_status( $order ) {
		$status_slug = 'wc-' . $order->get_status();
		$color       = '';
		$label       = wc_get_order_status_name( $order->get_status() );

		$matched_icon = '';

		foreach ( $this->statuses as $status ) {
			if ( ( $status['slug'] ?? '' ) === $status_slug && ! empty( $status['enabled'] ) ) {
				$color        = sanitize_hex_color( $status['color'] ?? '' );
				$matched_icon = $status['icon'] ?? '';
				break;
			}
		}

		if ( $color ) {
			$icon = sanitize_text_field( $matched_icon ?? '' );

			printf(
				'<span class="fmp-os-badge" style="background-color:%s;color:#fff;padding:4px 10px;border-radius:4px;font-size:12px;font-weight:500;display:inline-flex;align-items:center;gap:5px;">%s%s</span>',
				esc_attr( $color ),
				$icon ? sprintf( '<span class="dashicons %s" style="font-size:14px;width:14px;height:14px;line-height:14px;"></span>', esc_attr( $icon ) ) : '',
				esc_html( $label )
			);
		} else {
			echo esc_html( $label );
		}
	}

	/**
	 * Output badge CSS on frontend pages (My Account, order details).
	 *
	 * @return void
	 */
	public function frontend_badge_styles() {
		if ( ! is_account_page() ) {
			return;
		}

		if ( empty( $this->statuses ) ) {
			return;
		}

		wp_enqueue_style( 'dashicons' );
	}

	/**
	 * Color the status badge on the view-order detail page.
	 *
	 * @param string    $status_html Status HTML string.
	 * @param \WC_Order $order       Order object.
	 *
	 * @return string
	 */
	public function frontend_view_order_status( $status_html, $order ) {
		$status_slug = 'wc-' . $order->get_status();

		foreach ( $this->statuses as $status ) {
			if ( ( $status['slug'] ?? '' ) !== $status_slug ) {
				continue;
			}

			$color = sanitize_hex_color( $status['color'] ?? '' );
			$icon  = sanitize_text_field( $status['icon'] ?? '' );
			$label = esc_html( $status['label'] ?? '' );

			if ( ! $color || ! $label ) {
				break;
			}

			$icon_html = '';

			if ( $icon ) {
				$icon_html = sprintf(
					'<span class="dashicons %s" style="font-size:14px;width:14px;height:14px;line-height:14px;margin-right:4px;"></span>',
					esc_attr( $icon )
				);
			}

			$badge = sprintf(
				'<mark class="order-status" style="background-color:%s;color:#fff;padding:4px 10px;border-radius:4px;font-size:12px;font-weight:500;display:inline-flex;align-items:center;">%s%s</mark>',
				esc_attr( $color ),
				$icon_html,
				$label
			);

			// Use regex to match regardless of what text is inside the mark tag.
			$status_html = preg_replace(
				'/<mark class="order-status">.*?<\/mark>/s',
				$badge,
				$status_html
			);

			break;
		}

		return $status_html;
	}

	/**
	 * Trigger email notification on status change.
	 *
	 * @param int      $order_id  Order ID.
	 * @param string   $old_status Old status.
	 * @param string   $new_status New status.
	 * @param \WC_Order $order Order object.
	 *
	 * @return void
	 */
	public function trigger_email( $order_id, $old_status, $new_status, $order ) {
		$wc_new_status = 'wc-' . $new_status;

		$meta = FnsPro::get_status_metadata( $wc_new_status );
		if ( ! $meta ) {
			return;
		}

		// Only send if there's an actual subject or body configured for this status.
		if ( empty( $meta['email_subject'] ) && empty( $meta['email_body'] ) ) {
			return;
		}

		$mailer = WC()->mailer();
		$emails = $mailer->get_emails();

		if ( isset( $emails['FMP_Order_Status_Email'] ) ) {
			$emails['FMP_Order_Status_Email']->trigger( $order_id, $meta, true, true );
		}
	}

	/**
	 * Register the custom email class with WooCommerce.
	 *
	 * @param array $emails Email classes.
	 *
	 * @return array
	 */
	public function register_email_class( $emails ) {
		$emails['FMP_Order_Status_Email'] = new OrderStatusEmail();

		return $emails;
	}
}
