<?php
/**
 * Order Statuses settings fields class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\OrderStatuses;

defined( 'ABSPATH' ) || exit();

/**
 * Order Statuses settings fields class.
 */
class OrderStatusesFns {

	/**
	 * Order statuses setting fields.
	 *
	 * @return array
	 */
	public static function settings_field() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/order_statuses_settings/fields',
			[
				'fmp_enable_custom_order_statuses' => [
					'label'       => esc_html__( 'Enable Custom Order Statuses?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Add custom workflow statuses (e.g., Prepping, In Oven, Driver Out) to WooCommerce orders.', 'food-menu-pro' ),
					'value'       => $settings['fmp_enable_custom_order_statuses'] ?? '',
				],
			]
		);
	}
}
