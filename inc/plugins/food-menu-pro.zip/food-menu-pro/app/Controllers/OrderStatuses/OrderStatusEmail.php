<?php
/**
 * Order Status Email class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\OrderStatuses;

defined( 'ABSPATH' ) || exit();

/**
 * Order Status Email — extends WC_Email.
 */
class OrderStatusEmail extends \WC_Email {

	/**
	 * Custom email body from status config.
	 *
	 * @var string
	 */
	public $custom_body = '';

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id             = 'fmp_order_status';
		$this->title          = __( 'Food Menu Order Status', 'food-menu-pro' );
		$this->description    = __( 'Order status change notification for custom Food Menu statuses.', 'food-menu-pro' );
		$this->heading        = __( 'Order Status Update', 'food-menu-pro' );
		$this->subject        = __( 'Your order status has been updated', 'food-menu-pro' );
		$this->template_html  = 'emails/fmp-order-status.php';
		$this->template_plain = 'emails/plain/fmp-order-status.php';
		$this->template_base  = FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'app/Controllers/OrderStatuses/templates/';
		$this->customer_email = true;

		parent::__construct();
	}

	/**
	 * Trigger the email.
	 *
	 * @param int   $order_id    Order ID.
	 * @param array $status_data Status configuration.
	 *
	 * @return void
	 */
	public function trigger( $order_id, $status_data = [], $send_customer = true, $send_admin = false ) {
		$this->setup_locale();

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			$this->restore_locale();
			return;
		}

		$this->object = $order;

		$this->placeholders = array_merge(
			$this->placeholders,
			[
				'{customer_name}' => $order->get_billing_first_name(),
				'{order_number}'  => $order->get_order_number(),
				'{order_date}'    => wc_format_datetime( $order->get_date_created() ),
				'{status_label}'  => $status_data['label'] ?? '',
				'{site_name}'     => get_bloginfo( 'name' ),
				'{order_url}'     => $order->get_view_order_url(),
			]
		);

		if ( ! empty( $status_data['email_subject'] ) ) {
			$this->subject = $this->format_string( sanitize_text_field( wp_unslash( $status_data['email_subject'] ) ) );
		}

		$this->custom_body = '';

		if ( ! empty( $status_data['email_body'] ) ) {
			$this->custom_body = $this->format_string( sanitize_textarea_field( wp_unslash( $status_data['email_body'] ) ) );
		}

		$subject     = $this->get_subject();
		$content     = $this->get_content();
		$headers     = $this->get_headers();
		$attachments = $this->get_attachments();

		// Send to customer.
		if ( $send_customer && $this->is_enabled() ) {
			$this->recipient = $order->get_billing_email();

			if ( $this->get_recipient() ) {
				$this->send( $this->get_recipient(), $subject, $content, $headers, $attachments );
			}
		}

		// Send to admin.
		if ( $send_admin ) {
			$admin_email = get_option( 'woocommerce_email_from_address', get_option( 'admin_email' ) );

			if ( $admin_email ) {
				$admin_subject = sprintf(
					/* translators: 1: order number, 2: status label */
					__( '[Order #%1$s] Status changed to %2$s', 'food-menu-pro' ),
					$order->get_order_number(),
					$status_data['label'] ?? ''
				);

				$this->custom_body = sprintf(
					/* translators: 1: order number, 2: status label, 3: customer name */
					__( 'Order #%1$s from %3$s has been updated to "%2$s".', 'food-menu-pro' ),
					$order->get_order_number(),
					$status_data['label'] ?? '',
					$order->get_billing_first_name() . ' ' . $order->get_billing_last_name()
				);

				$admin_content = $this->get_content();

				$this->send( $admin_email, $admin_subject, $admin_content, $headers, $attachments );
			}
		}

		$this->restore_locale();
	}

	/**
	 * Get HTML content.
	 *
	 * @return string
	 */
	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			[
				'order'         => $this->object,
				'email_heading' => $this->get_heading(),
				'custom_body'   => $this->custom_body,
				'sent_to_admin' => false,
				'plain_text'    => false,
				'email'         => $this,
			],
			'',
			$this->template_base
		);
	}

	/**
	 * Get plain text content.
	 *
	 * @return string
	 */
	public function get_content_plain() {
		return wc_get_template_html(
			$this->template_plain,
			[
				'order'         => $this->object,
				'email_heading' => $this->get_heading(),
				'custom_body'   => $this->custom_body,
				'sent_to_admin' => false,
				'plain_text'    => true,
				'email'         => $this,
			],
			'',
			$this->template_base
		);
	}
}
