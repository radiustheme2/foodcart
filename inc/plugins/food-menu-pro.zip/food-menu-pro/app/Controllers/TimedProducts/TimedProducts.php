<?php
/**
 * Timed Products Controller.
 *
 * Controls product visibility based on time-based rules.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\TimedProducts;

use RT\FoodMenuPro\Controllers\Hooks\ActionHooks;
use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Api\TimedProducts\TimedProductsApi;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Timed Products Controller.
 */
class TimedProducts {

	use SingletonTrait;

	/**
	 * Plugin settings.
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Cached rules loaded once per request.
	 *
	 * @var array|null
	 */
	private $rules;

	/**
	 * Product ids per category-rule key, memoized for the request.
	 *
	 * @var array<string, int[]>
	 */
	private $category_products = [];

	/**
	 * Whether to skip the purchase block filter.
	 *
	 * True during cart session loading so WC doesn't generate
	 * duplicate "removed from cart" notices.
	 *
	 * @var bool
	 */
	private $skip_purchase_block = false;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		$this->options = FnsPro::get_settings_option();
		$fm_type       = $this->options['fm_food_menu_type'] ?? '';
		$enabled       = $this->options['fmp_enable_timed_products'] ?? '';

		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type || 'on' !== $enabled ) {
			return;
		}

		// REST API.
		TimedProductsApi::get_instance();

		// Admin hooks.
		add_filter( 'fmp/sub_menu/timed_products', [ $this, 'render_page' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue' ] );

		// Frontend hooks — only on non-admin pages.
		if ( ! is_admin() ) {
			// Default must match the settings UI default ('disable') so an
			// unsaved new site behaves the same as what the dropdown shows.
			$behavior = $this->options['fmp_timed_products_behavior'] ?? 'disable';

			if ( 'disappear' === $behavior ) {
				add_filter( 'rt_fm_sc_query_args', [ $this, 'filter_by_schedule' ], 15, 2 );
				add_action( 'woocommerce_product_query', [ $this, 'filter_shop_by_schedule' ] );
			} else {
				add_filter( 'rt_fm_shortcode_data', [ $this, 'mark_unavailable' ], 10, 4 );
				add_filter( 'woocommerce_is_purchasable', [ $this, 'block_purchase' ], 10, 2 );
				add_filter( 'woocommerce_variation_is_purchasable', [ $this, 'block_purchase' ], 10, 2 );
				add_action( 'wp_loaded', [ $this, 'enable_cart_load_bypass' ], 9 );
				add_action( 'woocommerce_cart_loaded_from_session', [ $this, 'remove_unavailable_from_cart' ], 0 );
			}

			// Render badge script in both modes — in 'disappear' it only paints
			// "Available" / "Will be Unavailable" badges on still-visible products.
			add_action( 'wp_footer', [ $this, 'render_disable_script' ] );
		}
	}

	/**
	 * Render the React mount point.
	 *
	 * @return void
	 */
	public function render_page() {
		echo '<div class="wrap"><div id="fmp-timed-products"></div></div>';
	}

	/**
	 * Enqueue React app script on the Timed Products page only.
	 *
	 * @return void
	 */
	public function admin_enqueue() {
		$screen = get_current_screen();

		if ( ! $screen || 'food-menu_page_timed_products' !== $screen->id ) {
			return;
		}

		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : FMP()->options['version'];

		wp_enqueue_style(
			'fmp-timed-products',
			FMP()->assets_url() . 'css/timed-products-css.min.css',
			[],
			$version
		);

		wp_enqueue_script(
			'fmp-timed-products',
			FMP()->assets_url() . 'js/timed-products.min.js',
			[ 'wp-element', 'wp-api-fetch', 'wp-i18n' ],
			$version,
			true
		);
		wp_set_script_translations( 'fmp-timed-products', 'food-menu-pro', FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages' );

		// Build locations array if food location is enabled.
		$locations              = [];
		$food_location_enabled  = $this->options['fmp_food_location_popup'] ?? '';
		$multi_location_enabled = $this->options['fmp_food_location_popup'] ?? '';

		if ( 'on' === $food_location_enabled && taxonomy_exists( 'tpl-food-location' ) ) {
			$terms = get_terms(
				[
					'taxonomy'   => 'tpl-food-location',
					'hide_empty' => false,
				]
			);

			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$locations[] = [
						'value' => $term->term_id,
						'label' => $term->name,
					];
				}
			}
		}

		// Build categories array.
		$categories = [];
		$cat_terms  = get_terms(
			[
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			]
		);

		if ( ! is_wp_error( $cat_terms ) ) {
			foreach ( $cat_terms as $term ) {
				$categories[] = [
					'value' => $term->term_id,
					'label' => $term->name,
				];
			}
		}

		wp_localize_script(
			'fmp-timed-products',
			'fmpTimedProducts',
			[
				'nonce'      => wp_create_nonce( 'wp_rest' ),
				'restRoot'   => esc_url_raw( rest_url() ),
				'apiUrl'     => esc_url( rest_url( 'fmp/v1' ) ),
				'locations'       => $locations,
				'multiLocationOn' => ( 'on' === $food_location_enabled && 'on' === $multi_location_enabled ),
				'categories'      => $categories,
				'siteTime'      => wp_date( 'F j, Y g:i a' ),
				'timezone'      => wp_timezone_string(),
				'tzSettingsUrl' => esc_url( admin_url( 'options-general.php' ) ),
				'primaryColor' => \RT\FoodMenu\Helpers\Fns::get_setting( 'fm_primary_color', '#fc202e' ),
			]
		);
	}

	/**
	 * Get all rules, loaded once per request.
	 *
	 * @return array
	 */
	private function get_rules() {
		if ( null === $this->rules ) {
			$this->rules = get_option( TimedProductsApi::OPTION_KEY, [] );

			if ( ! is_array( $this->rules ) ) {
				$this->rules = [];
			}
		}

		return $this->rules;
	}

	/**
	 * Conflict winner when a product matches both an "available" and an
	 * "unavailable" rule at the same moment: 'unavailable' (default) or
	 * 'available'.
	 *
	 * @return string
	 */
	private function get_conflict_winner() {
		$winner = $this->options['fmp_timed_products_conflict_winner'] ?? 'unavailable';

		return 'available' === $winner ? 'available' : 'unavailable';
	}

	/**
	 * Get unavailable product IDs for a moment and location.
	 *
	 * @param int      $location_id Current location ID (0 = all).
	 * @param int|null $moment      Unix timestamp to judge the rules at.
	 *                              Null means now, which is every caller on
	 *                              the website.
	 *
	 * @return array Product IDs that should not be shown.
	 */
	private function get_unavailable_product_ids( $location_id = 0, $moment = null ) {
		$rules = $this->get_rules();

		if ( empty( $rules ) ) {
			return [];
		}

		$multi_location_on = 'on' === ( $this->options['fmp_food_location_popup'] ?? '' )
			&& 'on' === ( $this->options['fmp_food_location_popup'] ?? '' );

		$unavailable_ids      = [];
		$available_ids        = []; // Products currently available via a matching rule.
		$location_claimed_ids = []; // Products covered by location-specific rules.

		// Phase 1: Location-specific rules take priority.
		if ( $multi_location_on && $location_id > 0 ) {
			foreach ( $rules as $rule ) {
				if ( empty( $rule['enabled'] ) ) {
					continue;
				}

				$rule_location = absint( $rule['location_id'] ?? 0 );

				if ( 0 === $rule_location || $rule_location !== $location_id ) {
					continue;
				}

				$product_ids          = $this->get_rule_product_ids( $rule );
				$location_claimed_ids = array_merge( $location_claimed_ids, $product_ids );

				if ( $this->is_rule_unavailable( $rule, $moment ) ) {
					$unavailable_ids = array_merge( $unavailable_ids, $product_ids );
				} else {
					$available_ids = array_merge( $available_ids, $product_ids );
				}
			}
		}

		// Phase 2: "All Locations" rules — skip products already claimed by location-specific rules.
		foreach ( $rules as $rule ) {
			if ( empty( $rule['enabled'] ) ) {
				continue;
			}

			$rule_location = absint( $rule['location_id'] ?? 0 );

			// Only process "All Locations" rules in this phase.
			if ( $rule_location > 0 ) {
				continue;
			}

			$product_ids = $this->get_rule_product_ids( $rule );

			// Exclude products already handled by location-specific rules.
			if ( ! empty( $location_claimed_ids ) ) {
				$product_ids = array_diff( $product_ids, $location_claimed_ids );
			}

			if ( $this->is_rule_unavailable( $rule, $moment ) ) {
				$unavailable_ids = array_merge( $unavailable_ids, $product_ids );
			} else {
				$available_ids = array_merge( $available_ids, $product_ids );
			}
		}

		// When "available wins", a product covered by any currently-available
		// rule is rescued from the unavailable list (location precedence above
		// is preserved — claimed products are already excluded from phase 2).
		if ( 'available' === $this->get_conflict_winner() ) {
			$unavailable_ids = array_diff( $unavailable_ids, $available_ids );
		}

		return array_values( array_unique( array_map( 'absint', $unavailable_ids ) ) );
	}

	/**
	 * Get all product IDs that have any enabled timed rule for the current location.
	 *
	 * @param int $location_id Current location ID (0 = all).
	 *
	 * @return array Product IDs covered by timed rules.
	 */
	private function get_all_timed_product_ids( $location_id = 0 ) {
		$rules = $this->get_rules();

		if ( empty( $rules ) ) {
			return [];
		}

		$multi_location_on = 'on' === ( $this->options['fmp_food_location_popup'] ?? '' )
			&& 'on' === ( $this->options['fmp_food_location_popup'] ?? '' );

		$timed_ids            = [];
		$location_claimed_ids = [];

		// Phase 1: Location-specific rules.
		if ( $multi_location_on && $location_id > 0 ) {
			foreach ( $rules as $rule ) {
				if ( empty( $rule['enabled'] ) ) {
					continue;
				}

				$rule_location = absint( $rule['location_id'] ?? 0 );

				if ( 0 === $rule_location || $rule_location !== $location_id ) {
					continue;
				}

				$product_ids          = $this->get_rule_product_ids( $rule );
				$location_claimed_ids = array_merge( $location_claimed_ids, $product_ids );
				$timed_ids            = array_merge( $timed_ids, $product_ids );
			}
		}

		// Phase 2: "All Locations" rules.
		foreach ( $rules as $rule ) {
			if ( empty( $rule['enabled'] ) ) {
				continue;
			}

			$rule_location = absint( $rule['location_id'] ?? 0 );

			if ( $rule_location > 0 ) {
				continue;
			}

			$product_ids = $this->get_rule_product_ids( $rule );

			if ( ! empty( $location_claimed_ids ) ) {
				$product_ids = array_diff( $product_ids, $location_claimed_ids );
			}

			$timed_ids = array_merge( $timed_ids, $product_ids );
		}

		return array_values( array_unique( array_map( 'absint', $timed_ids ) ) );
	}

	/**
	 * Check if a rule makes products unavailable at a moment.
	 *
	 * @param array    $rule   Rule data.
	 * @param int|null $moment Unix timestamp, or null for now.
	 *
	 * @return bool
	 */
	private function is_rule_unavailable( $rule, $moment = null ) {
		$is_active = $this->is_rule_active( $rule['timed_rules'] ?? [], $moment );
		$action    = $rule['action'] ?? 'show';

		return ( 'show' === $action && ! $is_active ) || ( 'hide' === $action && $is_active );
	}

	/**
	 * Get product IDs affected by a rule.
	 *
	 * Memoized for the request: a category rule costs a `get_posts()`, and the
	 * rules are walked once per moment being judged. The website judges two or
	 * three moments a page; `/app/slots` judges one per slot, which without
	 * this would be a product query per slot per category rule.
	 *
	 * @param array $rule Rule data.
	 *
	 * @return array Product IDs.
	 */
	private function get_rule_product_ids( $rule ) {
		$product_rule_type = $rule['product_rule_type'] ?? 'specific_products';

		if ( 'specific_products' === $product_rule_type ) {
			return array_map( 'intval', (array) ( $rule['products'] ?? [] ) );
		}

		if ( 'product_categories' === $product_rule_type ) {
			$cat_ids = array_map( 'intval', (array) ( $rule['categories'] ?? [] ) );

			if ( ! empty( $cat_ids ) ) {
				sort( $cat_ids );
				$cache_key = implode( ',', $cat_ids );

				if ( isset( $this->category_products[ $cache_key ] ) ) {
					return $this->category_products[ $cache_key ];
				}

				$this->category_products[ $cache_key ] = get_posts(
					[
						'post_type'      => 'product',
						'posts_per_page' => -1,
						'fields'         => 'ids',
						'tax_query'      => [ //phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
							[
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'terms'    => $cat_ids,
							],
						],
					]
				);

				return $this->category_products[ $cache_key ];
			}
		}

		return [];
	}

	/**
	 * Check if timed rule conditions are met at a moment.
	 *
	 * Rules of the same type use OR logic (any match = pass).
	 * Different types use AND logic (all types must pass).
	 *
	 * @param array    $timed_rules Array of timed rule conditions.
	 * @param int|null $moment      Unix timestamp, or null for now.
	 *
	 * @return bool True if conditions pass, false otherwise.
	 */
	private function is_rule_active( $timed_rules, $moment = null ) {
		if ( empty( $timed_rules ) ) {
			return true;
		}

		// Group rules by type.
		$grouped = [];

		foreach ( $timed_rules as $rule ) {
			$type = $rule['type'] ?? '';

			if ( ! $type ) {
				continue;
			}

			$grouped[ $type ][] = $rule;
		}

		// Each type group must have at least one matching rule (AND between types, OR within type).
		foreach ( $grouped as $type => $type_rules ) {
			$type_matched = false;

			foreach ( $type_rules as $rule ) {
				if ( $this->check_single_condition( $type, $rule, $moment ) ) {
					$type_matched = true;
					break;
				}
			}

			if ( ! $type_matched ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Check a single timed rule condition.
	 *
	 * Every condition is a question about one moment, so the moment is a
	 * parameter. Passing null keeps the website's reading — the rules are
	 * about whether a dish can be ordered *now* — while `/app/slots` asks the
	 * same rules about a slot the customer is choosing, which is the only way
	 * to tell them a breakfast dish cannot be collected at three in the
	 * afternoon.
	 *
	 * @param string   $type   Condition type.
	 * @param array    $rule   Rule data.
	 * @param int|null $moment Unix timestamp, or null for now.
	 *
	 * @return bool True if condition is met.
	 */
	private function check_single_condition( $type, $rule, $moment = null ) {
		// `current_time()` and `wp_date()` are both in the site's timezone, so
		// the null branch is exactly what this method did before.
		$date = null === $moment ? current_time( 'Y-m-d' ) : wp_date( 'Y-m-d', (int) $moment );
		$time = null === $moment ? current_time( 'H:i' ) : wp_date( 'H:i', (int) $moment );
		$day  = null === $moment ? current_time( 'l' ) : wp_date( 'l', (int) $moment );

		switch ( $type ) {
			case 'on_date':
				return $date === ( $rule['date'] ?? '' );

			case 'date_range':
				return $date >= ( $rule['start'] ?? '' ) && $date <= ( $rule['end'] ?? '' );

			case 'time_range':
				$start = $rule['start'] ?? '';
				$end   = $rule['end'] ?? '';

				// Handle midnight crossover (e.g., 22:00 - 02:00).
				if ( $start > $end ) {
					return $time >= $start || $time <= $end;
				}

				return $time >= $start && $time <= $end;

			case 'day_of_week':
				return in_array( strtolower( $day ), (array) ( $rule['days'] ?? [] ), true );

			case 'before_date':
				return $date <= ( $rule['date'] ?? '' );

			case 'after_date':
				return $date >= ( $rule['date'] ?? '' );
		}

		return false;
	}

	/**
	 * Filter shortcode/widget queries — disappear mode.
	 *
	 * @param array $args Query args.
	 * @param int   $scID Shortcode ID.
	 *
	 * @return array
	 */
	public function filter_by_schedule( $args, $scID ) {
		$location_id     = $this->get_location_id();
		$unavailable_ids = $this->get_unavailable_product_ids( $location_id );

		if ( empty( $unavailable_ids ) ) {
			return $args;
		}

		if ( ! empty( $args['post__not_in'] ) ) {
			$args['post__not_in'] = array_unique( array_merge( $args['post__not_in'], $unavailable_ids ) );
		} else {
			$args['post__not_in'] = $unavailable_ids;
		}

		return $args;
	}

	/**
	 * Filter WooCommerce shop page — disappear mode.
	 *
	 * @param \WP_Query $query WooCommerce product query.
	 *
	 * @return void
	 */
	public function filter_shop_by_schedule( $query ) {
		$location_id     = $this->get_location_id();
		$unavailable_ids = $this->get_unavailable_product_ids( $location_id );

		if ( empty( $unavailable_ids ) ) {
			return;
		}

		$existing = $query->get( 'post__not_in' );

		if ( ! empty( $existing ) ) {
			$query->set( 'post__not_in', array_unique( array_merge( $existing, $unavailable_ids ) ) );
		} else {
			$query->set( 'post__not_in', $unavailable_ids );
		}
	}

	/**
	 * Mark product as unavailable in shortcode data — disable mode.
	 *
	 * @param array $arg      Product data array.
	 * @param array $meta     Post meta.
	 * @param array $scMeta   Shortcode meta.
	 * @param int   $postID   Post ID.
	 *
	 * @return array
	 */
	/**
	 * Render inline script to add info icon and disabled state to unavailable products.
	 *
	 * Uses data attributes set by mark_unavailable() on each product card.
	 * Works across all layout templates without modifying them.
	 *
	 * @return void
	 */
	public function render_disable_script() {
		$location_id     = $this->get_location_id();
		$all_timed_ids   = $this->get_all_timed_product_ids( $location_id );

		if ( empty( $all_timed_ids ) ) {
			return;
		}

		$unavailable_ids = $this->get_unavailable_product_ids( $location_id );

		// Build schedule text + pending list (any product whose state will change in future).
		$schedule_map = [];
		$pending_ids  = [];

		foreach ( $all_timed_ids as $pid ) {
			$schedule_map[ $pid ] = $this->get_schedule_text_for_product( $pid, $location_id );

			$matched_rule = $this->find_matched_rule_for_product( $pid, $location_id );

			if ( $matched_rule && 'future' === $this->get_rule_temporal_state( $matched_rule ) ) {
				$pending_ids[] = $pid;
			}
		}

		$all_ids_json      = wp_json_encode( $all_timed_ids );
		$unavailable_json  = wp_json_encode( $unavailable_ids );
		$pending_json      = wp_json_encode( $pending_ids );
		$schedule_json     = wp_json_encode( $schedule_map );
		$info_svg          = '<svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.30371 0C5.05696 0 3.8382 0.369706 2.80156 1.06237C1.76492 1.75503 0.956957 2.73953 0.479844 3.89138C0.00273132 5.04324 -0.122103 6.3107 0.121127 7.5335C0.364357 8.7563 0.964727 9.87952 1.84632 10.7611C2.72791 11.6427 3.85112 12.2431 5.07392 12.4863C6.29672 12.7295 7.56419 12.6047 8.71604 12.1276C9.86789 11.6505 10.8524 10.8425 11.5451 9.80586C12.2377 8.76922 12.6074 7.55047 12.6074 6.30371C12.6055 4.63247 11.9407 3.03024 10.7589 1.84849C9.57718 0.666744 7.97495 0.00197161 6.30371 0ZM6.30371 11.4613C5.28364 11.4613 4.28647 11.1588 3.43831 10.5921C2.59015 10.0254 1.92909 9.21985 1.53873 8.27743C1.14836 7.33501 1.04623 6.29799 1.24523 5.29752C1.44424 4.29704 1.93545 3.37805 2.65675 2.65675C3.37805 1.93545 4.29705 1.44424 5.29752 1.24523C6.29799 1.04622 7.33501 1.14836 8.27743 1.53873C9.21986 1.92909 10.0254 2.59015 10.5921 3.43831C11.1588 4.28647 11.4613 5.28364 11.4613 6.30371C11.4596 7.67107 10.9157 8.98195 9.94883 9.94883C8.98196 10.9157 7.67108 11.4596 6.30371 11.4613Z" fill="currentColor"/>
<path d="M6.8766 6.06619V2.86506C6.8766 2.71307 6.81622 2.56731 6.70875 2.45984C6.60128 2.35237 6.45552 2.29199 6.30353 2.29199C6.15155 2.29199 6.00579 2.35237 5.89832 2.45984C5.79085 2.56731 5.73047 2.71307 5.73047 2.86506V6.30344C5.7305 6.45542 5.7909 6.60115 5.89838 6.7086L7.61757 8.42779C7.72565 8.53218 7.87041 8.58994 8.02066 8.58864C8.17092 8.58733 8.31465 8.52706 8.4209 8.42081C8.52715 8.31456 8.58742 8.17083 8.58873 8.02057C8.59003 7.87032 8.53227 7.72556 8.42788 7.61748L6.8766 6.06619Z" fill="currentColor"/>
</svg>
';

		?>
		<script>
		(function() {
			var allIds = <?php echo $all_ids_json; ?>;
			var unavailableIds = <?php echo $unavailable_json; ?>;
			var pendingIds = <?php echo $pending_json; ?>;
			var schedules = <?php echo $schedule_json; ?>;
			var svg = <?php echo wp_json_encode( $info_svg ); ?>;

			function applyTimedState() {
				allIds.forEach(function(id) {
					var isUnavailable = unavailableIds.indexOf(id) !== -1;
					var isPending = pendingIds.indexOf(id) !== -1;

					// Strategy 1: Match by outer wrapper class (shortcodes + pro layouts + elementor).
					var wrappers = document.querySelectorAll(
						'[data-pid="' + id + '"], .fmp-item-' + id + ', .post-' + id
					);

					wrappers.forEach(function(el) {
						processElement(el, id, isUnavailable, isPending);
					});

					// Strategy 2: Match by data-id on links (grid-by-cat and other layouts).
					var links = document.querySelectorAll('a[data-id="' + id + '"]');
					links.forEach(function(link) {
						// Walk up to find the closest product container.
						var container = link.closest('.fmp-food-item')
							|| link.closest('.fmp-box-wrapper')
							|| link.closest('.food-menu5-box')
							|| link.closest('li')
							|| link.parentElement;
						if (container) {
							processElement(container, id, isUnavailable, isPending);
						}
					});
				});
			}

			function processElement(el, id, isUnavailable, isPending) {
				if (el.classList.contains('fmp-timed-processed')) return;
				el.classList.add('fmp-timed-processed');

				// Dim unavailable products. Pending is independent so a currently-unavailable
				// product with a future "Will be Available" notice still gets the blue badge.
				if (isUnavailable) {
					el.classList.add('fmp-timed-unavailable');
				}
				if (isPending) {
					el.classList.add('fmp-timed-pending');
				}

				// Show info badge on all timed products.
				var titleEl = el.querySelector('h3') || el.querySelector('h2') || el.querySelector('.fmp-title');
				if (titleEl && !titleEl.querySelector('.fmp-timed-info')) {
					var info = document.createElement('span');
					info.className = 'fmp-timed-info';
					info.innerHTML = '<span class="fmp-timed-info-icon" title="' +
						(schedules[id] || '').replace(/"/g, '&quot;') + '">' + svg + '</span>';
					titleEl.insertBefore(info, titleEl.firstChild);
				}
			}

			// Debounced re-application — safe to call many times because processElement()
			// short-circuits on already-tagged nodes via `fmp-timed-processed`.
			var debounceTimer = null;
			function scheduleApply() {
				if (debounceTimer) {
					return;
				}
				debounceTimer = setTimeout(function() {
					debounceTimer = null;
					applyTimedState();
				}, 50);
			}

			// Run on DOM ready and after AJAX/dynamic content loads.
			if (document.readyState === 'loading') {
				document.addEventListener('DOMContentLoaded', applyTimedState);
			} else {
				applyTimedState();
			}

			// Re-apply after isotope/AJAX load more.
			document.addEventListener('fmp:content-loaded', applyTimedState);

			// Block themes (Twenty Twenty-Three etc.) swap product lists in via AJAX
			// pagination without firing a load event — watch the DOM for inserted nodes.
			function startObserver() {
				if (typeof MutationObserver === 'undefined' || !document.body) {
					return;
				}

				var observer = new MutationObserver(function(mutations) {
					for (var i = 0; i < mutations.length; i++) {
						var added = mutations[i].addedNodes;
						if (!added || !added.length) {
							continue;
						}
						for (var j = 0; j < added.length; j++) {
							if (added[j].nodeType === 1) {
								scheduleApply();
								return;
							}
						}
					}
				});

				observer.observe(document.body, { childList: true, subtree: true });
			}

			if (document.body) {
				startObserver();
			} else {
				document.addEventListener('DOMContentLoaded', startObserver);
			}

			// Common WooCommerce / shop AJAX events (classic themes, fragments, infinite scroll plugins).
			if (window.jQuery) {
				window.jQuery(document.body).on(
					'updated_wc_div wc_fragments_refreshed wc_fragments_loaded post-load',
					scheduleApply
				);
			}
		})();
		</script>
		<?php
	}

	/**
	 * Check if a product is currently unavailable due to timed rules.
	 *
	 * Public helper for use in popup, single page, etc.
	 *
	 * @param int $product_id Product ID.
	 *
	 * @return bool
	 */
	public function is_product_unavailable( $product_id ) {
		$enabled  = $this->options['fmp_enable_timed_products'] ?? '';
		$fm_type  = $this->options['fm_food_menu_type'] ?? '';
		// Default must match the settings UI default ('disable').
		$behavior = $this->options['fmp_timed_products_behavior'] ?? 'disable';

		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type || 'on' !== $enabled || 'disappear' === $behavior ) {
			return false;
		}

		$location_id     = $this->get_location_id();
		$unavailable_ids = $this->get_unavailable_product_ids( $location_id );

		return in_array( (int) $product_id, $unavailable_ids, true );
	}

	/**
	 * Which of these products cannot be served at a given moment.
	 *
	 * The public way in for code that asks about a time other than now —
	 * `/app/slots`, which has to know whether the cart can be fulfilled in
	 * the slot the customer is about to pick.
	 *
	 * `fmp_timed_products_behavior` is deliberately **not** consulted, unlike
	 * `is_product_unavailable()`. That setting decides how the menu presents a
	 * dish that is unorderable right now — hidden, or greyed out. Whether a
	 * kitchen can serve it at four tomorrow afternoon is the same answer
	 * either way.
	 *
	 * @param int[]    $product_ids Products to judge.
	 * @param int|null $moment      Unix timestamp, or null for now.
	 * @param int      $location_id Location term ID (0 = none).
	 *
	 * @return int[] The subset that is unavailable then.
	 */
	public function unavailable_at( array $product_ids, $moment = null, $location_id = 0 ) {
		$enabled = $this->options['fmp_enable_timed_products'] ?? '';
		$fm_type = $this->options['fm_food_menu_type'] ?? '';

		// Checked here rather than left to callers: `init()` returns early
		// when the feature is off, so the singleton exists either way and
		// would otherwise happily evaluate rules a store has switched off.
		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type || 'on' !== $enabled ) {
			return [];
		}

		if ( empty( $product_ids ) ) {
			return [];
		}

		$unavailable = $this->get_unavailable_product_ids( $location_id, $moment );

		return array_values( array_intersect( array_map( 'absint', $product_ids ), $unavailable ) );
	}

	/**
	 * Enable bypass flag before WC loads cart from session.
	 *
	 * Runs on wp_loaded priority 9, just before WC initializes the cart
	 * at priority 10. This prevents block_purchase from triggering WC's
	 * built-in "removed from cart" notice during session loading.
	 *
	 * @return void
	 */
	public function enable_cart_load_bypass() {
		$this->skip_purchase_block = true;
	}

	/**
	 * Block purchase for unavailable products — disable mode.
	 *
	 * Prevents adding to cart via direct URL or WC shop page.
	 *
	 * @param bool        $purchasable Whether the product is purchasable.
	 * @param \WC_Product $product     Product object.
	 *
	 * @return bool
	 */
	public function block_purchase( $purchasable, $product ) {
		if ( $this->skip_purchase_block || ! $purchasable ) {
			return $purchasable;
		}

		$location_id     = $this->get_location_id();
		$unavailable_ids = $this->get_unavailable_product_ids( $location_id );

		if ( in_array( (int) $product->get_id(), $unavailable_ids, true ) ) {
			return false;
		}

		return $purchasable;
	}

	/**
	 * Remove unavailable products from cart after session loads.
	 *
	 * Runs on woocommerce_cart_loaded_from_session priority 0,
	 * removes items and shows a single notice, then re-enables
	 * the purchase block filter for the rest of the request.
	 *
	 * @return void
	 */
	public function remove_unavailable_from_cart() {
		$this->skip_purchase_block = false;

		if ( ! WC()->cart ) {
			return;
		}

		$location_id     = $this->get_location_id();
		$unavailable_ids = $this->get_unavailable_product_ids( $location_id );

		if ( empty( $unavailable_ids ) ) {
			return;
		}

		$removed = [];

		foreach ( WC()->cart->get_cart() as $cart_key => $cart_item ) {
			$product_id = $cart_item['product_id'];

			if ( in_array( (int) $product_id, $unavailable_ids, true ) ) {
				WC()->cart->remove_cart_item( $cart_key );
				$removed[] = $cart_item['data']->get_name();
			}
		}

		if ( ! empty( $removed ) ) {
			$names = implode( ', ', array_unique( $removed ) );
			wc_add_notice(
				sprintf(
					/* translators: %s: product name(s) */
					__( '%s is currently unavailable and has been removed from your cart.', 'food-menu-pro' ),
					$names
				),
				'notice'
			);
		}
	}

	public function mark_unavailable( $arg, $meta, $scMeta, $postID ) {
		$location_id     = $this->get_location_id();
		$unavailable_ids = $this->get_unavailable_product_ids( $location_id );

		if ( in_array( (int) $postID, $unavailable_ids, true ) ) {
			$arg['fmp_timed_unavailable']   = true;
			$arg['fmp_timed_schedule_text'] = $this->get_schedule_text_for_product( (int) $postID, $location_id );
		}

		return $arg;
	}

	/**
	 * Find the rule that applies to a product right now.
	 *
	 * Location-specific rules take priority over "All Locations" rules.
	 * Within the matched set, the configured conflict winner decides which rule
	 * is surfaced (unavailable-wins by default, available-wins if set) so the
	 * badge reflects the same state the storefront enforces.
	 *
	 * @param int $product_id  Product ID.
	 * @param int $location_id Location ID (0 for none).
	 *
	 * @return array|null Matched rule or null if none matched.
	 */
	private function find_matched_rule_for_product( $product_id, $location_id = 0 ) {
		$rules = $this->get_rules();

		$multi_location_on = 'on' === ( $this->options['fmp_food_location_popup'] ?? '' );

		$matched_rules = [];

		if ( $multi_location_on && $location_id > 0 ) {
			foreach ( $rules as $rule ) {
				if ( empty( $rule['enabled'] ) ) {
					continue;
				}

				$rule_location = absint( $rule['location_id'] ?? 0 );

				if ( $rule_location !== $location_id ) {
					continue;
				}

				if ( $this->rule_matches_product( $rule, $product_id ) ) {
					$matched_rules[] = $rule;
				}
			}
		}

		if ( empty( $matched_rules ) ) {
			foreach ( $rules as $rule ) {
				if ( empty( $rule['enabled'] ) ) {
					continue;
				}

				$rule_location = absint( $rule['location_id'] ?? 0 );

				if ( $rule_location > 0 ) {
					continue;
				}

				if ( $this->rule_matches_product( $rule, $product_id ) ) {
					$matched_rules[] = $rule;
				}
			}
		}

		// Surface the rule that matches the configured conflict winner so the
		// badge reflects the same state the storefront enforces.
		if ( 'available' === $this->get_conflict_winner() ) {
			foreach ( $matched_rules as $rule ) {
				if ( ! $this->is_rule_unavailable( $rule ) ) {
					return $rule;
				}
			}
		} else {
			foreach ( $matched_rules as $rule ) {
				if ( $this->is_rule_unavailable( $rule, $moment ) ) {
					return $rule;
				}
			}
		}

		return $matched_rules[0] ?? null;
	}

	/**
	 * Get human-readable schedule text for a product.
	 *
	 * Finds the first matching rule and builds text from its timed_rules.
	 *
	 * @param int $product_id Product ID.
	 *
	 * @return string Schedule text.
	 */
	private function get_schedule_text_for_product( $product_id, $location_id = 0 ) {
		$matched_rule = $this->find_matched_rule_for_product( $product_id, $location_id );

		if ( ! $matched_rule ) {
			return __( 'Available', 'food-menu-pro' );
		}

		$is_unavailable_now = $this->is_rule_unavailable( $matched_rule );
		$temporal           = $this->get_rule_temporal_state( $matched_rule );

		// Future change pending — show heads-up text with date/time.
		if ( 'future' === $temporal ) {
			$parts = [];

			foreach ( $matched_rule['timed_rules'] ?? [] as $tr ) {
				$parts[] = $this->format_timed_rule( $tr );
			}

			$schedule = implode( ', ', array_filter( $parts ) );

			if ( '' !== $schedule ) {
				if ( $is_unavailable_now ) {
					/* translators: %s: schedule details */
					return sprintf( __( 'Will be Available: %s', 'food-menu-pro' ), $schedule );
				}

				/* translators: %s: schedule details */
				return sprintf( __( 'Will be Unavailable: %s', 'food-menu-pro' ), $schedule );
			}
		}

		// Currently active or already past — bare badge, no date/time.
		if ( $is_unavailable_now ) {
			return __( 'Unavailable', 'food-menu-pro' );
		}

		return __( 'Available', 'food-menu-pro' );
	}

	/**
	 * Determine whether a matched rule is currently active, will activate later, or has already passed.
	 *
	 * - 'active': rule conditions are currently met.
	 * - 'future': rule has a date/time trigger that hasn't fired yet, OR contains
	 *   a recurring constraint (time_range / day_of_week) that will reactivate it.
	 * - 'past':   all date constraints have expired and there is nothing recurring left.
	 *
	 * @param array $matched_rule Rule data.
	 *
	 * @return string One of 'active', 'future', 'past'.
	 */
	private function get_rule_temporal_state( $matched_rule ) {
		if ( $this->is_rule_active( $matched_rule['timed_rules'] ?? [] ) ) {
			return 'active';
		}

		$today = current_time( 'Y-m-d' );

		// If any date constraint has expired, the whole rule is past
		// (an AND'd expired constraint can never match again).
		foreach ( $matched_rule['timed_rules'] ?? [] as $tr ) {
			$type = $tr['type'] ?? '';

			if ( 'date_range' === $type && '' !== ( $tr['end'] ?? '' ) && $tr['end'] < $today ) {
				return 'past';
			}

			if ( 'on_date' === $type && '' !== ( $tr['date'] ?? '' ) && $tr['date'] < $today ) {
				return 'past';
			}

			if ( 'before_date' === $type && '' !== ( $tr['date'] ?? '' ) && $tr['date'] < $today ) {
				return 'past';
			}
		}

		// Otherwise, look for any constraint that can still fire.
		foreach ( $matched_rule['timed_rules'] ?? [] as $tr ) {
			$type = $tr['type'] ?? '';

			if ( 'date_range' === $type && ( $tr['start'] ?? '' ) > $today ) {
				return 'future';
			}

			if ( 'on_date' === $type && ( $tr['date'] ?? '' ) > $today ) {
				return 'future';
			}

			if ( 'after_date' === $type && ( $tr['date'] ?? '' ) > $today ) {
				return 'future';
			}

			if ( 'time_range' === $type || 'day_of_week' === $type ) {
				return 'future';
			}
		}

		return 'past';
	}

	/**
	 * Check if a rule's product/category selection matches a product.
	 *
	 * @param array $rule       Rule data.
	 * @param int   $product_id Product ID.
	 *
	 * @return bool
	 */
	private function rule_matches_product( $rule, $product_id ) {
		$product_rule_type = $rule['product_rule_type'] ?? 'specific_products';

		if ( 'specific_products' === $product_rule_type ) {
			$rule_products = array_map( 'intval', (array) ( $rule['products'] ?? [] ) );
			return in_array( (int) $product_id, $rule_products, true );
		}

		if ( 'product_categories' === $product_rule_type ) {
			$cat_ids       = array_map( 'intval', (array) ( $rule['categories'] ?? [] ) );
			$product_terms = wp_get_post_terms( $product_id, 'product_cat', [ 'fields' => 'ids' ] );
			return ! empty( array_intersect( $cat_ids, $product_terms ) );
		}

		return false;
	}

	/**
	 * Format a single timed rule as human-readable text.
	 *
	 * @param array $tr Timed rule array.
	 *
	 * @return string Formatted text.
	 */
	private function format_timed_rule( $tr ) {
		$type = $tr['type'] ?? '';

		switch ( $type ) {
			case 'time_range':
				$start = date_i18n( get_option( 'time_format', 'g:i a' ), strtotime( '2000-01-01 ' . ( $tr['start'] ?? '' ) ) );
				$end   = date_i18n( get_option( 'time_format', 'g:i a' ), strtotime( '2000-01-01 ' . ( $tr['end'] ?? '' ) ) );

				/* translators: 1: start time, 2: end time */
				return sprintf( __( '%1$s – %2$s', 'food-menu-pro' ), $start, $end );

			case 'day_of_week':
				$days_raw = (array) ( $tr['days'] ?? [] );

				if ( count( $days_raw ) >= 7 ) {
					return __( 'Every day', 'food-menu-pro' );
				}

				$day_labels = [
					'monday'    => __( 'Mon', 'food-menu-pro' ),
					'tuesday'   => __( 'Tue', 'food-menu-pro' ),
					'wednesday' => __( 'Wed', 'food-menu-pro' ),
					'thursday'  => __( 'Thu', 'food-menu-pro' ),
					'friday'    => __( 'Fri', 'food-menu-pro' ),
					'saturday'  => __( 'Sat', 'food-menu-pro' ),
					'sunday'    => __( 'Sun', 'food-menu-pro' ),
				];
				$days = array_map(
					function ( $d ) use ( $day_labels ) {
						return $day_labels[ $d ] ?? $d;
					},
					$days_raw
				);

				return implode( ', ', $days );

			case 'on_date':
				return date_i18n( get_option( 'date_format', 'F j, Y' ), strtotime( $tr['date'] ?? '' ) );

			case 'date_range':
				$start = date_i18n( get_option( 'date_format', 'F j, Y' ), strtotime( $tr['start'] ?? '' ) );
				$end   = date_i18n( get_option( 'date_format', 'F j, Y' ), strtotime( $tr['end'] ?? '' ) );

				/* translators: 1: start date, 2: end date */
				return sprintf( __( '%1$s – %2$s', 'food-menu-pro' ), $start, $end );

			case 'before_date':
				/* translators: %s: date */
				return sprintf( __( 'Before %s', 'food-menu-pro' ), date_i18n( get_option( 'date_format', 'F j, Y' ), strtotime( $tr['date'] ?? '' ) ) );

			case 'after_date':
				/* translators: %s: date */
				return sprintf( __( 'After %s', 'food-menu-pro' ), date_i18n( get_option( 'date_format', 'F j, Y' ), strtotime( $tr['date'] ?? '' ) ) );

			default:
				return '';
		}
	}

	/**
	 * Get the selected location ID from cookie.
	 *
	 * @return int
	 */
	private function get_location_id() {
		return ! empty( $_COOKIE['fmp_location_id'] ) ? absint( $_COOKIE['fmp_location_id'] ) : 0;
	}
}
