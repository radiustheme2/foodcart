<?php
/**
 * OrderBumps settings fields class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\OrderBumps;

defined( 'ABSPATH' ) || exit();

/**
 * OrderBumps settings fields class.
 */
class OrderBumpsFns {

	/**
	 * Order bumps setting fields.
	 *
	 * @return array
	 */
	public static function settings_field() {

		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/order_bumps_settings/fields',
			[
				'enable_order_bumps'  => [
					'label'       => esc_html__( 'Enable Order Bumps?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Show cross-sell product suggestions in the mini-cart. This feature requires the Mini Cart to be enabled.', 'food-menu-pro' ),
					'value'       => $settings['enable_order_bumps'] ?? 'on',
				],

				'order_bumps_heading' => [
					'id'          => 'order_bumps_heading',
					'type'        => 'text',
					'label'       => esc_html__( 'Order Bumps Heading', 'food-menu-pro' ),
					'description' => esc_html__( 'Heading text displayed above the order bumps slider.', 'food-menu-pro' ),
					'value'       => $settings['order_bumps_heading'] ?? esc_html__( 'You might also like', 'food-menu-pro' ),
				],

				'order_bumps_slider_settings_title' => [
					'label' => esc_html__( 'Slider Settings', 'food-menu-pro' ),
					'type'  => 'title',
				],

				'order_bumps_slides_per_view' => [
					'type'        => 'number',
					'label'       => esc_html__( 'Slides Per View', 'food-menu-pro' ),
					'description' => esc_html__( 'Number of bump cards visible at once in the slider.', 'food-menu-pro' ),
					'value'       => $settings['order_bumps_slides_per_view'] ?? 1,
					'attr'        => 'min="1" max="4" step="1"',
				],

				'order_bumps_slides_per_group' => [
				'type'        => 'number',
				'label'       => esc_html__( 'Slides Per Group', 'food-menu-pro' ),
				'description' => esc_html__( 'Number of slides to move at once when navigating.', 'food-menu-pro' ),
				'value'       => $settings['order_bumps_slides_per_group'] ?? 1,
				'attr'        => 'min="1" max="4" step="1"',
			],

			'order_bumps_space_between' => [
					'type'        => 'number',
					'label'       => esc_html__( 'Space Between Slides (px)', 'food-menu-pro' ),
					'description' => esc_html__( 'Gap in pixels between each slide in the slider.', 'food-menu-pro' ),
					'value'       => $settings['order_bumps_space_between'] ?? 10,
					'attr'        => 'min="0" max="50" step="1"',
				],

				'order_bumps_speed' => [
					'type'        => 'number',
					'label'       => esc_html__( 'Slide Speed (ms)', 'food-menu-pro' ),
					'description' => esc_html__( 'Duration of the slide transition animation in milliseconds.', 'food-menu-pro' ),
					'value'       => $settings['order_bumps_speed'] ?? 600,
					'attr'        => 'min="100" max="5000" step="100"',
				],

				'order_bumps_autoplay' => [
					'type'        => 'switch',
					'label'       => esc_html__( 'Autoplay', 'food-menu-pro' ),
					'description' => esc_html__( 'Automatically advance slides in the order bumps slider.', 'food-menu-pro' ),
					'value'       => $settings['order_bumps_autoplay'] ?? '',
				],

				'order_bumps_autoplay_delay' => [
					'type'        => 'number',
					'label'       => esc_html__( 'Autoplay Delay (ms)', 'food-menu-pro' ),
					'description' => esc_html__( 'Time in milliseconds between slide transitions.', 'food-menu-pro' ),
					'value'       => $settings['order_bumps_autoplay_delay'] ?? 3000,
					'attr'        => 'min="500" max="10000" step="100"',
				],

				'order_bumps_pause_on_hover' => [
					'type'        => 'switch',
					'label'       => esc_html__( 'Pause on Hover', 'food-menu-pro' ),
					'description' => esc_html__( 'Pause autoplay when the mouse hovers over the slider.', 'food-menu-pro' ),
					'value'       => $settings['order_bumps_pause_on_hover'] ?? 'on',
				],
			]
		);
	}
}
