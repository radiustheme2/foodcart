<?php
/**
 * Order Bumps main class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\OrderBumps;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Order Bumps main class.
 */
class OrderBumps {

	use SingletonTrait;

	/**
	 * Settings option.
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Init function — hooks if conditions are met.
	 *
	 * @return void
	 */
	public function init() {
		$this->options = FnsPro::get_settings_option();

		$fm_type          = $this->options['fm_food_menu_type'] ?? 'food_menu_post';
		$enable_mini_cart = $this->options['enable_mini_cart'] ?? 'on';
		$enable_bumps     = $this->options['enable_order_bumps'] ?? 'on';

		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type ) {
			return;
		}

		if ( 'on' !== $enable_mini_cart || 'on' !== $enable_bumps ) {
			return;
		}

		add_action( 'fmp_before_mini_cart_coupon', [ $this, 'render_order_bumps' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
	}

	/**
	 * Enqueue order bumps assets.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		$nonce = wp_create_nonce( Fns::nonceText() );

		\wp_enqueue_script( 'fmp-order-bumps' );
		\wp_localize_script(
			'fmp-order-bumps',
			'fmpOrderBumpsParams',
			[
				'ajaxurl'       => esc_url( admin_url( 'admin-ajax.php' ) ),
				'nonceID'       => esc_attr( Fns::nonceId() ),
				'nonce'         => esc_attr( $nonce ),
				'addingText'    => esc_html__( 'Adding...', 'food-menu-pro' ),
				'slidesPerView' => absint( $this->options['order_bumps_slides_per_view'] ?? 1 ) ?: 1,
				'slidesPerGroup' => absint( $this->options['order_bumps_slides_per_group'] ?? 1 ) ?: 1,
				'spaceBetween'   => absint( $this->options['order_bumps_space_between'] ?? 10 ) ?: 10,
				'speed'          => absint( $this->options['order_bumps_speed'] ?? 600 ) ?: 600,
				'autoplay'       => ( $this->options['order_bumps_autoplay'] ?? 'on' ) === 'on' ? 'on' : '',
				'autoplayDelay'  => absint( $this->options['order_bumps_autoplay_delay'] ?? 3000 ) ?: 3000,
				'pauseOnHover'   => ( $this->options['order_bumps_pause_on_hover'] ?? 'on' ) === 'on' ? 'on' : '',
			]
		);
	}

	/**
	 * Render order bumps slider in mini-cart.
	 *
	 * @return void
	 */
	public function render_order_bumps() {
		if ( ! WC()->cart || WC()->cart->is_empty() ) {
			return;
		}
		$cart_items      = array_reverse( WC()->cart->get_cart() );
		$cart_product_ids = wp_list_pluck( $cart_items, 'product_id' );
		$cross_sell_ids   = [];

		foreach ( $cart_items as $cart_item ) {
			$product = $cart_item['data'] ?? null;

			if ( ! $product instanceof \WC_Product ) {
				continue;
			}

			foreach ( $product->get_cross_sell_ids() as $id ) {
				if ( ! in_array( $id, $cross_sell_ids, true ) && ! in_array( $id, $cart_product_ids, true ) ) {
					$cross_sell_ids[] = $id;
				}
			}
		}

		if ( empty( $cross_sell_ids ) ) {
			return;
		}

		$cross_sell_products = wc_get_products(
			[
				'include'    => $cross_sell_ids,
				'limit'      => count( $cross_sell_ids ),
				'stock_status' => 'instock',
			]
		);

		$products = [];

		foreach ( $cross_sell_products as $product ) {
			if ( $product->is_type( 'simple' ) && ! $product->is_purchasable() ) {
				continue;
			}

			if ( ! $product->is_type( 'simple' ) && ! $product->is_visible() ) {
				continue;
			}

			$products[] = $product;
		}

		if ( empty( $products ) ) {
			return;
		}

		$heading = $this->options['order_bumps_heading'] ?? esc_html__( 'You might also like', 'food-menu-pro' );

		Fns::render(
			'order-bumps/order-bumps',
			[
				'products' => $products,
				'heading'  => $heading,
			]
		);
	}
}
