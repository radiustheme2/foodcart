<?php
/**
 * Custom Checkout controller.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Checkout;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Custom Checkout controller.
 */
class CustomCheckout {

	use SingletonTrait;

	/**
	 * Settings options.
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Init hooks.
	 *
	 * @return void
	 */
	public function init() {
		$this->options = FnsPro::get_settings_option();

		$fm_type = $this->options['fm_food_menu_type'] ?? 'food_menu_post';
		$enabled = $this->options['fmp_enable_custom_checkout'] ?? '';

		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type || 'on' !== $enabled ) {
			return;
		}

		// Replace checkout template.
		add_filter( 'template_include', [ $this, 'custom_checkout_template' ], 99 );

		// Enqueue frontend assets.
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_checkout_assets' ] );

		// Custom Place Order button text.
		add_filter( 'woocommerce_order_button_text', [ $this, 'custom_place_order_text' ] );

		// Remove default WC checkout hooks we replace.
		add_action( 'wp', [ $this, 'remove_default_checkout_hooks' ] );

		// Customize checkout form fields (4 hooks like ShopBuilder).
		add_filter( 'woocommerce_billing_fields', [ $this, 'customize_billing_fields' ], 99, 2 );
		add_filter( 'woocommerce_shipping_fields', [ $this, 'customize_shipping_fields' ], 9999, 2 );
		add_filter( 'woocommerce_default_address_fields', [ $this, 'override_default_address_fields' ], 9999 );
		add_filter( 'woocommerce_get_country_locale', [ $this, 'override_country_locale' ] );

		// Add custom totals to WC's update_order_review fragments.
		add_filter( 'woocommerce_update_order_review_fragments', [ $this, 'add_totals_fragment' ] );
	}

	/**
	 * Remove default WC hooks on checkout page.
	 *
	 * @return void
	 */
	public function remove_default_checkout_hooks() {
		if ( ! $this->is_custom_checkout_page() ) {
			return;
		}

		remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
		remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 10 );

		// Remove P&D, Tip, and Location default hooks — custom checkout renders them at its own positions.
		$pickup_delivery = \RT\FoodMenuPro\Controllers\PickupDelivery\PickupDelivery::get_instance();
		remove_action( 'woocommerce_checkout_before_customer_details', [ $pickup_delivery, 'render_order_time' ] );

		$tip = FnsPro::free_instance( \RT\FoodMenu\Controllers\Tip\Tip::class );
		if ( $tip ) {
			remove_action( 'woocommerce_after_order_notes', [ $tip, 'tip_form' ] );
		}

		// Only suppress free's hidden-field render when this custom checkout
		// actually renders its own location card. Otherwise free's render is
		// the only place the `fmp_location_name` input exists and removing it
		// would silently break order-meta save on checkout.
		if ( CheckoutFns::show_your_location() ) {
			$food_location = FnsPro::free_instance( \RT\FoodMenu\Controllers\Frontend\FoodLocation::class );
			if ( $food_location ) {
				remove_action( 'woocommerce_checkout_before_customer_details', [ $food_location, 'render_location_form' ] );
			}
		}

		// Always remove — our custom template handles rendering, and render method now self-checks the toggle.
		remove_action( 'woocommerce_after_order_notes', [ $pickup_delivery, 'render_custom_checkout_fields' ] );
	}

	/**
	 * Check if current page should use custom checkout.
	 *
	 * @return bool
	 */
	private function is_custom_checkout_page() {
		return is_checkout() && ! is_order_received_page() && ! is_checkout_pay_page();
	}

	/**
	 * Replace checkout template.
	 *
	 * @param string $template Template path.
	 *
	 * @return string
	 */
	public function custom_checkout_template( $template ) {
		if ( ! $this->is_custom_checkout_page() ) {
			return $template;
		}

		$custom_template = FMP()->plugin_template_path() . 'checkout/checkout.php';

		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}

		return $template;
	}

	/**
	 * Enqueue checkout assets.
	 *
	 * @return void
	 */
	public function enqueue_checkout_assets() {
		if ( ! $this->is_custom_checkout_page() ) {
			return;
		}

		\wp_enqueue_style( 'fmp-custom-checkout' );
		\wp_enqueue_script( 'fmp-custom-checkout' );

		$nonce = wp_create_nonce( Fns::nonceText() );

		\wp_localize_script(
			'fmp-custom-checkout',
			'fmpCheckoutParams',
			[
				'ajaxUrl' => esc_url( admin_url( 'admin-ajax.php' ) ),
				'nonceID' => esc_attr( Fns::nonceId() ),
				'nonce'   => esc_attr( $nonce ),
			]
		);

	}

	/**
	 * Custom Place Order button text.
	 *
	 * @param string $text Button text.
	 *
	 * @return string
	 */
	public function custom_place_order_text( $text ) {
		if ( ! $this->is_custom_checkout_page() ) {
			return $text;
		}

		$custom_text = CheckoutFns::get_place_order_text();

		return ! empty( $custom_text ) ? $custom_text : $text;
	}

	/**
	 * Add custom totals HTML to WC's order review fragments.
	 *
	 * This lets WC's native AJAX update our totals when shipping changes.
	 *
	 * @param array $fragments Fragments to update.
	 *
	 * @return array
	 */
	public function add_totals_fragment( $fragments ) {
		ob_start();
		Fns::render( 'checkout/order-review-totals' );
		$fragments['.woocommerce-checkout-review-order-table'] = '<div class="fmp-order-totals-wrap woocommerce-checkout-review-order-table">' . ob_get_clean() . '</div>';

		// Update shipping method section with new zone methods.
		if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) {
			ob_start();
			Fns::render( 'checkout/shipping-method' );
			$fragments['.fmp-shipping-method-card'] = ob_get_clean();
		}

		return $fragments;
	}

	/**
	 * Build field overrides from config for a given group.
	 *
	 * Only returns enabled fields with label/required applied.
	 * Uses wp_parse_args() to merge onto WC defaults (ShopBuilder pattern).
	 *
	 * @param array  $address_fields WC's original fields.
	 * @param string $group          billing or shipping.
	 *
	 * @return array
	 */
	private function render_fields( $address_fields, $group ) {
		$config = CheckoutFns::get_fields_config();

		if ( empty( $config ) ) {
			return $address_fields;
		}

		$modified = [];
		$priority = 10;

		// Track which config keys are present in WC fields.
		$seen_bases = [];

		foreach ( $address_fields as $key => $field_data ) {
			// Strip prefix: billing_first_name → first_name.
			$base                = preg_replace( '/^(billing|shipping)_/', '', $key );
			$seen_bases[ $base ] = true;

			if ( isset( $config[ $base ] ) ) {
				$cfg = $config[ $base ];

				// Skip disabled fields.
				if ( isset( $cfg['enabled'] ) && 'on' !== $cfg['enabled'] ) {
					continue;
				}

				$overrides = [];

				// Custom label.
				if ( ! empty( $cfg['label'] ) ) {
					$overrides['label'] = sanitize_text_field( $cfg['label'] );
				}

				// Custom placeholder.
				if ( ! empty( $cfg['placeholder'] ) ) {
					$overrides['placeholder'] = sanitize_text_field( $cfg['placeholder'] );
				}

				// Required toggle.
				if ( isset( $cfg['required'] ) ) {
					$overrides['required'] = 'on' === $cfg['required'];
				}

				// Ensure enabled fields are not hidden by country locale.
				if ( ! empty( $field_data['hidden'] ) ) {
					$overrides['hidden'] = false;
				}

				$overrides['priority']  = $priority;
				$modified[ $key ]       = wp_parse_args( $overrides, $field_data );
			} else {
				$field_data['priority'] = $priority;
				$modified[ $key ]       = $field_data;
			}

			$priority += 10;
		}

		// Inject config-enabled fields that WC didn't include (e.g., company).
		foreach ( $config as $base => $cfg ) {
			if ( isset( $seen_bases[ $base ] ) ) {
				continue;
			}

			if ( isset( $cfg['enabled'] ) && 'on' !== $cfg['enabled'] ) {
				continue;
			}

			$field_key             = $group . '_' . $base;
			$modified[ $field_key ] = [
				'label'    => ! empty( $cfg['label'] ) ? sanitize_text_field( $cfg['label'] ) : ucfirst( str_replace( '_', ' ', $base ) ),
				'required' => isset( $cfg['required'] ) && 'on' === $cfg['required'],
				'class'    => [ 'form-row-wide' ],
				'priority' => $priority,
			];

			if ( ! empty( $cfg['placeholder'] ) ) {
				$modified[ $field_key ]['placeholder'] = sanitize_text_field( $cfg['placeholder'] );
			}

			$priority += 10;
		}

		return $modified;
	}

	/**
	 * Customize billing fields.
	 *
	 * @param array  $fields  Billing fields.
	 * @param string $country Country code.
	 *
	 * @return array
	 */
	public function customize_billing_fields( $fields, $country ) {
		return $this->render_fields( $fields, 'billing' );
	}

	/**
	 * Customize shipping fields.
	 *
	 * @param array  $fields  Shipping fields.
	 * @param string $country Country code.
	 *
	 * @return array
	 */
	public function customize_shipping_fields( $fields, $country ) {
		return $this->render_fields( $fields, 'shipping' );
	}

	/**
	 * Override WC default address fields to prevent country locale
	 * from undoing our label/required changes.
	 *
	 * Applies to: address_1, address_2, city, state, postcode.
	 *
	 * @param array $fields Default address fields.
	 *
	 * @return array
	 */
	public function override_default_address_fields( $fields ) {
		$config         = CheckoutFns::get_fields_config();
		$address_fields = [ 'company', 'address_1', 'address_2', 'city', 'state', 'postcode' ];

		foreach ( $address_fields as $base ) {
			if ( empty( $fields[ $base ] ) || ! isset( $config[ $base ] ) ) {
				continue;
			}

			$cfg = $config[ $base ];

			if ( ! empty( $cfg['label'] ) ) {
				$fields[ $base ]['label'] = sanitize_text_field( $cfg['label'] );
			}

			if ( ! empty( $cfg['placeholder'] ) ) {
				$fields[ $base ]['placeholder'] = sanitize_text_field( $cfg['placeholder'] );
			}

			if ( isset( $cfg['required'] ) ) {
				$fields[ $base ]['required'] = 'on' === $cfg['required'];
			}

			// Ensure enabled fields are not hidden.
			if ( isset( $cfg['enabled'] ) && 'on' === $cfg['enabled'] ) {
				$fields[ $base ]['hidden'] = false;
			}
		}

		return $fields;
	}

	/**
	 * Override country-specific locale settings to prevent WC JS
	 * from reverting our label/required on country change.
	 *
	 * Applies to: city, state, postcode per country.
	 *
	 * @param array $locales Country locale data.
	 *
	 * @return array
	 */
	public function override_country_locale( $locales ) {
		$config        = CheckoutFns::get_fields_config();
		$locale_fields = [ 'city', 'state', 'postcode' ];

		foreach ( $locales as $country_code => $fields ) {
			foreach ( $locale_fields as $base ) {
				if ( ! isset( $config[ $base ] ) || empty( $fields[ $base ] ) ) {
					continue;
				}

				$cfg = $config[ $base ];

				if ( ! empty( $cfg['label'] ) && isset( $fields[ $base ]['label'] ) ) {
					$locales[ $country_code ][ $base ]['label'] = sanitize_text_field( $cfg['label'] );
				}

				if ( ! empty( $cfg['placeholder'] ) && isset( $fields[ $base ]['placeholder'] ) ) {
					$locales[ $country_code ][ $base ]['placeholder'] = sanitize_text_field( $cfg['placeholder'] );
				}

				if ( isset( $cfg['required'] ) && isset( $fields[ $base ]['required'] ) ) {
					$locales[ $country_code ][ $base ]['required'] = 'on' === $cfg['required'];
				}

				// Prevent country locale from hiding fields enabled in config.
				if ( isset( $cfg['enabled'] ) && 'on' === $cfg['enabled'] && ! empty( $fields[ $base ]['hidden'] ) ) {
					$locales[ $country_code ][ $base ]['hidden'] = false;
				}
			}
		}

		return $locales;
	}

	/**
	 * Static check if custom checkout is active.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$options = FnsPro::get_settings_option();
		$fm_type = $options['fm_food_menu_type'] ?? 'food_menu_post';
		$enabled = $options['fmp_enable_custom_checkout'] ?? '';

		return TLPFoodMenu()->isWcActive() && 'online_ordering' === $fm_type && 'on' === $enabled;
	}
}
