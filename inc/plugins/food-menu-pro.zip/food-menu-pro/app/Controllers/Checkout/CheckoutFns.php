<?php
/**
 * Checkout helper functions.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\Checkout;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\QrTableOrdering\QrTableOrdering;

/**
 * Checkout helper functions.
 */
class CheckoutFns {

	/**
	 * Get all checkout settings with defaults.
	 *
	 * @return array
	 */
	public static function get_checkout_settings() {
		$options = FnsPro::get_settings_option();

		return [
			'enabled'               => $options['fmp_enable_custom_checkout'] ?? '',
			'layout'                => $options['fmp_checkout_layout'] ?? 'two-column',
			'show_coupon'           => $options['fmp_checkout_show_coupon'] ?? '',
			'show_order_type'       => $options['fmp_checkout_show_order_type'] ?? '',
			'show_your_location'    => $options['fmp_checkout_show_your_location'] ?? '',
			'show_location_popup'   => $options['fmp_food_location_popup'] ?? '',
			'show_tips'             => $options['fmp_checkout_show_tips'] ?? '',
			'show_order_bumps'      => $options['fmp_checkout_show_order_bumps'] ?? '',
			'show_order_notes'      => $options['fmp_checkout_show_order_notes'] ?? 'on',
			'show_shipping_address' => $options['fmp_checkout_show_shipping_address'] ?? 'on',
			'show_additional_info'  => $options['fmp_checkout_show_additional_info'] ?? 'on',
			'heading_text'          => $options['fmp_checkout_heading_text'] ?? '',
			'terms_text'            => $options['fmp_checkout_terms_text'] ?? '',
			'place_order_text'      => $options['fmp_checkout_place_order_text'] ?? '',
		];
	}

	/**
	 * Get layout CSS class.
	 *
	 * @return string
	 */
	public static function get_layout_class() {
		$settings = self::get_checkout_settings();

		return 'single-column' === $settings['layout'] ? 'single-column' : '';
	}

	/**
	 * Whether coupon section should show.
	 *
	 * @return bool
	 */
	public static function show_coupon() {
		$settings = self::get_checkout_settings();

		return ! empty( $settings['show_coupon'] ) && function_exists( 'wc_coupons_enabled' ) && wc_coupons_enabled();
	}

	public static function show_your_location() {
		// Minimal QR-checkout mode hides the location card — table = location.
		if ( QrTableOrdering::is_minimal_checkout_active() ) {
			return false;
		}

		$settings = self::get_checkout_settings();

		return ! empty( $settings['show_your_location'] ) && ! empty( $settings['show_location_popup'] );
	}

	/**
	 * Whether order type (P&D) section should show.
	 *
	 * @return bool
	 */
	/**
	 * Whether the custom checkout template is in effect on the current
	 * request — i.e. the feature is enabled AND we're rendering a checkout
	 * page (not the order-received or pay endpoints). Used by sections that
	 * also hook into core WC checkout actions, so they can avoid double-
	 * rendering their own UI on top of the custom checkout cards.
	 *
	 * @return bool
	 */
	public static function is_custom_checkout_active() {
		$options = FnsPro::get_settings_option();

		if ( empty( $options['fmp_enable_custom_checkout'] ) ) {
			return false;
		}

		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return false;
		}

		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			return false;
		}

		if ( function_exists( 'is_checkout_pay_page' ) && is_checkout_pay_page() ) {
			return false;
		}

		return true;
	}

	public static function show_order_type() {
		$settings = self::get_checkout_settings();

		if ( empty( $settings['show_order_type'] ) ) {
			return false;
		}


		// Dine-in QR scan orders never need Pickup/Delivery.
		if ( QrTableOrdering::has_active_session() ) {
			return false;
		}

		// Also check if P&D is actually enabled.
		$options = FnsPro::get_settings_option();

		$pickup_on   = ( $options['enable_pickup'] ?? 'on' ) === 'on';
		$delivery_on = ( $options['enable_delivery'] ?? 'on' ) === 'on';
		return $pickup_on || $delivery_on;
	}

	/**
	 * Whether tip section should show.
	 *
	 * @return bool
	 */
	public static function show_tips() {
		$settings = self::get_checkout_settings();

		if ( empty( $settings['show_tips'] ) ) {
			return false;
		}

		// Also check if tips are actually enabled. `enable_tip` defaults to on
		// (the settings UI shows it on by default and the Tip controller reads
		// it as `?? 'on'`), so an absent value means enabled — matching that
		// default here is what keeps the custom checkout in sync with the
		// classic checkout. Only an explicit '' (toggled off) disables it.
		$options = FnsPro::get_settings_option();

		return 'on' === ( $options['enable_tip'] ?? 'on' );
	}

	/**
	 * Whether order bumps should show.
	 *
	 * @return bool
	 */
	public static function show_order_bumps() {
		$settings = self::get_checkout_settings();

		if ( empty( $settings['show_order_bumps'] ) ) {
			return false;
		}

		// Also check if order bumps and mini cart are enabled.
		// Both default to 'on' when never saved (fresh install), matching the
		// settings UI defaults — otherwise unset keys would read as disabled.
		$options            = FnsPro::get_settings_option();
		$enable_order_bumps = $options['enable_order_bumps'] ?? 'on';
		$enable_mini_cart   = $options['enable_mini_cart'] ?? 'on';

		return 'on' === $enable_order_bumps && 'on' === $enable_mini_cart;
	}

	/**
	 * Whether order notes should show.
	 *
	 * @return bool
	 */
	public static function show_order_notes() {
		$settings = self::get_checkout_settings();

		return ! empty( $settings['show_order_notes'] );
	}

	/**
	 * Check if shipping address section is enabled.
	 *
	 * @return bool
	 */
	public static function show_shipping_address() {
		// Minimal QR-checkout mode hides shipping — in-house dine-in orders.
		if ( QrTableOrdering::is_minimal_checkout_active() ) {
			return false;
		}

		$settings = self::get_checkout_settings();

		return ! empty( $settings['show_shipping_address'] ) && WC()->cart->needs_shipping_address();
	}

	/**
	 * Get dynamic step number based on enabled sections.
	 *
	 * @param string $section Section name: details, order_type, tips, payment.
	 *
	 * @return int
	 */
	public static function get_step_number( $section ) {
		$step = 0;

		$sections = [ 'order_type', 'your_location', 'details', 'order_notes', 'additional_info', 'tips', 'shipping', 'order_summary', 'payment' ];

		$enabled = [
			'order_type'      => self::show_order_type(),
			'details'         => true,
			'your_location'   => self::show_your_location(),
			'order_notes'     => self::show_order_notes(),
			'additional_info' => self::show_additional_info(),
			'tips'            => self::show_tips(),
			'shipping'        => WC()->cart->needs_shipping() && WC()->cart->show_shipping(),
			'order_summary'   => 'single-column' === ( self::get_checkout_settings()['layout'] ?? 'two-column' ),
			'payment'         => true,
		];

		foreach ( $sections as $s ) {
			if ( ! empty( $enabled[ $s ] ) ) {
				++ $step;
			}

			if ( $s === $section ) {
				return $step;
			}
		}

		return $step;
	}

	/**
	 * Check if custom checkout fields exist.
	 *
	 * @return bool
	 */
	public static function has_custom_checkout_fields() {
		$fields = FnsPro::get_setting( 'fmp_order_custom_fields', [] );

		return ! empty( $fields );
	}

	/**
	 * Check if additional info section is enabled.
	 *
	 * @return bool
	 */
	public static function show_additional_info() {
		// Minimal QR-checkout mode hides custom additional info fields.
		if ( QrTableOrdering::is_minimal_checkout_active() ) {
			return false;
		}

		$settings = self::get_checkout_settings();

		return ! empty( $settings['show_additional_info'] ) && self::has_custom_checkout_fields();
	}

	/**
	 * Cached fields config.
	 *
	 * @var array|null
	 */
	private static $fields_config_cache = null;

	/**
	 * Get checkout billing fields configuration.
	 *
	 * Cached so the 4 WC filter hooks share one lookup per request.
	 *
	 * @return array Field key => { enabled, label, required } settings.
	 */
	public static function get_fields_config() {
		if ( null !== self::$fields_config_cache ) {
			return self::$fields_config_cache;
		}

		$options                   = FnsPro::get_settings_option();
		$config                    = $options['fmp_checkout_fields'] ?? [];
		self::$fields_config_cache = is_array( $config ) ? $config : [];

		return self::$fields_config_cache;
	}

	/**
	 * Get checkout heading text.
	 *
	 * @return string
	 */
	public static function get_heading_text() {
		$settings = self::get_checkout_settings();

		return ! empty( $settings['heading_text'] ) ? $settings['heading_text'] : esc_html__( 'Checkout', 'food-menu-pro' );
	}

	/**
	 * Get place order button text.
	 *
	 * @return string
	 */
	public static function get_place_order_text() {
		$settings = self::get_checkout_settings();

		return ! empty( $settings['place_order_text'] ) ? $settings['place_order_text'] : esc_html__( 'Place Order', 'food-menu-pro' );
	}

	/**
	 * Get terms text.
	 *
	 * @return string
	 */
	public static function get_terms_text() {
		$settings = self::get_checkout_settings();

		return $settings['terms_text'] ?? '';
	}

}
