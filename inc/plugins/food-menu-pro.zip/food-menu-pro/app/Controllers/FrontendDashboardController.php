<?php
/**
 * Inventory Controller.
 *
 * @package RT_FoodMenu
 */

namespace RT\FoodMenuPro\Controllers;

use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Hooks\InventoryHooks;
use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Database\InventoryLogsTable;
use RT\FoodMenuPro\Services\InventoryServices;
use RT\FoodMenuPro\Api\Inventory\InventoryListApi;
use RT\FoodMenuPro\Api\Inventory\InventoryDashboardApi;
use RT\FoodMenuPro\Api\Orders\OrdersApi;
use RT\FoodMenuPro\Api\Inventory\PurchaseOrderApi;
use RT\FoodMenuPro\Api\Inventory\StockAlertApi;
use RT\FoodMenuPro\Api\Inventory\ReportsApi;
use RT\FoodMenuPro\Api\Inventory\SupplierApi;
use RT\FoodMenuPro\Database\PurchaseOrdersTable;
use RT\FoodMenuPro\Controllers\PosPrinting\PosPrintingFns;
use RT\FoodMenuPro\Controllers\KitchenMonitor\KitchenMonitorFns;
use RT\FoodMenuPro\Controllers\PickupDelivery\PickupDeliveryFns;
use RT\FoodMenuPro\Hooks\LowStockNotification;

/**
 * InventoryController Class.
 */
class FrontendDashboardController {

	use SingletonTrait;

	private $inventoryService = null;

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_filter( 'template_include', [ $this, 'wc_missing_template' ] );
			return;
		}

		$GLOBALS['fmp_inventory_internal_update'] = false;
		$this->inventoryService                   = new InventoryServices();
		InventoryHooks::get_instance();
		LowStockNotification::get_instance();
		InventoryListApi::get_instance();
		InventoryDashboardApi::get_instance();
		OrdersApi::get_instance();
		PurchaseOrderApi::get_instance();
		StockAlertApi::get_instance();
		ReportsApi::get_instance();
		SupplierApi::get_instance();
		InventoryLogsTable::get_instance();
		PurchaseOrdersTable::get_instance();

//		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_script' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_script' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue_script' ] );
		add_action( 'admin_init', [ $this, 'seeding' ], 10 );
		add_action( 'woocommerce_update_product', [ $this, 'update_product' ] );
		add_filter( 'template_include', [ $this, 'template_include' ] );
		add_filter( 'body_class', [ $this, 'add_dashboard_body_class' ] );
		add_action( 'wp_head', [ $this, 'inject_dashboard_body_class' ], 1 );
		add_action( 'wp_ajax_fmp_dashboard_logout', [ $this, 'handle_dashboard_logout' ] );
	}

	/**
	 * Handle AJAX logout from the frontend dashboard.
	 *
	 * @return void
	 */
	public function handle_dashboard_logout() {
		check_ajax_referer( 'fmp_dashboard_logout', 'nonce' );
		wp_logout();
		wp_send_json_success();
	}

	public function seeding() {
		$this->inventoryService->inventory_seeding();
	}

	public function update_product( $product_id ) {
		$this->inventoryService->add_opening_log( $product_id );
	}


	/**
	 * Enqueue Scripts
	 *
	 * @return void
	 */
	public function enqueue_script() {
		//wp_enqueue_style('rtfm-el-style', TLPFoodMenu()->assets_url() . 'css/elementor-frontend.min.css', [], '1.0.0' );
	}

	/**
	 * Admin Enqueue Scripts
	 *
	 * @param $hook
	 *
	 * @return void
	 */
	public function admin_enqueue_script( $hook ) {
		$screen = get_current_screen();

		// Make sure it’s the correct page
		if (
			$screen->post_type === 'food-menu' &&
			isset( $_GET['page'] ) &&
			$_GET['page'] === 'inventory'
		) {
			$this->dashboard_enqueue();
		}

	}

	/**
	 * Front-end Enqueue Scripts
	 *
	 * @param $hook
	 *
	 * @return void
	 */
	public function frontend_enqueue_script() {

		global $post;

		if ( ! is_singular() || ! $post ) {
			return;
		}

		$frontend_page_id = FnsPro::get_frontend_order_page();

		if ( (int) $post->ID === (int) $frontend_page_id ) {
			$this->dashboard_enqueue();
		}
	}


	private function dashboard_enqueue() {
		wp_enqueue_script( 'fmp-frontend-dashboard', FMP()->assets_url() . 'js/frontend-dashboard.min.js', [ 'jquery', 'wp-element', 'wp-components', 'wp-api-fetch', 'wp-i18n' ], FOOD_MENU_PRO_VERSION, true );
		wp_set_script_translations( 'fmp-frontend-dashboard', 'food-menu-pro', FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages' );
		wp_enqueue_style( 'fmp-frontend-dashboard', FMP()->assets_url() . 'css/frontend-dashboard-css.min.css', '', FOOD_MENU_PRO_VERSION );

		$settings = get_option( TLPFoodMenu()->options['settings'], [] );

		// Dynamic dashboard colors.
		$primary_color = ! empty( $settings['fm_primary_color'] ) ? sanitize_hex_color( $settings['fm_primary_color'] ) : '';

		if ( $primary_color ) {
			$dark_color = FnsPro::darken_color( $primary_color, 25 );
			$soft_color = FnsPro::lighten_color( $primary_color, 92 );
			$css        = ':root{--rtfm-primary-color:' . $primary_color . ';--rtfm-primary-dark:' . $dark_color . ';--rtfm-primary-soft:' . $soft_color . ';--ring:' . $primary_color . ';}';
			wp_add_inline_style( 'fmp-frontend-dashboard', $css );
		}

		// Kitchen monitor CSS for the embedded kitchen monitor page.
		wp_enqueue_style( 'fm-kitchen-monitor', FMP()->assets_url() . 'css/kitchen-monitor-css.min.css', [], FOOD_MENU_PRO_VERSION );

		$saved_reasons   = isset( $settings['fmp_waste_reasons'] ) && is_array( $settings['fmp_waste_reasons'] )
			? $settings['fmp_waste_reasons']
			: [ 'Expired', 'Damaged', 'Spoiled', 'Broken', 'Returned' ];
		$wastage_reasons = [ '' => 'Select' ];
		foreach ( $saved_reasons as $reason ) {
			$key                     = sanitize_title( $reason );
			$wastage_reasons[ $key ] = $reason;
		}
		$time_format       = get_option( 'time_format' ); // e.g. g:i A OR H:i
		$dayjs_time_format = FnsPro::php_to_dayjs_time_format( (string) $time_format );

		$inventory_settings = get_option( 'fmp_inventory_settings', [] );

		$order_statuses = [];
		foreach ( wc_get_order_statuses() as $key => $label ) {
			if ( in_array( $key, [ 'wc-failed', 'wc-checkout-draft' ], true ) ) {
				continue;
			}
			$order_statuses[] = [
				'value' => str_replace( 'wc-', '', $key ),
				'label' => $label,
			];
		}

		$payment_methods = [];
		$gateways        = WC()->payment_gateways()->payment_gateways();
		foreach ( $gateways as $gateway ) {
			if ( 'yes' === $gateway->enabled ) {
				$payment_methods[] = [
					'value' => $gateway->id,
					'label' => $gateway->get_title(),
				];
			}
		}

		// Custom order fields from settings.
		$custom_fields = isset( $settings['fmp_order_custom_fields'] ) && is_array( $settings['fmp_order_custom_fields'] )
			? array_map(
				function ( $field ) {
					$field['required'] = filter_var( $field['required'] ?? false, FILTER_VALIDATE_BOOLEAN );
					$field['multiple'] = filter_var( $field['multiple'] ?? false, FILTER_VALIDATE_BOOLEAN );
					return $field;
				},
				$settings['fmp_order_custom_fields']
			)
			: [];

		// Excluded product types.
		$exclude_product_types = FnsPro::get_excluded_product_types();

		// Feature flags from main settings.
		$location_enabled     = 'on' === ( $settings['fmp_food_location_popup'] ?? '' );
		$qr_table_enabled     = 'on' === ( $settings['fmp_enable_qr_table_ordering'] ?? '' );
		$pos_printing_enabled = 'on' === ( $settings['fmp_enable_pos_printing'] ?? '' );

		// Dashboard logo.
		$dashboard_logo     = $settings['fmp_frontend_dashboard_logo'] ?? [];
		$dashboard_logo_url = '';
		if ( ! empty( $dashboard_logo['id'] ) ) {
			$logo_src = wp_get_attachment_image_url( (int) $dashboard_logo['id'], 'full' );
			if ( $logo_src ) {
				$dashboard_logo_url = $logo_src;
			}
		}

		$current_user = wp_get_current_user();

		// Build status → color map (WC defaults + custom statuses).
		$status_colors   = [
			'pending'    => '#EA871E',
			'processing' => '#2563eb',
			'on-hold'    => '#ea580c',
			'completed'  => '#16a34a',
			'cancelled'  => '#dc2626',
			'refunded'   => '#6b7280',
			'failed'     => '#dc2626',
		];
		$custom_statuses = get_option( 'fmp_custom_order_statuses', [] );

		if ( is_array( $custom_statuses ) ) {
			foreach ( $custom_statuses as $cs ) {
				if ( ! empty( $cs['enabled'] ) && ! empty( $cs['slug'] ) ) {
					$slug                    = str_replace( 'wc-', '', $cs['slug'] );
					$status_colors[ $slug ] = $cs['color'] ?? '#6b7280';
				}
			}
		}

		$localize_data = [
			'ajaxurl'               => admin_url( 'admin-ajax.php' ),
			'nonce'                 => wp_create_nonce( 'wp_rest' ),
			'wastage_reasons'       => $wastage_reasons,
			'pluginUrl'             => FOOD_MENU_PRO_PLUGIN_URL,
			'isAdmin'               => current_user_can( 'manage_options' ),
			// "Edit product" links are only offered to staff who can actually use
			// them — a shop manager on the dashboard is not necessarily an admin, and
			// a dashboard user with no product rights would just land on a wp-admin
			// permission error.
			'canEditProducts'       => current_user_can( 'edit_products' ),
			'productEditUrl'        => admin_url( 'post.php' ),
			'currentUser'           => [
				'name'        => $current_user->display_name,
				'email'       => $current_user->user_email,
				'avatar'      => get_avatar_url( $current_user->ID, [ 'size' => 80 ] ),
				'logoutNonce' => wp_create_nonce( 'fmp_dashboard_logout' ),
			],
			'is24Hour'              => strpos( $time_format, 'H' ) !== false,
			// Settings → General → Time Format, as a Day.js format, so pickers can
			// display times the way the site does while still exchanging `HH:mm`.
			'timeFormat'            => $dayjs_time_format,
			'timeUse12Hours'        => FnsPro::dayjs_format_is_12h( $dayjs_time_format ),
			'ordersEnabled'         => ! empty( $inventory_settings['orders_enabled'] ),
			'orderStatuses'         => $order_statuses,
			'statusColors'          => $status_colors,
			'paymentMethods'        => $payment_methods,
			'ordersPerPage'         => ! empty( $settings['fmp_order_per_page'] ) ? (int) $settings['fmp_order_per_page'] : 10,
			'lowStockThreshold'     => isset( $inventory_settings['low_stock_threshold'] ) ? (int) $inventory_settings['low_stock_threshold'] : 10,
			'orderCustomFields'     => $custom_fields,
			'excludeProductTypes'   => $exclude_product_types,
			'locationEnabled'       => $location_enabled,
			'qrTableEnabled'        => $qr_table_enabled,
			'posPrintingEnabled'    => $pos_printing_enabled,
			'kitchenMonitorEnabled' => 'on' === ( $settings['fmp_enable_kitchen_monitor'] ?? '' ),
			'inventoryEnabled'      => 'on' === ( $settings['fmp_enable_frontend_inventory'] ?? '' ),
			'dashboardLogoUrl'      => $dashboard_logo_url,
			'dashboardLogoHeight'   => max( 20, min( 100, (int) ( $settings['fmp_frontend_dashboard_logo_height'] ?? 40 ) ) ),
			'allowedMenus'          => FnsPro::get_allowed_dashboard_menus(),
			'pollInterval'          => max( 30, (int) ( $settings['fmp_dashboard_poll_interval'] ?? 60 ) ) * 1000,
			'currency'              => function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$',
			// Full WooCommerce price format, so every money figure in the dashboard
			// renders in the store's own currency instead of a hardcoded symbol —
			// including stores whose currency has no decimals (XOF/CFA, JPY…).
			'priceFormat'           => FnsPro::get_price_format(),
			'siteName'              => get_bloginfo( 'name' ),
			'restRoot'              => esc_url_raw( rest_url() ),
			'timelineCompletedStatus' => str_replace( 'wc-', '', $settings['fmp_tracking_completed_status'] ?? 'wc-completed' ),
		];

		// Order types available when creating/editing an order from the dashboard.
		// Mirrors the checkout: only enabled types are offered.
		$order_types = [];

		if ( 'on' === ( $settings['enable_delivery'] ?? 'on' ) ) {
			$order_types[] = [ 'value' => 'delivery', 'label' => FnsPro::get_order_type_label( 'delivery' ) ];
		}
		if ( 'on' === ( $settings['enable_pickup'] ?? 'on' ) ) {
			$order_types[] = [ 'value' => 'pickup', 'label' => FnsPro::get_order_type_label( 'pickup' ) ];
		}
		if ( 'on' === ( $settings['enable_dinein'] ?? '' ) ) {
			$order_types[] = [ 'value' => 'dinein', 'label' => FnsPro::get_order_type_label( 'dinein' ) ];
		}

		// Weekly schedule per order type, so the dashboard's time picker offers
		// the same generated slots the checkout does instead of a free-form
		// clock that lets staff pick hours the kitchen isn't open.
		$order_schedules = [];

		foreach ( $order_types as $order_type_option ) {
			$type     = $order_type_option['value'];
			$schedule = FnsPro::get_setting( "new_fmp_{$type}_weekly_schedule", [] );

			$order_schedules[ $type ] = [
				'interval' => max( 1, intval( $settings[ "{$type}_time_interval" ] ?? 15 ) ),
				'start'    => FnsPro::get_schedule_time( $schedule ),
				'end'      => FnsPro::get_schedule_time( $schedule, 'end' ),
				'slots'    => FnsPro::get_schedule_slots( $schedule ),
				'holiday'  => FnsPro::get_offday_schedule( $schedule ),
			];
		}

		$localize_data['dateFormat']     = FnsPro::php_to_dayjs_date_format( (string) get_option( 'date_format', 'Y-m-d' ) );
		$localize_data['orderSchedules'] = $order_schedules;
		$localize_data['orderTypes']     = $order_types;
		$localize_data['dineinTables']  = PickupDeliveryFns::get_dinein_table_options();
		$localize_data['dineinEnabled'] = 'on' === ( $settings['enable_dinein'] ?? '' );

		if ( $pos_printing_enabled ) {
			$localize_data['posNonce']       = wp_create_nonce( 'fmp_pos_printing_nonce' );
			$localize_data['posSlipTypes']   = PosPrintingFns::slip_types();
			$localize_data['posDefaultSlip'] = $settings['fmp_default_slip_type'] ?? 'order_confirmation';
		}

		// Kitchen monitor data (nested to avoid duplication).
		$kitchen_enabled = 'on' === ( $settings['fmp_enable_kitchen_monitor'] ?? '' );

		if ( $kitchen_enabled ) {
			$complete_status_slug = $settings['fmp_kitchen_monitor_complete_status'] ?? '';
			$display_statuses     = $this->get_kitchen_monitor_statuses( $settings );

			// Hide the complete status from default tabs — the React app re-adds it
			// when the "Show Completed" toggle is on.
			$complete_status_obj = null;
			if ( $complete_status_slug ) {
				foreach ( $display_statuses as $idx => $st ) {
					if ( ( $st['slug'] ?? '' ) === $complete_status_slug ) {
						$complete_status_obj = $st;
						unset( $display_statuses[ $idx ] );
					}
				}
				$display_statuses = array_values( $display_statuses );

				// If not in the configured display list, still resolve it for the toggle UI.
				if ( ! $complete_status_obj ) {
					$resolved = $this->get_kitchen_monitor_statuses( array_merge( $settings, [ 'fmp_kitchen_monitor_statuses' => [ $complete_status_slug ] ] ) );
					$complete_status_obj = $resolved[0] ?? null;
				}
			}

			$localize_data['kitchenMonitor'] = [
				'nonce'           => wp_create_nonce( 'fmp_kitchen_monitor_nonce' ),
				'defaultSound'    => $settings['fmp_kitchen_monitor_sound'] ?? 'on',
				'sound'           => KitchenMonitorFns::get_sound_config(),
				'allowedStatuses' => $display_statuses,
				'completeStatus'  => $complete_status_obj,
				'isPaused'        => KitchenMonitorFns::paused_state(),
				'allowPause'      => KitchenMonitorFns::pause_enabled(),
				'pauseSchedule'   => get_option( 'fmp_kitchen_pause_schedule', null ),
				'tableField'      => $this->get_kitchen_monitor_table_field( $settings ),
			];
		} else {
			$localize_data['kitchenMonitor'] = [
				'allowedStatuses' => [],
				'completeStatus'  => null,
				'defaultSound'    => 'off',
				'sound'           => KitchenMonitorFns::get_sound_config(),
				'isPaused'        => 'no',
				'allowPause'      => false,
				'tableField'      => null,
			];
		}

		$localize_data['extraNavItems'] = $this->get_extra_nav_items();

		wp_localize_script( 'fmp-frontend-dashboard', 'fmpInventory', $localize_data );
	}

	/**
	 * Third-party links appended to the bottom of the dashboard sidebar.
	 *
	 * The sidebar is built in React from a static list, so add-ons have no way
	 * to extend it. This gives them one: whatever the filter returns is
	 * rendered as plain anchors after the last built-in nav item.
	 *
	 * Each item accepts:
	 *   key     string Unique slug. Falls back to the array index.
	 *   label   string Visible text. Required.
	 *   url     string Link target. Required.
	 *   target  string '_self' (default) or '_blank'.
	 *   iconSvg string Optional inner SVG markup, drawn on a 24x24 grid with
	 *                  `stroke="currentColor"` and no fill so it matches the
	 *                  built-in lucide icons. Falls back to an external-link
	 *                  glyph when omitted.
	 *
	 * Example:
	 *   add_filter( 'fmp_frontend_dashboard_nav_extra_items', function ( $items ) {
	 *       $items[] = [
	 *           'key'   => 'hotel-dashboard',
	 *           'label' => 'Hotel Dashboard',
	 *           'url'   => home_url( '/hotel-dashboard/' ),
	 *       ];
	 *       return $items;
	 *   } );
	 *
	 * Items are rendered for anyone who can reach the dashboard — this is a
	 * navigation aid, not an access control. The linked page must still run its
	 * own capability checks.
	 *
	 * @return array<int, array<string, string>>
	 */
	private function get_extra_nav_items() {
		/**
		 * Extra sidebar links for the front-end dashboard.
		 *
		 * @param array $items Nav items. See get_extra_nav_items() for the shape.
		 */
		$items = apply_filters( 'fmp_frontend_dashboard_nav_extra_items', [] );

		if ( ! is_array( $items ) ) {
			return [];
		}

		$clean = [];

		foreach ( $items as $index => $item ) {
			if ( ! is_array( $item ) || empty( $item['label'] ) || empty( $item['url'] ) ) {
				continue;
			}

			$clean[] = [
				'key'     => ! empty( $item['key'] ) ? sanitize_key( $item['key'] ) : 'extra-' . $index,
				'label'   => wp_strip_all_tags( (string) $item['label'] ),
				'url'     => esc_url_raw( (string) $item['url'] ),
				'target'  => ( isset( $item['target'] ) && '_blank' === $item['target'] ) ? '_blank' : '_self',
				'iconSvg' => isset( $item['iconSvg'] ) ? (string) $item['iconSvg'] : '',
			];
		}

		return $clean;
	}

	/**
	 * Resolve the configured "table" custom field for the kitchen monitor.
	 *
	 * @param array $settings Plugin settings.
	 *
	 * @return array|null
	 */
	private function get_kitchen_monitor_table_field( $settings ) {
		$idx_raw = $settings['fmp_kitchen_monitor_table_field'] ?? '';

		if ( '' === $idx_raw ) {
			return null;
		}

		$fields = $settings['fmp_order_custom_fields'] ?? [];

		if ( ! is_array( $fields ) ) {
			return null;
		}

		$idx = (int) $idx_raw;

		if ( ! isset( $fields[ $idx ] ) ) {
			return null;
		}

		return [
			'index' => $idx,
			'label' => $fields[ $idx ]['label'] ?? '',
		];
	}

	private function get_kitchen_monitor_statuses( $settings ) {
		$selected_slugs  = $settings['fmp_kitchen_monitor_statuses'] ?? [];
		$custom_statuses = get_option( 'fmp_custom_order_statuses', [] );
		$wc_statuses     = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : [];

		// Empty selection means show all statuses.
		if ( ! is_array( $selected_slugs ) || empty( $selected_slugs ) ) {
			$all_slugs = array_keys( $wc_statuses );

			if ( is_array( $custom_statuses ) ) {
				foreach ( $custom_statuses as $status ) {
					if ( ! empty( $status['enabled'] ) && ! in_array( $status['slug'], $all_slugs, true ) ) {
						$all_slugs[] = $status['slug'];
					}
				}
			}

			$selected_slugs = $all_slugs;
		}

		$allowed = [];

		foreach ( $selected_slugs as $slug ) {
			$meta = FnsPro::get_status_metadata( $slug );
			if ( ! $meta ) {
				continue;
			}
			$allowed[] = [
				'slug'  => $slug,
				'label' => $meta['label'],
				'color' => $meta['color'],
				'icon'  => $meta['icon'],
			];
		}

		return $allowed;
	}

	/**
	 * @param $template
	 *
	 * @return mixed|string
	 */
	/**
	 * Show a notice when WooCommerce is not active on the dashboard page.
	 *
	 * @param string $template Template path.
	 *
	 * @return string
	 */
	public function wc_missing_template( $template ) {
		if ( ! empty( FnsPro::get_frontend_order_page() ) && is_page( FnsPro::get_frontend_order_page() ) ) {
			// Render the WooCommerce required notice inline.
			add_action( 'wp_head', function () {
				echo '<style>
					.fmp-wc-notice-wrap { display:flex; align-items:center; justify-content:center; min-height:100vh; padding:40px 20px; background:#f8f8fa; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; }
					.fmp-wc-notice { text-align:center; max-width:520px; background:#fff; border-radius:16px; padding:48px 40px; box-shadow:0 4px 24px -4px rgba(0,0,0,0.08); }
					.fmp-wc-notice-icon { width:72px; height:72px; border-radius:16px; background:linear-gradient(135deg,#fef3c7,#fde68a); display:flex; align-items:center; justify-content:center; margin:0 auto 24px; }
					.fmp-wc-notice h2 { margin:0 0 8px; font-size:22px; font-weight:700; color:#111827; letter-spacing:-0.02em; }
					.fmp-wc-notice p { margin:0 0 28px; color:#6b7280; font-size:15px; line-height:1.6; }
				</style>';
			} );

			add_filter( 'the_content', function () {
				ob_start();
				?>
				<div class="fmp-wc-notice-wrap">
					<div class="fmp-wc-notice">
						<div class="fmp-wc-notice-icon">
							<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
								<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
								<line x1="12" y1="9" x2="12" y2="13"/>
								<line x1="12" y1="17" x2="12.01" y2="17"/>
							</svg>
						</div>

						<h2><?php esc_html_e( 'WooCommerce Required', 'food-menu-pro' ); ?></h2>
						<p><?php esc_html_e( 'The Food Menu Dashboard requires WooCommerce to manage orders, inventory, and online ordering features. Please install and activate WooCommerce to continue.', 'food-menu-pro' ); ?></p>
					</div>
				</div>
				<?php
				return ob_get_clean();
			} );
		}

		return $template;
	}

	/**
	 * Add a body class on the frontend dashboard page.
	 *
	 * @param array $classes Existing body classes.
	 *
	 * @return array
	 */
	public function add_dashboard_body_class( $classes ) {
		if ( $this->is_dashboard_page() ) {
			$classes[] = 'rtrb-front-end-dashboard';
		}

		return $classes;
	}

	/**
	 * Inject the dashboard body class via JS as a fallback,
	 * because the dashboard template may skip calling body_class()
	 * when header/footer visibility is disabled.
	 *
	 * @return void
	 */
	public function inject_dashboard_body_class() {
		if ( ! $this->is_dashboard_page() ) {
			return;
		}

		echo "<script>(function(){function add(){if(document.body){document.body.classList.add('rtrb-front-end-dashboard');}else{document.addEventListener('DOMContentLoaded',function(){document.body.classList.add('rtrb-front-end-dashboard');});}}add();})();</script>";
	}

	/**
	 * Whether the current request is the frontend dashboard page.
	 *
	 * @return bool
	 */
	private function is_dashboard_page() {
		$frontend_page_id = FnsPro::get_frontend_order_page();

		return ! empty( $frontend_page_id ) && is_page( $frontend_page_id );
	}

	public function template_include( $template ) {
		if ( ! empty( FnsPro::get_frontend_order_page() ) && is_page( FnsPro::get_frontend_order_page() ) ) {
			$file_path   = 'frontend-dashboard/frontend-dashboard.php';
			$plugin_file = FMP()->plugin_template_path() . $file_path;

			if ( file_exists( $plugin_file ) ) {
				// Redirect anonymous visitors to login BEFORE the template loads.
				// The template also performs this check, but doing it here protects
				// against rare cases where the template's redirect fires too late
				// (e.g. premature output from a theme or another plugin).
				if ( ! is_user_logged_in() ) {
					wp_safe_redirect( wp_login_url( get_permalink() ) );
					exit;
				}

				add_filter( 'tlp_mini_cart_enabled', '__return_false' );
				add_filter( 'tlp_floating_location_btn', '__return_false' );

				show_admin_bar( false );
				add_filter( 'show_admin_bar', '__return_false' );

				return $plugin_file;
			}
		}

		return $template;
	}

}
