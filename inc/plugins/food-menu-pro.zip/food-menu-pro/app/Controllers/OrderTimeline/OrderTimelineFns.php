<?php
/**
 * Order Timeline helper functions.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\OrderTimeline;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Helper functions for Order Timeline settings.
 */
class OrderTimelineFns {

	/**
	 * Check if order timeline feature is enabled.
	 *
	 * Defaults to **on**: this class only ever runs with Pro active, and an order
	 * history that was never recorded cannot be reconstructed later — so a site
	 * that has not made a choice gets the timeline rather than a silent gap. An
	 * explicit "off" is stored as an empty string by the settings toggle, so
	 * turning it off still sticks; only a missing key falls back to on. The
	 * timeline table is created on demand (`OrderTimelineTable::maybe_create_table()`
	 * on `admin_init`/`rest_api_init`), so existing installs need no migration.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return FnsPro::get_setting( 'fmp_enable_order_timeline', 'on' ) === 'on';
	}

	/**
	 * Format a timeline entry's timestamp for display, in the site's timezone.
	 *
	 * Every timeline surface must show the same wall-clock time — the one the kitchen
	 * was working to — so this is the single formatter for all of them: the staff
	 * dashboard, the customer tracking page and the wp-admin metabox.
	 *
	 * Two traps this exists to avoid:
	 *
	 *  - **Browser timezone.** The JS surfaces used `new Date(...).toLocaleDateString()`,
	 *    which renders in whatever timezone the viewer's machine is set to. A kitchen
	 *    in Abidjan checking orders from a laptop still on European time saw every
	 *    status change shifted by an hour. Formatting server-side removes the
	 *    question entirely.
	 *  - **Double conversion.** `created_at` is written with `current_time( 'mysql' )`,
	 *    i.e. already in site-local time. WordPress runs PHP on UTC, so
	 *    `strtotime( $created_at )` reads that wall clock as UTC, and passing the
	 *    result to `date_i18n()`/`wp_date()` then shifts it into the site timezone a
	 *    *second* time — off by the site's whole UTC offset. Parsing with an explicit
	 *    `wp_timezone()` is what makes the round trip correct.
	 *
	 * @param string $created_at MySQL datetime in site-local time.
	 *
	 * @return string Formatted date and time, or an empty string if unparseable.
	 */
	public static function format_datetime( $created_at ) {
		if ( empty( $created_at ) ) {
			return '';
		}

		$timezone = wp_timezone();
		$date     = date_create_immutable( $created_at, $timezone );

		if ( ! $date ) {
			return '';
		}

		$timestamp = $date->getTimestamp();

		return sprintf(
			/* translators: 1: date, e.g. Aug 13, 2026. 2: time, e.g. 9:33 pm. */
			__( '%1$s at %2$s', 'food-menu-pro' ),
			wp_date( get_option( 'date_format' ), $timestamp, $timezone ),
			wp_date( get_option( 'time_format' ), $timestamp, $timezone )
		);
	}

	/**
	 * Get tracking link expiry days.
	 *
	 * @return int
	 */
	public static function get_expiry_days() {
		$days = FnsPro::get_setting( 'fmp_tracking_link_expiry_days', 30 );
		return absint( $days );
	}

	/**
	 * Get tracking page title.
	 *
	 * @return string
	 */
	public static function get_page_title() {
		return FnsPro::get_setting( 'fmp_tracking_page_title', __( 'Track Your Order', 'food-menu-pro' ) );
	}

	/**
	 * Check if a tracking token has expired.
	 *
	 * @param \WC_Order $order Order object.
	 *
	 * @return bool
	 */
	public static function is_token_expired( $order ) {
		$expiry_days = self::get_expiry_days();

		// 0 means never expire.
		if ( 0 === $expiry_days ) {
			return false;
		}

		$order_date = $order->get_date_created();

		if ( ! $order_date ) {
			return false;
		}

		$expiry_time = $order_date->getTimestamp() + ( $expiry_days * DAY_IN_SECONDS );

		return time() > $expiry_time;
	}
}
