<?php
/**
 * Order Timeline Controller.
 *
 * Records every order status change into a timeline history table
 * and manages the public tracking page via rewrite rules.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\OrderTimeline;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Models\OrderTimelineModel;
use RT\FoodMenuPro\Database\OrderTimelineTable;
use RT\FoodMenuPro\Api\OrderTimeline\OrderTimelineApi;
use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Order Timeline Controller.
 */
class OrderTimeline {

	use SingletonTrait;

	/**
	 * Pending note to attach to the next timeline entry.
	 * Set by the API before calling $order->update_status().
	 *
	 * @var string|null
	 */
	public static $pending_note = null;

	/**
	 * Orders whose timeline was just initialized in the current request,
	 * mapped to the status they were initialized with. Used to suppress the
	 * duplicate status_changed (pending -> X) that WooCommerce fires when an
	 * order is created via wc_create_order() with a non-pending status.
	 *
	 * @var array<int,string>
	 */
	private static $just_initialized = [];

	/**
	 * Init.
	 *
	 * @return void
	 */
	protected function init() {
		// Ensure the DB table exists.
		OrderTimelineTable::get_instance();

		// Register REST API endpoints.
		OrderTimelineApi::get_instance();

		// Record timeline on status change (priority 5, before notifications at 10/20).
		add_action( 'woocommerce_order_status_changed', [ $this, 'record_status_change' ], 5, 4 );

		// Record initial "Order Placed" entry on new orders.
		add_action( 'woocommerce_new_order', [ $this, 'record_new_order' ], 10, 2 );
		add_action( 'woocommerce_checkout_order_created', [ $this, 'record_checkout_order' ], 10, 1 );

		// Rewrite rules for public tracking page.
		add_action( 'init', [ $this, 'register_rewrite_rules' ] );
		add_filter( 'query_vars', [ $this, 'register_query_vars' ] );
		add_filter( 'template_include', [ $this, 'load_tracking_template' ] );

		// The tracking page is token-gated and meant to be reachable by anyone
		// (e.g. a customer following a WhatsApp link). Exclude it from
		// WooCommerce's "Coming Soon" / Launch Your Store mode so it isn't
		// replaced with the coming-soon screen for logged-out visitors.
		add_filter( 'woocommerce_coming_soon_exclude', [ $this, 'exclude_tracking_from_coming_soon' ] );

		// The tracking page is a standalone, distraction-free screen. Strip the
		// plugin's other frontend elements (floating location button,
		// mini-cart, popups, badges) so only the order timeline shows.
		add_action( 'template_redirect', [ $this, 'declutter_tracking_page' ] );

		// Show timeline on WooCommerce My Account → View Order page.
		add_action( 'woocommerce_view_order', [ $this, 'render_view_order_timeline' ], 5 );

		// Enqueue timeline styles on frontend when needed.
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_timeline_styles' ] );

		// Add a "Tracking" column to the WC admin orders list (HPOS + legacy CPT).
		// This controller is only loaded when fmp_enable_order_timeline === 'on',
		// so the column automatically hides when the feature is disabled.
		add_filter( 'manage_woocommerce_page_wc-orders_columns', [ $this, 'add_tracking_column' ] );
		add_filter( 'manage_edit-shop_order_columns', [ $this, 'add_tracking_column' ] );
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', [ $this, 'render_tracking_column' ], 10, 2 );
		add_action( 'manage_shop_order_posts_custom_column', [ $this, 'render_tracking_column_legacy' ], 10, 2 );

		// Timeline metabox on the WC admin order edit page (HPOS + legacy CPT).
		add_action( 'add_meta_boxes', [ $this, 'register_order_metabox' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_metabox_assets' ] );
	}

	/**
	 * Inject the Tracking column into the orders list. Placed right after the
	 * Status column so it sits next to the most relevant info.
	 *
	 * @param array $columns Existing columns.
	 *
	 * @return array
	 */
	public function add_tracking_column( $columns ) {
		$new = [];
		$inserted = false;
		foreach ( $columns as $key => $title ) {
			$new[ $key ] = $title;
			if ( ! $inserted && in_array( $key, [ 'order_status', 'shop_order_status' ], true ) ) {
				$new['fmp_tracking_link'] = esc_html__( 'Tracking', 'food-menu-pro' );
				$inserted = true;
			}
		}
		// Fallback: append at the end if the status column isn't present (custom layouts).
		if ( ! $inserted ) {
			$new['fmp_tracking_link'] = esc_html__( 'Tracking', 'food-menu-pro' );
		}
		return $new;
	}

	/**
	 * Render the Tracking column cell (HPOS — receives the order object).
	 *
	 * @param string    $column Column key.
	 * @param \WC_Order $order  Order.
	 *
	 * @return void
	 */
	public function render_tracking_column( $column, $order ) {
		if ( 'fmp_tracking_link' !== $column ) {
			return;
		}
		if ( ! $order instanceof \WC_Order ) {
			$order = wc_get_order( $order );
		}
		if ( ! $order ) {
			return;
		}

		$token = $order->get_meta( '_fmp_tracking_token' );
		if ( empty( $token ) ) {
			echo '<span style="color:#9ca3af;" title="' . esc_attr__( 'No tracking token yet (order predates timeline activation)', 'food-menu-pro' ) . '">—</span>';
			return;
		}

		$url     = esc_url( home_url( '/fmp-track/' . $token ) );
		$label   = esc_html__( 'Track', 'food-menu-pro' );
		$tooltip = esc_attr__( 'Open public tracking page in a new tab', 'food-menu-pro' );

		echo '<a href="' . $url . '" target="_blank" rel="noopener noreferrer" class="button button-small fmp-tracking-link-btn" title="' . $tooltip . '" style="display:inline-flex;align-items:center;gap:4px;line-height:1.6;padding:2px 8px;">';
		echo '<span class="dashicons dashicons-external" style="width:14px;height:14px;font-size:14px;line-height:1.4;"></span>';
		echo '<span>' . $label . '</span>';
		echo '</a>';
	}

	/**
	 * Legacy CPT render bridge — second arg is post_id, not order.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 *
	 * @return void
	 */
	public function render_tracking_column_legacy( $column, $post_id ) {
		if ( 'fmp_tracking_link' !== $column ) {
			return;
		}
		$order = wc_get_order( $post_id );
		if ( ! $order ) {
			return;
		}
		$this->render_tracking_column( $column, $order );
	}

	/**
	 * Register the Order Timeline metabox on both the HPOS order edit screen
	 * and the legacy shop_order CPT edit screen.
	 *
	 * @return void
	 */
	public function register_order_metabox() {
		$screens   = [ 'shop_order' ];
		$hpos_id   = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : '';
		if ( $hpos_id ) {
			$screens[] = $hpos_id;
		}

		foreach ( array_unique( array_filter( $screens ) ) as $screen ) {
			add_meta_box(
				'fmp_order_timeline_metabox',
				esc_html__( 'Order Timeline', 'food-menu-pro' ),
				[ $this, 'render_order_metabox' ],
				$screen,
				'normal',
				'default'
			);
		}
	}

	/**
	 * Render the metabox mount node. The React component fetches its own data
	 * via the existing /fmp/v1/orders/{id}/timeline endpoint.
	 *
	 * @param \WP_Post|\WC_Order $post_or_order Post (legacy) or order (HPOS).
	 *
	 * @return void
	 */
	public function render_order_metabox( $post_or_order ) {
		$order = wc_get_order( $post_or_order );
		if ( ! $order ) {
			return;
		}
		echo '<div id="fmp-admin-order-timeline" data-order-id="' . esc_attr( $order->get_id() ) . '"></div>';
	}

	/**
	 * Enqueue the timeline React bundle on the order edit screen only.
	 * Localizes the same `fmpInventory` global the component already reads.
	 *
	 * @return void
	 */
	public function enqueue_admin_metabox_assets() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen ) {
			return;
		}

		$hpos_id = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : '';
		$valid   = array_filter( [ $hpos_id, 'shop_order' ] );

		if ( ! in_array( $screen->id, $valid, true ) ) {
			return;
		}

		// HPOS shares one screen ID for list + edit; gate on the edit action.
		if ( $hpos_id && $screen->id === $hpos_id ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';
			if ( 'edit' !== $action && 'new' !== $action ) {
				return;
			}
		}

		wp_enqueue_script(
			'fmp-admin-order-timeline',
			FMP()->assets_url() . 'js/admin-order-timeline.min.js',
			[ 'wp-element', 'wp-api-fetch', 'wp-i18n' ],
			FOOD_MENU_PRO_VERSION,
			true
		);
		wp_set_script_translations( 'fmp-admin-order-timeline', 'food-menu-pro', FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages' );

		$settings = get_option( 'tpl_food_menu_settings', [] );

		wp_localize_script( 'fmp-admin-order-timeline', 'fmpInventory', [
			'nonce'                   => wp_create_nonce( 'wp_rest' ),
			'restRoot'                => esc_url_raw( rest_url() ),
			'timelineCompletedStatus' => str_replace( 'wc-', '', $settings['fmp_tracking_completed_status'] ?? 'wc-completed' ),
			// This bundle shares components with the dashboard, so it has to carry
			// the price format too — anything reaching for it without this would
			// silently format money as dollars.
			'priceFormat'             => FnsPro::get_price_format(),
		] );
	}

	/**
	 * Record a status change in the timeline.
	 *
	 * @param int       $order_id   Order ID.
	 * @param string    $old_status Old status (without wc- prefix).
	 * @param string    $new_status New status (without wc- prefix).
	 * @param \WC_Order $order      Order object.
	 *
	 * @return void
	 */
	public function record_status_change( $order_id, $old_status, $new_status, $order ) {
		// Skip initial creation transitions.
		$initial_statuses = [ '', 'new', 'auto-draft', 'checkout-draft' ];
		if ( in_array( (string) $old_status, $initial_statuses, true ) ) {
			return;
		}

		// Suppress the duplicate transition that fires immediately after wc_create_order()
		// when an order is created with a non-pending status. record_new_order already
		// recorded the initial entry with the correct status.
		if ( isset( self::$just_initialized[ $order_id ] ) && self::$just_initialized[ $order_id ] === $new_status ) {
			unset( self::$just_initialized[ $order_id ] );
			return;
		}

		$this->insert_timeline_entry( $order, $new_status );
	}

	/**
	 * Record initial "Order Placed" entry for a new order by ID.
	 *
	 * @param int            $order_id Order ID.
	 * @param \WC_Order|null $order    Order object (may be null in some WC versions).
	 *
	 * @return void
	 */
	public function record_new_order( $order_id, $order = null ) {
		if ( ! $order instanceof \WC_Order ) {
			$order = wc_get_order( $order_id );
		}

		if ( ! $order ) {
			return;
		}

		// Avoid duplicate entries if checkout_order_created already fired.
		if ( $order->get_meta( '_fmp_timeline_initialized' ) ) {
			return;
		}

		$this->initialize_order_timeline( $order );
	}

	/**
	 * Record initial entry for a checkout-created order.
	 *
	 * @param \WC_Order $order Order object.
	 *
	 * @return void
	 */
	public function record_checkout_order( $order ) {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		if ( $order->get_meta( '_fmp_timeline_initialized' ) ) {
			return;
		}

		$this->initialize_order_timeline( $order );
	}

	/**
	 * Initialize the timeline for a new order: generate token and insert first entry.
	 *
	 * @param \WC_Order $order Order object.
	 *
	 * @return void
	 */
	private function initialize_order_timeline( $order ) {
		$status = $order->get_status();

		// Flag this order BEFORE the meta save — that nested save() runs
		// status_transition() which fires woocommerce_order_status_changed
		// (pending -> $status) when an order is created via wc_create_order()
		// with a non-pending status. Without the flag set first, the duplicate
		// fires before record_status_change can suppress it.
		self::$just_initialized[ $order->get_id() ] = $status;

		// Generate tracking token.
		$token = self::generate_unique_token();
		$order->update_meta_data( '_fmp_tracking_token', $token );
		$order->update_meta_data( '_fmp_timeline_initialized', '1' );
		$order->save();

		OrderTimelineModel::insert_entry( [
			'order_id'     => $order->get_id(),
			'status'       => $status,
			'status_label' => self::resolve_status_label( $status ),
			'note'         => __( 'Order placed', 'food-menu-pro' ),
			'updated_by'   => get_current_user_id() ?: null,
		] );
	}

	/**
	 * Insert a timeline entry for the given order and status.
	 *
	 * @param \WC_Order $order  Order object.
	 * @param string    $status Status slug (without wc- prefix).
	 *
	 * @return void
	 */
	private function insert_timeline_entry( $order, $status ) {
		// Get or generate tracking token.
		$token = $order->get_meta( '_fmp_tracking_token' );

		if ( empty( $token ) ) {
			$token = self::generate_unique_token();
			$order->update_meta_data( '_fmp_tracking_token', $token );
			$order->save();
		}

		// Capture and clear pending note.
		$note              = self::$pending_note;
		self::$pending_note = null;

		OrderTimelineModel::insert_entry( [
			'order_id'     => $order->get_id(),
			'status'       => $status,
			'status_label' => self::resolve_status_label( $status ),
			'note'         => $note,
			'updated_by'   => get_current_user_id() ?: null,
		] );
	}

	/**
	 * Resolve a status slug to its human-readable label.
	 *
	 * @param string $status Status slug (without wc- prefix).
	 *
	 * @return string
	 */
	public static function resolve_status_label( $status ) {
		$all_statuses = wc_get_order_statuses();
		$wc_key       = 'wc-' . $status;

		if ( isset( $all_statuses[ $wc_key ] ) ) {
			return $all_statuses[ $wc_key ];
		}

		// Fallback: capitalize the slug.
		return ucfirst( str_replace( [ '-', '_' ], ' ', $status ) );
	}

	/**
	 * Get the public tracking URL for an order.
	 *
	 * @param \WC_Order $order Order object.
	 *
	 * @return string
	 */
	public static function get_tracking_url( $order ) {
		$token = $order->get_meta( '_fmp_tracking_token' );

		if ( empty( $token ) ) {
			return $order->get_view_order_url();
		}

		return home_url( '/fmp-track/' . $token );
	}

	/**
	 * Generate a unique 12-character alphanumeric tracking token.
	 *
	 * @return string
	 */
	private static function generate_unique_token() {
		$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

		do {
			$token = '';
			$bytes = random_bytes( 12 );
			for ( $i = 0; $i < 12; $i++ ) {
				$token .= $chars[ ord( $bytes[ $i ] ) % 62 ];
			}
			$exists = wc_get_orders( [
				'meta_key'   => '_fmp_tracking_token',
				'meta_value' => $token,
				'limit'      => 1,
				'return'     => 'ids',
			] );
		} while ( ! empty( $exists ) );

		return $token;
	}

	/**
	 * Register rewrite rules for the public tracking page.
	 *
	 * @return void
	 */
	public function register_rewrite_rules() {
		add_rewrite_rule(
			'^fmp-track/([a-zA-Z0-9]{12,64})/?$',
			'index.php?fmp_tracking_token=$matches[1]',
			'top'
		);

		// Auto-flush once after install / feature enable. WP only persists rewrite
		// rules on flush — without this, /fmp-track/{token} 404s until the admin
		// manually saves Permalinks. Gated by a version option so we don't flush
		// on every request (that would slow down every page load).
		$rewrite_version = '1';
		if ( get_option( 'fmp_tracking_rewrite_version' ) !== $rewrite_version ) {
			flush_rewrite_rules( false );
			update_option( 'fmp_tracking_rewrite_version', $rewrite_version, false );
		}
	}

	/**
	 * Register the tracking token query variable.
	 *
	 * @param array $vars Query vars.
	 *
	 * @return array
	 */
	public function register_query_vars( $vars ) {
		$vars[] = 'fmp_tracking_token';
		return $vars;
	}

	/**
	 * Load the tracking page template when the query var is present.
	 *
	 * @param string $template Current template path.
	 *
	 * @return string
	 */
	public function load_tracking_template( $template ) {
		$token = get_query_var( 'fmp_tracking_token' );

		if ( ! $token ) {
			return $template;
		}

		$template_path = FMP()->pro_plugin_path() . '/templates/order-timeline/tracking-page.php';

		if ( file_exists( $template_path ) ) {
			return $template_path;
		}

		return $template;
	}

	/**
	 * Exclude the public tracking page from WooCommerce's "Coming Soon" mode.
	 *
	 * Hooked on `woocommerce_coming_soon_exclude`, which WC evaluates during
	 * `template_include` — by then the rewrite has populated the query var, so
	 * we can detect a tracking request reliably.
	 *
	 * @param bool $excluded Whether the request is already excluded.
	 *
	 * @return bool
	 */
	public function exclude_tracking_from_coming_soon( $excluded ) {
		if ( get_query_var( 'fmp_tracking_token' ) ) {
			return true;
		}

		return $excluded;
	}

	/**
	 * On the public tracking page, remove every other plugin-injected frontend
	 * element so the page shows only the order timeline. Runs on
	 * template_redirect — after controllers have registered their wp_footer /
	 * wp_head renderers (on init) but before those hooks fire.
	 *
	 * @return void
	 */
	public function declutter_tracking_page() {
		if ( ! get_query_var( 'fmp_tracking_token' ) ) {
			return;
		}

		// Floating "change location" button — same filter the Front-End
		// Dashboard uses to suppress it.
		add_filter( 'tlp_floating_location_btn', '__return_false' );

		// Each entry is [ fully-qualified class, hook, method ]. remove_action
		// targets the singleton instance that registered the render callback,
		// and is a no-op when the hook isn't registered (feature disabled), so
		// the guarded class_exists is enough to stay safe across Free/Pro.
		$frontend_elements = [
			[ '\RT\FoodMenu\Controllers\Frontend\FoodLocation', 'wp_footer', 'render_food_location_popup' ],
			[ '\RT\FoodMenu\Controllers\Frontend\FoodLocation', 'wp_footer', 'render_floating_location_button' ],
			[ '\RT\FoodMenu\Controllers\MiniCart\MiniCart', 'wp_footer', 'render' ],
			[ '\RT\FoodMenu\Controllers\SpecialMenu\SpecialMenu', 'wp_footer', 'render_special_menu_popup' ],
			[ '\RT\FoodMenu\Controllers\Discount\Discount', 'wp_footer', 'render_discount_badge_script' ],
			[ '\RT\FoodMenuPro\Controllers\QrTableOrdering\QrTableOrdering', 'wp_footer', 'handle_qr_location_param' ],
			[ '\RT\FoodMenuPro\Controllers\TimedProducts\TimedProducts', 'wp_footer', 'render_disable_script' ],
			[ '\RT\FoodMenuPro\Controllers\OrderStatuses\OrderStatuses', 'wp_head', 'frontend_badge_styles' ],
		];

		foreach ( $frontend_elements as $entry ) {
			list( $class, $hook, $method ) = $entry;
			if ( class_exists( $class ) && method_exists( $class, 'get_instance' ) ) {
				remove_action( $hook, [ $class::get_instance(), $method ] );
			}
		}
	}

	/**
	 * Render the order timeline on WooCommerce My Account → View Order page.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return void
	 */
	public function render_view_order_timeline( $order_id ) {
		$entries = OrderTimelineModel::get_timeline( $order_id );

		if ( empty( $entries ) ) {
			return;
		}

		$order          = wc_get_order( $order_id );
		$current_status = $order ? $order->get_status() : '';

		// Get custom status colors.
		$custom_statuses = get_option( 'fmp_custom_order_statuses', [] );
		$status_colors   = [];

		if ( is_array( $custom_statuses ) ) {
			foreach ( $custom_statuses as $cs ) {
				$slug                  = str_replace( 'wc-', '', $cs['slug'] ?? '' );
				$status_colors[ $slug ] = $cs['color'] ?? '';
			}
		}

		// Default WC status colors.
		$wc_colors = [
			'pending'    => '#d97706',
			'processing' => '#2563eb',
			'on-hold'    => '#ea580c',
			'completed'  => '#16a34a',
			'cancelled'  => '#dc2626',
			'refunded'   => '#6b7280',
			'failed'     => '#dc2626',
		];

		$total = count( $entries );
		?>
		<div class="fmp-order-timeline-wrap">
			<h2 class="fmp-order-timeline-title"><?php esc_html_e( 'Order Timeline', 'food-menu-pro' ); ?></h2>
			<div class="fmp-order-timeline">
				<?php foreach ( $entries as $i => $entry ) :
					$is_last  = ( $i === $total - 1 );
					$slug     = $entry['status'];
					$color    = $status_colors[ $slug ] ?? $wc_colors[ $slug ] ?? '#6b7280';
					$dot_class = $is_last ? 'fmp-ot-dot--current' : 'fmp-ot-dot--done';
				?>
				<div class="fmp-ot-step <?php echo $is_last ? 'fmp-ot-step--current' : 'fmp-ot-step--done'; ?>">
					<div class="fmp-ot-indicator">
						<div class="fmp-ot-dot <?php echo esc_attr( $dot_class ); ?>" style="<?php echo $is_last ? 'background:' . esc_attr( $color ) . ';box-shadow:0 0 0 4px ' . esc_attr( $color ) . '20;' : 'background:#10b981;'; ?>">
							<?php if ( ! $is_last ) : ?>
								<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
							<?php endif; ?>
						</div>
						<?php if ( ! $is_last ) : ?>
							<div class="fmp-ot-connector"></div>
						<?php endif; ?>
					</div>
					<div class="fmp-ot-content">
						<div class="fmp-ot-label"><?php echo esc_html( $entry['status_label'] ); ?></div>
						<div class="fmp-ot-time">
							<?php echo esc_html( OrderTimelineFns::format_datetime( $entry['created_at'] ) ); ?>
						</div>
					</div>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue timeline styles on the View Order page.
	 *
	 * @return void
	 */
	public function maybe_enqueue_timeline_styles() {
		if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
			return;
		}

		// Register a dummy handle so we can attach inline CSS.
		wp_register_style( 'fmp-order-timeline', false );
		wp_enqueue_style( 'fmp-order-timeline' );

		$css = '
		.fmp-order-timeline-wrap {
			margin: 0 0 30px;
		}
		.fmp-order-timeline-title {
			font-size: 18px;
			font-weight: 700;
			color: #111827;
			margin: 0 0 20px;
			letter-spacing: -0.01em;
		}
		.fmp-order-timeline {
			position: relative;
		}
		.fmp-ot-step {
			display: flex;
			gap: 16px;
		}
		.fmp-ot-indicator {
			display: flex;
			flex-direction: column;
			align-items: center;
			flex-shrink: 0;
			width: 24px;
		}
		.fmp-ot-dot {
			width: 24px;
			height: 24px;
			border-radius: 50%;
			display: flex;
			align-items: center;
			justify-content: center;
			flex-shrink: 0;
		}
		.fmp-ot-dot--done {
			background: #10b981;
		}
		.fmp-ot-dot--current {
			width: 16px;
			height: 16px;
			margin: 4px;
		}
		.fmp-ot-connector {
			width: 2px;
			flex: 1;
			min-height: 16px;
			background: #e5e7eb;
			border-radius: 1px;
			margin: 4px 0;
		}
		.fmp-ot-content {
			flex: 1;
			padding-bottom: 24px;
			padding-top: 2px;
		}
		.fmp-ot-step:last-child .fmp-ot-content {
			padding-bottom: 0;
		}
		.fmp-ot-label {
			font-size: 14px;
			font-weight: 600;
			color: #1f2937;
			line-height: 1.3;
		}
		.fmp-ot-step--done .fmp-ot-label {
			font-weight: 500;
			color: #374151;
		}
		.fmp-ot-step--current .fmp-ot-label {
			font-weight: 700;
			color: #111827;
		}
		.fmp-ot-time {
			font-size: 12px;
			color: #9ca3af;
			margin-top: 2px;
		}
		@media (max-width: 480px) {
			.fmp-ot-content { padding-bottom: 18px; }
			.fmp-ot-label { font-size: 13px; }
		}
		';

		wp_add_inline_style( 'fmp-order-timeline', $css );
	}
}
