<?php
/**
 * Kitchen Monitor Controller.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\KitchenMonitor;

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\PosPrinting\PosPrintingFns;

defined( 'ABSPATH' ) || exit();

/**
 * Kitchen Monitor Controller.
 */
class KitchenMonitorController {

	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Plugin settings.
	 *
	 * @var array
	 */
	private static $settings;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$settings       = get_option( TLPFoodMenu()->options['settings'] );
		self::$settings = $settings;

		// Register Kitchen Manager role once for existing installations.
		if ( ! get_option( 'fmp_kitchen_manager_role_added' ) ) {
			if ( ! get_role( 'fm_kitchen_manager' ) ) {
				\RT\FoodMenuPro\Helpers\Install::fmp_add_kitchen_manager_role();
			}
			update_option( 'fmp_kitchen_manager_role_added', true );
		}

		$fm_type    = $settings['fm_food_menu_type'] ?? 'food_menu_post';
		$is_enabled = $settings['fmp_enable_kitchen_monitor'] ?? false;

		if ( ! TLPFoodMenu()->isWcActive() || 'online_ordering' !== $fm_type || ! $is_enabled ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

		// Pause enforcement on checkout.
		add_action( 'woocommerce_checkout_process', [ $this, 'block_checkout_if_paused' ] );

		KitchenMonitorAjax::get_instance();
	}

	/**
	 * Enqueue kitchen monitor scripts and styles.
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		$page_id = FnsPro::get_kitchen_monitor_page();

		if ( empty( $page_id ) || ! is_page( $page_id ) ) {
			return;
		}

		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : FMP()->options['version'];

		wp_enqueue_style(
			'fm-kitchen-monitor',
			FMP()->assets_url() . 'css/kitchen-monitor-css.min.css',
			[],
			$version
		);

		wp_enqueue_script(
			'fm-kitchen-monitor',
			FMP()->assets_url() . 'js/kitchen-monitor.min.js',
			[ 'wp-element', 'wp-i18n' ],
			$version,
			true
		);
		wp_set_script_translations( 'fm-kitchen-monitor', 'food-menu-pro', FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages' );

		$primary_color = ! empty( self::$settings['fm_primary_color'] ) ? sanitize_hex_color( self::$settings['fm_primary_color'] ) : '#fc202e';
		$dark_color    = FnsPro::darken_color( $primary_color, 25 );
		$soft_color    = FnsPro::lighten_color( $primary_color, 92 );
		$css           = ':root{--rtfm-primary-color:' . $primary_color . ';--rtfm-primary-dark:' . $dark_color . ';--rtfm-primary-soft:' . $soft_color . ';--ring:' . $primary_color . ';}';
		wp_add_inline_style( 'fm-kitchen-monitor', $css );

		$pos_enabled = 'on' === ( self::$settings['fmp_enable_pos_printing'] ?? '' );

		$localize_data = [
			'ajaxurl'         => admin_url( 'admin-ajax.php' ),
			'nonce'           => wp_create_nonce( 'fmp_kitchen_monitor_nonce' ),
			'pollInterval'    => max( 30, (int) ( self::$settings['fmp_dashboard_poll_interval'] ?? self::$settings['fmp_kitchen_monitor_poll_interval'] ?? 60 ) ) * 1000,
			'defaultSound'    => self::$settings['fmp_kitchen_monitor_sound'] ?? 'on',
			'sound'           => KitchenMonitorFns::get_sound_config(),
			'allowedStatuses' => $this->get_allowed_statuses(),
			'completeStatus'  => $this->get_complete_status(),
			'isPaused'        => KitchenMonitorFns::paused_state(),
			'allowPause'      => KitchenMonitorFns::pause_enabled(),
			'siteName'        => get_bloginfo( 'name' ),
			'currency'        => function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$',
			'posPrinting'     => $pos_enabled,
			'tableField'      => self::get_table_field_config(),
		];

		if ( $pos_enabled ) {
			$localize_data['posNonce']  = wp_create_nonce( 'fmp_pos_printing_nonce' );
			$localize_data['slipTypes'] = PosPrintingFns::slip_types();
		}

		wp_localize_script( 'fm-kitchen-monitor', 'fmKitchenMonitor', $localize_data );
	}

	/**
	 * Get statuses selected by admin for the kitchen monitor.
	 *
	 * @return array
	 */
	private function get_allowed_statuses() {
		$selected_slugs  = self::$settings['fmp_kitchen_monitor_statuses'] ?? [];
		$custom_statuses = get_option( 'fmp_custom_order_statuses', [] );
		$wc_statuses     = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : [];

		// Build lookup for custom statuses.
		$custom_lookup = [];
		if ( is_array( $custom_statuses ) ) {
			foreach ( $custom_statuses as $status ) {
				if ( ! empty( $status['enabled'] ) ) {
					$custom_lookup[ $status['slug'] ] = $status;
				}
			}
		}

		// When nothing selected, show all WC statuses + custom statuses.
		if ( ! is_array( $selected_slugs ) || empty( $selected_slugs ) ) {
			$all_slugs = array_keys( $wc_statuses );
			foreach ( $custom_lookup as $slug => $cs ) {
				if ( ! in_array( $slug, $all_slugs, true ) ) {
					$all_slugs[] = $slug;
				}
			}
			$selected_slugs = $all_slugs;
		}

		// Strip the complete status so it doesn't render as a tab by default.
		// React re-adds it when the "Show Completed" toggle is on.
		$complete_status = self::$settings['fmp_kitchen_monitor_complete_status'] ?? '';
		if ( $complete_status ) {
			$selected_slugs = array_values( array_diff( $selected_slugs, [ $complete_status ] ) );
		}

		$allowed = [];

		foreach ( $selected_slugs as $slug ) {
			$meta = FnsPro::get_status_metadata( $slug );
			if ( ! $meta ) {
				continue;
			}
			$allowed[] = [
				'slug'  => $slug,
				'label' => $meta['label'],
				'color' => $meta['color'],
				'icon'  => $meta['icon'],
			];
		}

		return $allowed;
	}

	/**
	 * Resolve the configured complete status into the same shape as allowedStatuses.
	 *
	 * @return array|null
	 */
	private function get_complete_status() {
		$slug = self::$settings['fmp_kitchen_monitor_complete_status'] ?? '';
		if ( ! $slug ) {
			return null;
		}

		$meta = FnsPro::get_status_metadata( $slug );
		if ( ! $meta ) {
			return null;
		}

		return [
			'slug'  => $slug,
			'label' => $meta['label'],
			'color' => $meta['color'],
			'icon'  => $meta['icon'],
		];
	}

	/**
	 * Resolve the configured "table" custom field for the kitchen monitor.
	 *
	 * Reads `fmp_kitchen_monitor_table_field` (index into `fmp_order_custom_fields`)
	 * and returns the field definition, or null when not configured.
	 *
	 * @return array|null
	 */
	public static function get_table_field_config() {
		$settings = self::$settings ?: get_option( TLPFoodMenu()->options['settings'], [] );
		$idx_raw  = $settings['fmp_kitchen_monitor_table_field'] ?? '';

		if ( '' === $idx_raw ) {
			return null;
		}

		$fields = $settings['fmp_order_custom_fields'] ?? [];

		if ( ! is_array( $fields ) ) {
			return null;
		}

		$idx = (int) $idx_raw;

		if ( ! isset( $fields[ $idx ] ) ) {
			return null;
		}

		return [
			'index' => $idx,
			'label' => $fields[ $idx ]['label'] ?? '',
		];
	}

	/**
	 * Get default color for WooCommerce statuses.
	 *
	 * @param string $slug Status slug.
	 *
	 * @return string
	 */
	private function get_wc_status_color( $slug ) {
		$colors = [
			'wc-pending'    => '#d97706',
			'wc-processing' => '#2563eb',
			'wc-on-hold'    => '#ea580c',
			'wc-completed'  => '#16a34a',
			'wc-cancelled'  => '#dc2626',
			'wc-refunded'   => '#6b7280',
			'wc-failed'     => '#dc2626',
		];

		return $colors[ $slug ] ?? '#6b7280';
	}

	/**
	 * Block checkout if orders are paused.
	 *
	 * @return void
	 */
	public function block_checkout_if_paused() {
		if ( 'yes' !== KitchenMonitorFns::paused_state() ) {
			return;
		}

		$schedule = get_option( 'fmp_kitchen_pause_schedule', null );

		// No schedule — legacy global pause, block all orders.
		if ( empty( $schedule ) || empty( $schedule['active'] ) ) {
			$message = self::$settings['fmp_kitchen_monitor_pause_message'] ?? '';

			if ( empty( $message ) ) {
				$message = esc_html__( 'We are currently not taking any orders. Please try again later.', 'food-menu-pro' );
			}

			wc_add_notice( esc_html( $message ), 'error' );

			return;
		}

		$tz    = wp_timezone();
		$start = \DateTime::createFromFormat( 'Y-m-d H:i', $schedule['start_date'] . ' ' . $schedule['start_time'], $tz );
		$end   = \DateTime::createFromFormat( 'Y-m-d H:i', $schedule['end_date'] . ' ' . $schedule['end_time'], $tz );
		$now   = new \DateTime( 'now', $tz );

		if ( ! $start || ! $end ) {
			return;
		}

		// Auto-expire if past end.
		if ( $now > $end ) {
			delete_option( 'fmp_kitchen_pause_schedule' );
			update_option( 'fmp_kitchen_orders_paused', 'no' );

			return;
		}

		// Determine the order's target datetime.
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$order_type = isset( $_POST['fmp_order_time_type'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_order_time_type'] ) ) : '';
		$order_dt   = null;

		if ( in_array( $order_type, [ 'pickup', 'delivery', 'dinein' ], true ) ) {
			$date_str = isset( $_POST[ "fmp_{$order_type}_date" ] ) ? sanitize_text_field( wp_unslash( $_POST[ "fmp_{$order_type}_date" ] ) ) : '';
			$time_str = isset( $_POST[ "fmp_{$order_type}_time" ] ) ? sanitize_text_field( wp_unslash( $_POST[ "fmp_{$order_type}_time" ] ) ) : '';

			if ( $date_str ) {
				$wp_date_format = get_option( 'date_format', 'Y-m-d' );
				$wp_time_format = get_option( 'time_format', 'g:i a' );

				if ( $time_str ) {
					$order_dt = \DateTime::createFromFormat( $wp_date_format . ' ' . $wp_time_format, $date_str . ' ' . $time_str, $tz );
				}

				// Fallback: date only — treat as start of day.
				if ( ! $order_dt ) {
					$order_dt = \DateTime::createFromFormat( $wp_date_format, $date_str, $tz );

					if ( $order_dt ) {
						$order_dt->setTime( 0, 0 );
					}
				}
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		// QR scan / no type / unparseable date — use current time.
		if ( ! $order_dt ) {
			$order_dt = $now;
		}

		// Check if order datetime falls within pause window.
		if ( $order_dt >= $start && $order_dt <= $end ) {
			$message = self::$settings['fmp_kitchen_monitor_pause_message'] ?? '';

			if ( empty( $message ) ) {
				$message = esc_html__( 'We are currently not taking any orders. Please try again later.', 'food-menu-pro' );
			}

			wc_add_notice( esc_html( $message ), 'error' );
		}
	}
}
