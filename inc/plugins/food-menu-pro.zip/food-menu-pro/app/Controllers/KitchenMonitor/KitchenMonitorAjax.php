<?php
/**
 * Kitchen Monitor AJAX handlers.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\KitchenMonitor;

use RT\FoodMenuPro\Helpers\FnsPro;

defined( 'ABSPATH' ) || exit();

/**
 * Kitchen Monitor AJAX handlers.
 */
class KitchenMonitorAjax {

	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Order item meta: this line has been prepared.
	 *
	 * Kept on the order *item* rather than the order so each dish can be ticked
	 * off independently, and underscore-prefixed so WooCommerce keeps it out of
	 * the customer's order view and the card's add-on list skips it.
	 */
	const ITEM_DONE_META = '_fmp_kitchen_done';

	/**
	 * Order item meta: when the line was ticked off.
	 */
	const ITEM_DONE_AT_META = '_fmp_kitchen_done_at';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_ajax_fmp_kitchen_get_orders', [ $this, 'get_orders' ] );
		add_action( 'wp_ajax_fmp_kitchen_update_status', [ $this, 'update_status' ] );
		add_action( 'wp_ajax_fmp_kitchen_toggle_item', [ $this, 'toggle_item_done' ] );
		add_action( 'wp_ajax_fmp_kitchen_check_new', [ $this, 'check_new_orders' ] );
		add_action( 'wp_ajax_fmp_kitchen_toggle_pause', [ $this, 'toggle_pause' ] );
		add_action( 'wp_ajax_fmp_kitchen_set_pause_schedule', [ $this, 'set_pause_schedule' ] );
		add_action( 'wp_ajax_fmp_kitchen_resume_orders', [ $this, 'resume_orders' ] );
		add_action( 'wp_ajax_fmp_kitchen_get_stats', [ $this, 'get_stats' ] );
	}

	/**
	 * Verify nonce and capability.
	 *
	 * @return bool
	 */
	private function verify_request() {
		if ( ! check_ajax_referer( 'fmp_kitchen_monitor_nonce', 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => 'Invalid nonce.' ] );
			return false;
		}

		// The nonce is localized on the dashboard page for any logged-in visitor, so it is not access control.
		if ( ! self::user_can_use_monitor() ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Permission denied.', 'food-menu-pro' ) ], 403 );
			return false;
		}

		return true;
	}

	/**
	 * Kitchen staff: the dashboard's Kitchen Monitor menu, a store manager, or the
	 * plugin's kitchen / order-manager roles (used by the standalone monitor page).
	 *
	 * @return bool
	 */
	private static function user_can_use_monitor() {
		if ( current_user_can( 'manage_woocommerce' ) || FnsPro::can_use_dashboard_menu( [ 'kitchen-monitor' ] ) ) {
			return true;
		}

		$user = wp_get_current_user();

		return (bool) array_intersect( [ 'fm_kitchen_manager', 'fm_order_manage' ], (array) $user->roles );
	}

	/**
	 * Refuse to pause orders when the admin has switched the feature off.
	 *
	 * @return void
	 */
	private function ensure_pause_enabled() {
		if ( ! KitchenMonitorFns::pause_enabled() ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Pausing orders is disabled.', 'food-menu-pro' ) ] );
		}
	}

	/**
	 * Resolve the location filter for the current user.
	 *
	 * Returns:
	 *  - array : term IDs to clamp on (parent + descendants)
	 *  - null  : no clamp (user manages all locations and no specific pick)
	 *  - false : forbidden — caller should short-circuit with empty result
	 *
	 * @param int $requested_location_id Requested location term ID from the request.
	 *
	 * @return array|null|false
	 */
	private function resolve_user_location_filter( $requested_location_id ) {
		$allowed = FnsPro::get_user_allowed_locations();
		return FnsPro::resolve_location_filter( (int) $requested_location_id, $allowed );
	}

	/**
	 * Get the active status slugs the kitchen monitor displays by default.
	 * The configured complete status is excluded — it's only included when the
	 * user explicitly picks it from the filter dropdown.
	 *
	 * @return array
	 */
	private function get_allowed_status_slugs() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );
		$selected = $settings['fmp_kitchen_monitor_statuses'] ?? [];

		// When nothing selected, return all WC + custom statuses.
		if ( ! is_array( $selected ) || empty( $selected ) ) {
			$wc_slugs        = function_exists( 'wc_get_order_statuses' ) ? array_keys( wc_get_order_statuses() ) : [];
			$custom_statuses = get_option( 'fmp_custom_order_statuses', [] );

			if ( is_array( $custom_statuses ) ) {
				foreach ( $custom_statuses as $status ) {
					if ( ! empty( $status['enabled'] ) && ! in_array( $status['slug'], $wc_slugs, true ) ) {
						$wc_slugs[] = $status['slug'];
					}
				}
			}

			$slugs = $wc_slugs;
		} else {
			$slugs = $selected;
		}

		$complete_status = $this->get_complete_status_slug();
		if ( $complete_status ) {
			$slugs = array_values( array_diff( $slugs, [ $complete_status ] ) );
		}

		return $slugs;
	}

	/**
	 * Get the configured complete status slug, or empty string if not set.
	 *
	 * @return string
	 */
	private function get_complete_status_slug() {
		$settings = get_option( TLPFoodMenu()->options['settings'] );
		return $settings['fmp_kitchen_monitor_complete_status'] ?? '';
	}

	/**
	 * Get the union of active + complete statuses — used to validate that a status
	 * the user is moving an order INTO is reachable from the kitchen monitor.
	 *
	 * @return array
	 */
	private function get_transition_target_slugs() {
		$slugs           = $this->get_allowed_status_slugs();
		$complete_status = $this->get_complete_status_slug();

		if ( $complete_status && ! in_array( $complete_status, $slugs, true ) ) {
			$slugs[] = $complete_status;
		}

		return $slugs;
	}

	/**
	 * Fetch orders for kitchen display.
	 *
	 * @return void
	 */
	public function get_orders() {
		$this->verify_request();

		$page          = isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1;
		$per_page      = isset( $_POST['per_page'] ) ? absint( $_POST['per_page'] ) : 15;
		$status_filter = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : '';
		$search        = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$new_only    = isset( $_POST['new_only'] ) && '1' === (string) $_POST['new_only'];
		$include_raw = isset( $_POST['include'] ) ? sanitize_text_field( wp_unslash( $_POST['include'] ) ) : '';
		$include     = [];
		if ( ! empty( $include_raw ) ) {
			$include = array_filter( array_map( 'intval', explode( ',', $include_raw ) ) );
		}

		$requested_loc   = isset( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0;
		$location_filter = $this->resolve_user_location_filter( $requested_loc );

		if ( $location_filter === false ) {
			wp_send_json_success( [
				'orders'       => [],
				'total'        => 0,
				'total_pages'  => 0,
				'current_page' => $page,
			] );
			return;
		}

		$location_meta_clause = is_array( $location_filter ) ? FnsPro::build_location_meta_query( $location_filter ) : [];

		$allowed_slugs   = $this->get_allowed_status_slugs();
		$complete_status = $this->get_complete_status_slug();

		// Determine the query's status set:
		//  - If the user picked the complete status from the filter, query just that.
		//  - Else if they picked an active status, query just that.
		//  - Else query all active (allowed) statuses.
		if ( $status_filter && $complete_status && $status_filter === $complete_status ) {
			$query_statuses = [ $complete_status ];
		} elseif ( $status_filter && in_array( $status_filter, $allowed_slugs, true ) ) {
			$query_statuses = [ $status_filter ];
		} else {
			$query_statuses = $allowed_slugs;
		}

		if ( empty( $query_statuses ) ) {
			wp_send_json_success( [
				'orders'       => [],
				'total'        => 0,
				'total_pages'  => 0,
				'current_page' => $page,
			] );
			return;
		}

		$args = [
			'type'     => 'shop_order',
			'status'   => $query_statuses,
			'limit'    => $per_page,
			'page'     => $page,
			'orderby'  => 'date',
			'order'    => 'DESC',
			'paginate' => true,
		];

		$meta_query_parts = [];

		if ( $new_only ) {
			$meta_query_parts[] = [
				'key'   => '_fmp_is_new',
				'value' => 'yes',
			];
		}

		if ( ! empty( $location_meta_clause ) ) {
			$meta_query_parts[] = $location_meta_clause;
		}

		if ( ! empty( $meta_query_parts ) ) {
			$args['meta_query'] = count( $meta_query_parts ) === 1
				? $meta_query_parts
				: array_merge( [ 'relation' => 'AND' ], $meta_query_parts );
		}

		$excluded_types = FnsPro::get_excluded_product_types();

		// Fetch specific order IDs (used for "show new orders only" mode).
		if ( ! empty( $include ) ) {
			$orders = array_filter( array_map( 'wc_get_order', $include ) );

			if ( ! empty( $excluded_types ) ) {
				$orders = array_filter( $orders, static function ( $order ) use ( $excluded_types ) {
					return ! FnsPro::order_has_excluded_product_type( $order, $excluded_types );
				} );
			}

			if ( $location_filter !== null ) {
				$orders = array_filter( $orders, static function ( $order ) use ( $location_filter ) {
					return FnsPro::order_matches_allowed_locations( $order, $location_filter );
				} );
			}

			$orders      = array_values( $orders );
			$total       = count( $orders );
			$total_pages = 1;
		} elseif ( $search && is_numeric( $search ) ) {
			// Search by order ID — use wc_get_order() for HPOS compatibility.
			$order = wc_get_order( absint( $search ) );

			if ( $order && ! empty( $excluded_types ) && FnsPro::order_has_excluded_product_type( $order, $excluded_types ) ) {
				$order = null;
			}

			if ( $order && $location_filter !== null && ! FnsPro::order_matches_allowed_locations( $order, $location_filter ) ) {
				$order = null;
			}

			$orders      = $order ? [ $order ] : [];
			$total       = count( $orders );
			$total_pages = 1;
		} else {
			// Push product-type exclusion into SQL so pagination/total stay accurate
			// and we never load excluded orders into PHP.
			$orders      = [];
			$total       = 0;
			$total_pages = 0;

			FnsPro::with_excluded_product_types( $excluded_types, static function () use ( $args, &$orders, &$total, &$total_pages ) {
				$orders_result = wc_get_orders( FnsPro::order_query_args( $args ) );
				$orders        = $orders_result->orders;
				$total         = $orders_result->total;
				$total_pages   = $orders_result->max_num_pages;
			} );
		}

		// Batch prime meta cache.
		$order_ids = array_map( function ( $order ) {
			return $order->get_id();
		}, $orders );

		if ( ! empty( $order_ids ) ) {
			update_meta_cache( 'post', $order_ids );
		}

		$orders_data = [];

		foreach ( $orders as $order ) {
			$orders_data[] = $this->format_order( $order );
		}

		wp_send_json_success( [
			'orders'       => $orders_data,
			'total'        => $total,
			'total_pages'  => $total_pages,
			'current_page' => $page,
		] );
	}

	/**
	 * Format a single order for the kitchen monitor.
	 *
	 * @param \WC_Order $order WooCommerce order.
	 *
	 * @return array
	 */
	private function format_order( $order ) {
		$items      = [];
		$item_count = 0;
		$items_done = 0;

		foreach ( $order->get_items() as $item ) {
			$addons = [];

			// Get addon meta.
			foreach ( $item->get_meta_data() as $meta ) {
				$key = $meta->key;
				// Skip internal meta.
				if ( str_starts_with( $key, '_' ) ) {
					continue;
				}
				// Strip HTML tags and decode entities (WooCommerce price spans).
				$addon_value = is_string( $meta->value )
					? html_entity_decode( wp_strip_all_tags( $meta->value ), ENT_QUOTES, 'UTF-8' )
					: $meta->value;
				$addons[]    = [
					'name'  => wp_strip_all_tags( $key ),
					'value' => $addon_value,
				];
			}

			$is_done = '1' === (string) $item->get_meta( self::ITEM_DONE_META );

			$items[] = [
				// The line's own ID — what the "prepared" checkbox toggles against.
				'id'      => $item->get_id(),
				'name'    => $item->get_name(),
				'qty'     => $item->get_quantity(),
				'total'   => $item->get_total(),
				'addons'  => $addons,
				'done'    => $is_done,
				'done_at' => $is_done ? $this->format_done_at( $item->get_meta( self::ITEM_DONE_AT_META ) ) : '',
			];

			$item_count += $item->get_quantity();

			if ( $is_done ) {
				++$items_done;
			}
		}

		// Determine order type.
		$order_type = $order->get_meta( 'fmp_order_time_type' ) ?: '';

		// QR table info.
		$table_name  = $order->get_meta( 'fmp_qr_table_name' ) ?: '';
		$is_qr_order = ! empty( $table_name );

		// Dine In table — a real checkout selection, not a QR scan, so it fills
		// the same chip but must not be flagged as a QR order.
		if ( ! $table_name && 'dinein' === $order_type ) {
			$table_name = $order->get_meta( 'fmp_dinein_table' ) ?: '';
		}

		// Configured custom-field-based table name (separate from QR table).
		$table_field_value = '';
		$table_field_cfg   = KitchenMonitorController::get_table_field_config();

		if ( $table_field_cfg ) {
			$custom_fields = $order->get_meta( '_fmp_custom_fields' );

			if ( is_array( $custom_fields ) ) {
				$key = 'custom_' . $table_field_cfg['index'];
				$val = $custom_fields[ $key ] ?? '';
				$table_field_value = is_array( $val ) ? implode( ', ', $val ) : (string) $val;
			}
		}

		// Time ago.
		$order_date = $order->get_date_created();
		$time_ago   = '';
		$time_value = '';

		if ( $order_date ) {
			$diff     = current_time( 'timestamp' ) - $order_date->getTimestamp();
			$time_value = $order_date->date_i18n( get_option( 'time_format', 'g:i a' ) );

			if ( $diff < 60 ) {
				$time_ago = esc_html__( 'just now', 'food-menu-pro' );
			} elseif ( $diff < 3600 ) {
				$mins     = floor( $diff / 60 );
				/* translators: %d: number of minutes */
				$time_ago = sprintf( _n( '%d min ago', '%d mins ago', $mins, 'food-menu-pro' ), $mins );
			} elseif ( $diff < 86400 ) {
				$hours    = floor( $diff / 3600 );
				/* translators: %d: number of hours */
				$time_ago = sprintf( _n( '%d hour ago', '%d hours ago', $hours, 'food-menu-pro' ), $hours );
			} else {
				$time_ago = $order_date->date_i18n( get_option( 'date_format' ) );
			}
		}

		// Build items summary.
		$summary_parts = [];
		$shown         = 0;

		foreach ( $items as $item ) {
			if ( $shown >= 2 ) {
				$remaining       = count( $items ) - 2;
				$summary_parts[] = '+' . $remaining . ' more';
				break;
			}
			$summary_parts[] = $item['qty'] . 'x ' . $item['name'];
			$shown++;
		}

		return [
			'id'            => $order->get_id(),
			'number'        => $order->get_order_number(),
			'status'        => 'wc-' . $order->get_status(),
			'status_label'  => wc_get_order_status_name( $order->get_status() ),
			'is_new'        => 'yes' === $order->get_meta( '_fmp_is_new' ),
			'items'         => $items,
			'items_summary' => implode( ', ', $summary_parts ),
			'item_count'    => $item_count,
			// Lines ticked off as prepared, for the card's progress chip.
			'items_done'    => $items_done,
			'order_type'    => $order_type,
			'customer_name' => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'customer_phone' => $order->get_billing_phone(),
			'customer_email' => $order->get_billing_email(),
			'total'         => $order->get_total(),
			'total_formatted' => html_entity_decode( wp_strip_all_tags( $order->get_formatted_order_total() ), ENT_QUOTES, 'UTF-8' ),
			'time_ago'      => $time_ago,
			'time_value'    => $time_value,
			'date'          => $order_date ? $order_date->date_i18n( get_option( 'date_format' ) . ' — ' . get_option( 'time_format' ) ) : '',
			'table_name'    => $table_name,
			'is_qr_order'   => $is_qr_order,
			'table_field_value' => $table_field_value,
			'location_name' => $order->get_meta( 'fmp_location_name' ) ?: '',
			'order_note'    => $order->get_customer_note(),
			'subtotal'      => $order->get_subtotal(),
			'tax_total'     => $order->get_total_tax(),
			'discount'      => $order->get_discount_total(),
			'pickup_date'   => $order->get_meta( 'fmp_pickup_date' ) ?: '',
			'pickup_time'   => $order->get_meta( 'fmp_pickup_time' ) ?: '',
			'delivery_date' => $order->get_meta( 'fmp_delivery_date' ) ?: '',
			'delivery_time' => $order->get_meta( 'fmp_delivery_time' ) ?: '',
		];
	}

	/**
	 * Update order status.
	 *
	 * @return void
	 */
	public function update_status() {
		$this->verify_request();

		$order_id   = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$new_status = isset( $_POST['new_status'] ) ? sanitize_text_field( wp_unslash( $_POST['new_status'] ) ) : '';

		if ( ! $order_id || ! $new_status ) {
			wp_send_json_error( [ 'message' => 'Missing order ID or status.' ] );
			return;
		}

		// Validate against the union of active + complete statuses so staff can
		// both progress orders and mark them complete (or move them back out).
		$allowed_slugs = $this->get_transition_target_slugs();
		if ( ! in_array( $new_status, $allowed_slugs, true ) ) {
			wp_send_json_error( [ 'message' => 'Status not allowed.' ] );
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			wp_send_json_error( [ 'message' => 'Order not found.' ] );
			return;
		}

		$allowed = FnsPro::get_user_allowed_locations();
		if ( ! FnsPro::order_matches_allowed_locations( $order, $allowed ) ) {
			wp_send_json_error( [ 'message' => 'You are not assigned to this order\'s location.' ] );
			return;
		}

		// Remove 'wc-' prefix for update_status.
		$status_without_prefix = str_replace( 'wc-', '', $new_status );
		$order->update_status( $status_without_prefix, esc_html__( 'Status updated via Kitchen Monitor.', 'food-menu-pro' ) );

		wp_send_json_success( [
			'message'      => esc_html__( 'Order status updated.', 'food-menu-pro' ),
			'new_status'   => $new_status,
			'status_label' => wc_get_order_status_name( $status_without_prefix ),
		] );
	}

	/**
	 * Tick a single order line off as prepared, or untick it.
	 *
	 * Kitchen staff work through an order dish by dish, so the "done" state has
	 * to live per line and on the server — the board polls, and several screens
	 * may be showing the same order at once. Storing it as order item meta means
	 * one cook ticking off the chips is visible on every other screen at the next
	 * refresh, and survives a reload.
	 *
	 * This deliberately does not touch the order's status. Marking every dish
	 * prepared is the cook's own checklist; deciding the order is ready remains a
	 * status change someone makes on purpose.
	 *
	 * @return void
	 */
	public function toggle_item_done() {
		$this->verify_request();

		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$item_id  = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;

		// Checkboxes post '1'/'0'; anything else is treated as unticking.
		$done = isset( $_POST['done'] ) && '1' === (string) sanitize_text_field( wp_unslash( $_POST['done'] ) );

		if ( ! $order_id || ! $item_id ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Missing order or item.', 'food-menu-pro' ) ] );
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Order not found.', 'food-menu-pro' ) ] );
			return;
		}

		$allowed = FnsPro::get_user_allowed_locations();
		if ( ! FnsPro::order_matches_allowed_locations( $order, $allowed ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'You are not assigned to this order\'s location.', 'food-menu-pro' ) ] );
			return;
		}

		// Reading the item off the order is what proves the line belongs to it —
		// a stray item ID from another order simply is not found here.
		$item = $order->get_item( $item_id );

		if ( ! $item ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Item not found on this order.', 'food-menu-pro' ) ] );
			return;
		}

		if ( $done ) {
			$item->update_meta_data( self::ITEM_DONE_META, '1' );
			$item->update_meta_data( self::ITEM_DONE_AT_META, current_time( 'mysql' ) );
		} else {
			$item->delete_meta_data( self::ITEM_DONE_META );
			$item->delete_meta_data( self::ITEM_DONE_AT_META );
		}

		// Meta-only save — the order's totals and status are untouched, so there
		// is no reason to run the full order-save pipeline here.
		$item->save_meta_data();

		// Recount from the order so the response carries the same progress figure
		// the next poll will produce.
		$total = 0;
		$count = 0;

		foreach ( $order->get_items() as $line ) {
			++$total;

			if ( '1' === (string) $line->get_meta( self::ITEM_DONE_META ) ) {
				++$count;
			}
		}

		wp_send_json_success( [
			'item_id'    => $item_id,
			'done'       => $done,
			'done_at'    => $done ? $this->format_done_at( $item->get_meta( self::ITEM_DONE_AT_META ) ) : '',
			'items_done' => $count,
			'items_total' => $total,
		] );
	}

	/**
	 * Format a "prepared at" timestamp in the site's own time format.
	 *
	 * @param string $value Stored MySQL datetime.
	 *
	 * @return string Empty string when there is nothing to show.
	 */
	private function format_done_at( $value ) {
		$value = (string) $value;

		if ( '' === $value ) {
			return '';
		}

		$timestamp = strtotime( $value );

		return $timestamp ? date_i18n( (string) get_option( 'time_format', 'H:i' ), $timestamp ) : '';
	}

	/**
	 * Check for new orders since last check.
	 *
	 * @return void
	 */
	public function check_new_orders() {
		$this->verify_request();

		$last_check = isset( $_POST['last_check_time'] ) ? absint( $_POST['last_check_time'] ) : 0;

		$allowed_slugs = $this->get_allowed_status_slugs();

		if ( empty( $allowed_slugs ) || ! $last_check ) {
			wp_send_json_success( [
				'new_count'   => 0,
				'latest_time' => time(),
				'new_ids'     => [],
			] );
			return;
		}

		$requested_loc   = isset( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0;
		$location_filter = $this->resolve_user_location_filter( $requested_loc );

		if ( $location_filter === false ) {
			wp_send_json_success( [
				'new_count'   => 0,
				'latest_time' => time(),
				'new_ids'     => [],
			] );
			return;
		}

		$location_meta_clause = is_array( $location_filter ) ? FnsPro::build_location_meta_query( $location_filter ) : [];

		$date_after     = gmdate( 'Y-m-d H:i:s', $last_check );
		$excluded_types = FnsPro::get_excluded_product_types();

		$orders = FnsPro::with_excluded_product_types( $excluded_types, static function () use ( $allowed_slugs, $date_after, $location_meta_clause ) {
			$args = [
				'status'     => $allowed_slugs,
				'date_after' => $date_after,
				'limit'      => 50,
				'return'     => 'ids',
			];
			if ( ! empty( $location_meta_clause ) ) {
				$args['meta_query'] = [ $location_meta_clause ];
			}
			return wc_get_orders( FnsPro::order_query_args( $args ) );
		} );

		wp_send_json_success( [
			'new_count'   => count( $orders ),
			'latest_time' => time(),
			'new_ids'     => $orders,
		] );
	}

	/**
	 * Toggle pause state.
	 *
	 * @return void
	 */
	public function toggle_pause() {
		$this->verify_request();
		$this->ensure_pause_enabled();

		$current = get_option( 'fmp_kitchen_orders_paused', 'no' );
		$new     = ( 'yes' === $current ) ? 'no' : 'yes';

		update_option( 'fmp_kitchen_orders_paused', $new );

		wp_send_json_success( [
			'paused'  => $new,
			'message' => ( 'yes' === $new )
				? esc_html__( 'Orders paused.', 'food-menu-pro' )
				: esc_html__( 'Orders resumed.', 'food-menu-pro' ),
		] );
	}

	/**
	 * Set a scheduled pause window.
	 *
	 * @return void
	 */
	public function set_pause_schedule() {
		$this->verify_request();
		$this->ensure_pause_enabled();

		$start_date = isset( $_POST['start_date'] ) ? sanitize_text_field( wp_unslash( $_POST['start_date'] ) ) : '';
		$start_time = isset( $_POST['start_time'] ) ? sanitize_text_field( wp_unslash( $_POST['start_time'] ) ) : '';
		$end_date   = isset( $_POST['end_date'] ) ? sanitize_text_field( wp_unslash( $_POST['end_date'] ) ) : '';
		$end_time   = isset( $_POST['end_time'] ) ? sanitize_text_field( wp_unslash( $_POST['end_time'] ) ) : '';

		if ( ! $start_date || ! $start_time || ! $end_date || ! $end_time ) {
			wp_send_json_error( [ 'message' => esc_html__( 'All date and time fields are required.', 'food-menu-pro' ) ] );
			return;
		}

		$tz    = wp_timezone();
		$start = \DateTime::createFromFormat( 'Y-m-d H:i', $start_date . ' ' . $start_time, $tz );
		$end   = \DateTime::createFromFormat( 'Y-m-d H:i', $end_date . ' ' . $end_time, $tz );

		if ( ! $start || ! $end ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Invalid date or time format.', 'food-menu-pro' ) ] );
			return;
		}

		if ( $end <= $start ) {
			wp_send_json_error( [ 'message' => esc_html__( 'End time must be after start time.', 'food-menu-pro' ) ] );
			return;
		}

		$schedule = [
			'active'     => true,
			'start_date' => $start_date,
			'start_time' => $start_time,
			'end_date'   => $end_date,
			'end_time'   => $end_time,
		];

		update_option( 'fmp_kitchen_pause_schedule', $schedule );
		update_option( 'fmp_kitchen_orders_paused', 'yes' );

		wp_send_json_success( [
			'paused'        => 'yes',
			'pauseSchedule' => $schedule,
			'message'       => esc_html__( 'Pause schedule set.', 'food-menu-pro' ),
		] );
	}

	/**
	 * Resume orders by clearing the pause schedule.
	 *
	 * @return void
	 */
	public function resume_orders() {
		$this->verify_request();

		delete_option( 'fmp_kitchen_pause_schedule' );
		update_option( 'fmp_kitchen_orders_paused', 'no' );

		wp_send_json_success( [
			'paused'        => 'no',
			'pauseSchedule' => null,
			'message'       => esc_html__( 'Orders resumed.', 'food-menu-pro' ),
		] );
	}

	/**
	 * Get stats for the kitchen monitor.
	 *
	 * @return void
	 */
	public function get_stats() {
		$this->verify_request();

		$allowed_slugs   = $this->get_allowed_status_slugs();
		$complete_status = $this->get_complete_status_slug();

		if ( empty( $allowed_slugs ) ) {
			wp_send_json_success( [
				'active_orders'   => 0,
				'new_today'       => 0,
				'completed_today' => 0,
				'status_counts'   => [],
			] );
			return;
		}

		$requested_loc   = isset( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0;
		$location_filter = $this->resolve_user_location_filter( $requested_loc );

		if ( $location_filter === false ) {
			wp_send_json_success( [
				'active_orders'   => 0,
				'new_today'       => 0,
				'completed_today' => 0,
				'new_count'       => 0,
				'status_counts'   => array_fill_keys( $allowed_slugs, 0 ),
				'paused'          => KitchenMonitorFns::paused_state(),
				'pauseSchedule'   => get_option( 'fmp_kitchen_pause_schedule', null ),
			] );
			return;
		}

		global $wpdb;

		$is_hpos = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

		// Build a NOT EXISTS fragment to also exclude orders containing any
		// excluded product type — same semantics as the order list, but kept
		// in pure SQL so we never load 10k+ WC_Order objects.
		$excluded_types = FnsPro::get_excluded_product_types();
		$exclusion_sql  = '';

		if ( ! empty( $excluded_types ) ) {
			$term_ids = FnsPro::get_excluded_product_type_term_ids( $excluded_types );

			if ( ! empty( $term_ids ) ) {
				$order_id_ref  = $is_hpos ? "{$wpdb->prefix}wc_orders.id" : "{$wpdb->posts}.ID";
				$exclusion_sql = FnsPro::build_excluded_product_types_sql( $order_id_ref, $term_ids );
			}
		}

		// Location clamp SQL fragment.
		$loc_sql = '';
		if ( is_array( $location_filter ) ) {
			$order_id_ref = $is_hpos ? "{$wpdb->prefix}wc_orders.id" : "{$wpdb->posts}.ID";
			$loc_sql      = FnsPro::build_location_sql_fragment( $order_id_ref, $location_filter, $is_hpos );
		}
		// Append the location clamp onto the existing exclusion_sql so all
		// per-status / today queries pick it up without further changes.
		$exclusion_sql .= $loc_sql;

		$placeholders = implode( ',', array_fill( 0, count( $allowed_slugs ), '%s' ) );

		// 1. Per-status counts — single GROUP BY query instead of N queries.
		if ( $is_hpos ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$results = $wpdb->get_results( $wpdb->prepare( "SELECT status, COUNT(*) as cnt FROM {$wpdb->prefix}wc_orders WHERE type = 'shop_order' AND status IN ($placeholders){$exclusion_sql} GROUP BY status", ...$allowed_slugs ) );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$results = $wpdb->get_results( $wpdb->prepare( "SELECT post_status as status, COUNT(*) as cnt FROM {$wpdb->posts} WHERE post_type = 'shop_order' AND post_status IN ($placeholders){$exclusion_sql} GROUP BY post_status", ...$allowed_slugs ) );
		}

		$status_counts = array_fill_keys( $allowed_slugs, 0 );
		$active_total  = 0;

		// Allowed slugs already exclude the complete status, so every row counts as active.
		foreach ( $results as $row ) {
			$status_counts[ $row->status ] = (int) $row->cnt;
			$active_total                  += (int) $row->cnt;
		}

		// Today's date in site timezone.
		$today_start = wp_date( 'Y-m-d 00:00:00' );
		$today_gmt   = get_gmt_from_date( $today_start );

		// 2. New today + completed today — single query, 2 counts.
		// Include the configured complete status so we can count "Completed Today".
		$today_slugs = $complete_status
			? array_values( array_unique( array_merge( $allowed_slugs, [ $complete_status ] ) ) )
			: $allowed_slugs;

		$new_today_count       = 0;
		$completed_today_count = 0;

		if ( ! empty( $today_slugs ) ) {
			$today_ph     = implode( ',', array_fill( 0, count( $today_slugs ), '%s' ) );
			$today_params = array_merge( $today_slugs, [ $today_gmt ] );

			if ( $is_hpos ) {
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$today_results = $wpdb->get_results( $wpdb->prepare( "SELECT status, COUNT(*) as cnt FROM {$wpdb->prefix}wc_orders WHERE type = 'shop_order' AND status IN ($today_ph) AND date_created_gmt >= %s{$exclusion_sql} GROUP BY status", ...$today_params ) );
			} else {
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$today_results = $wpdb->get_results( $wpdb->prepare( "SELECT post_status as status, COUNT(*) as cnt FROM {$wpdb->posts} WHERE post_type = 'shop_order' AND post_status IN ($today_ph) AND post_date_gmt >= %s{$exclusion_sql} GROUP BY post_status", ...$today_params ) );
			}

			foreach ( $today_results as $row ) {
				if ( $complete_status && $row->status === $complete_status ) {
					$completed_today_count = (int) $row->cnt;
				}
				if ( in_array( $row->status, $allowed_slugs, true ) ) {
					$new_today_count += (int) $row->cnt;
				}
			}
		}

		$pause_schedule = get_option( 'fmp_kitchen_pause_schedule', null );

		// Auto-expire if past end time.
		if ( ! empty( $pause_schedule['active'] ) ) {
			$tz       = wp_timezone();
			$end_dt   = \DateTime::createFromFormat( 'Y-m-d H:i', $pause_schedule['end_date'] . ' ' . $pause_schedule['end_time'], $tz );
			$now_dt   = new \DateTime( 'now', $tz );

			if ( $end_dt && $now_dt > $end_dt ) {
				delete_option( 'fmp_kitchen_pause_schedule' );
				update_option( 'fmp_kitchen_orders_paused', 'no' );
				$pause_schedule = null;
			}
		}

		// 3. Count orders flagged as new — single COUNT query with meta join.
		$new_params = array_merge( $allowed_slugs, [ '_fmp_is_new', 'yes' ] );

		// Build per-query exclusion SQL using the JOIN aliases (`o.id` / `p.ID`).
		$new_exclusion_sql = '';
		if ( ! empty( $excluded_types ) ) {
			$term_ids = FnsPro::get_excluded_product_type_term_ids( $excluded_types );
			if ( ! empty( $term_ids ) ) {
				$new_exclusion_sql = FnsPro::build_excluded_product_types_sql( $is_hpos ? 'o.id' : 'p.ID', $term_ids );
			}
		}

		// Re-build the location clamp against the aliased order ID.
		if ( is_array( $location_filter ) ) {
			$new_exclusion_sql .= FnsPro::build_location_sql_fragment(
				$is_hpos ? 'o.id' : 'p.ID',
				$location_filter,
				$is_hpos
			);
		}

		if ( $is_hpos ) {
			$meta_table = $wpdb->prefix . 'wc_orders_meta';
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$new_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}wc_orders o INNER JOIN {$meta_table} m ON o.id = m.order_id WHERE o.type = 'shop_order' AND o.status IN ($placeholders) AND m.meta_key = %s AND m.meta_value = %s{$new_exclusion_sql}", ...$new_params ) );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$new_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id WHERE p.post_type = 'shop_order' AND p.post_status IN ($placeholders) AND pm.meta_key = %s AND pm.meta_value = %s{$new_exclusion_sql}", ...$new_params ) );
		}

		wp_send_json_success( [
			'active_orders'   => $active_total,
			'new_today'       => $new_today_count,
			'completed_today' => $completed_today_count,
			'new_count'       => $new_count,
			'status_counts'   => $status_counts,
			'paused'          => KitchenMonitorFns::paused_state(),
			'pauseSchedule'   => $pause_schedule,
		] );
	}

}
