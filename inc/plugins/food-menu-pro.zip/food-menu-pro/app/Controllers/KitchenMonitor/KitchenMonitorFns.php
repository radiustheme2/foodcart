<?php
/**
 * Kitchen Monitor settings fields class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\KitchenMonitor;

defined( 'ABSPATH' ) || exit();

/**
 * Kitchen Monitor settings fields class.
 */
class KitchenMonitorFns {

	/**
	 * Kitchen Monitor setting fields.
	 *
	 * @return array
	 */
	public static function settings_field() {

		$settings = get_option( TLPFoodMenu()->options['settings'] );

		return apply_filters(
			'fmp/kitchen_monitor_settings/fields',
			[
				'fmp_enable_kitchen_monitor'      => [
					'label'       => esc_html__( 'Enable Kitchen Monitor', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Enable a live kitchen display page for monitoring and managing incoming orders.', 'food-menu-pro' ),
					'value'       => $settings['fmp_enable_kitchen_monitor'] ?? '',
				],
				/*'fmp_kitchen_monitor_role'          => [
					'id'    => 'fmp_kitchen_monitor_role',
					'type'  => 'select',
					'value' => $settings['fmp_kitchen_monitor_role'] ?? 'fm_kitchen_manager',
					'label' => esc_html__( 'Choose Role for Kitchen Monitor', 'food-menu-pro' ),
				],*/
				'fmp_kitchen_monitor_sound'         => [
					'label' => esc_html__( 'Default Sound Notification', 'food-menu-pro' ),
					'type'  => 'switch',
					'value' => $settings['fmp_kitchen_monitor_sound'] ?? 'on',
				],
				'fmp_kitchen_sound_staff_toggle'   => [
					'label' => esc_html__( 'Allow Staff to Control Sound', 'food-menu-pro' ),
					'type'  => 'switch',
					'value' => $settings['fmp_kitchen_sound_staff_toggle'] ?? 'on',
				],
				'fmp_kitchen_sound_type'           => [
					'label' => esc_html__( 'Alert Sound', 'food-menu-pro' ),
					'type'  => 'select',
					'value' => $settings['fmp_kitchen_sound_type'] ?? 'default',
				],
				'fmp_kitchen_sound_file'           => [
					'label' => esc_html__( 'Custom Sound File', 'food-menu-pro' ),
					'type'  => 'group',
					'value' => $settings['fmp_kitchen_sound_file'] ?? [ 'id' => 0, 'url' => '' ],
				],
				'fmp_kitchen_sound_repeat'         => [
					'label' => esc_html__( 'Repeat', 'food-menu-pro' ),
					'type'  => 'select',
					'value' => $settings['fmp_kitchen_sound_repeat'] ?? 'once',
				],
				'fmp_kitchen_sound_repeat_count'   => [
					'label' => esc_html__( 'Number of Repeats', 'food-menu-pro' ),
					'type'  => 'number',
					'value' => $settings['fmp_kitchen_sound_repeat_count'] ?? 3,
				],
				'fmp_kitchen_sound_gap'            => [
					'label' => esc_html__( 'Gap Between Repeats (seconds)', 'food-menu-pro' ),
					'type'  => 'number',
					'value' => $settings['fmp_kitchen_sound_gap'] ?? 2,
				],
				'fmp_kitchen_sound_volume'         => [
					'label' => esc_html__( 'Volume', 'food-menu-pro' ),
					'type'  => 'number',
					'value' => $settings['fmp_kitchen_sound_volume'] ?? 100,
				],
				'fmp_kitchen_sound_max_minutes'    => [
					'label' => esc_html__( 'Stop Ringing After (minutes)', 'food-menu-pro' ),
					'type'  => 'number',
					'value' => $settings['fmp_kitchen_sound_max_minutes'] ?? 0,
				],
				'fmp_kitchen_monitor_statuses'      => [
					'id'          => 'fmp_kitchen_monitor_statuses',
					'type'        => 'checkbox',
					'multiple'    => true,
					'value'       => $settings['fmp_kitchen_monitor_statuses'] ?? [],
					'label'       => esc_html__( 'Statuses to Display', 'food-menu-pro' ),
					'description' => esc_html__( 'Leave empty to show all order statuses.', 'food-menu-pro' ),
				],
				'fmp_kitchen_monitor_allow_pause'   => [
					'label' => esc_html__( 'Allow Staff to Pause Orders', 'food-menu-pro' ),
					'type'  => 'switch',
					'value' => $settings['fmp_kitchen_monitor_allow_pause'] ?? 'on',
				],
				'fmp_kitchen_monitor_pause_message' => [
					'id'    => 'fmp_kitchen_monitor_pause_message',
					'type'  => 'text',
					'value' => $settings['fmp_kitchen_monitor_pause_message'] ?? esc_html__( 'We are currently not taking any orders. Please try again later.', 'food-menu-pro' ),
					'label' => esc_html__( 'Pause Message', 'food-menu-pro' ),
				],
			]
		);
	}

	/**
	 * Whether the Kitchen Monitor's Pause Orders feature is available.
	 *
	 * Defaults to on — the button has always been there. When an admin turns it
	 * off the button is hidden, pause requests are refused, and a pause left
	 * over from before is no longer enforced at checkout: otherwise a store
	 * paused at that moment would stay closed with no button to reopen it.
	 *
	 * @return bool
	 */
	public static function pause_enabled(): bool {
		$settings = get_option( TLPFoodMenu()->options['settings'], [] );

		return 'on' === ( $settings['fmp_kitchen_monitor_allow_pause'] ?? 'on' );
	}

	/**
	 * The stored pause state, reported as 'no' while the feature is disabled.
	 *
	 * @return string 'yes' or 'no'.
	 */
	public static function paused_state(): string {
		if ( ! self::pause_enabled() ) {
			return 'no';
		}

		return 'yes' === get_option( 'fmp_kitchen_orders_paused', 'no' ) ? 'yes' : 'no';
	}

	/**
	 * Resolve the alert-sound configuration for the monitor.
	 *
	 * A busy, noisy kitchen cannot rely on a half-second chime, so the alert can
	 * be a custom file that repeats — optionally until someone actually accepts
	 * the order, the way a delivery-platform tablet behaves.
	 *
	 * **Every default here reproduces the original behaviour exactly**: the
	 * built-in chime, played once. Existing sites hear no change until an admin
	 * chooses otherwise, and the master on/off switch keeps its own meaning.
	 *
	 * @return array<string,mixed>
	 */
	public static function get_sound_config(): array {
		$settings = get_option( TLPFoodMenu()->options['settings'], [] );

		$type   = 'custom' === ( $settings['fmp_kitchen_sound_type'] ?? 'default' ) ? 'custom' : 'default';
		$file   = $settings['fmp_kitchen_sound_file'] ?? [];
		$url    = is_array( $file ) ? (string) ( $file['url'] ?? '' ) : (string) $file;
		$repeat = (string) ( $settings['fmp_kitchen_sound_repeat'] ?? 'once' );

		if ( ! in_array( $repeat, [ 'once', 'count', 'until_accepted' ], true ) ) {
			$repeat = 'once';
		}

		// A custom sound with no file selected would be silence — fall back to the
		// built-in chime so the kitchen is never left without an alert.
		if ( 'custom' === $type && '' === $url ) {
			$type = 'default';
		}

		return [
			// Whether the Sound On/Off button appears on the monitor at all. With
			// it hidden, the sound follows the admin's own setting and staff
			// cannot mute an alarm that exists so orders are not missed.
			// Defaults to allowed, which is how the monitor has always behaved.
			'staffToggle' => 'on' === ( $settings['fmp_kitchen_sound_staff_toggle'] ?? 'on' ),
			'type'        => $type,
			'url'         => 'custom' === $type ? esc_url_raw( $url ) : '',
			'repeat'      => $repeat,
			'repeatCount' => max( 1, min( 100, (int) self::number_setting( $settings, 'fmp_kitchen_sound_repeat_count', 3 ) ) ),
			'gap'         => max( 0, min( 60, (float) self::number_setting( $settings, 'fmp_kitchen_sound_gap', 2 ) ) ),
			// A blank saved value must fall back to full volume, never to 0 —
			// casting '' to int gives 0, which is a silent alarm that still looks
			// like it is ringing.
			'volume'      => max( 0, min( 100, (int) self::number_setting( $settings, 'fmp_kitchen_sound_volume', 100 ) ) ) / 100,
			// 0 means "keep ringing until someone accepts", which is the point of
			// the feature; the cap exists for sites that want a backstop.
			'maxMinutes'  => max( 0, min( 120, (int) self::number_setting( $settings, 'fmp_kitchen_sound_max_minutes', 0 ) ) ),
		];
	}

	/**
	 * Read a numeric setting, treating a missing or non-numeric value as unset.
	 *
	 * The settings form stores whatever it is given, so a field that was rendered
	 * and submitted empty lands in the option as `''`. Casting that straight to a
	 * number yields 0 — fine for a delay, disastrous for a volume.
	 *
	 * @param array  $settings Settings array.
	 * @param string $key      Setting key.
	 * @param mixed  $default  Value to use when nothing usable is stored.
	 *
	 * @return mixed
	 */
	private static function number_setting( array $settings, string $key, $default ) {
		$value = $settings[ $key ] ?? '';

		return is_numeric( $value ) ? $value : $default;
	}
}
