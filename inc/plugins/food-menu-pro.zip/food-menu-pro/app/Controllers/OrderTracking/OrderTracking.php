<?php
/**
 * Order tracking — flags orders as "new" via meta until status changes.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\OrderTracking;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;

/**
 * Tracks new orders server-side via order meta.
 *
 * - On creation: sets `_fmp_is_new = yes`.
 * - On status change: removes the meta.
 *
 * This makes "new order" state cross-device and authoritative.
 */
class OrderTracking {

	use SingletonTrait;

	const META_KEY = '_fmp_is_new';

	/**
	 * Init.
	 *
	 * @return void
	 */
	protected function init() {
		// Mark order as new on creation (covers both checkout and admin/manual creation).
		add_action( 'woocommerce_new_order', [ $this, 'mark_new' ], 1, 1 );
		add_action( 'woocommerce_checkout_order_created', [ $this, 'mark_new_obj' ], 1, 1 );
		// Safety net: also mark on thankyou (after checkout payment processing completes).
		add_action( 'woocommerce_thankyou', [ $this, 'mark_new' ], 1, 1 );

		// Clear on any status change (any → any).
		add_action( 'woocommerce_order_status_changed', [ $this, 'clear_on_status_change' ], 10, 4 );

		// One-time cleanup: wipe is_new meta from any pre-existing orders so only
		// orders created after install get the badge.
		add_action( 'admin_init', [ $this, 'maybe_cleanup_legacy_meta' ] );
	}

	/**
	 * One-time cleanup: remove `_fmp_is_new` meta from all existing orders.
	 * Runs once per site, gated by an option flag.
	 *
	 * Going forward, only orders created AFTER this runs will be flagged as new
	 * (via the woocommerce_new_order hook).
	 *
	 * @return void
	 */
	public function maybe_cleanup_legacy_meta() {
		if ( get_option( 'fmp_is_new_cleanup_done' ) ) {
			return;
		}

		global $wpdb;

		// HPOS-aware: delete from both legacy postmeta and HPOS orders meta.
		// Legacy CPT meta.
		$wpdb->delete( $wpdb->postmeta, [ 'meta_key' => self::META_KEY ] );

		// HPOS orders meta (only if table exists).
		$hpos_meta_table = $wpdb->prefix . 'wc_orders_meta';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $hpos_meta_table ) );
		if ( $exists ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->delete( $hpos_meta_table, [ 'meta_key' => self::META_KEY ] );
		}

		update_option( 'fmp_is_new_cleanup_done', 1, false );
	}

	/**
	 * Mark an order as new by ID.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function mark_new( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		if ( ! self::should_flag_as_new( $order->get_status() ) ) {
			return;
		}
		$order->update_meta_data( self::META_KEY, 'yes' );
		$order->save();
	}

	/**
	 * Mark an order as new from order object.
	 *
	 * @param \WC_Order $order Order object.
	 * @return void
	 */
	public function mark_new_obj( $order ) {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}
		if ( ! self::should_flag_as_new( $order->get_status() ) ) {
			return;
		}
		$order->update_meta_data( self::META_KEY, 'yes' );
		$order->save();
	}

	/**
	 * Decide whether an order placed in the given status should receive the
	 * "New" badge.
	 *
	 * Admins can pick an inclusion list via `fmp_new_badge_statuses` (stored as
	 * `wc-{slug}` values to match the WC status options). When that list is
	 * empty or unset, fall back to the default behavior: badge for everything
	 * except terminal statuses (completed, cancelled, refunded, failed).
	 *
	 * @param string $status Status slug without the `wc-` prefix.
	 *
	 * @return bool
	 */
	public static function should_flag_as_new( $status ) {
		if ( '' === (string) $status ) {
			return false;
		}

		$settings = get_option( 'tpl_food_menu_settings', [] );
		$allowed  = isset( $settings['fmp_new_badge_statuses'] ) && is_array( $settings['fmp_new_badge_statuses'] )
			? $settings['fmp_new_badge_statuses']
			: [];

		if ( empty( $allowed ) ) {
			$excluded_defaults = [ 'completed', 'cancelled', 'refunded', 'failed' ];
			return ! in_array( $status, $excluded_defaults, true );
		}

		return in_array( 'wc-' . $status, $allowed, true );
	}

	/**
	 * Clear the "new" flag when status changes.
	 *
	 * IMPORTANT: skip if we're still in the same request as the order creation.
	 * During checkout, an order may transition pending → processing (payment
	 * auto-complete) immediately after creation, which fires this hook and would
	 * wipe the flag we just set. did_action('woocommerce_new_order') tells us
	 * whether the creation hook has fired in the current request.
	 *
	 * @param int       $order_id   Order ID.
	 * @param string    $old_status Old status (without wc- prefix).
	 * @param string    $new_status New status (without wc- prefix).
	 * @param \WC_Order $order      Order object.
	 * @return void
	 */
	public function clear_on_status_change( $order_id, $old_status, $new_status, $order ) {
		// Skip during the initial creation request — payment gateways often
		// transition pending → processing immediately, which is part of creation
		// not a real status change by staff.
		if ( did_action( 'woocommerce_new_order' ) > 0 ) {
			return;
		}

		// Initial creation transition — not a real status change.
		$initial_statuses = [ '', 'new', 'auto-draft', 'checkout-draft' ];
		if ( in_array( (string) $old_status, $initial_statuses, true ) ) {
			return;
		}

		if ( ! $order instanceof \WC_Order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! $order ) {
			return;
		}
		if ( $order->get_meta( self::META_KEY ) ) {
			$order->delete_meta_data( self::META_KEY );
			$order->save();
		}
	}
}
