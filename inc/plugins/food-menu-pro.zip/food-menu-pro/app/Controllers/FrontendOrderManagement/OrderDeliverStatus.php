<?php

namespace RT\FoodMenuPro\Controllers\FrontendOrderManagement;

use RT\FoodMenuPro\Helpers\FnsPro;
use \RT\FoodMenuPro\Traits\SingletonTrait;

class OrderDeliverStatus {

	use SingletonTrait;

	public function __construct() {
		add_action( 'init', [ $this, 'wc_register_order_status_delivered' ] );
		add_filter( 'wc_order_statuses', [ $this, 'wc_add_delivered_to_order_statuses' ] );
		add_filter( 'woocommerce_order_actions', [ $this, 'wc_order_actions_add_mark_delivered' ] );
		add_action( 'woocommerce_order_action_mark_delivered', [ $this, 'wc_order_action_mark_delivered' ] );
		add_filter( 'woocommerce_admin_order_actions', [ $this, 'wc_admin_orders_add_delivered_button' ], 100, 2 );
		add_action( 'wp_ajax_wc_mark_order_delivered', [ $this, 'wc_ajax_mark_order_delivered' ] );
		add_filter( 'bulk_actions-edit-shop_order', [ $this, 'wc_bulk_action_register_mark_delivered' ] );
		add_filter( 'handle_bulk_actions-edit-shop_order', [ $this, 'wc_bulk_action_handle_mark_delivered' ], 10, 3 );
		add_action( 'admin_notices', [ $this, 'wc_bulk_mark_delivered_admin_notice' ] );
		add_action( 'admin_head', [ $this, 'wc_admin_delivered_icon_css' ] );
	}


	/**
	 * Register custom post status for delivered orders
	 */
	function wc_register_order_status_delivered() {
		register_post_status( 'wc-delivered', [
			'label'                     => _x( 'Delivered', 'Order status', 'my-text-domain' ),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Delivered <span class="count">(%s)</span>', 'Delivered <span class="count">(%s)</span>', 'my-text-domain' )
		] );
	}

	/**
	 * Add 'delivered' to WooCommerce order statuses dropdowns
	 */
	function wc_add_delivered_to_order_statuses( $order_statuses ) {
		$new = [];

		// Insert after 'completed' if it exists, otherwise append
		foreach ( $order_statuses as $key => $status ) {
			$new[ $key ] = $status;
			if ( 'wc-completed' === $key ) {
				$new['wc-delivered'] = _x( 'Delivered', 'Order status', 'my-text-domain' );
			}
		}

		if ( ! isset( $new['wc-delivered'] ) ) {
			$new['wc-delivered'] = _x( 'Delivered', 'Order status', 'my-text-domain' );
		}

		return $new;
	}


	/**
	 * Add "Mark delivered" to order actions (Order actions dropdown on single order edit)
	 */
	function wc_order_actions_add_mark_delivered( $actions ) {
		$actions['mark_delivered'] = __( 'Mark order as delivered', 'my-text-domain' );

		return $actions;
	}


	/**
	 * Handle the order action (single order edit "Order actions" select)
	 *
	 * Hook name: woocommerce_order_action_{$action_key}
	 * For our action key 'mark_delivered' -> hook: woocommerce_order_action_mark_delivered
	 */
	function wc_order_action_mark_delivered( $order ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}

		// Only change if not already delivered
		if ( 'delivered' !== $order->get_status() ) {
			$order->update_status( 'delivered', __( 'Order marked as delivered via order actions.', 'my-text-domain' ) );
		}
	}


	/**
	 * Add quick action button to Orders admin list (the small icons)
	 */
	function wc_admin_orders_add_delivered_button( $actions, $order ) {
		// Only show for orders that are not delivered already and user can edit orders
		if ( 'delivered' !== $order->get_status() && current_user_can( 'edit_shop_orders' ) ) {
			$nonce = wp_create_nonce( 'wc_mark_order_delivered' );
			$url   = wp_nonce_url(
				add_query_arg(
					[
						'action'   => 'wc_mark_order_delivered',
						'order_id' => $order->get_id(),
					],
					admin_url( 'admin-ajax.php' )
				),
				'wc_mark_order_delivered'
			);

			$actions['mark_delivered'] = [
				'url'    => $url,
				'name'   => __( 'Mark delivered', 'my-text-domain' ),
				// 'action' value determines CSS class for the button, can be any string; WooCommerce applies icon based on it.
				'action' => 'delivered',
			];
		}

		return $actions;
	}


	/**
	 * AJAX handler for the admin-order list "mark delivered" action
	 */
	function wc_ajax_mark_order_delivered() {
		// Only allow in admin
		if ( ! is_admin() ) {
			wp_send_json_error( 'Permission denied' );
		}

		$order_id = isset( $_REQUEST['order_id'] ) ? absint( $_REQUEST['order_id'] ) : 0;
		check_admin_referer( 'wc_mark_order_delivered' );

		if ( ! current_user_can( 'edit_shop_orders', $order_id ) ) {
			wp_die( __( 'You do not have permission to edit orders', 'my-text-domain' ) );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( __( 'Order not found', 'my-text-domain' ) );
		}

		if ( 'delivered' !== $order->get_status() ) {
			$order->update_status( 'delivered', __( 'Order marked as delivered via admin list action.', 'my-text-domain' ) );
		}

		// If call was AJAX, return JSON success; otherwise redirect back
		if ( wp_doing_ajax() ) {
			wp_send_json_success( [ 'order_id' => $order_id, 'status' => 'delivered' ] );
		} else {
			wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'edit.php?post_type=shop_order' ) );
			exit;
		}
	}


	/**
	 * Bulk action: add option to bulk mark delivered on orders list
	 */
	function wc_bulk_action_register_mark_delivered( $bulk_actions ) {
		$bulk_actions['mark_delivered'] = __( 'Mark as delivered', 'my-text-domain' );

		return $bulk_actions;
	}


	/**
	 * Bulk action handler
	 */
	function wc_bulk_action_handle_mark_delivered( $redirect_to, $doaction, $post_ids ) {
		if ( $doaction !== 'mark_delivered' ) {
			return $redirect_to;
		}

		if ( empty( $post_ids ) || ! is_array( $post_ids ) ) {
			return $redirect_to;
		}

		foreach ( $post_ids as $post_id ) {
			$order = wc_get_order( $post_id );
			if ( $order && 'delivered' !== $order->get_status() ) {
				// Only users with capability should modify
				if ( current_user_can( 'edit_shop_orders', $post_id ) ) {
					$order->update_status( 'delivered', __( 'Order marked as delivered (bulk action).', 'my-text-domain' ) );
				}
			}
		}

		$redirect_to = add_query_arg( 'bulk_mark_delivered', count( $post_ids ), $redirect_to );

		return $redirect_to;
	}


	/**
	 * Optional: Show admin notice after bulk action
	 */
	function wc_bulk_mark_delivered_admin_notice() {
		if ( ! empty( $_REQUEST['bulk_mark_delivered'] ) ) {
			$count = absint( $_REQUEST['bulk_mark_delivered'] );
			printf( '<div id="message" class="updated notice is-dismissible"><p>%s</p></div>',
				esc_html( sprintf( _n( '%d order marked delivered.', '%d orders marked delivered.', $count, 'my-text-domain' ), $count ) )
			);
		}
	}


	/**
	 * Optional: Add a tiny CSS to give the admin list action a green check icon (purely cosmetic)
	 */
	function wc_admin_delivered_icon_css() {
		?>
        <style>
            /* Targets the small action icon in the orders list — tweak to taste */
            .wc-action-button.delivered::after {
                font-family: "dashicons";
                content: "\f147"; /* dashicons-yes */
                speak: none;
            }

            /* Change background color for delivered action icon if needed */
            .wc-action-button.delivered {
                background: transparent;
            }
        </style>
		<?php
	}

}