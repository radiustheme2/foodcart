<?php
/**
 * This Class responsible for modify anything from the Right Popup modal
 * Update Order
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\FrontendOrderManagement;

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Traits\SingletonTrait;

class ReportGenerate {
	use SingletonTrait;

	/**
	 * Class constructor.
	 */

	private static $settings;

	public function __construct() {
		$this->view();
	}

	public function view() {
		$current_url  = get_permalink( FnsPro::get_frontend_order_page() );
		$order_status = ! empty( $_GET['order-status'] ) ? $_GET['order-status'] : '';
		?>
        <a class="button" href="<?php echo esc_url( $current_url ) ?>" style="--btn-bg:#0073aa;">
            <svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M201.85 314.54C195.77 314.54 189.67 312.33 184.86 307.87L83.4203 213.79C80.8759 211.43 78.8507 208.567 77.4734 205.382C76.0961 202.197 75.397 198.76 75.4205 195.29C75.444 191.82 76.1897 188.393 77.61 185.227C79.0303 182.061 81.0942 179.225 83.6703 176.9L187.89 82.82C198.14 73.57 213.95 74.38 223.2 84.63C232.45 94.88 231.64 110.69 221.39 119.94L137.45 195.71L218.85 271.21C228.97 280.6 229.57 296.42 220.18 306.54C215.26 311.85 208.56 314.54 201.85 314.54Z" fill="white"/>
                <path d="M304.54 435.61H100.08C86.2701 435.61 75.0801 424.42 75.0801 410.61C75.0801 396.8 86.2701 385.61 100.08 385.61H304.54C349.96 385.61 386.91 348.66 386.91 303.24C386.91 257.82 349.96 220.87 304.54 220.87H100.08C86.2701 220.87 75.0801 209.68 75.0801 195.87C75.0801 182.06 86.2701 170.87 100.08 170.87H304.54C377.53 170.87 436.91 230.25 436.91 303.24C436.91 376.23 377.53 435.61 304.54 435.61Z" fill="white"/>
            </svg>
			<?php echo esc_html__( "Back to Order", "food-menu-pro" ); ?>
        </a>

        <form method="get" action="">
            <div class="rt-order-report-filter">
                <div class="date-wrapper">
                    <input class="flatpicker" type="text" name="from_date" id="from_date" placeholder="Select From Date" value="<?php echo esc_attr( $_GET['from_date'] ?? '' ); ?>">
                </div>
                <div class="date-wrapper">
                    <input class="flatpicker" type="text" name="to_date" id="to_date" placeholder="Select To Date" value="<?php echo esc_attr( $_GET['to_date'] ?? '' ); ?>">
                </div>
                <div class="report-order-status">
                    <select name="order-status">
                        <option value=""><?php echo esc_html__( 'Choose Status', 'food-menu-pro' ); ?></option>
						<?php
						foreach ( wc_get_order_statuses() as $status_key => $status_label ) :
							?>
                            <option value="<?php echo esc_attr( $status_key ); ?>"
								<?php echo selected( $order_status, $status_key ) ?>>
								<?php echo esc_html( $status_label ); ?>
                            </option>
						<?php endforeach; ?>
                    </select>
                </div>


                <input type="hidden" name="show-report" value="1">
                <button type="submit" style="--btn-bg: green;">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 36 36" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M4 33.99h2.5c1.103 0 2-.898 2-2v-3.46c0-1.103-.897-2-2-2H4c-1.103 0-2 .897-2 2v3.46c0 1.102.897 2 2 2zm0-5.46h2.5l.002 3.46H4zM12.5 33.99H15c1.103 0 2-.898 2-2v-12.4c0-1.102-.897-2-2-2h-2.5c-1.103 0-2 .898-2 2v12.4c0 1.102.897 2 2 2zm0-14.4H15l.002 12.4H12.5zM21 21.07c-1.103 0-2 .897-2 2v8.92c0 1.102.897 2 2 2h2.5c1.103 0 2-.898 2-2v-8.92c0-1.103-.897-2-2-2zm0 10.92v-8.92h2.5l.002 8.92zM34 31.99V12.57c0-1.103-.897-2-2-2h-2.5c-1.103 0-2 .897-2 2v19.42c0 1.102.897 2 2 2H32c1.103 0 2-.898 2-2zm-4.5-19.42H32l.002 19.42H29.5zM5.947 16.737l7.546-7.546a1.003 1.003 0 0 1 1.134-.197l5.956 2.801a3 3 0 0 0 3.398-.592l7.487-7.486a1 1 0 1 0-1.414-1.414L22.567 9.79a1 1 0 0 1-1.132.197l-5.956-2.803a3.012 3.012 0 0 0-3.4.594l-7.546 7.546a1 1 0 1 0 1.414 1.414z" fill="#FFFFFF" opacity="1" data-original="#FFFFFF"></path></g></svg>
	                <?php echo esc_html__( "Generate Report", "food-menu-pro" ); ?>
                </button>
            </div>
        </form>

		<?php

		$from_date = ! empty( $_GET['from_date'] ) ? sanitize_text_field( $_GET['from_date'] ) : '';
		$to_date   = ! empty( $_GET['to_date'] ) ? sanitize_text_field( $_GET['to_date'] ) : '';

		if ( $from_date || $to_date ) {
			// If only one date is chosen → make it single-day report
			if ( $from_date && empty( $to_date ) ) {
				$date_filter = $from_date . '...' . $from_date;
			} elseif ( $to_date && empty( $from_date ) ) {
				$date_filter = $to_date . '...' . $to_date;
			} else {
				$date_filter = $from_date . '...' . $to_date;
			}

			$args           = [
				'limit'        => - 1,
				'date_created' => $date_filter,
				'return'       => 'ids',
				'type'         => 'shop_order',
			];
			$args['status'] = $order_status ?: [ 'wc-completed', 'wc-processing' ];

			$orders = wc_get_orders( $args );


			if ( ! empty( $orders ) ) {
				$grand_total = 0;

                ?>
                <button id="print-report">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M329.956 399.834H182.044c-9.425 0-17.067 7.641-17.067 17.067s7.641 17.067 17.067 17.067h147.911c9.425 0 17.067-7.641 17.067-17.067s-7.641-17.067-17.066-17.067zM329.956 346.006H182.044c-9.425 0-17.067 7.641-17.067 17.067s7.641 17.067 17.067 17.067h147.911c9.425 0 17.067-7.641 17.067-17.067s-7.641-17.067-17.066-17.067z" fill="#000000" opacity="1" data-original="#000000" class=""></path><path d="M472.178 133.907h-54.303V35.132c0-9.425-7.641-17.067-17.067-17.067H111.192c-9.425 0-17.067 7.641-17.067 17.067v98.775H39.822C17.864 133.907 0 151.772 0 173.73v171.702c0 21.958 17.864 39.822 39.822 39.822h54.306v91.614c0 9.425 7.641 17.067 17.067 17.067h289.61c9.425 0 17.067-7.641 17.067-17.067v-91.614h54.306c21.958 0 39.822-17.864 39.822-39.822V173.73c0-21.957-17.864-39.823-39.822-39.823zm-343.92-81.708h255.483v81.708H128.258V52.199zm255.48 407.602H128.262V320.173h255.477l-.001 139.628zm17.07-225.679h-43.443c-9.425 0-17.067-7.641-17.067-17.067s7.641-17.067 17.067-17.067h43.443c9.425 0 17.067 7.641 17.067 17.067s-7.641 17.067-17.067 17.067z" fill="#FFFFFF"" opacity="1" data-original="#FFFFFF" class=""></path></g></svg>
                    <?php echo esc_html__( 'Print Report', 'food-menu-pro' )?>
                </button>
                    <?php

				echo '<div class="report-print">';
				if ( ! empty( $_GET['from_date'] ) && ! empty( $_GET['to_date'] ) ) {
					$from_date = sanitize_text_field( $_GET['from_date'] );
					$to_date   = sanitize_text_field( $_GET['to_date'] );

					echo '<h3>Total sales from ' . esc_html( $from_date ) . ' to ' . esc_html( $to_date ) . ':</h3>';
				}

				echo '<table border="1" cellpadding="5" cellspacing="0" style="width:100%; border-collapse:collapse;">';
				echo '<tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Customer</th>
                <th>Status</th>
                <th>Total</th>
              </tr>';

				foreach ( $orders as $order_id ) {
					$order = wc_get_order( $order_id );

					if ( is_a( $order, 'WC_Order' ) ) {
						$customer_name = $order->get_formatted_billing_full_name();
					} else {
						$customer_name = 'N/A';
					}
					$date   = $order->get_date_created()->date( 'Y-m-d H:i' );
					$status = wc_get_order_status_name( $order->get_status() );
					$total  = $order->get_total();

					$grand_total += $total;

					echo '<tr>
                    <td>#' . esc_html( $order_id ) . '</td>
                    <td>' . esc_html( $date ) . '</td>
                    <td>' . esc_html( $customer_name ) . '</td>
                    <td>' . esc_html( $status ) . '</td>
                    <td>' . wc_price( $total ) . '</td>
                  </tr>';
				}

				echo '<tr style="font-weight:bold;">
                <td colspan="4" style="text-align:right;">Grand Total:</td>
                <td>' . wc_price( $grand_total ) . '</td>
              </tr>';
				echo '</table>';
				echo '</div>';
			} else {
				echo '<p>No orders found in this date range.</p>';
			}

		}
		?>
		<?php
	}
}