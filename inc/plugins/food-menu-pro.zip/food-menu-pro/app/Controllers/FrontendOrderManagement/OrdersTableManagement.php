<?php
/**
 * This Class responsible for Front-end Order Table management
 *
 * Load Orders Table
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\FrontendOrderManagement;

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\PosPrinting\PosPrintingFns;
use RT\FoodMenuPro\Traits\SingletonTrait;

class OrdersTableManagement {
	use SingletonTrait;

	/**
	 * Class constructor.
	 */

	private static $settings;


	public function __construct() {
		self::$settings = get_option( TLPFoodMenu()->options['settings'] );

		add_action( 'wp_ajax_fm_get_orders', [ $this, 'fm_get_orders' ] );

		// AJAX: Update Order Status
		add_action( 'wp_ajax_fm_update_order_status', [ __CLASS__, 'fm_update_order_status' ] );

		//Bulk order update
		add_action( 'wp_ajax_fm_update_bulk_order', [ __CLASS__, 'fm_update_bulk_order_cbf' ] );

		//Live new Orders notice
		add_action( 'wp_ajax_check_new_orders', [ __CLASS__, 'fm_check_new_orders_callback' ] );
	}

	public function fm_get_orders() {
		if ( ! FnsPro::has_order_manage_capability() ) {
			wp_send_json_error( __( 'Permission denied.', 'food-menu-pro' ) );
		}

		$_paged   = isset( $_REQUEST['current'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['current'] ) ) : 1;
		$status   = ! empty( $_REQUEST['status'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['status'] ) ) : '';
		$paged    = max( 1, (int) $_paged );
		$per_page = self::$settings['fmp_order_per_page'] ?? 10;

		$args = [
			'posts_per_page' => $per_page,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'paginate'       => true,
			'page'           => $paged,
			'type'           => 'shop_order',
		];

		// Build status list: WC defaults + any registered custom statuses.
		$all_wc_statuses = array_keys( wc_get_order_statuses() );
		$default_status  = array_map( function ( $key ) {
			return str_replace( 'wc-', '', $key );
		}, $all_wc_statuses );
		$default_status = array_diff( $default_status, [ 'checkout-draft' ] );
		$default_status = array_values( $default_status );

		if ( 'new' == $status ) {//Request for new orders
			$args = self::new_orders_args( $args );
		} else if ( in_array( $status, $default_status ) ) {
			$args['status'] = sanitize_text_field( $_REQUEST['status'] );
		} else {
			$args['status'] = $default_status;
		}


		// Filters
		if ( isset( $_REQUEST['filter'] ) ) {
			$search_term      = isset( $_REQUEST['filter']['search'] ) ? sanitize_text_field( $_REQUEST['filter']['search'] ) : '';
			$search_filter_by = isset( $_REQUEST['filter']['search_filter_by'] ) ? sanitize_text_field( $_REQUEST['filter']['search_filter_by'] ) : '';
			$date_from        = isset( $_REQUEST['filter']['date_start'] ) ? sanitize_text_field( $_REQUEST['filter']['date_start'] ) : '';
			$date_to          = isset( $_REQUEST['filter']['date_end'] ) ? sanitize_text_field( $_REQUEST['filter']['date_end'] ) : '';

			if ( $date_from ) {
				$start_date_obj = new \WC_DateTime( $date_from . ' 00:00:00' );
				$start_date_obj->setTimezone( wp_timezone() );
			}

			$end_date_obj = new \WC_DateTime( $date_to . ' 23:59:59' );
			$end_date_obj->setTimezone( wp_timezone() );


			if ( $date_from && $date_to ) {
				$args['date_created'] = $start_date_obj->format( 'Y-m-d H:i:s' ) . '...' . $end_date_obj->format( 'Y-m-d H:i:s' );
			}

			// Searching by order ID
			if ( $search_term ) {
				if ( 'order_id' === $search_filter_by ) {
					$args['id'] = absint( $search_term );
				}

				if ( 'customer_email' === $search_filter_by ) {
					$args['billing_email'] = sanitize_email( $search_term );
				}

				if ( 'customer_name' === $search_filter_by ) {
					$meta_query   = [ 'relation' => 'OR' ];
					$meta_query[] = [
						'key'     => '_billing_address_index',
						'value'   => $search_term,
						'compare' => 'LIKE',
					];

					$args['meta_query'] = $meta_query;
				}
			}

		}

		$orders = wc_get_orders( FnsPro::order_query_args( $args ) );

		$available_rooms = FnsPro::get_available_rooms();

		$pos_settings         = FnsPro::get_settings_option();
		$pos_printing_enabled = 'on' === ( $pos_settings['fmp_enable_pos_printing'] ?? '' );
		$default_slip         = $pos_settings['fmp_default_slip_type'] ?? 'order_confirmation';
		$slip_types           = $pos_printing_enabled ? PosPrintingFns::slip_types() : [];
		?>

        <div id="fm-order-list">
            <div class="order-item">
                <div class="item order-id">
					<?php echo esc_html__( 'Order #', 'food-menu-pro' ); ?>
                </div>
                <div class="item order-date">
					<?php echo esc_html__( 'Date', 'food-menu-pro' ); ?>
                </div>
				<?php if ( ! empty( $available_rooms ) ) : ?>
                    <div class="item order-meta-room">
						<?php echo esc_html__( 'Room Number', 'food-menu-pro' ); ?>
                    </div>
				<?php endif; ?>
				<?php if ( 'on' === ( $pos_settings['fmp_food_location_popup'] ?? '' ) ) : ?>
                    <div class="item order-meta-location">
						<?php echo esc_html__( 'Location', 'food-menu-pro' ); ?>
                    </div>
				<?php endif; ?>
				<?php
				// The Table column serves both QR table ordering and Dine In.
				$show_table_column = 'on' === ( $pos_settings['fmp_enable_qr_table_ordering'] ?? '' )
					|| 'on' === ( $pos_settings['enable_dinein'] ?? '' );
				?>
				<?php if ( $show_table_column ) : ?>
                    <div class="item order-meta-qr-table">
						<?php echo esc_html__( 'Table', 'food-menu-pro' ); ?>
                    </div>
				<?php endif; ?>
                <div class="item order-meta-total">
					<?php echo esc_html__( 'Total', 'food-menu-pro' ); ?>
                </div>

                <div class="item order-status-item" style="width: 150px">
					<?php echo esc_html__( 'Status', 'food-menu-pro' ); ?>
                </div>
				<?php if ( $pos_printing_enabled ) : ?>
                    <div class="item order-print">
						<?php echo esc_html__( 'Print', 'food-menu-pro' ); ?>
                    </div>
				<?php endif; ?>
                <div class="item order-actions">
					<?php echo esc_html__( 'Action', 'food-menu-pro' ); ?>
                </div>
            </div>


			<?php foreach ( $orders->orders as $order ) :

				if ( $order instanceof \WC_Order_Refund ) {
					continue;
				}
				$preview_manager = $order->get_meta( 'preview_manager' );

				$label = '';
				if ( ! $preview_manager ) {
					$date_created = $order->get_date_created();
					$now          = new \WC_DateTime(); // current time
					$interval     = $now->getTimestamp() - $date_created->getTimestamp(); // difference in seconds
					if ( $interval <= 24 * 60 * 60 && 'pending' === $order->get_status() ) { // 24 hours = 24*60*60 seconds
						$label = 'new';
					}
				}
				?>
                <div class="order-item" data-order-id="<?php echo esc_attr( $order->get_id() ); ?>">
                    <div class="item order-id">
                        <div class="order-id-name">
                            <input class="fm_order_checkbox" type="checkbox" name="fm_order_checkbox[]">
                            <a class="view-order fm-view-order" href="javascript:void(0)" data-action="view">
                                #<?php echo esc_html( $order->get_id() ); //Order ID

								if ( $order->get_billing_first_name() || $order->get_billing_last_name() ) {
									echo " - ";
									echo esc_html( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
								}
								if ( $label ) : ?>
                                    <span class="<?php echo esc_attr( $label ? 'new' : '' ) ?>">
                                        <?php echo esc_html( $label ); ?>
                                    </span>
								<?php endif; ?>
                            </a>
                        </div>
                    </div>

                    <div class="item order-date">
						<?php
						$date_created = $order->get_date_created();
						echo esc_html( wc_format_datetime( $date_created ) );
						?>
                    </div>

					<?php if ( ! empty( $available_rooms ) ) : ?>
                        <div class="item order-meta-room">
							<?php
							$room = $order->get_meta( '_hotel_room_number' );
							echo $room ? esc_html( $room ) : '-'; ?>
                        </div>
					<?php endif; ?>

					<?php if ( 'on' === ( $pos_settings['fmp_food_location_popup'] ?? '' ) ) : ?>
                        <div class="item order-meta-location">
							<?php
							$loc_name = $order->get_meta( 'fmp_location_name' );
							if ( $loc_name ) : ?>
								<span style="display:inline-block;padding:1px 8px;background:#52c41a;border-radius:4px;color:#fff;font-size:12px;font-weight:bold;"><?php echo esc_html( $loc_name ); ?></span>
							<?php else : ?>
								-
							<?php endif; ?>
                        </div>
					<?php endif; ?>

					<?php if ( $show_table_column ) : ?>
                        <div class="item order-meta-qr-table">
							<?php
							// QR table wins when both are present; dine-in gets its
							// own colour so staff can tell the two apart at a glance.
							$qr_table     = $order->get_meta( 'fmp_qr_table_name' );
							$table_label  = $qr_table ?: $order->get_meta( 'fmp_dinein_table' );
							$table_bg     = $qr_table ? '#1677ff' : '#b8860b';
							if ( $table_label ) :
								?>
								<span style="display:inline-block;padding:1px 8px;background:<?php echo esc_attr( $table_bg ); ?>;border-radius:4px;color:#fff;font-size:12px;font-weight:bold;"><?php echo esc_html( $table_label ); ?></span>
							<?php else : ?>
								-
							<?php endif; ?>
                        </div>
					<?php endif; ?>

                    <div class="item order-meta-total">
						<?php echo $order->get_total(); ?>
                    </div>

                    <div class="item order-status-item fm-order-status">
                        <select class="order-status status-<?php echo esc_attr( strtolower( str_replace( ' ', '-', wc_get_order_status_name( $order->get_status() ) ) ) ); ?>">
							<?php foreach ( wc_get_order_statuses() as $status_key => $status_label ) :
								if ( in_array( $status_key, [ 'wc-failed', 'wc-checkout-draft' ] ) ) {
									continue;
								}
								?>
                                <option value="<?php echo esc_attr( str_replace( 'wc-', '', $status_key ) ); ?>" <?php selected( $order->get_status(), str_replace( 'wc-', '', $status_key ) ); ?>>
									<?php echo esc_html( $status_label ); ?>
                                </option>
							<?php endforeach; ?>
                        </select>
                    </div>
					<?php if ( $pos_printing_enabled ) : ?>
                        <div class="item order-print">
                            <div class="fmp-slip-buttons" data-order-id="<?php echo esc_attr( $order->get_id() ); ?>">
								<?php foreach ( $slip_types as $slug => $label ) : ?>
                                    <button type="button"
                                        class="fmp-print-slip<?php echo $slug === $default_slip ? ' active' : ''; ?>"
                                        data-slip="<?php echo esc_attr( $slug ); ?>"
                                        title="<?php echo esc_attr( $label ); ?>">
										<span class="dashicons <?php echo esc_attr( \RT\FoodMenuPro\Controllers\PosPrinting\PosPrinting::slip_dashicon( $slug ) ); ?>"></span>
                                    </button>
								<?php endforeach; ?>
                            </div>
                        </div>
					<?php endif; ?>
                    <div class="item order-actions">
                        <button class="button fm-view-order" data-order-id="<?php echo esc_attr( $order->get_id() ); ?>">
							<?php _e( 'View Order', 'food-menu-pro' ); ?>
                        </button>
                    </div>
                </div>
			<?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <div class="fm-orders-pagination">
			<?php

			$total_pages = $orders->max_num_pages;
			if ( $total_pages > 1 ) {

				// Get the current page URL (frontend page where orders are displayed)
				$current_url = get_permalink( FnsPro::get_frontend_order_page() );

				echo paginate_links( [
					'base'      => add_query_arg( 'current', '%#%', $current_url ),
					'format'    => '',
					'current'   => $paged,
					'total'     => $total_pages,
					'prev_text' => __( '« Prev', 'food-menu-pro' ),
					'next_text' => __( 'Next »', 'food-menu-pro' ),
				] );
			}
			?>
        </div>
		<?php
		wp_die();
	}


	/**
	 * Update Order Status only by selecting the Select from the table
	 *
	 * @return void
	 */
	public static function fm_update_order_status() {
		if ( ! FnsPro::has_order_manage_capability() ) {
			wp_send_json_error( __( 'Permission denied.', 'food-menu-pro' ) );
		}

		check_ajax_referer( 'fm_order_update_nonce', '_ajax_nonce' );

		$order_id   = intval( $_POST['order_id'] ?? 0 );
		$new_status = sanitize_text_field( $_POST['new_status'] ?? '' );

		if ( ! $order_id || ! $new_status ) {
			wp_send_json_error( __( 'Invalid request.', 'food-menu-pro' ) );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order || 'shop_order' !== $order->get_type() || ! FnsPro::order_matches_allowed_locations( $order, FnsPro::get_user_allowed_locations() ) ) {
			wp_send_json_error( __( 'Order not found.', 'food-menu-pro' ) );
		}

		$old_status = $order->get_status();
		$order->update_meta_data( 'preview_manager', '1' );

		//FnsPro::update_product_stocks_on_status_change( $order, $old_status, $new_status );

		// Update status
		$order->update_status( $new_status );

		wp_send_json_success( [
			'message' => __( 'Order updated successfully.', 'food-menu-pro' ),
			'status'  => wc_get_order_status_name( $order->get_status() ),
		] );
	}

	public static function fm_update_bulk_order_cbf() {
		if ( ! FnsPro::has_order_manage_capability() ) {
			wp_send_json_error( __( 'Permission denied.', 'food-menu-pro' ) );
		}

		check_ajax_referer( 'fm_order_update_nonce', '_ajax_nonce' );

		$requestAction = ! empty( $_REQUEST['requestAction'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['requestAction'] ) ) : '';
		$sendValue     = ! empty( $_REQUEST['sendValue'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['sendValue'] ) ) : '';
		$orderIds      = ! empty( $_REQUEST['orderIds'] ) ? array_map( 'sanitize_text_field', $_REQUEST['orderIds'] ) : [];

		if ( ! is_array( $orderIds ) || ! $orderIds ) {
			wp_send_json_error( __( 'Order not found.', 'food-menu-pro' ) );
		}

		$allowed = FnsPro::get_user_allowed_locations();

		foreach ( $orderIds as $order_id ) {
			$orderId = intval( $order_id );
			$order   = wc_get_order( $orderId );
			if ( ! $order || 'shop_order' !== $order->get_type() || ! FnsPro::order_matches_allowed_locations( $order, $allowed ) ) {
				continue;
			}
			$order->update_meta_data( 'preview_manager', '1' );
			if ( 'status' == $requestAction ) {
				$order->update_status( $sendValue );
			}

			if ( 'trash' == $requestAction ) {
				$order->delete();
			}

		}

		wp_send_json_success( [
			'message' => __( 'Order updated successfully.', 'food-menu-pro' ),
			'status'  => $order ? wc_get_order_status_name( $order->get_status() ) : '',
		] );
	}

	public static function new_orders_args( $args ) {
		$last_24_hours = new \WC_DateTime();
		$last_24_hours->modify( '-24 hours' );

		unset( $args['meta_query'] );

		$args['meta_query'] = [
			'relation' => 'OR',
			[
				'key'     => 'preview_manager',
				'compare' => 'NOT EXISTS',
			],
			[
				'key'     => 'preview_manager',
				'value'   => '1',
				'compare' => '!=',
			],
		];

		$args['date_created'] = '>=' . $last_24_hours->format( 'Y-m-d H:i:s' );

		return $args;
	}

	public static function fm_check_new_orders_callback() {
		if ( ! FnsPro::has_order_manage_capability() ) {
			wp_send_json_error( __( 'Permission denied.', 'food-menu-pro' ) );
		}
		// Check for new orders in the last 1 minute

		// 'status'       => [ 'processing', 'on-hold', 'completed' ],
		$args = [
			'limit'  => - 1,
			'return' => 'ids',
			'type'   => 'shop_order',
			'status' => 'wc-pending'
		];

		$args   = self::new_orders_args( $args );
		$orders = wc_get_orders( FnsPro::order_query_args( $args ) );

		$count = count( $orders );


		wp_send_json_success( [
			'order_ids' => $orders,
			'count'     => $count,
			'message'   => $count > 0 ? $count . ' new order(s)' : '',
		] );
	}
}