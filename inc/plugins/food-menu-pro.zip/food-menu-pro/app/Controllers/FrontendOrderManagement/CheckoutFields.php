<?php

namespace RT\FoodMenuPro\Controllers\FrontendOrderManagement;

use RT\FoodMenuPro\Helpers\FnsPro;
use \RT\FoodMenuPro\Traits\SingletonTrait;

class CheckoutFields {

	use SingletonTrait;

	public function __construct() {
		$this->add_hotel_room_number_checkout();
	}


	public function add_hotel_room_number_checkout() {
		add_filter( 'woocommerce_checkout_fields', function ( $fields ) {
			$available_rooms                        = FnsPro::get_available_rooms();
			if(! $available_rooms) {
				return $available_rooms;
			}
			$fields['billing']['hotel_room_number'] = [
				'type'     => 'select',
				'label'    => __( 'Hotel Room Number', 'food-menu-pro' ),
				'required' => true,
				'class'    => [ 'form-row-wide' ],
				'options'  => $available_rooms,
				'priority' => 25,
			];

			return $fields;
		} );

		// Save hotel room field
		// Save checkout field to order meta
		add_action( 'woocommerce_checkout_update_order_meta', function ( $order_id ) {
			if ( ! empty( $_POST['hotel_room_number'] ) ) {
				$order = wc_get_order( $order_id );
				if ( $order ) {
					$order->update_meta_data( '_hotel_room_number', sanitize_text_field( $_POST['hotel_room_number'] ) );
					$order->save(); // IMPORTANT: must save after update_meta_data()
				}
			}
		} );

		// Show in admin order
		add_action( 'woocommerce_admin_order_data_after_billing_address', function ( $order ) {
			$room = $order->get_meta( '_hotel_room_number' );
			if ( $room ) {
				echo '<p><strong>' . __( 'Hotel Room:', 'food-menu-pro' ) . '</strong> ' . esc_html( $room ) . '</p>';
			}
		}, 10, 1 );

		// Add to emails
		add_filter( 'woocommerce_email_order_meta_fields', function ( $fields, $sent_to_admin, $order ) {
			$room = $order->get_meta( '_hotel_room_number' );
			if ( $room ) {
				$fields['hotel_room_number'] = [
					'label' => __( 'Hotel Room Number', 'food-menu-pro' ),
					'value' => $room,
				];
			}
			return $fields;
		}, 10, 3 );
	}
}