<?php
/**
 * This Class responsible for modify anything from the Right Popup modal
 * Update Order
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers\FrontendOrderManagement;

use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenuPro\Controllers\PosPrinting\PosPrintingFns;
use RT\FoodMenuPro\Traits\SingletonTrait;

class CRUD_Order {
	use SingletonTrait;

	/**
	 * Class constructor.
	 */

	private static $settings;

	public function __construct() {
		add_filter( 'body_class', function ( $classes ) {
			// Add custom class
			if ( isset( $_GET['show-report'] ) && $_GET['show-report'] == 1 ) {
				$classes[] = 'fm-order-report';
			}

			return $classes;
		} );

		//popup order ajax
		add_action( 'wp_ajax_fm_get_order_details', [ __CLASS__, 'fm_get_order_details' ] );

		//update all data
		add_action( 'wp_ajax_fm_create_update_order', [ __CLASS__, 'fm_create_update_order' ] );

		//add order items
		add_action( 'wp_ajax_fm_add_item_search_products', [ __CLASS__, 'fm_add_item_search_products' ] );
		add_action( 'wp_ajax_fm_add_item_in_order', [ __CLASS__, 'fm_add_item_in_order' ] );
		add_action( 'wp_ajax_fm_update_item_in_order', [ __CLASS__, 'fm_update_item_in_order' ] );
		add_action( 'wp_ajax_fm_update_item_price_order', [ __CLASS__, 'fm_update_item_price_order' ] );
		add_action( 'wp_ajax_fm_order_recalculate', [ __CLASS__, 'fm_order_recalculate' ] );

		//Update product stock
		add_action( 'wp_ajax_fm_delete_item_from_order', [ __CLASS__, 'fm_delete_item_from_order' ] );

	}

	public static function get_existing_product( $number = 10 ) {

		$args = [
			'status' => 'publish',
			'limit'  => $number, // get all products
		];

		$products = wc_get_products( $args );

		foreach ( $products as $product ) {
			$product_id   = $product->get_id();
			$product_name = $product->get_name();
			$stock_status = $product->get_stock_status();

			$li_style    = '';
			$stock_label = '';

			if ( $stock_status === 'outofstock' ) {
				$li_style    = 'background-color:#CCC;color:#999;pointer-events:none;';
				$stock_label = '<span style="font-size:.8em;color:red">Out of Stock</span>';
			} elseif ( $stock_status === 'instock' ) {
				$stock_label = '<span style="font-size:.8em;color:green">In Stock</span>';
			} elseif ( $stock_status === 'onbackorder' ) {
				$stock_label = '<span style="font-size:.8em;color:orange">On Backorder</span>';
			}

			if ( $product->managing_stock() ) {
				$stock_qty = $product->get_stock_quantity();
				if ( $product->get_stock_quantity() > 0 ) {
					$stock_label = '<span style="font-size:.8em;color:green">In Stock</span>' . "( $stock_qty )";
				}
			}

			?>
            <li class="suggestion-item" style="<?php echo esc_attr( $li_style ); ?>"
                data-name="<?php echo esc_attr( $product_name ); ?>"
                data-stock="<?php echo esc_attr( $stock_status ); ?>"
                data-id="<?php echo esc_attr( $product_id ); ?>">
                [#<?php echo esc_html( $product_id ); ?>]
				<?php echo esc_html( $product_name ); ?> - <?php echo $stock_label; ?>
            </li>
		<?php } ?>
		<?php
	}

	/**
	 * Get product stock info
	 *
	 * Returns stock quantity if managing stock, otherwise the stock status label.
	 *
	 * @param $product
	 *
	 * @return string|int
	 */
	public static function get_product_stock_info( $product ) {
		if ( ! $product ) {
			return 'N/A';
		}

		// If stock is managed, return quantity
		if ( $product->managing_stock() ) {
			return $product->get_stock_quantity();
		}

		// Otherwise return human-readable stock status
		$stock_status_array = wc_get_product_stock_status_options();
		$product_status     = $product->get_stock_status();

		return isset( $stock_status_array[ $product_status ] ) ? $stock_status_array[ $product_status ] : 'N/A';
	}

	public static function fm_get_order_details() {
		if ( ! FnsPro::has_order_manage_capability() ) {
			wp_send_json_error( __( 'Permission denied.', 'food-menu-pro' ) );
		}

		$order_id   = intval( $_POST['order_id'] ?? 0 );
		$formAction = sanitize_text_field( $_POST['formAction'] ?? 'view' );

		if ( 'new' !== $formAction && $order_id ) {
			self::ensure_staff_can_edit( $order_id );
		}

		$order        = null;
		$is_new_order = false;

		if ( $formAction === 'new' ) {
			// New order: don't create order yet, just render blank form
			$order = wc_create_order( [ 'status' => 'pending' ] );
			/*$order->set_status( 'pending' ); //auto-draft
			$order->save();*/
			if ( is_wp_error( $order ) ) {
				wp_send_json_error( __( 'Failed to create order.', 'food-menu-pro' ) );
			}

			$is_new_order = true;
		} elseif ( $order_id ) {
			// Existing order: load the order
			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				wp_send_json_error( __( 'Order not found', 'food-menu-pro' ) );
			}
		} else {
			wp_send_json_error( __( 'Invalid order ID', 'food-menu-pro' ) );
		}
		// Order Details Markup
		ob_start();
		?>
        <form id="fm-order-form">
            <div class="order-popup-wrapper">
                <header class="popup-header">
                    <h3>
						<?php printf( __( 'Order #%d Details %s', 'food-menu-pro' ), $order->get_id(), $order->get_status() ) ?>
                    </h3>

                    <p class="description">
						<?php printf( __( 'Created on %s', 'food-menu-pro' ), wc_format_datetime( $order->get_date_created() ) ); ?>
                    </p>
                </header>

                <div class="order-details-inner <?php echo esc_attr( $order->get_status() ) ?>" data-order-id="<?php echo esc_attr( $order->get_id() ); ?>">
                    <input type="hidden" name="order_id" value="<?php echo esc_attr( $order->get_id() ); ?>">
                    <input type="hidden" name="is_new" value="<?php echo esc_attr( $is_new_order ? 'new' : 'old' ); ?>">

                    <!-- Order Status -->
                    <div class="order-details-section">
                        <h4><?php _e( 'Order Status', 'food-menu-pro' ); ?></h4>
                        <select class="order-status" name="status">
							<?php foreach ( wc_get_order_statuses() as $status_key => $status_label ) :
								if ( in_array( $status_key, [ 'wc-failed', 'wc-checkout-draft' ] ) ) {
									continue;
								}
								?>
                                <option value="<?php echo esc_attr( str_replace( 'wc-', '', $status_key ) ); ?>"
									<?php echo ! $is_new_order && selected( $order->get_status(), str_replace( 'wc-', '', $status_key ) ); ?>>
									<?php echo esc_html( $status_label ); ?>
                                </option>
							<?php endforeach; ?>
                        </select>
                    </div>
					<?php
					$available_rooms = FnsPro::get_available_rooms();
					$existing_room   = $order->get_meta( '_hotel_room_number' );
					if ( ! empty( $available_rooms ) ) :
						?>

                        <div class="order-details-section">
                            <h4><?php _e( 'Room Number', 'food-menu-pro' ); ?></h4>

                            <select class="hotel-room-number" name="hotel_room_number">
                                <option value=""><?php echo esc_html__( "Select Room", "food-menu-pro" ) ?></option>
								<?php foreach ( $available_rooms as $id => $room ) : ?>
                                    <option value="<?php echo esc_attr( $id ); ?>"
										<?php echo ! $is_new_order && selected( $existing_room, $id ); ?>>
										<?php echo esc_html( $room ); ?>
                                    </option>
								<?php endforeach; ?>
                            </select>
                        </div>
					<?php endif; ?>
                    <!-- Customer Info -->
                    <div class="order-details-section">
                        <h4><?php _e( 'Customer', 'food-menu-pro' ); ?></h4>
						<?php
						$fields = [
							'billing_first_name' => __( 'First Name', 'food-menu-pro' ),
							'billing_last_name'  => __( 'Last Name', 'food-menu-pro' ),
							'billing_email'      => __( 'Email', 'food-menu-pro' ),
							'billing_phone'      => __( 'Phone', 'food-menu-pro' ),
						];
						foreach ( $fields as $key => $label ) :
							$value = $is_new_order ? '' : esc_attr( $order->{"get_$key"}() );
							?>
                            <div class="order-details-row">
                                <label><?php echo $label; ?></label>
                                <input type="text" name="<?php echo $key; ?>" value="<?php echo $value; ?>">
                            </div>
						<?php endforeach; ?>
                    </div>

                    <!-- Billing & Shipping -->
					<?php
					$addresses = [
						'Billing'  => [
							'billing_address_1',
							'billing_address_2',
							'billing_city',
							'billing_state',
							'billing_postcode',
							'billing_country'
						],
						'Shipping' => [
							'shipping_address_1',
							'shipping_address_2',
							'shipping_city',
							'shipping_state',
							'shipping_postcode',
							'shipping_country'
						]
					];
					foreach ( $addresses as $title => $fields_arr ) :
						?>
                        <div class="order-details-section">
                            <h4><?php echo $title . ' ' . __( 'Address', 'food-menu-pro' ); ?></h4>
							<?php foreach ( $fields_arr as $field ) :
								$value = $is_new_order ? '' : esc_attr( $order->{"get_$field"}() );
								$label = ucwords( str_replace( [ 'billing_', 'shipping_', '_' ], [ '', '', ' ' ], $field ) );
								?>
                                <div class="order-details-row">
                                    <strong><?php echo $label; ?>:</strong>
                                    <input type="text" name="<?php echo $field; ?>" value="<?php echo $value; ?>">
                                </div>
							<?php endforeach; ?>
                        </div>
					<?php endforeach; ?>

                    <!-- Customer Note -->
                    <div class="order-details-section">
                        <h4><?php _e( 'Customer Note', 'food-menu-pro' ); ?></h4>
                        <div class="order-details-row">
                            <textarea name="customer_note" placeholder="Customer notes about the order"><?php echo $is_new_order ? '' : esc_html( $order->get_customer_note() ); ?></textarea>
                        </div>
                    </div>

                    <!-- Items -->
                    <div class="order-details-section">
                        <h4><?php _e( 'Items', 'food-menu-pro' ); ?></h4>

                        <div style="margin-bottom: 5px;"><strong><?php _e( 'Add Items in the order:', 'food-menu-pro' ); ?></strong></div>

                        <div class="fm-add-item-input">
                            <input type="text" class="new-item-name" placeholder="Please enter 3 or more characters to add item in order">
                            <ul class="product-suggestions"></ul>
                        </div>

                        <table class="order-items-table widefat">
                            <thead>
                            <tr>
                                <th><?php _e( 'Product', 'food-menu-pro' ); ?></th>
                                <th style="width: 90px"><?php _e( 'Stock', 'food-menu-pro' ); ?></th>
                                <th style="width: 40px"><?php _e( 'Quantity', 'food-menu-pro' ); ?></th>
                                <th style="width: 200px"><?php _e( 'Unit Price', 'food-menu-pro' ); ?></th>
                                <th style="width:40px"><?php _e( 'Action', 'food-menu-pro' ); ?></th>
                            </tr>
                            </thead>
                            <tbody class="order-items-body">
							<?php
							$edit_capability = ( ! $is_new_order && 'refunded' === $order->get_status() ) ? 'no-edit' : '';

							if ( ! $is_new_order ) :

								foreach ( $order->get_items() as $item_id => $item ) :
									$pId = $item->get_product_id();
									$product = $item->get_product();

									$has_stock_enable = $product ? ( $product->managing_stock() ? "has-stock" : "no-stock" ) : null;
									$stock            = self::get_product_stock_info( $product );
									$max              = ( is_numeric( $stock ) && $stock > 0 ) ? "max=$stock" : '';
									$stock_class      = str_replace( ' ', '', strtolower( $stock ) );
									$stock_class      = is_numeric( $stock_class ) && $stock_class > 0 ? 'instock' : $stock_class;

									?>
                                    <tr data-item-id="<?php echo esc_attr( $item_id ); ?>">
                                        <td>
                                            <input class="fm-product-name" readonly type="text" name="items[<?php echo esc_attr( $item_id ); ?>][name]" value="<?php echo esc_attr( $item->get_name() ); ?>" style="width:100%;">
                                            <input class="fm-product-id" type="hidden" name="items[<?php echo esc_attr( $item_id ); ?>][product_id]" value="<?php echo esc_attr( $pId ); ?>">
											<?php
											$item_addons = [];
											foreach ( $item->get_meta_data() as $meta ) {
												if ( str_starts_with( $meta->key, '_' ) ) {
													continue;
												}
												$item_addons[] = [
													'name'  => wp_strip_all_tags( $meta->key ),
													'value' => wp_strip_all_tags( $meta->value ),
												];
											}
											if ( ! empty( $item_addons ) ) :
												?>
												<div class="fm-order-item-addons" style="margin-top:6px;padding:6px 8px;background:#f8f9fa;border-radius:4px;border-left:3px solid #ddd;">
													<?php foreach ( $item_addons as $item_addon ) : ?>
														<div style="font-size:0.85em;color:#555;line-height:1.4;padding:3px 0;border-bottom:1px solid #eee;">
															<strong style="color:#333;margin-right:4px;"><?php echo esc_html( $item_addon['name'] ); ?>:</strong>
															<?php echo esc_html( $item_addon['value'] ); ?>
														</div>
													<?php endforeach; ?>
												</div>
											<?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="stock-quantity <?php echo esc_attr( $stock_class ) ?>"><?php echo esc_html( $stock ); ?></span>
                                        </td>
                                        <td>
                                            <input class="fm-product-qty" type="number" name="items[<?php echo esc_attr( $item_id ); ?>][qty]" value="<?php echo esc_attr( $item->get_quantity() ); ?>" data-old-value="<?php echo esc_attr( $item->get_quantity() ); ?>" min="1" <?php echo esc_attr( $max ) ?> style="width:40px;">
                                        </td>
                                        <td>
											<?php $unit_price = $item->get_total() / max( 1, $item->get_quantity() ); ?>
                                            <input type="text" class="fm-product-price"
                                                   name="items[<?php echo esc_attr( $item_id ); ?>][price]"
                                                   data-unit-price="<?php echo esc_attr( $unit_price ); ?>"

                                                   value="<?php echo esc_attr( $unit_price ); ?>"
                                                   style="width:100%;">
                                        </td>
                                        <td>
                                            <a class="fm-delete-order-item <?php echo esc_attr( $has_stock_enable ); ?> tips" href="#" aria-label="Delete item">×</a>
                                        </td>
                                    </tr>
								<?php endforeach;
							endif; ?>
                            </tbody>
                        </table>

                        <div class="fm-order-total">
							<?php

							// Correct way: calculate subtotal from items
							$items_subtotal = 0;
							foreach ( $order->get_items() as $item ) {
								$items_subtotal += $item->get_subtotal(); // item subtotal (qty x price)
							}

							// Total (final total including taxes, shipping, fees)
							$total = $order->get_total();

							?>
                            <div id="fm-order-price-total">
                                <div class="item-sub-total">
                                    <span><?php echo esc_html__( 'Items Subtotal', 'food-menu-pro' ) ?></span>
									<?php echo wc_price( $items_subtotal ) ?>
                                </div>

                                <div class="item-total">
                                    <span><?php echo esc_html__( 'Order Total', 'food-menu-pro' ) ?></span>
									<?php echo wc_price( $total ); ?>
                                </div>
                            </div>

							<?php if ( 'no-edit' !== $edit_capability ) : ?>
                                <button id="fm-order-recalculate"><?php echo esc_html__( 'Recalculate', 'food-menu-pro' ) ?></button>
							<?php endif; ?>
                        </div>

						<?php if ( FnsPro::is_editable_order( $order->get_status() ) ) {
							?>
                            <div class="fm-order-notice">
                                <div><strong><?php printf( "%s %s", esc_html__( "The Order Has Been " ), ucfirst( $order->get_status() ) ) ?></strong></div>
								<?php echo esc_html__( "This order is no longer editable. To edit this order change the status back to Pending payment.", "food-menu-pro" ); ?>
                            </div>
							<?php
						} ?>

                    </div>

                </div>

                <footer class="popup-footer">
                    <div class="order-details-row">
                        <button type="submit" class="button fm-update-order"><?php _e( 'Save Changes', 'food-menu-pro' ); ?></button>
						<?php
						$pos_settings         = FnsPro::get_settings_option();
						$pos_printing_enabled = 'on' === ( $pos_settings['fmp_enable_pos_printing'] ?? '' );

						if ( $pos_printing_enabled ) :
							$slip_types    = PosPrintingFns::slip_types();
							$default_slip  = $pos_settings['fmp_default_slip_type'] ?? 'order_confirmation';
							$default_label = $slip_types[ $default_slip ] ?? $slip_types['order_confirmation'];
							?>
                            <div class="fmp-modal-print-actions" data-order-id="<?php echo esc_attr( $order->get_id() ); ?>">
                                <button type="button" class="button fmp-print-default-slip" title="<?php echo esc_attr( $default_label ); ?>">
                                    <span class="dashicons dashicons-printer"></span>
									<?php esc_html_e( 'Print Slips', 'food-menu-pro' ); ?>
                                </button>
                                <div class="fmp-slip-dropdown">
                                    <button type="button" class="fmp-slip-dropdown-toggle" title="<?php esc_attr_e( 'Change slip type', 'food-menu-pro' ); ?>">
                                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                                    </button>
                                    <ul class="fmp-slip-dropdown-menu">
										<?php foreach ( $slip_types as $slug => $label ) : ?>
                                            <li>
                                                <a href="#" class="fmp-print-slip-option" data-slip="<?php echo esc_attr( $slug ); ?>" title="<?php echo esc_attr( $label ); ?>">
													<?php echo esc_html( $label ); ?>
                                                </a>
                                            </li>
										<?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
						<?php endif; ?>
                    </div>
                    <div class="order-message"></div>
                </footer>
            </div>
        </form>
		<?php

		wp_send_json_success( ob_get_clean() );
	}

	public static function fm_create_update_order() {
		if ( ! FnsPro::has_order_manage_capability() ) {
			wp_send_json_error( __( 'Permission denied.', 'food-menu-pro' ) );
		}

		// Check nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'fm_order_update_nonce' ) ) {
			wp_send_json_error( 'Invalid nonce' );
		}

		$order_id     = intval( $_POST['order_id'] ?? 0 );
		$is_new_order = ( isset( $_POST['is_new'] ) ? sanitize_text_field( $_POST['is_new'] ) : 'old' ) === 'new';

		self::ensure_staff_can_edit( $order_id );

		//The Order ID should always come from the Form Submit
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( 'Order not found' );
		}

		if ( ! empty( $_POST['hotel_room_number'] ) ) {
			$order->update_meta_data( '_hotel_room_number', sanitize_text_field( $_POST['hotel_room_number'] ) );
		}

		$old_status = $order->get_status();

		// Update order status
		$new_status = isset( $_POST['status'] ) ? sanitize_text_field( $_POST['status'] ) : null;


		if ( $new_status ) {
			$order->update_status( $new_status, 'Updated via custom form' );
		}

		if ( ! $is_new_order || 'pending' === $new_status ) {
			$order->update_meta_data( 'preview_manager', '1' );
		}


		// Update customer info
		$fields = [
			'billing_first_name',
			'billing_last_name',
			'billing_email',
			'billing_phone',
			'billing_address_1',
			'billing_address_2',
			'billing_city',
			'billing_state',
			'billing_postcode',
			'billing_country',
			'shipping_address_1',
			'shipping_address_2',
			'shipping_city',
			'shipping_state',
			'shipping_postcode',
			'shipping_country',
			'customer_note'
		];

		foreach ( $fields as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				$order->{"set_$field"}( sanitize_text_field( $_POST[ $field ] ) );
			}
		}
		$stock_updated = true;
		/*if ( ! $is_new_order ) {
			FnsPro::update_product_stocks_on_status_change( $order, $old_status, $new_status );
		}*/

		$order->calculate_totals();
		$order->save();

		$_message = $is_new_order ? 'Order created successfully' : 'Order updated successfully';

		wp_send_json_success( [ 'message' => $_message ] );
	}

	public static function fm_add_item_search_products() {
		self::ensure_staff_can_edit();

		if ( ! isset( $_POST['_ajax_nonce'] ) || ! wp_verify_nonce( $_POST['_ajax_nonce'], 'fm_order_update_nonce' ) ) {
			wp_send_json_error( 'Invalid nonce' );
		}

		$query = sanitize_text_field( $_POST['query'] ?? '' );

		if ( strlen( $query ) < 3 ) {
			wp_send_json_error( 'Query too short' );
		}

		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 10,
			's'              => $query,
		];

		$products = get_posts( $args );
		$results  = [];

		foreach ( $products as $product_post ) {
			$product = wc_get_product( $product_post->ID );

			$stock_status = $product->get_stock_status();

			$stock = '';
			if ( $product->managing_stock() ) {
				$stock = $product->get_stock_quantity();
			}
			$results[] = [
				'id'           => $product->get_id(),
				'name'         => $product->get_name(),
				'enable_stock' => $product->managing_stock(),
				'stock'        => $stock,
				'stock_status' => $stock_status,
			];
		}

		if ( empty( $results ) ) {
			$results = [
				'message' => "No matching found",
			];
		}

		wp_send_json_success( $results );
	}

	public static function fm_add_item_in_order() {
		check_ajax_referer( 'fm_order_update_nonce', '_ajax_nonce' );
		self::ensure_staff_can_edit( absint( $_POST['order_id'] ?? 0 ) );
		$order_id   = intval( $_POST['order_id'] );
		$product_id = intval( $_POST['product_id'] );
		$product    = wc_get_product( $product_id );
		$order      = wc_get_order( $order_id );

		if ( ! $product || ! $order ) {
			wp_send_json_error( 'Product or Order Invalid' );
		}
		$price = $product->get_price();
		$qty   = 1;

		$item = new \WC_Order_Item_Product();
		$item->set_product_id( $product_id );
		$item->set_name( $product->get_name() );
		$item->set_quantity( 1 );
		$item->set_subtotal( $price * $qty );
		$item->set_total( $price * $qty );
		$order->add_item( $item );
		$order->calculate_totals();
		$item->save();

		//wc_update_product_stock( $product, 1, 'decrease' );

		$stock       = self::get_product_stock_info( $product );
		$stock_class = str_replace( ' ', '', strtolower( $stock ) );
		$stock_class = is_numeric( $stock_class ) && $stock_class > 0 ? 'instock' : $stock_class;

		$newRow = <<<HTML
<tr data-item-id="{$item->get_id()}">
    <td>
        <input type="text" name="items[{$item->get_id()}][name]" value="{$product->get_name()}" style="width:100%;" readonly>
        <input class="fm-product-id" type="hidden" name="items[{$item->get_id()}][product_id]" value="{$product->get_id()}" style="width:100%;">
    </td>
    <td>
        <span class="stock-quantity $stock_class">$stock</span>
    </td>
    <td>
        <input type="number" class="fm-product-qty" name="items[{$item->get_id()}][qty]" value="1" data-old-value="1" min="1" max="{$stock}" style="width:40px;">
    </td>
    <td>
        <input type="text" class="fm-product-price" name="items[{$item->get_id()}][price]" value="{$price}" style="width:100%;">
    </td>
    <td>
        <a class="fm-delete-order-item tips" href="#" aria-label="Delete item">×</a>
    </td>
</tr>
HTML;

		wp_send_json_success( [
			'html' => $newRow
		] );

	}

	public static function fm_update_item_in_order() {
		check_ajax_referer( 'fm_order_update_nonce', '_ajax_nonce' );
		self::ensure_staff_can_edit( absint( $_POST['order_id'] ?? 0 ) );

		$item_id    = intval( $_POST['item_id'] );
		$order_id   = intval( $_POST['order_id'] );
		$product_id = intval( $_POST['product_id'] );
		$unit_price = max( 0, (float) ( $_POST['unit_price'] ?? 0 ) );
		$old_qty    = intval( $_POST['old_qty'] );
		$new_qty    = max( 1, intval( $_POST['new_qty'] ) );

		$product = wc_get_product( $product_id );
		$order   = wc_get_order( $order_id );

		if ( ! $product || ! $order ) {
			wp_send_json_error( 'Product or Order Invalid' );
		}

		// Get the existing order item
		$item = $order->get_item( $item_id );

		if ( ! $item ) {
			wp_send_json_error( 'Order item not found' );
		}

		$price = $unit_price;
		$qty   = $new_qty;

		// Update the item fields
		$item->set_name( $product->get_name() );
		$item->set_product_id( $product_id );
		$item->set_quantity( $qty );
		$item->set_subtotal( $price * $qty );
		$item->set_total( $price * $qty );

		$item->save();

// Recalculate order totals after modification
		$order->calculate_totals();
		$order->save();

		$updated_stock = '';
		/*if ( $product->managing_stock() ) {
			$qty_diff = $new_qty - $old_qty;
			if ( $qty_diff > 0 ) {
				// Order increased → decrease stock
				wc_update_product_stock( $product, $qty_diff, 'decrease' );
			} elseif ( $qty_diff < 0 ) {
				// Order decreased → increase stock
				wc_update_product_stock( $product, abs( $qty_diff ), 'increase' );
			}
			// Refresh the product object
			$product       = wc_get_product( $product->get_id() );
			$updated_stock = $product->get_stock_quantity();
		}*/

		$product       = wc_get_product( $product->get_id() );
		$updated_stock = $product->get_stock_quantity();

		wp_send_json_success( [
			'stock_quantity' => $updated_stock,
			'message'        => 'Order item updated successfully'
		] );

	}

	public static function fm_update_item_price_order() {
		check_ajax_referer( 'fm_order_update_nonce', '_ajax_nonce' );
		self::ensure_staff_can_edit( absint( $_POST['order_id'] ?? 0 ) );

		$item_id    = intval( $_POST['item_id'] );
		$order_id   = intval( $_POST['order_id'] );
		$product_id = intval( $_POST['product_id'] );
		$price      = max( 0, floatval( $_POST['price'] ) );
		$quantity   = max( 1, absint( $_POST['quantity'] ) );

		$product = wc_get_product( $product_id );
		$order   = wc_get_order( $order_id );

		if ( ! $product || ! $order ) {
			wp_send_json_error( 'Product or Order Invalid' );
		}

		// Get the existing order item
		$item = $order->get_item( $item_id );

		if ( ! $item ) {
			wp_send_json_error( 'Order item not found' );
		}

		// Update the item fields
		$item->set_name( $product->get_name() );
		$item->set_product_id( $product_id );
		$item->set_quantity( $quantity );
		$item->set_subtotal( $price * $quantity );
		$item->set_total( $price * $quantity );

		$item->save();

		// Recalculate order totals after modification
		$order->calculate_totals();
		$order->save();

		wp_send_json_success( [
			'message' => 'Order item updated successfully'
		] );

	}


	public static function fm_order_recalculate() {
		check_ajax_referer( 'fm_order_update_nonce', '_ajax_nonce' );
		self::ensure_staff_can_edit( absint( $_POST['order_id'] ?? 0 ) );


		$order_id = intval( $_POST['order_id'] );

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			wp_send_json_error( 'Product or Order Invalid' );
		}

		// Recalculate order totals after modification
		$order->calculate_totals();

		$subtotal = wc_price( $order->get_subtotal() );
		$total    = wc_price( $order->get_total() );

		$subtotal_label = __( 'Items Subtotal', 'food-menu-pro' );
		$total_label    = __( 'Order Total', 'food-menu-pro' );

		$html = <<<HTML
<div class="item-sub-total"><span>$subtotal_label:</span>{$subtotal}</div>
<div class="item-total"><span>$total_label:</span>{$total}</div>
HTML;

		wp_send_json_success( [
			'html'    => $html,
			'message' => 'Order item updated successfully'
		] );

	}


	public static function fm_delete_item_from_order() {
		check_ajax_referer( 'fm_order_update_nonce', '_ajax_nonce' );
		self::ensure_staff_can_edit( absint( $_POST['order_id'] ?? 0 ) );

		$product_id   = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$quantity     = isset( $_POST['quantity'] ) ? absint( $_POST['quantity'] ) : 0;
		$order_id     = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$item_id      = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
		$stock_enable = isset( $_POST['stock_enable'] ) ? sanitize_text_field( wp_unslash( $_POST['stock_enable'] ) ) : 'no';

		$order   = wc_get_order( $order_id );
		$product = wc_get_product( $product_id );

		if ( ! $order ) {
			wp_send_json_error( [ 'message' => 'Order not found' ] );
		}

		$item = $order->get_item( $item_id );

		if ( $item ) {
			// Use item quantity if not passed (more reliable than trusting $_POST['quantity'])
			$qty = $quantity > 0 ? $quantity : $item->get_quantity();

			// Restore stock before removing the item
//			if ( $stock_enable === 'yes' && $qty > 0 ) {
//				wc_update_product_stock( $product, $qty, 'increase' );
//			}

			// Ensure totals exist for the item even if no product
//			if ( ! $item->get_total() ) {
//				$item->set_total( $item->get_subtotal() );
//			}

			// Remove the item
			$order->remove_item( $item_id );
			$order->calculate_totals();
			$order->save();

			wp_send_json_success( [ 'message' => 'Item removed and stock restored successfully.' ] );
		}

		wp_send_json_error( [ 'message' => 'Item not found in order.' ] );
	}

	/**
	 * Gate for the order-edit AJAX handlers: the nonce is printed to anyone who opens the
	 * order page, so it proves nothing on its own. Requires dashboard staff, and for an
	 * order ID, a real shop order inside the user's allowed locations.
	 *
	 * @param int $order_id Order ID, or 0 for actions not tied to an order.
	 * @return void Sends a JSON error and exits when not allowed.
	 */
	private static function ensure_staff_can_edit( $order_id = 0 ) {
		if ( ! FnsPro::has_order_manage_capability() ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Permission denied.', 'food-menu-pro' ) ], 403 );
		}

		if ( ! $order_id ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order || 'shop_order' !== $order->get_type() ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Permission denied.', 'food-menu-pro' ) ], 403 );
		}

		// An order with no location yet is one this page just created ("New order" builds it first, then adds items).
		$unassigned = ! $order->get_meta( 'fmp_location_id' ) && '' === (string) $order->get_meta( 'fmp_location_name' );

		if ( ! $unassigned && ! FnsPro::order_matches_allowed_locations( $order, FnsPro::get_user_allowed_locations() ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Permission denied.', 'food-menu-pro' ) ], 403 );
		}
	}
}
