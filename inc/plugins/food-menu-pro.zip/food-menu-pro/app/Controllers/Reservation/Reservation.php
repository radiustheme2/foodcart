<?php

namespace RT\FoodMenuPro\Controllers\Reservation;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenu\Helpers\Fns;
use DateTime;

/**
 * Special Menu Main class
 */
class Reservation {

	use SingletonTrait;

	/**
	 * Admin settings
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		$this->options = FnsPro::get_settings_option();
		wp_enqueue_script( 'fmp-timepicker' );
		wp_enqueue_style( 'fmp-timepicker' );

		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_assets' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue_assets' ] );

		//Check booking seats capacity
		add_action( 'wp_ajax_booking_seat_capacity', [ $this, 'booking_seat_capacity' ] );
		add_action( 'wp_ajax_nopriv_booking_seat_capacity', [ $this, 'booking_seat_capacity' ] );

		//Change reservation status in ajax
		add_action( 'wp_ajax_save_fmp_resi_meta_status', [ $this, 'save_fmp_resi_meta_status' ] );
		add_action( 'wp_ajax_nopriv_save_fmp_resi_meta_status', [ $this, 'save_fmp_resi_meta_status' ] ); // For non-logged-in users

		add_action( 'fmp_reservation_change_email_hook', [ $this, 'fmp_reservation_change_email_hook' ], 10, 2 );
		add_action( 'admin_init', [ $this, 'fmp_handle_export_import' ] );

		ReservationSubmit::get_instance();
		ReservationTableList::get_instance();
	}

	/**
	 * Table Layout export and import
	 *
	 * @return void
	 */
	public function fmp_handle_export_import() {
		// EXPORT
		if ( isset( $_POST['fmp_export'] ) && check_admin_referer( 'fmp_export_nonce', 'fmp_export_nonce_field' ) ) {
			$data = get_option( 'fmp_table_layout' );
			if ( $data ) {
				$filename = 'fmp_table_layout_export_' . date( 'Y-m-d' ) . '.txt';
				header( 'Content-Type: text/plain' );
				header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
				echo maybe_serialize( $data );
				exit;
			}
		}

		// IMPORT
		if ( isset( $_POST['fmp_import'] ) && check_admin_referer( 'fmp_import_nonce', 'fmp_import_nonce_field' ) ) {
			if ( ! empty( $_FILES['fmp_import_file']['tmp_name'] ) ) {
				$import_data = file_get_contents( $_FILES['fmp_import_file']['tmp_name'] );

				if ( $import_data ) {
					$unserialized = maybe_unserialize( $import_data );
					if ( $unserialized !== false || $import_data === 'b:0;' ) {
						update_option( 'fmp_table_layout', $unserialized );
						add_action( 'admin_notices', function() {
							echo '<div class="notice notice-success is-dismissible"><p>Layout imported successfully.</p></div>';
						} );
					} else {
						add_action( 'admin_notices', function() {
							echo '<div class="notice notice-error is-dismissible"><p>Import failed: invalid data.</p></div>';
						} );
					}
				}
			}
		}
	}

	/**
	 * Frontend enqueue
	 *
	 * @return void
	 */
	public function frontend_enqueue_assets() {
		// time picker.
		wp_enqueue_script( 'fmp-timepicker' );
		wp_enqueue_style( 'fmp-timepicker' );
		// date picker.
		wp_enqueue_script( 'fmp-flatpickr' );
		wp_enqueue_style( 'fmp-flatpickr' );

		// form validation.
		wp_enqueue_script( 'fmp-form-validation' );

		wp_enqueue_script( 'fmp-reservation' );
		wp_localize_script(
			'fmp-reservation',
			'fmpResiParams',
			$this->reservation_data_obj()
		);
	}

	/**
	 * Admin enqueue
	 *
	 * @return void
	 */
	public function admin_enqueue_assets() {
		// time picker.
		wp_enqueue_script( 'fmp-timepicker' );
		wp_enqueue_style( 'fmp-timepicker' );
		// date picker.
		wp_enqueue_script( 'fmp-flatpickr' );
		wp_enqueue_script( 'fmp-range-flatpickr' );
		wp_enqueue_style( 'fmp-flatpickr' );
		// form validation.
		wp_enqueue_script( 'fmp-form-validation' );

		wp_enqueue_style( 'fm-admin' );
		wp_enqueue_style( 'fmp-admin' );
		wp_enqueue_script( 'fmp-admin-reservation' );
		wp_enqueue_script( 'fmp-reservation' );
		wp_localize_script(
			'fmp-reservation',
			'fmpResiParams',
			$this->reservation_data_obj()
		);
	}

	/**
	 * Reservation localize data object
	 *
	 * @return array
	 */
	public function reservation_data_obj() {
		$settings          = $this->options;
		$fm_date_format    = get_option( 'date_format' ) ?? 'Y-m-d';
		$fm_time_format    = get_option( 'time_format' ) ?? 'H:i A';
		$current_date_time = current_datetime();
		$current_date      = $current_date_time->format( $fm_date_format );
		$current_time      = $current_date_time->format( $fm_time_format );
		$nonce             = wp_create_nonce( Fns::nonceText() );

		return [
			'resi_time_interval'              => ! empty( $settings['fmp_resi_time_interval'] ) ? $settings['fmp_resi_time_interval'] : 30,
			'resi_weekly_schedule'            => $settings['fmp_resi_weekly_schedule'] ?? [],
			'resi_weekly_schedule_start_time' => $settings['fmp_resi_weekly_schedule_start_time'] ?? [],
			'resi_weekly_schedule_end_time'   => $settings['fmp_resi_weekly_schedule_end_time'] ?? [],
			'resi_weekly_holiday'             => $settings['fmp_resi_weekly_holiday'] ?? [],
			'current_time'                    => $current_time,
			'current_date'                    => $current_date,
			'date_format'                     => $fm_date_format,
			'time_format'                     => $fm_time_format,
			'nonceID'                         => esc_attr( Fns::nonceId() ),
			'nonce'                           => esc_attr( $nonce ),
			'ajaxurl'                         => esc_url( admin_url( 'admin-ajax.php' ) ),
			'validation_message'              => [
				'required_text'     => esc_html__( 'Kindly fill out this field.', 'food-menu-pro' ),
				'email'             => esc_html__( 'Email is not valid.', 'food-menu-pro' ),
				'phone'             => esc_html__( 'Only number allowed.', 'food-menu-pro' ),
				'end_time'          => esc_html__( 'End time must be greater than start time.', 'food-menu-pro' ),
				'table_layout'      => [],
				'guest_select_text' => esc_html__( 'Select total guests', 'food-menu-pro' ),
			],
		];
	}

	/**
	 * Reservation capacity status.
	 *
	 * @param string $selected_date .
	 * @param string $start_time .
	 * @param string $end_time .
	 * @param string $type .
	 *
	 * @return array
	 */
	public function resi_capacity_status( $selected_date = null, $start_time = '', $end_time = '', $type = '' ) {
		$settings = $this->options;
		$response = [
			'capacity' => 30,
			'status'   => 'open',
		];

		$seat_capacity = ! empty( $settings['fmp_resi_seat_capacity'] ) ? (int) $settings['fmp_resi_seat_capacity'] : 30;

		if ( ! empty( $seat_capacity ) ) {
			$reservation_data = $this->get_all_reservation(
				[
					'capacity'      => $seat_capacity,
					'selected_date' => $selected_date,
				],
				$start_time,
				$end_time,
				$type
			);

			if ( ! empty( $type ) ) {
				$response['date_booked_ids']       = $reservation_data['date_booked_ids'];
				$response['date_booked_table_ids'] = $reservation_data['date_booked_table_ids'];
				$reserved_seats                    = $reservation_data['total_seat'];
				$response['date_booked_total']     = $reserved_seats;
			} else {
				$reserved_seats = $reservation_data;
			}

			if ( $reserved_seats >= $seat_capacity ) {
				$response['status']  = 'closed';
				$response['message'] = esc_html__( 'Fully booked. Try another time.', 'food-menu-pro' );
			}

			$available_capacity = absint( $seat_capacity - $reserved_seats );
			$max_guest_capacity = absint( $settings['fmp_resi_max_guest'] ?? $available_capacity );

			$response['capacity']     = $available_capacity;
			$response['max_capacity'] = min( $max_guest_capacity, $available_capacity );
		}

		return $response;
	}

	/**
	 * Get all reservation .
	 *
	 * @param array $data .
	 * @param string $start_time .
	 * @param string $end_time .
	 * @param string $type .
	 *
	 * @return int|string[]
	 */
	public function get_all_reservation( $data = [], $start_time = '', $end_time = '', $type = '' ) {
		$total_seat            = 0;
		$date_booked_ids       = [];
		$date_booked_table_ids = [];

		$booking_date = ! empty( $data['selected_date'] ) ? $data['selected_date'] : gmdate( TLP_FOOD_MENU_DEFAULT_DATE_FORMAT );
		$booking_date = strtotime( $booking_date );
		$args         = [
			'post_type'   => 'fmp_reservation',
			'numberposts' => - 1,
			'post_status' => 'publish',
			'fields'      => 'ids',
			//phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			'meta_query'  => [
				[
					'key'     => 'fmp_resi_meta_status',
					'value'   => [ 'confirmed', 'completed' ],
					'compare' => 'IN',
				],
				[
					'key'     => 'fmp_resi_meta_date',
					'value'   => $booking_date,
					'compare' => '=',
				],
			],
		];

		$all_reservations = get_posts( $args );

		foreach ( $all_reservations as $reservation ) {
			$saved_start_time = strtotime( get_post_meta( $reservation, 'fmp_resi_meta_start_time', true ) ?: '12:00 AM' );
			$saved_end_time   = strtotime( get_post_meta( $reservation, 'fmp_resi_meta_end_time', true ) ?: '11:30 PM' );

			$should_calculate_seats = $this->should_calculate_seats( $saved_start_time, $saved_end_time, strtotime( $start_time ), strtotime( $end_time ) );

			if ( $should_calculate_seats ) {
				$total_seat += (int) get_post_meta( $reservation, 'fmp_resi_meta_seat', true );

				$this->merge_meta_ids( $reservation, 'fmp_resi_meta_booked_ids', $date_booked_ids ); //merge all chair ids
				$this->merge_meta_ids( $reservation, 'fmp_resi_meta_booked_table_ids', $date_booked_table_ids ); //merge all table ids
			}
		}

		$date_booking_data = [
			'total_seat'            => $total_seat, //total seats
			'date_booked_ids'       => $date_booked_ids, //chair ids
			'date_booked_table_ids' => $date_booked_table_ids, //table ids
		];

		return empty( $type ) ? $total_seat : $date_booking_data;
	}

	/**
	 * Should calculate seats.
	 *
	 * @param number $saved_start_time .
	 * @param number $saved_end_time .
	 * @param number $start_time .
	 * @param number $end_time .
	 *
	 * @return bool
	 */
	private function should_calculate_seats( $saved_start_time, $saved_end_time, $start_time, $end_time ) {
		return $saved_start_time < $end_time && $saved_end_time > $start_time;

		//return !($end_time <= $saved_start_time || $start_time >= $saved_end_time);

		/*return (
			( $saved_start_time >= $start_time && $saved_start_time < $end_time ) ||
			( $saved_end_time > $start_time && $saved_end_time <= $end_time ) ||
			( $start_time >= $saved_start_time && $start_time < $saved_end_time ) ||
			( $end_time > $saved_start_time && $end_time <= $saved_end_time )
		);*/
	}

	/**
	 * Merge meta ids.
	 *
	 * @param number $post_id .
	 * @param string $meta_key .
	 * @param array $merged_ids .
	 *
	 * @return void
	 */
	private function merge_meta_ids( $post_id, $meta_key, &$merged_ids ) {
		$ids = get_post_meta( $post_id, $meta_key, true );

		if ( ! empty( $ids ) ) {
			$ids = maybe_unserialize( $ids );

			if ( is_array( $ids ) && count( $ids ) > 0 ) {
				$merged_ids[] = $ids;
			}
		}
	}

	/**
	 * Booking form seat capacity
	 *
	 * @return void
	 */
	public function booking_seat_capacity() {
		// Initialize default response data.
		$responseData = [
			'message' => '',
			'status'  => 'open',
		];
		$errorMessage = esc_html__( 'Something went wrong', 'food-menu-pro' );

		// Sanitize and retrieve POST data.
		$postData = filter_input_array( INPUT_POST, FILTER_SANITIZE_SPECIAL_CHARS );

		// Validate action.
		if ( empty( $postData['fmp_action'] ) || 'fmp_seat_qty' !== $postData['fmp_action'] ) {
			wp_send_json_error(
				[
					'success' => false,
					'message' => [ $errorMessage ],
					'data'    => $responseData,
				]
			);
			exit();
		}

		// Check if selected_date is provided.
		if ( ! empty( $postData['selected_date'] ) ) {
			$startTime       = ! empty( $postData['start_time'] ) ? $postData['start_time'] : '';
			$endTime         = ! empty( $postData['end_time'] ) ? $postData['end_time'] : '';
			$reservationType = ! empty( $postData['type'] ) ? $postData['type'] : '';

			// If  from_time is provided, check the seat capacity status.
			if ( ! ( $startTime && $endTime ) ) {
				wp_send_json_error(
					[
						'success' => false,
						'message' => [ $errorMessage ],
					]
				);
			}
			$responseData = $this->resi_capacity_status(
				$postData['selected_date'],
				$startTime,
				$endTime,
				$reservationType
			);

			$successMessage = esc_html__( 'Everything is okay', 'food-menu-pro' );
		}

		// Send success response.
		wp_send_json_success(
			[
				'success' => true,
				'message' => [ $successMessage ],
				'data'    => $responseData,
			]
		);

		exit();
	}

	/**
	 * Change reservation status cbf
	 *
	 * @return void
	 */
	function save_fmp_resi_meta_status() {
		// Verify nonce for security

		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			wp_send_json_error( [ 'message' => 'Invalid nonce' ] );

			return;
		}

		// Sanitize all input data properly
		$post_id    = isset( $_POST['post_id'] ) ? intval( $_POST['post_id'] ) : 0;
		$meta_value = isset( $_POST['meta_value'] ) ? sanitize_text_field( $_POST['meta_value'] ) : '';

		if ( $post_id <= 0 || empty( $meta_value ) ) {
			wp_send_json_error( [ 'message' => 'Invalid or missing parameters' ] );

			return;
		}

		// Update the post meta securely
		update_post_meta( $post_id, 'fmp_resi_meta_status', $meta_value );

		$newReservation = $meta_value;
		do_action( 'fmp_reservation_change_email_hook', $post_id, $newReservation );

		wp_send_json_success( [ 'message' => 'Status updated successfully' ] );
	}

	public function fmp_reservation_change_email_hook( $post_id, $newReservation ) {
		$booking_id      = get_post_meta( $post_id, 'fmp_resi_meta_invoice', true );
		$customer_email  = get_post_meta( $post_id, 'fmp_resi_meta_email', 'true' );
		$customer_name   = get_post_meta( $post_id, 'fmp_resi_meta_name', 'true' );
		$sender_mail     = ! empty( $this->options['fmp_resi_sender_email'] ) ? $this->options['fmp_resi_sender_email'] : get_bloginfo( 'admin_email' );
		$mail_subject    = esc_html__( 'Hello ', 'food-menu-pro' ) . ' ' . $customer_name ?? '';
		$args['msg']     = sprintf(
			esc_html__( "We would like to inform you that your reservation status has been updated to <strong>%s</strong> under the booking id - <strong>%s</strong>", "food-menu-pro" ),
			$newReservation,
			$booking_id
		);
		$resi_date       = get_post_meta( $post_id, 'fmp_resi_meta_date', true ); //This is timestamp ex.1744675200
		$resi_start_time = get_post_meta( $post_id, 'fmp_resi_meta_start_time', true ); //start time: ex.12:00AM
		$resi_end_time   = get_post_meta( $post_id, 'fmp_resi_meta_end_time', true ); //end time: ex: 1:00PM

		$args['status']       = $newReservation;
		$args['resi_id']      = $post_id;
		$args['invoice']      = $booking_id;
		$args['booking_date'] = date( get_option( 'date_format' ), $resi_date ) . ' (' . $resi_start_time . ' to ' . $resi_end_time . ')';
		$mail_body            = FnsPro::mail_body_markup( $args, 'user' );
		$email_args           = [
			'to'        => $customer_email,
			'subject'   => $mail_subject,
			'mail_body' => $mail_body,
			'from'      => $sender_mail,
			'from_name' => get_bloginfo( 'name' ),
		];

		FnsPro::send_email( $email_args );
	}

}

