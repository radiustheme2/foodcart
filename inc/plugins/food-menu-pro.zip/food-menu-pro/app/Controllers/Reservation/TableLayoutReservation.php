<?php

namespace RT\FoodMenuPro\Controllers\Reservation;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenu\Helpers\Fns;

/**
 * Pro layer on top of the free Reservation flow.
 *
 * - Registers the visual-table-only shortcode `[fm_visual_table_reservation_form]`
 * - Hooks free's reservation filters to count pending visual-table bookings,
 *   add chair/table meta, supply per-location seat capacity, etc.
 * - Handles table-layout export/import and the location reservation schedule AJAX.
 */
class TableLayoutReservation {

	use SingletonTrait;

	/**
	 * Cached plugin settings.
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Init hooks.
	 *
	 * @return void
	 */
	public function init() {
		$this->options = FnsPro::get_settings_option();
		if ( ! is_array( $this->options ) ) {
			$this->options = [];
		}

		// Filter free's reservation flow.
		add_filter( 'fmp/reservation/counted_statuses', [ $this, 'counted_statuses' ], 10, 2 );
		add_filter( 'fmp/reservation/booked_seats_info', [ $this, 'booked_seats_info' ], 10, 2 );
		add_filter( 'fmp/reservation/pre_insert', [ $this, 'pre_insert' ], 10, 2 );
		add_filter( 'fmp/reservation/localize_data', [ $this, 'localize_data' ], 10, 2 );
		add_filter( 'fmp/reservation/capacity_context', [ $this, 'capacity_context' ], 10, 4 );
		add_filter( 'fmp/reservation/slot_schedule', [ $this, 'slot_schedule' ], 10, 2 );
		add_filter( 'fmp/reservation/shortcode_hint', [ $this, 'shortcode_hint' ], 10, 2 );

		// Visual-table-only shortcode lives in Pro.
		add_shortcode( 'fm_visual_table_reservation_form', [ $this, 'visual_table_render' ] );

		// Location reservation schedule AJAX (multi-location toggle).
		if ( ! empty( $this->options['fmp_food_location_popup'] ) ) {
			add_action( 'wp_ajax_fmp_get_location_resi_schedule', [ $this, 'get_location_resi_schedule' ] );
			add_action( 'wp_ajax_nopriv_fmp_get_location_resi_schedule', [ $this, 'get_location_resi_schedule' ] );
		}

		add_action( 'admin_init', [ $this, 'handle_table_layout_export_import' ] );
	}

	/**
	 * Pending bookings must also block a chair for visual-table lookups —
	 * otherwise two customers can claim the same chair at the same time while
	 * the first is awaiting confirmation. Normal seat-capacity lookups keep
	 * the confirmed/completed filter so unconfirmed requests don't eat into
	 * the per-slot capacity number.
	 *
	 * @param array  $statuses .
	 * @param string $type .
	 *
	 * @return array
	 */
	public function counted_statuses( $statuses, $type ) {
		if ( 'table_layout' === $type ) {
			$statuses[] = 'pending';
		}

		return $statuses;
	}

	/**
	 * Translate booked chair/table ids into human-readable labels.
	 *
	 * @param array $info .
	 * @param int   $post_id .
	 *
	 * @return array
	 */
	public function booked_seats_info( $info, $post_id ) {
		$pro_info = FnsPro::get_booked_seats_info( $post_id );

		return empty( $pro_info ) ? $info : $pro_info;
	}

	/**
	 * Validate visual-table chair selection before inserting a reservation.
	 *
	 * @param array $state   ['meta_data', 'skip_seat_check', 'error', 'message'].
	 * @param array $context Form context.
	 *
	 * @return array
	 */
	public function pre_insert( $state, $context ) {
		$form_data     = $context['form_data'] ?? [];
		$visual_table  = ! empty( $form_data['fmp_visual_selection'] ) ? absint( $form_data['fmp_visual_selection'] ) : 0;

		if ( ! $visual_table ) {
			return $state;
		}

		$resi_date    = $context['resi_date'] ?? '';
		$resi_start   = $context['resi_start'] ?? '';
		$resi_end     = $context['resi_end'] ?? '';
		$resi_guest   = $context['resi_guest'] ?? '';

		$selected_ids   = $form_data['fmp_booked_ids'] ?? '';
		$selected_ids   = ! empty( $selected_ids ) ? explode( ',', $selected_ids ) : [];
		$total_selected = count( $selected_ids );

		if ( 0 === $total_selected ) {
			$state['error']   = true;
			$state['message'] = esc_html__( 'Please select at least one table or chair from the layout before submitting.', 'food-menu-pro' );

			return $state;
		}

		if ( (int) $resi_guest !== $total_selected ) {
			$state['error']   = true;
			$state['message'] = esc_html__( 'Guest and selected seat count mismatch. Please check and try again.', 'food-menu-pro' );

			return $state;
		}

		$booking_data = Fns::get_booking_data( $resi_date, $resi_start, $resi_end );

		if ( empty( $booking_data['booking_open'] ) ) {
			$state['error']   = true;
			$state['message'] = esc_html__( 'Sorry, all seats are booked. Please change the schedule and try again.', 'food-menu-pro' );

			return $state;
		}

		$capacity = (int) $booking_data['capacity'];
		if ( $total_selected > $capacity ) {
			$state['error']   = true;
			$state['message'] = esc_html__( 'Selected seats exceed the total capacity', 'food-menu-pro' );

			return $state;
		}

		$booked_ids      = $booking_data['booked_ids'] ?? [];
		$intersected_ids = array_intersect( $selected_ids, $booked_ids );
		if ( ! empty( $intersected_ids ) ) {
			$state['error']   = true;
			$state['message'] = esc_html__( 'Selected seat already booked', 'food-menu-pro' );

			return $state;
		}

		$fmp_schedule_slug    = $form_data['fmp_schedule_slug'] ?? 'table_layout_slug';
		$fmp_obj_names        = ! empty( $_POST['fmp_obj_names'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_obj_names'] ) ) : '';
		$fmp_intersected_data = ! empty( $_POST['fmp_intersected_data'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_intersected_data'] ) ) : '';
		$fmp_mapping_data     = ! empty( $_POST['fmp_mapping_data'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_mapping_data'] ) ) : '';
		$selected_table_ids   = ! empty( $_POST['fmp_booked_table_ids'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_booked_table_ids'] ) ) : '';
		$selected_table_ids   = ! empty( $selected_table_ids ) ? explode( ',', $selected_table_ids ) : [];

		$meta_data                                  = $state['meta_data'] ?? [];
		$meta_data['fmp_resi_meta_visual_selection'] = $visual_table;
		$meta_data['fmp_resi_meta_schedule_slug']    = $fmp_schedule_slug;
		$meta_data['fmp_resi_meta_booked_ids']       = maybe_serialize( $selected_ids );
		$meta_data['fmp_resi_meta_booked_table_ids'] = maybe_serialize( $selected_table_ids );
		$meta_data['fmp_resi_meta_obj_names']        = $fmp_obj_names;
		$meta_data['fmp_resi_meta_intersected_data'] = $fmp_intersected_data;
		$meta_data['fmp_resi_meta_mapping_data']     = $fmp_mapping_data;

		$state['meta_data']       = $meta_data;
		$state['skip_seat_check'] = true; // Visual-table uses chair-overlap validation, not seat-capacity.

		return $state;
	}

	/**
	 * Add location-specific schedule + global visual-table data to the
	 * localized JS object.
	 *
	 * @param array $data .
	 * @param array $settings .
	 *
	 * @return array
	 */
	public function localize_data( $data, $settings ) {
		if ( empty( $settings['fmp_food_location_popup'] ) ) {
			return $data;
		}

		$location_id = ! empty( $_COOKIE['fmp_location_id'] ) ? absint( $_COOKIE['fmp_location_id'] ) : 0;

		if ( $location_id > 0 ) {
			$loc_data = FnsPro::get_location_reservation_data( $location_id );

			if ( null !== $loc_data ) {
				$data['resi_time_interval']              = $loc_data['time_interval'];
				$data['resi_weekly_schedule_start_time'] = $loc_data['fmp_loc_resi_weekly_schedule_start_time'];
				$data['resi_weekly_schedule_end_time']   = $loc_data['fmp_loc_resi_weekly_schedule_end_time'];
				$data['resi_weekly_schedule_slots']      = $loc_data['fmp_loc_resi_weekly_schedule_slots'];
				$data['resi_weekly_holiday']             = $loc_data['fmp_loc_resi_weekly_holiday'];
				$data['min_guest']                       = $loc_data['min_guest'];
				$data['max_guest']                       = $loc_data['max_guest'];
			}
		}

		// Visual table reservation always uses the global schedule, never per-location.
		$new_schedule = Fns::get_setting( 'new_fmp_resi_weekly_schedule', [] );

		$data['global_resi_time_interval']              = ! empty( $settings['fmp_resi_time_interval'] ) ? $settings['fmp_resi_time_interval'] : 30;
		$data['global_resi_weekly_schedule']            = $new_schedule;
		$data['global_resi_weekly_schedule_start_time'] = Fns::get_schedule_time( $new_schedule );
		$data['global_resi_weekly_schedule_end_time']   = Fns::get_schedule_time( $new_schedule, 'end' );
		$data['global_resi_weekly_schedule_slots']      = Fns::get_schedule_slots( $new_schedule );
		$data['global_resi_weekly_holiday']             = Fns::get_offday_schedule( $new_schedule );

		return $data;
	}

	/**
	 * Override seat capacity / max-guest with location values when present.
	 *
	 * @param array  $context .
	 * @param int    $location_id .
	 * @param string $selected_date .
	 * @param string $start_time .
	 *
	 * @return array
	 */
	public function capacity_context( $context, $location_id, $selected_date, $start_time ) {
		if ( $location_id <= 0 ) {
			return $context;
		}

		$loc_data = FnsPro::get_location_reservation_data( $location_id );
		if ( null === $loc_data ) {
			return $context;
		}

		$context['seat_capacity'] = (int) $loc_data['seat_capacity'];
		$context['max_guest']     = (int) $loc_data['max_guest'];

		return $context;
	}

	/**
	 * Return the location-specific reservation schedule (if enabled), else null
	 * for free to fall back to the global schedule.
	 *
	 * @param array|null $schedule .
	 * @param int        $location_id .
	 *
	 * @return array|null
	 */
	public function slot_schedule( $schedule, $location_id ) {
		if ( null !== $schedule || $location_id <= 0 ) {
			return $schedule;
		}

		if ( empty( $this->options['fmp_food_location_popup'] ) ) {
			return $schedule;
		}

		$has_custom = get_term_meta( $location_id, 'fmp_location_has_custom_reservation', true );
		if ( 'on' !== $has_custom ) {
			return $schedule;
		}

		$loc_schedule = get_term_meta( $location_id, 'fmp_loc_new_resi_weekly_schedule', true );
		if ( ! empty( $loc_schedule ) && is_array( $loc_schedule ) ) {
			return $loc_schedule;
		}

		return $schedule;
	}

	/**
	 * Append the visual-table shortcode to the settings hint.
	 *
	 * @param string $hint .
	 * @param array  $settings .
	 *
	 * @return string
	 */
	public function shortcode_hint( $hint, $settings ) {
		$hint .= " <br> And <input style='width:260px;display: inline;text-align: center' type='text' value='[fm_visual_table_reservation_form]' onclick='copyText(this)' readonly> shortcodes for table layout reservation.";

		if ( ! empty( $settings['fmp_food_location_popup'] ) ) {
			$hint .= '<div style="margin-top:10px;padding:10px 14px;background:#fff8e1;border-left:4px solid #f0b429;border-radius:4px;font-size:13px;color:#6b5900;">'
				. '<strong>' . esc_html__( 'Note:', 'food-menu-pro' ) . '</strong> '
				. esc_html__( 'Visual table layout reservation does not support multi-location filtering. The table layout will work as a global layout for all locations.', 'food-menu-pro' )
				. '</div>';
		}

		return $hint;
	}

	/**
	 * Render the visual-table reservation form shortcode.
	 *
	 * @param array $atts .
	 *
	 * @return string
	 */
	public function visual_table_render( $atts ) {
		$settings = $this->options;

		if ( 'on' !== ( $settings['fmp_food_reservation_status'] ?? '' ) ) {
			return $this->disabled_notice();
		}

		ob_start();
		$enable_cancel_form = ! empty( $settings['fmp_resi_enable_cancel_form'] ) ? $settings['fmp_resi_enable_cancel_form'] : 'on';
		$attrs_data         = apply_filters( 'fmp/resi/visual_table_reservation_form_atts', $atts );
		$data               = [
			'settings'   => $settings,
			'attrs_data' => $attrs_data,
		];
		$table_content      = get_option( 'fmp_table_layout', [] );
		?>
		<div class="fmp-reservation-form-wrap">
			<?php
			if ( ! empty( $table_content ) ) {
				Fns::render( 'reservation/visual-table-reservation', $data );
				if ( ! empty( $enable_cancel_form ) ) {
					Fns::render( 'reservation/cancel-form', $data );
				}
			} else {
				?>
				<div class="fmp-resi-empty-state" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 48px 24px; text-align: center;">
					<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 16px;">
						<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
					</svg>
					<p style="margin: 0 0 8px; font-size: 16px; font-weight: 600; color: #1f2937;">
						<?php echo esc_html__( 'No Table Layout Found', 'food-menu-pro' ); ?>
					</p>
					<p style="margin: 0 0 20px; font-size: 14px; color: #6b7280; max-width: 400px;">
						<?php echo esc_html__( 'A visual table layout is required for table reservations. Please create one from the admin panel.', 'food-menu-pro' ); ?>
					</p>
					<?php if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) : ?>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=food-menu&page=table_layout' ) ); ?>" style="display: inline-flex; align-items: center; gap: 6px; padding: 10px 20px; background: var(--rtfm-primary-color, #fc202e); color: #fff; border-radius: 8px; font-size: 14px; font-weight: 500; text-decoration: none;">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
							<?php echo esc_html__( 'Create Table Layout', 'food-menu-pro' ); ?>
						</a>
					<?php endif; ?>
				</div>
				<?php
			}
			?>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Disabled-reservation notice.
	 *
	 * @return string
	 */
	private function disabled_notice() {
		$is_admin = is_user_logged_in() && current_user_can( 'manage_options' );

		ob_start();
		?>
		<div class="fmp-reservation-form-wrap">
			<div class="fmp-resi-empty-state" style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 24px;text-align:center;">
				<p style="margin:0 0 8px;font-size:16px;font-weight:600;color:#1f2937;">
					<?php echo esc_html__( 'Reservations are currently unavailable', 'food-menu-pro' ); ?>
				</p>
				<?php if ( $is_admin ) : ?>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=food-menu&page=fmp_settings#/reservation' ) ); ?>" style="display:inline-flex;align-items:center;gap:6px;padding:10px 20px;background:var(--rtfm-primary-color,#fc202e);color:#fff;border-radius:8px;font-size:14px;font-weight:500;text-decoration:none;">
						<?php echo esc_html__( 'Open Reservation Settings', 'food-menu-pro' ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * AJAX: get location-specific reservation schedule data.
	 *
	 * @return void
	 */
	public function get_location_resi_schedule() {
		$location_id = ! empty( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0;

		if ( $location_id > 0 ) {
			$loc_data = FnsPro::get_location_reservation_data( $location_id );

			if ( null !== $loc_data ) {
				wp_send_json_success( [
					'resi_time_interval'              => $loc_data['time_interval'],
					'resi_weekly_schedule_start_time' => $loc_data['fmp_loc_resi_weekly_schedule_start_time'],
					'resi_weekly_schedule_end_time'   => $loc_data['fmp_loc_resi_weekly_schedule_end_time'],
					'resi_weekly_schedule_slots'      => $loc_data['fmp_loc_resi_weekly_schedule_slots'],
					'resi_weekly_holiday'             => $loc_data['fmp_loc_resi_weekly_holiday'],
					'seat_capacity'                   => $loc_data['seat_capacity'],
					'min_guest'                       => $loc_data['min_guest'],
					'max_guest'                       => $loc_data['max_guest'],
				] );
			}
		}

		// Fall back to the global data object.
		if ( class_exists( '\\RT\\FoodMenu\\Controllers\\Reservation\\Reservation' ) ) {
			wp_send_json_success( \RT\FoodMenu\Controllers\Reservation\Reservation::get_instance()->reservation_data_obj() );
		}

		wp_send_json_success( [] );
	}

	/**
	 * Table-layout export/import.
	 *
	 * @return void
	 */
	public function handle_table_layout_export_import() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['fmp_export'] ) && check_admin_referer( 'fmp_export_nonce', 'fmp_export_nonce_field' ) ) {
			$data = get_option( 'fmp_table_layout' );
			if ( $data ) {
				$filename = 'fmp_table_layout_export_' . date( 'Y-m-d' ) . '.txt';
				header( 'Content-Type: text/plain' );
				header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
				echo maybe_serialize( $data ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				exit;
			}
		}

		if ( isset( $_POST['fmp_import'] ) && check_admin_referer( 'fmp_import_nonce', 'fmp_import_nonce_field' ) ) {
			if ( ! empty( $_FILES['fmp_import_file']['tmp_name'] ) ) {
				//phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$import_data = file_get_contents( $_FILES['fmp_import_file']['tmp_name'] );

				if ( $import_data ) {
					// Exports are serialized arrays; never let an uploaded file instantiate PHP objects.
					$unserialized = is_serialized( $import_data ) ? @unserialize( trim( $import_data ), [ 'allowed_classes' => false ] ) : $import_data; //phpcs:ignore
					if ( is_array( $unserialized ) ) {
						update_option( 'fmp_table_layout', $unserialized );
						add_action( 'admin_notices', function () {
							echo '<div class="notice notice-success is-dismissible"><p>Layout imported successfully.</p></div>';
						} );
					} else {
						add_action( 'admin_notices', function () {
							echo '<div class="notice notice-error is-dismissible"><p>Import failed: invalid data.</p></div>';
						} );
					}
				}
			}
		}
	}
}
