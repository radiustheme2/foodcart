<?php

namespace RT\FoodMenuPro\Controllers\Reservation;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenu\Helpers\Fns;
use DateTime;

/**
 * Special Menu Main class
 */
class ReservationTableList {

	use SingletonTrait;

	public $dateFormat;

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'pre_get_posts', [ $this, 'query_modify' ], 9999 );
		add_action( 'manage_fmp_reservation_posts_custom_column', [ $this, 'reservation_custom_column' ], 10, 2 );
		add_filter( 'manage_fmp_reservation_posts_columns', [ $this, 'reservation_post_column' ] );
		add_filter( 'page_row_actions', [ $this, 'post_row_actions' ], 10, 2 );
		add_filter( 'manage_edit-fmp_reservation_sortable_columns', [ $this, 'make_reservation_date_sortable' ] );
		add_filter( 'fmp/resi/reservation_details', [ $this, 'reservation_details' ] );
		add_action( 'restrict_manage_posts', [ $this, 'add_reservation_filter_dropdown' ] );
		add_action( 'admin_head', [ $this, 'reservation_table_list_css' ] );
		add_action( 'admin_head', [ $this, 'remove_admin_notices_on_reservation_page' ] );
		// add_action( 'manage_posts_extra_tablenav', [ $this, 'reservation_filter_export_btn' ] );
		$this->dateFormat = get_option( 'date_format' );
	}

	public function query_modify( $query ) {
		if ( is_admin() && $query->is_main_query() && $query->get( 'post_type' ) === 'fmp_reservation' ) {
			if ( ! isset( $_GET['orderby'] ) ) {
				$query->set( 'orderby', 'date' );
				$query->set( 'order', 'DESC' );
			}

			$meta_query = [];
			if ( isset( $_GET['status_meta_filter'] ) && ! empty( $_GET['status_meta_filter'] ) ) {
				$status = sanitize_text_field( $_GET['status_meta_filter'] );

				$meta_query[] = [
					'key'     => 'fmp_resi_meta_status',
					'value'   => $status,
					'compare' => '=',
				];
			}

			if ( ! empty( $_GET['created_date_start'] ) && ! empty( $_GET['created_date_end'] ) ) {
				// Sanitize and retrieve the user input
				$start_date = sanitize_text_field( $_GET['created_date_start'] );
				$end_date   = sanitize_text_field( $_GET['created_date_end'] );

				// Convert the user input to MySQL-compatible date format (YYYY-MM-DD)
				$start_date = date( 'Y-m-d', strtotime( $start_date ) );
				$end_date   = date( 'Y-m-d', strtotime( $end_date ) );

				// Prepare the date query for WP_Query
				$date_query = [
					[
						'after'     => $start_date,
						'before'    => $end_date,
						'inclusive' => true,
					],
				];

				// Set the date query on the WP_Query object
				$query->set( 'date_query', $date_query );
			}

			if ( ! empty( $_GET['booking_date_start'] ) && ! empty( $_GET['booking_date_end'] ) ) {
				$start_date = sanitize_text_field( $_GET['booking_date_start'] );
				$end_date   = sanitize_text_field( $_GET['booking_date_end'] );

				// Convert user input to match the DB format
				$start_date = strtotime( $start_date );
				$end_date   = strtotime( $end_date );

				$meta_query[] = [
					'relation' => 'AND',
					[
						'key'     => 'fmp_resi_meta_date',
						'value'   => $start_date,
						'compare' => '>=',
						'type'    => 'CHAR', // Must use CHAR, because it's stored as a string
					],
					[
						'key'     => 'fmp_resi_meta_date',
						'value'   => $end_date,
						'compare' => '<=',
						'type'    => 'CHAR', // Still comparing strings, not actual dates
					],
				];
			}

			if ( ! empty( $meta_query ) ) {
				$query->set( 'meta_query', $meta_query );
			}
		}
	}

	/**
	 * Add reservation filter dropdown
	 *
	 * @return void
	 */
	public function add_reservation_filter_dropdown() {
		global $post_type, $wpdb, $pagenow;

		$status_meta_key = 'fmp_resi_meta_status';
		//phpcs:disable
		if ( 'fmp_reservation' === $post_type && 'edit.php' === $pagenow ) {
			// Fetch distinct status meta values.
			$status_meta_values = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s",
					$status_meta_key
				)
			);

			// Filter out empty meta values.
			$status_meta_values = array_filter( $status_meta_values );

			//phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$status_meta_filter = ! empty( $_GET['status_meta_filter'] ) ? sanitize_text_field( wp_unslash( $_GET['status_meta_filter'] ) ) : '';

			if ( $status_meta_values ) {
				echo '<select name="status_meta_filter">';
				echo '<option value="">' . esc_html__( 'Status', 'food-menu-pro' ) . '</option>';
				foreach ( $status_meta_values as $status ) {
					$selected = selected( $status_meta_filter, $status, false );
					echo sprintf(
						'<option value="%s" %s>%s</option>',
						esc_attr( $status ),
						esc_attr( $selected ),
						esc_html( $status )
					);
				}
				echo '</select>';
			}

			// Booking date filter input.

			$creating_date_start = ! empty( $_GET['created_date_start'] ) ? sanitize_text_field( wp_unslash( $_GET['created_date_start'] ) ) : '';
			$creating_date_end   = ! empty( $_GET['created_date_end'] ) ? sanitize_text_field( wp_unslash( $_GET['created_date_end'] ) ) : '';

			?>
            <div class="fmp-filter-date-picker-range-wrap">
                <span class="date-label"><?php echo esc_html__( "Created Date", "food-menu-pro" ) ?></span>
                <input type="text" name="created_date_start" class="fmp_date_start" value="<?php echo esc_attr( $creating_date_start ); ?>"
                       placeholder="<?php esc_attr_e( 'Start date', 'food-menu-pro' ); ?>" id="created_date_start"/>
                <input type="text" name="created_date_end" class="fmp_date_end" value="<?php echo esc_attr( $creating_date_end ); ?>"
                       placeholder="<?php esc_attr_e( 'End date', 'food-menu-pro' ); ?>" id="created_date_end">
            </div>

			<?php
			$selected_booking_date_start = ! empty( $_GET['booking_date_start'] ) ? sanitize_text_field( wp_unslash( $_GET['booking_date_start'] ) ) : '';
			$selected_booking_date_end   = ! empty( $_GET['booking_date_end'] ) ? sanitize_text_field( wp_unslash( $_GET['booking_date_end'] ) ) : '';
			?>
            <div class="fmp-filter-date-picker-range-wrap">
                <span class="date-label"><?php echo esc_html__( "Reservation Date", "food-menu-pro" ) ?></span>
                <input type="text" name="booking_date_start" class="fmp_date_start" value="<?php echo esc_attr( $selected_booking_date_start ); ?>"
                       placeholder="<?php esc_attr_e( 'Start date', 'food-menu-pro' ); ?>" id="booking_date_start"/>
                <input type="text" name="booking_date_end" class="fmp_date_end" value="<?php echo esc_attr( $selected_booking_date_end ); ?>"
                       placeholder="<?php esc_attr_e( 'End date', 'food-menu-pro' ); ?>" id="booking_date_end">
            </div>
			<?php
			//phpcs:enable
			wp_nonce_field( Fns::nonceText(), Fns::nonceId() );
		}
	}

	/**
	 * Reservation details page
	 *
	 * @return false|void
	 */
	public function reservation_details() {
		// Check if we are in the admin area and the correct action is set.
		if ( is_admin() && isset( $_GET['action'] ) && sanitize_text_field( wp_unslash( $_GET['action'] ) ) === 'resi_details' ) {
			// Verify nonce for security.
			if ( ! isset( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ), 'fmp-resi-details' ) ) {
				return false;
			}

			$id       = isset( $_GET['post_id'] ) ? absint( $_GET['post_id'] ) : '';
			$resi_arr = FnsPro::reservation_fields_array();

			// Generate the reservation details HTML.
			Fns::print_html( $this->generate_reservation_details_html( $id, $resi_arr ) );
		}
	}

	/**
	 * Generate the reservation details HTML
	 *
	 * @param int $id .
	 * @param array $resi_arr .
	 *
	 * @return string
	 */
	private function generate_reservation_details_html( $id, $resi_arr ) {
		ob_start();
		?>
        <div class="fmp-reservation-details-wrap">
            <h2 class="fmp-page-heading"><?php echo esc_html__( 'Reservation Details', 'food-menu-pro' ); ?></h2>
            <div class="fmp-reservation-details">
                <table>
					<?php
					foreach ( $resi_arr as $key => $value ) :
						$field = get_post_meta( $id, $key, true );
						if ( ! empty( $field ) ) :
							?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html( $value ); ?></strong>
                                </td>
                                <td>
									<?php
									if ( 'fmp_resi_meta_seat' === $key ) {
										$total_seat        = esc_html__( 'Total Guest: ', 'food-menu-pro' ) . $field . '<br>';
										$booked_seats_info = FnsPro::get_booked_seats_info( $id );
										$total_seat        .= join( '; <br>', $booked_seats_info );
										Fns::print_html( $total_seat );
									} else {
										echo esc_html( $field );
									}
									?>
                                </td>
                            </tr>
						<?php
						endif;
					endforeach;
					?>
                </table>
            </div>
        </div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Reservation post list custom action
	 *
	 * @param array $actions .
	 * @param array $post .
	 *
	 * @return mixed
	 */
	public function post_row_actions( $actions, $post ) {
		if ( 'fmp_reservation' === $post->post_type ) {
			unset( $actions['view'] );
			unset( $actions['inline hide-if-no-js'] );
		}

		return $actions;
	}

	/**
	 * Display custom column
	 *
	 * @param array $columns .
	 *
	 * @return array
	 */
	public function reservation_post_column( $columns ) {
		unset( $columns['date'] );
		unset( $columns['title'] );
		//		$columns['fmp_meta_id']      = esc_html__( 'ID', 'food-menu-pro' );
		$columns['fmp_meta_invoice'] = esc_html__( 'Booking ID', 'food-menu-pro' );
		$columns['fmp_created_date'] = esc_html__( 'Created Date', 'food-menu-pro' );
		$columns['fmp_meta_date']    = esc_html__( 'Reservation Date', 'food-menu-pro' );
		$columns['fmp_meta_name']    = esc_html__( 'Contact Details', 'food-menu-pro' );
		$columns['fmp_meta_seat']    = esc_html__( 'Seat', 'food-menu-pro' );
		$columns['fmp_meta_message'] = esc_html__( 'Message', 'food-menu-pro' );
		$columns['fmp_meta_status']  = esc_html__( 'Status', 'food-menu-pro' );

		return apply_filters( 'fmp/reservation/column_extra_field_title', $columns );
	}

	public function make_reservation_date_sortable() {
		$columns['fmp_meta_date']    = 'fmp_meta_date'; // The column we want to make sortable
		$columns['fmp_created_date'] = 'fmp_created_date'; // The column we want to make sortable

		return $columns;
	}

	/**
	 * Custom column set value
	 *
	 * @param string $column .
	 * @param number $post_id .
	 *
	 * @return void
	 */
	public function reservation_custom_column( $column, $post_id ) {
		switch ( $column ) {
			case 'fmp_meta_invoice':
				$booking_id = get_post_meta( $post_id, 'fmp_resi_meta_invoice', true );
				printf( "<input style='background:#FFF;border-color: #a9a9a9;width: 110px;text-align: center;padding: 0 3px;' type='text' onclick='copyText(this)' readonly value='%s'>", esc_html( $booking_id ) );
				break;
			case 'fmp_meta_name':
				echo "<strong>";
				echo esc_html( get_post_meta( $post_id, 'fmp_resi_meta_name', true ) );
				echo "</strong>";
				echo "<br>";

				$email = get_post_meta( $post_id, 'fmp_resi_meta_email', true );
				if ( ! empty( $email ) ) {
					echo '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>';
				}
				echo "<br>";

				$phone = get_post_meta( $post_id, 'fmp_resi_meta_phone', true );
				if ( ! empty( $phone ) ) {
					echo '<a href="tel:' . esc_attr( $phone ) . '">' . esc_html( $phone ) . '</a>';
				}
				break;
			case 'fmp_created_date':

				echo get_the_date( $this->dateFormat, $post_id );
				echo "</br>";
				echo get_the_date( 'h:i A', $post_id );
				//				echo $date;
				break;
			case 'fmp_meta_date':
				$booking_date       = get_post_meta( $post_id, 'fmp_resi_meta_date', true );
				$booking_start_time = str_replace( ' ', '', get_post_meta( $post_id, 'fmp_resi_meta_start_time', true ) );
				$booking_end_time   = str_replace( ' ', '', get_post_meta( $post_id, 'fmp_resi_meta_end_time', true ) );

				$today_date   = strtotime( date( 'Y-m-d' ) );
				$booking_date = strtotime( date( 'Y-m-d', $booking_date ) );
				printf(
					"<div class='booking-date'>%s %s</div>",
					$booking_date == $today_date ? '<span class="fmp-current-time"></span>' : '',
					date_i18n( $this->dateFormat, strtotime( $booking_date ) )
				);
				Fns::print_html( $booking_start_time . ' - ' . $booking_end_time );
				break;
			case 'fmp_meta_seat':
				$total_seat        = get_post_meta( $post_id, 'fmp_resi_meta_seat', true );
				$booked_seats_info = FnsPro::get_booked_seats_info( $post_id );

				echo "<div class='fmp-res-seats'>";
				$total_seat = sprintf( "<div class='total-guest'><span>%s <strong>%s</strong></span></div>",
					esc_html__( 'Total Guest: ', 'food-menu-pro' ),
					esc_html( $total_seat )
				);
				$total_seat .= join( '<br>', $booked_seats_info );
				Fns::print_html( $total_seat );

				echo "</div>";
				break;

			case 'fmp_meta_message':
				$total_seat = get_post_meta( $post_id, 'fmp_resi_meta_message', true );
				echo esc_html( wp_trim_words( $total_seat, 33, '...' ) );
				break;
			case 'fmp_meta_status':
				$status       = get_post_meta( $post_id, 'fmp_resi_meta_status', true );
				$status_class = strtolower( str_replace( ' ', '', $status ) );
				/*printf(
					"<span class='fmp-status %s'>%s</span>",
					,
					esc_html( $status )
				);*/

				$available_status = FnsPro::get_reservation_status();

				echo "<span class='fmp-status " . esc_attr( $status_class ) . "'>";
				echo "<select class='fmp_resi_meta_status_change_table' style='margin:5px 0 0' name='fmp_resi_meta_status' data-pid='" . esc_attr( $post_id ) . "'>";
				foreach ( $available_status as $key => $value ) {
					$selected = '';
					if ( $status == $key ) {
						$selected = "selected";
					}
					printf(
						"<option value='%s' %s>%s</option>",
						esc_attr( $key ),
						esc_attr( $selected ),
						esc_html( $value )
					);
				}
				echo "</select>";
				echo "</span>";

				break;
		}
	}

	function reservation_table_list_css() {
		$screen = get_current_screen();
		if ( $screen && $screen->post_type === 'fmp_reservation' && $screen->base === 'edit' ) {
			echo '<style>
            @media (min-width: 1800px){
                .column-fmp_meta_invoice { width: 220px; }
                .column-fmp_meta_date { width: 220px; }
                .column-fmp_created_date { width: 220px; }
                .column-fmp_meta_status { width: 140px; }
                .column-fmp_meta_name { width: 260px; }
                .column-fmp_meta_invoice { width: 130px; }
                .column-fmp_meta_message { width: 300px; }
            }
            </style>';
		}
	}

	public function remove_admin_notices_on_reservation_page() {
		// Check if we are on the specific admin page for fmp_reservation
		if ( isset( $_GET['post_type'] ) && $_GET['post_type'] === 'fmp_reservation' ) {
			remove_all_actions( 'admin_notices' );
			remove_all_actions( 'all_admin_notices' );
		}
	}

	/**
	 * Reservation filter export btn.
	 *
	 * @return void
	 */
	public function reservation_filter_export_btn() {
		global $typenow, $pagenow;
		if ( 'fmp_reservation' === $typenow && 'edit.php' === $pagenow ) {
			$total_reservations = count( FnsPro::get_reservation_list() );
			if ( $total_reservations > 0 ) {
				?>
                <button type="submit" name="fmp_resi_export_btn" class="button button-primary">
					<?php echo esc_html__( 'Export to CSV', 'food-menu-pro' ); ?>
                </button>
				<?php
			}
		}
	}

}

