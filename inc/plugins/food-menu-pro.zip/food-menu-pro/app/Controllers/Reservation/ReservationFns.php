<?php

namespace RT\FoodMenuPro\Controllers\Reservation;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Helpers\FnsPro;

/**
 * Reservation Fns class
 */
class ReservationFns {

	/**
	 * All setting fields
	 *
	 * @return array|null
	 */
	public static function settings_fields() {
		return array_merge(
			self::general_settings_fields(),
			self::schedule_settings_fields(),
			self::email_settings_fields(),
		);
	}

	/**
	 * General Settings fields
	 *
	 * @return array
	 */
	public static function general_settings_fields() {
		$settings = FnsPro::get_settings_option();

		return apply_filters(
			'fmp/reservation_general_settings/fields',
			[

				'fmp_resi_enable_cancel_form' => [
					'label'       => esc_html__( 'Enable Cancelled Form?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Allow users to easily cancel their reservations through a dedicated cancellation form.', 'food-menu-pro' ),
					'value'       => ! empty( $settings['fmp_resi_enable_cancel_form'] ) ? $settings['fmp_resi_enable_cancel_form'] : 'on',
				],

			]
		);
	}

	/**
	 * Schedule setting fields
	 *
	 * @return mixed|null
	 */
	public static function schedule_settings_fields() {
		$settings = FnsPro::get_settings_option();

		return apply_filters(
			'fmp/reservation_schedule_settings/fields',
			[
				'fmp_resi_information' => [
					'type'        => 'html',
					'description' => "In Reservation page, use <input style='width:auto;display: inline;text-align: center' type='text' value='[fm_reservation_form]' onclick='copyText(this)' readonly> shortcode for normal reservation. <br> And <input style='width:260px;display: inline;text-align: center' type='text' value='[fm_visual_table_reservation_form]' onclick='copyText(this)' readonly> shortcodes for table layout reservation.",
				],

				'fmp_resi_seat_capacity' => [
					'label'       => esc_html__( 'Seat Capacity', 'food-menu-pro' ),
					'type'        => 'number',
					'description' => esc_html__( 'Enter total seat capacity', 'food-menu-pro' ),
					'value'       => ! empty( $settings['fmp_resi_seat_capacity'] ) ? $settings['fmp_resi_seat_capacity'] : 30,
				],

				'fmp_resi_min_guest' => [
					'label'       => esc_html__( 'Min Guest', 'food-menu-pro' ),
					'type'        => 'number',
					'description' => esc_html__( 'Enter minimum guests number for reservation.', 'food-menu-pro' ),
					'value'       => ! empty( $settings['fmp_resi_min_guest'] ) ? $settings['fmp_resi_min_guest'] : 1,
				],

				'fmp_resi_max_guest' => [
					'label'       => esc_html__( 'Max Guest', 'food-menu-pro' ),
					'type'        => 'number',
					'description' => esc_html__( 'Enter maximum guests number for reservation', 'food-menu-pro' ),
					'value'       => ! empty( $settings['fmp_resi_max_guest'] ) ? $settings['fmp_resi_max_guest'] : 30,
				],

				'fmp_resi_weekly_schedule'            => [
					'id'       => 'fmp_resi_weekly_schedule',
					'type'     => 'array',
					'multiple' => true,
				],

				'fmp_resi_weekly_schedule_start_time' => [
					'id'       => 'fmp_resi_weekly_schedule_start_time',
					'type'     => 'array',
					'multiple' => true,
				],

				'fmp_resi_weekly_schedule_end_time'   => [
					'id'       => 'fmp_resi_weekly_schedule_end_time',
					'type'     => 'array',
					'multiple' => true,
				],

				'fmp_resi_weekly_holiday'             => [
					'id'       => 'fmp_resi_weekly_holiday',
					'type'     => 'array',
					'multiple' => true,
				],

				'fmp_resi_time_interval'              => [
					'id'          => 'fmp_resi_time_interval',
					'type'        => 'number',
					'value'       => ! empty( $settings['fmp_resi_time_interval'] ) ? $settings['fmp_resi_time_interval'] : 30,
					'label'       => esc_html__( 'Time Interval', 'food-menu-pro' ),
					'description' => esc_html__( 'Enter flexible time intervals to dynamically generate time slots in the reservation form.', 'food-menu-pro' ),
				],

				'fmp_resi_default_status' => [
					'label'       => esc_html__( 'Default Reservation Status', 'food-menu-pro' ),
					'type'        => 'select',
					'description' => esc_html__( 'Choose default reservation status. ', 'food-menu-pro' ),
					'value'       => ! empty( $settings['fmp_resi_default_status'] ) ? $settings['fmp_resi_default_status'] : 'confirmed',
					'options'     => FnsPro::get_reservation_status(),
					'default'     => 'confirmed',
					'class'       => 'fmp-select2',
				],
			]
		);
	}

	/**
	 * Email settings fields
	 *
	 * @return mixed|null
	 */
	public static function email_settings_fields() {
		$settings = FnsPro::get_settings_option();

		return apply_filters(
			'fmp/reservation_email_settings/fields',
			[
				'fmp_resi_sender_email' => [
					'label'       => esc_html__( 'Sender Email Address', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'Emails will be sent to both the admin and the user from the following email address.', 'food-menu-pro' ),
					'value'       => $settings['fmp_resi_sender_email'] ?? get_bloginfo( 'admin_email' ),
				],

				'fmp_resi_receive_email'        => [
					'label'       => esc_html__( 'Admin Receive Email', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'If \'Sender Email Address\' is not set, both admin and user emails will be sent to this address.', 'food-menu-pro' ),
					'value'       => $settings['fmp_resi_receive_email'] ?? '',
				],
				'fmp_resi_user_pending_notify'  => [
					'label'       => esc_html__( 'User Reservation Pending Notification?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Notify user upon new reservation.', 'food-menu-pro' ),
					'value'       => $settings['fmp_resi_user_pending_notify'] ?? 'on',
				],
				'fmp_resi_admin_pending_notify' => [
					'label'       => esc_html__( 'Admin Reservation Pending Notification?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Notify admin upon new reservation.', 'food-menu-pro' ),
					'value'       => $settings['fmp_resi_pending_notify'] ?? 'on',
				],

				'fmp_resi_user_confirm_notify'  => [
					'label'       => esc_html__( 'User Reservation Confirm Notification?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Notify user upon confirm reservation.', 'food-menu-pro' ),
					'value'       => $settings['fmp_resi_user_confirm_notify'] ?? 'on',
				],
				'fmp_resi_admin_confirm_notify' => [
					'label'       => esc_html__( 'Admin Reservation Confirm Notification?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Notify admin upon confirm reservation.', 'food-menu-pro' ),
					'value'       => $settings['fmp_resi_confirm_notify'] ?? 'on',
				],

				'fmp_resi_user_cancel_notify'  => [
					'label'       => esc_html__( 'User Reservation Cancelled Notification?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Notify user upon cancelled reservation.', 'food-menu-pro' ),
					'value'       => $settings['fmp_resi_user_cancel_notify'] ?? 'on',
				],
				'fmp_resi_admin_cancel_notify' => [
					'label'       => esc_html__( 'Admin Reservation Cancelled Notification?', 'food-menu-pro' ),
					'type'        => 'switch',
					'description' => esc_html__( 'Notify admin upon cancelled reservation.', 'food-menu-pro' ),
					'value'       => $settings['fmp_resi_cancel_notify'] ?? 'on',
				],
				'fmp_resi_pending_msg'         => [
					'label'       => esc_html__( 'Pending Message Text', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'Reservation pending message text', 'food-menu-pro' ),
					'value'       => ! empty( $settings['fmp_resi_pending_msg'] ) ? $settings['fmp_resi_pending_msg'] : FnsPro::get_reservation_message( [], 'pending' ),
				],
				'fmp_resi_confirm_msg'         => [
					'label'       => esc_html__( 'Confirmed Message Text', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'Reservation confirmation message text', 'food-menu-pro' ),
					'value'       => ! empty( $settings['fmp_resi_confirm_msg'] ) ? $settings['fmp_resi_confirm_msg'] : FnsPro::get_reservation_message( [], 'confirm' ),
				],
				'fmp_resi_cancel_msg'          => [
					'label'       => esc_html__( 'Cancelled Message Text', 'food-menu-pro' ),
					'type'        => 'text',
					'description' => esc_html__( 'Reservation cancelled message text', 'food-menu-pro' ),
					'value'       => ! empty( $settings['fmp_resi_cancel_msg'] ) ? $settings['fmp_resi_cancel_msg'] : FnsPro::get_reservation_message( [], 'cancel' ),
				],
			]
		);
	}

	/**
	 * Generate time interval in checkout page
	 *
	 * @return array
	 */
	public static function generateIntervalArray() {
		$intervals     = apply_filters( 'fmp_reservation_time_interval', [ 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60 ] );
		$interval_time = [];
		foreach ( $intervals as $value ) {
			$interval_time[ $value ] = $value;
		}

		return $interval_time;
	}

	/**
	 *  Get Pages list
	 *
	 * @return array
	 */
	public static function getPageLists() {
		$page_lists = [ '' => esc_html__( 'Select a Page', 'food-menu-pro' ) ];
		foreach ( get_pages() as $page ) {
			$page_lists[ $page->ID ] = $page->post_title;
		}

		return $page_lists;
	}

}
