<?php

namespace RT\FoodMenuPro\Controllers\Reservation;

defined( 'ABSPATH' ) || exit();

use RT\FoodMenuPro\Traits\SingletonTrait;
use RT\FoodMenuPro\Helpers\FnsPro;
use RT\FoodMenu\Helpers\Fns;
use DateTime;

/**
 * Special Menu Main class
 */
class ReservationSubmit {

	use SingletonTrait;

	/**
	 * Admin settings
	 *
	 * @var array
	 */
	private $options;

	/**
	 * Reservation Post Type
	 *
	 * @var string
	 */
	private $post_type = 'fmp_reservation';

	/**
	 * Init function call hooks
	 *
	 * @return void
	 */
	public function init() {
		$this->options = FnsPro::get_settings_option();

		// Reservation form submit.
		add_action( 'wp_ajax_reservation_form_submit', [ $this, 'reservation_form_submit' ] );
		add_action( 'wp_ajax_nopriv_reservation_form_submit', [ $this, 'reservation_form_submit' ] );
	}

	/**
	 * Reservation form submit from frontend
	 *
	 * @return void
	 */
	public function reservation_form_submit() {
		if ( ! wp_verify_nonce( Fns::getNonce(), Fns::nonceText() ) ) {
			return;
		}

		if ( empty( $_POST['fmp_action'] ) ) {
			return;
		}

		$action = sanitize_text_field( wp_unslash( $_POST['fmp_action'] ) );

		if ( 'fmp-reservation' === $action ) {
			$this->make_reservation();
		}

		if ( 'fmp-reservation-cancel' === $action ) {
			$this->cancel_reservation();
		}
	}

	/**
	 * Make Reservation
	 *
	 * @return void
	 */
	public function make_reservation() {
		$total_seat_capacity     = ! empty( $this->options['fmp_resi_seat_capacity'] ) ? $this->options['fmp_resi_seat_capacity'] : 30;
		$fmp_resi_default_status = ! empty( $this->options['fmp_resi_default_status'] ) ? $this->options['fmp_resi_default_status'] : 'confirmed';
		$form_data               = filter_input_array( INPUT_POST, FILTER_SANITIZE_SPECIAL_CHARS );

		$meta_data                             = [];
		$resi_name                             = ! empty( $form_data['fmp_name'] ) ? sanitize_text_field( $form_data['fmp_name'] ) : '';
		$resi_content                          = ! empty( $form_data['fmp_message'] ) ? sanitize_text_field( $form_data['fmp_message'] ) : '';
		$resi_email                            = ( ! empty( $form_data['fmp_email'] ) && is_email( $form_data['fmp_email'] ) ) ? sanitize_email( $form_data['fmp_email'] ) : '';
		$resi_date                             = ! empty( $form_data['fmp_date'] ) ? sanitize_text_field( $form_data['fmp_date'] ) : '';
		$resi_start_time                       = ! empty( $form_data['fmp_start_time'] ) ? sanitize_text_field( $form_data['fmp_start_time'] ) : '';
		$resi_end_time                         = ! empty( $form_data['fmp_end_time'] ) ? sanitize_text_field( $form_data['fmp_end_time'] ) : '';
		$resi_guest_no                         = ! empty( $form_data['fmp_guest_nub'] ) ? sanitize_text_field( $form_data['fmp_guest_nub'] ) : '';
		$resi_phone                            = ! empty( $form_data['fmp_phone'] ) ? preg_replace( '/[^0-9+-]/', '', sanitize_text_field( $form_data['fmp_phone'] ) ) : '';
		$meta_data['fmp_resi_meta_date']       = strtotime( $resi_date );
		$meta_data['fmp_resi_meta_start_time'] = $resi_start_time;
		$meta_data['fmp_resi_meta_end_time']   = $resi_end_time;
		$meta_data['fmp_resi_meta_seat']       = $resi_guest_no;
		$meta_data['fmp_resi_meta_name']       = $resi_name;
		$meta_data['fmp_resi_meta_email']      = $resi_email;
		$meta_data['fmp_resi_meta_phone']      = $resi_phone;
		$meta_data['fmp_resi_meta_message']    = $resi_content;
		$post_slug                             = sanitize_title_with_dashes( $resi_name, '', 'save' );
		$post_slug                             = sanitize_text_field( $post_slug );

		// visual table booking .
		$visual_table           = ! empty( $form_data['fmp_visual_selection'] ) ? absint( $form_data['fmp_visual_selection'] ) : 0;
		$visual_table_error     = false;
		$visual_table_error_msg = '';

		if ( $visual_table ) {
			$selected_ids   = $form_data['fmp_booked_ids'] ?? '';
			$selected_ids   = ! empty( $selected_ids ) ? explode( ',', $selected_ids ) : [];
			$total_selected = count( $selected_ids );

			if ( $total_selected > 0 ) {
				if ( $resi_guest_no != $total_selected ) {
					$visual_table_error     = true;
					$visual_table_error_msg = esc_html__( 'Guest and selected seat count mismatch. Please check and try again.', 'food-menu-pro' );
				} else {
					$booking_data = FnsPro::get_booking_data( $resi_date, $resi_start_time, $resi_end_time );
					$booking_open = $booking_data['booking_open'];

					if ( $booking_open ) {
						$capacity = $booking_data['capacity'];

						if ( $total_selected <= $capacity ) {
							$booked_ids         = $booking_data['booked_ids'];
							$intersected_ids    = array_intersect( $selected_ids, $booked_ids );
							$visual_table_error = ! empty( $intersected_ids );
							if ( $visual_table_error ) {
								$visual_table_error_msg = esc_html__( 'Selected seat already booked', 'food-menu-pro' );
							}
						} else {
							$visual_table_error     = true;
							$visual_table_error_msg = esc_html__( 'Selected seats exceed the total capacity', 'food-menu-pro' );
						}
					} else {
						$visual_table_error     = true;
						$visual_table_error_msg = esc_html__( 'Sorry, all seats are booked. Please change the schedule and try again.', 'food-menu-pro' );
					}

					if ( ! $visual_table_error ) {
						$fmp_schedule_slug    = $form_data['fmp_schedule_slug'] ?? 'table_layout_slug';
						$fmp_obj_names        = ! empty( $_POST['fmp_obj_names'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_obj_names'] ) ) : [];
						$fmp_intersected_data = ! empty( $_POST['fmp_intersected_data'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_intersected_data'] ) ) : [];
						$fmp_mapping_data     = ! empty( $_POST['fmp_mapping_data'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_mapping_data'] ) ) : [];
						$selected_table_ids   = ! empty( $_POST['fmp_booked_table_ids'] ) ? sanitize_text_field( wp_unslash( $_POST['fmp_booked_table_ids'] ) ) : [];
						$selected_table_ids   = ! empty( $selected_table_ids ) ? explode( ',', $selected_table_ids ) : [];

						$meta_data['fmp_resi_meta_visual_selection'] = $visual_table;
						$meta_data['fmp_resi_meta_schedule_slug']    = $fmp_schedule_slug;
						$meta_data['fmp_resi_meta_booked_ids']       = maybe_serialize( $selected_ids ); //store all chair ids
						$meta_data['fmp_resi_meta_booked_table_ids'] = maybe_serialize( $selected_table_ids ); //store all table ids
						$meta_data['fmp_resi_meta_obj_names']        = $fmp_obj_names;
						$meta_data['fmp_resi_meta_intersected_data'] = $fmp_intersected_data;
						$meta_data['fmp_resi_meta_mapping_data']     = $fmp_mapping_data;
					}
				}
			}
		}

		if ( $visual_table_error ) {
			$response = [
				'status_code' => 400,
				'message'     => $visual_table_error_msg,
			];
			wp_send_json_error( $response );
		}

		if ( ! empty( $resi_name ) && ! empty( $resi_email ) && ! empty( $resi_date )
		     && ! empty( $resi_start_time ) && ! empty( $resi_end_time ) && ! empty( $resi_guest_no ) && ! empty( $resi_phone ) ) {
			// Insert post in fmp_reservation post type.
			$post_args = [
				'post_type'      => $this->post_type,
				'post_name'      => $post_slug,
				'post_title'     => $resi_name,
				'post_content'   => $resi_content,
				'post_status'    => 'publish',
				'comment_status' => 'closed',
			];

			$post_id                            = wp_insert_post( $post_args );
			$booking_id                         = FnsPro::generate_invoice_number( $post_id );
			$meta_data['fmp_resi_meta_invoice'] = $booking_id;

			$meta_data['fmp_resi_meta_status'] = $fmp_resi_default_status;

			// Add post meta in fmp_reservation post type.
			foreach ( $meta_data as $key => $value ) {
				update_post_meta( $post_id, $key, $value );
			}

			if ( 0 != $post_id ) {
				if ( 'confirmed' === $meta_data['fmp_resi_meta_status'] ) {
					$message = FnsPro::get_reservation_message( $this->options, 'confirm', $booking_id );
				} else {
					$message = FnsPro::get_reservation_message( $this->options, 'pending', $booking_id );
				}

				$mail_args = [
					'ID'           => $post_id,
					'booking_date' => $resi_date . ' (' . $resi_start_time . ' to ' . $resi_end_time . ')'
				];

				// Send email admin & user.
				FnsPro::send_email_notify( $mail_args, $resi_email, $booking_id, $meta_data['fmp_resi_meta_status'] );

				$response = [
					'status_code' => 200,
					'message'     => $message,
				];
				wp_send_json_success( $response );
			} else {
				$response = [
					'status_code' => 400,
					'message'     => esc_html__( 'Failed to place booking. Please try again', 'food-menu-pro' ),
				];
				wp_send_json_error( $response );
			}
		} else {
			$response = [
				'status_code' => 400,
				'message'     => esc_html__( 'Please enter the all required fields.', 'food-menu-pro' ),
			];
			wp_send_json_error( $response );
		}
		wp_die();
	}

	/**
	 * Cancel Reservation
	 *
	 * @return void
	 */
	public function cancel_reservation() {
		$form_data    = filter_input_array( INPUT_POST, FILTER_SANITIZE_SPECIAL_CHARS );
		$booking_id   = ! empty( $form_data['fmp_booking_id'] ) ? sanitize_text_field( $form_data['fmp_booking_id'] ) : '';
		$cancel_email = ( ! empty( $form_data['fmp_cancel_email'] ) && is_email( $form_data['fmp_cancel_email'] ) ) ? sanitize_email( $form_data['fmp_cancel_email'] ) : '';
		$cancel_phone = ! empty( $form_data['fmp_cancel_phone'] ) ? preg_replace( '/[^0-9+-]/', '', sanitize_text_field( $form_data['fmp_cancel_phone'] ) ) : '';
		$content      = ! empty( $form_data['fmp_message'] ) ? sanitize_text_field( $form_data['fmp_message'] ) : '';
		$resi_status  = 'cancelled';
		if ( ! empty( $booking_id ) && ! empty( $cancel_email ) && ! empty( $cancel_phone ) ) {
			$args = [
				'post_type'      => $this->post_type,
				'posts_per_page' => 1,
				//phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'meta_query'     => [
					[
						'key'   => 'fmp_resi_meta_invoice',
						'value' => $booking_id,
					],
					[
						'key'   => 'fmp_resi_meta_email',
						'value' => $cancel_email,
					],
				],
			];

			$booking_post = get_posts( $args );
			if ( $booking_post && ! is_wp_error( $booking_post ) ) {
				$booking_post_id = $booking_post[0]->ID;
				update_post_meta( $booking_post_id, 'fmp_resi_meta_status', 'cancelled' );

				// Send email admin & user.
				FnsPro::send_email_notify( [ 'ID' => $booking_post_id ], $cancel_email, $booking_id, $resi_status );

				$response = [
					'status_code' => 200,
					'message'     => [ esc_html__( 'Your request for cancellation has been processed successfully.', 'food-menu-pro' ) ],
				];
				wp_send_json_success( $response );
			} else {
				$response = [
					'status_code' => 401,
					'message'     => [ esc_html__( 'No reservation found please provide the details', 'food-menu-pro' ) ],
				];
				wp_send_json_error( $response );
			}
		} else {
			$response = [
				'status_code' => 400,
				'message'     => [ esc_html__( 'Please enter the all required fields.', 'food-menu-pro' ) ],
			];
			wp_send_json_error( $response );
		}

		wp_die();
	}

}

