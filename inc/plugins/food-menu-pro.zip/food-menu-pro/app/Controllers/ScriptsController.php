<?php
/**
 * Scripts Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers;

use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Scripts Class.
 */
class ScriptsController {
	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Styles.
	 *
	 * @var array
	 */
	private $styles = [];

	/**
	 * Scripts.
	 *
	 * @var array
	 */
	private $scripts = [];

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		$this->get_assets();

		if ( empty( $this->styles ) && empty( $this->scripts ) ) {
			return;
		}

		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : FMP()->options['version'];

		wp_deregister_style( 'fmp-frontend' );
		wp_deregister_script( 'fmp-frontend' );
		foreach ( $this->styles as $style ) {
			wp_register_style( $style['handle'], $style['src'], '', $version );
		}

		foreach ( $this->scripts as $script ) {
			wp_register_script( $script['handle'], $script['src'], $script['deps'], $version, $script['footer'] );
		}

		add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_script' ] );

		// Make client JS translations from any translation plugin load regardless
		// of the JSON filename hash (see load_merged_script_translations()).
		add_filter( 'pre_load_script_translations', [ $this, 'load_merged_script_translations' ], 10, 4 );
	}

	/**
	 * Frontend scripts.
	 *
	 * @return void
	 */
	public function frontend_script() {
		\wp_enqueue_style( 'fmp-swiper' );
//		\wp_enqueue_style( 'fmp-scrollbar' );
		\wp_enqueue_style( 'fmp-fontawsome' );
		\wp_enqueue_style( 'fmp-modal' );
		\wp_enqueue_style( 'fmp-addon' );

		if ( is_rtl() ) {
			\wp_enqueue_style( 'fmp-rtl' );
		}

		\wp_enqueue_style( 'fmp-frontend' );

		if ( is_single() && get_post_type() == TLPFoodMenu()->post_type ) {
			\wp_enqueue_script( 'fmp-image-load' );
			\wp_enqueue_script( 'fmp-swiper' );
			\wp_enqueue_script( 'fmp-single-food' );
		}
	}

	/**
	 * Admin scripts.
	 *
	 * @return void
	 */
	public function admin_scripts() {
		global $pagenow, $typenow;

		// validate page.
		if ( ! in_array( $pagenow, [ 'edit.php', 'post.php', 'post-new.php' ] ) ) {
			return;
		}

		if ( TLPFoodMenu()->post_type != $typenow && 'product' != $typenow ) {
			return;
		}

		\wp_enqueue_script(
			[
				'ace_code_highlighter_js',
				'ace_mode_js',
				'fmp-admin',
			]
		);

		\wp_enqueue_style(
			[
				'fmp-fontawsome',
				'fmp-admin',
			]
		);

		// Dynamic admin primary color from settings.
		$settings    = get_option( TLPFoodMenu()->options['settings'], [] );
		$primary_hex = ! empty( $settings['fm_primary_color'] ) ? sanitize_hex_color( $settings['fm_primary_color'] ) : '';

		if ( $primary_hex ) {
			$hex       = ltrim( $primary_hex, '#' );
			$r         = hexdec( substr( $hex, 0, 2 ) );
			$g         = hexdec( substr( $hex, 2, 2 ) );
			$b         = hexdec( substr( $hex, 4, 2 ) );
			$hover_hex = sprintf( '#%02x%02x%02x', max( 0, (int) round( $r * 0.85 ) ), max( 0, (int) round( $g * 0.85 ) ), max( 0, (int) round( $b * 0.85 ) ) );

			$css = ':root{'
				. '--fmp-admin-primary:' . $primary_hex . ';'
				. '--fmp-admin-primary-rgb:' . $r . ',' . $g . ',' . $b . ';'
				. '--fmp-admin-primary-hover:' . $hover_hex . ';'
				. '}';
			wp_add_inline_style( 'fmp-admin', $css );
		}

		$nonce = wp_create_nonce( Fns::nonceText() );

		\wp_localize_script(
			'fmp-admin',
			'fmp_var',
			[
				'nonceID'        => esc_attr( Fns::nonceId() ),
				'nonce'          => esc_attr( $nonce ),
				'ajaxurl'        => esc_url( admin_url( 'admin-ajax.php' ) ),
				'pickupDelivery' => [
					'dayExist' => esc_html__( 'day exist. Please check another day', 'food-menu-pro' ),
				],
				'shouldSort'     => $this->condition_check()
			]
		);
	}

	public function condition_check() {

		//phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['orderby'] ) && $_GET['orderby'] !== 'menu_order' ) {
			return false;
		}

		// return if post status filtering.
		if ( isset( $_GET['post_status'] ) && $_GET['post_status'] !== 'all' ) {
			return false;
		}

		// return if post author filtering.
		if ( isset( $_GET['filter_action'] ) ) {
			return false;
		}

		// return if post author filtering.
		if ( isset( $_GET['author'] ) ) {
			return false;
		}
		//phpcs:enable WordPress.Security.NonceVerification.Recommended

		return true;
	}

	/**
	 * Get all scripts.
	 *
	 * @return void
	 */
	private function get_assets() {
		$this
			->get_styles()
			->get_scripts();
	}

	/**
	 * Get styles.
	 *
	 * @return object
	 */
	private function get_styles() {
		$this->styles[] = [
			'handle' => 'fmp-fontawsome',
			'src'    => FMP()->assets_url() . 'vendor/font-awesome/css/font-awesome.min.css',
		];

		/*$this->styles[] = [
			'handle' => 'fmp-scrollbar',
			'src'    => FMP()->assets_url() . 'vendor/scrollbar/jquery.mCustomScrollbar.min.css',
		];*/

		$this->styles[] = [
			'handle' => 'fmp-swiper',
			'src'    => FMP()->assets_url() . 'vendor/swiper/swiper.min.css',
		];

		$this->styles[] = [
			'handle' => 'fmp-modal',
			'src'    => FMP()->assets_url() . 'vendor/jquery-modal/jquery.modal.min.css',
		];

		$this->styles[] = [
			'handle' => 'fmp-frontend',
			'src'    => FMP()->assets_url() . 'css/foodmenu.min.css',
		];


		/*
		 * We include this file win front-end elementor. No need registration and enqueue separately
		 * $this->styles[] = [
			'handle' => 'fmp-elementor',
			'src'    => FMP()->assets_url() . 'css/fmp-elementor.min.css',
		];*/

		$this->styles[] = [
			'handle' => 'fmp-custom-checkout',
			'src'    => FMP()->assets_url() . 'css/custom-checkout-css.min.css',
		];

		/*$this->styles[] = [
			'handle' => 'fmp-rtl',
			'src'    => FMP()->assets_url() . 'css/foodmenu-rtl.css',
		];*/

		/**
		 * Admin Styles.
		 */
		if ( is_admin() ) {
			$this->styles[] = [
				'handle' => 'fmp-admin',
				'src'    => FMP()->assets_url() . 'css/admin.min.css',
			];

			$this->styles[] = [
				'handle' => 'fmp-admin-preview',
				'src'    => FMP()->assets_url() . 'css/admin-preview.min.css',
			];
		}

		return $this;
	}

	/**
	 * Get scripts.
	 *
	 * @return object
	 */
	private function get_scripts() {

		// Google Map API.
		$settings = get_option( TLPFoodMenu()->options['settings'] );
		$map_js   = 'https://maps.google.com/maps/api/js?libraries=places';
		if ( $settings ) {
			$api_key = ! empty( $settings['google_api_key'] ) ? $settings['google_api_key'] : 'AIzaSyBRiJpfKRV-hDFuQ6ynEAStJVO09g5Ecd4';
			$map_js  = $map_js . '&key=' . $api_key;
			$map_js  .= '&callback=Function.prototype';
		}

		$this->scripts[] = [
			'handle' => 'fmp-image-load',
			'src'    => FMP()->assets_url() . 'vendor/isotope/imagesloaded.pkgd.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-isotope',
			'src'    => FMP()->assets_url() . 'vendor/isotope/isotope.pkgd.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];

		$this->scripts[] = [
			'handle' => 'fmp-jzoom',
			'src'    => FMP()->assets_url() . 'vendor/jzoom/jzoom.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];

		/*$this->scripts[] = [
			'handle' => 'fmp-scrollbar',
			'src'    => FMP()->assets_url() . 'vendor/scrollbar/jquery.mCustomScrollbar.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];*/

		$this->scripts[] = [
			'handle' => 'fmp-swiper',
			'src'    => FMP()->assets_url() . 'vendor/swiper/swiper.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-actual-height',
			'src'    => FMP()->assets_url() . 'vendor/actual-height/jquery.actual.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];

		$this->scripts[] = [
			'handle' => 'fmp-modal',
			'src'    => FMP()->assets_url() . 'vendor/jquery-modal/jquery.modal.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];

		$this->scripts[] = [
			'handle' => 'fmp-single-food',
			'src'    => FMP()->assets_url() . 'js/single-food.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-frontend',
			'src'    => FMP()->assets_url() . 'js/foodmenu.min.js',
			'deps'   => [ 'jquery', 'fmp-actual-height', 'imagesloaded', 'fmp-addon' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-elementor',
			'src'    => FMP()->assets_url() . 'js/fmp-elementor.min.js',
			'deps'   => [ 'jquery', 'fmp-actual-height', 'fmp-image-load', 'fmp-isotope', 'fmp-addon' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-pickup-delivery',
			'src'    => FMP()->assets_url() . 'js/pickup-delivery.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-google-map',
			'src'    => $map_js,
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];
		$this->scripts[] = [
			'handle' => 'fmp-addon',
			'src'    => FMP()->assets_url() . 'js/addon.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];
		$this->scripts[] = [
			'handle' => 'fmp-order-bumps',
			'src'    => FMP()->assets_url() . 'js/order-bumps.min.js',
			'deps'   => [ 'jquery', 'fmp-swiper' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-custom-checkout',
			'src'    => FMP()->assets_url() . 'js/custom-checkout.min.js',
			'deps'   => [ 'jquery', 'wc-checkout', 'jquery-blockui' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-table-layout',
			'src'    => FMP()->assets_url() . 'js/table-layout.min.js',
			'deps'   => [ 'jquery', 'wp-element','wp-components' ],
			'footer' => true,
		];

		/**
		 * Admin Scripts.
		 */
		if ( is_admin() ) {
			$this->scripts[] = [
				'handle' => 'ace_code_highlighter_js',
				'src'    => FMP()->assets_url() . 'vendor/ace/ace.js',
				'deps'   => null,
				'footer' => false,
			];
			$this->scripts[] = [
				'handle' => 'ace_mode_js',
				'src'    => FMP()->assets_url() . 'vendor/ace/mode-css.js',
				'deps'   => [ 'ace_code_highlighter_js' ],
				'footer' => false,
			];
			$this->scripts[] = [
				'handle' => 'fmp-accounting',
				'src'    => FMP()->assets_url() . 'vendor/accounting/accounting.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-food',
				'src'    => FMP()->assets_url() . 'js/admin-food.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin',
				'src'    => FMP()->assets_url() . 'js/admin.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-preview',
				'src'    => FMP()->assets_url() . 'js/admin-preview.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-sc',
				'src'    => FMP()->assets_url() . 'js/admin-sc.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-taxonomy',
				'src'    => FMP()->assets_url() . 'js/admin-taxonomy.min.js',
				'deps'   => [ 'jquery', 'fmp-google-map' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-pickup-delivery',
				'src'    => FMP()->assets_url() . 'js/admin-pickup-delivery.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-addon',
				'src'    => FMP()->assets_url() . 'js/admin-addon.min.js',
				'deps'   => [ 'jquery', 'jquery-ui-sortable' ],
				'footer' => true,
			];
		}

		return $this;
	}

	/**
	 * Merge every JSON translation file for the current locale into one payload,
	 * regardless of its filename hash.
	 *
	 * WordPress' default JS-translation loading expects a single JSON file named
	 * by the md5 of the (unminified) enqueued bundle path. Translation plugins
	 * (Loco Translate, GlotPress, …) name their JSON after the original *source*
	 * file instead, so WordPress never finds it and React strings stay English.
	 *
	 * Returning a non-null value from `pre_load_script_translations` short-
	 * circuits that md5 lookup. We glob every `food-menu-pro-{locale}-*.json`
	 * (and the bare `food-menu-pro-{locale}.json`) from the plugin, Loco and
	 * WordPress.org language folders and merge them — so whatever any translation
	 * plugin produced for this locale is loaded. No filename matching, no shipped
	 * JSON, existing files untouched. (Approach proven in the Radius Booking
	 * plugin.)
	 *
	 * @param string|false|null $translations Existing value (null by default).
	 * @param string            $file         Path WordPress would otherwise load.
	 * @param string            $handle       Script handle.
	 * @param string            $domain       Text domain.
	 * @return string|false|null JSON string to use, or the original value to fall through.
	 */
	public function load_merged_script_translations( $translations, $file, $handle, $domain ) {
		if ( 'food-menu-pro' !== $domain ) {
			return $translations;
		}

		static $cache = [];

		$locales   = array_unique( array_filter( [ determine_locale(), get_locale() ] ) );
		$cache_key = implode( '|', $locales );

		if ( isset( $cache[ $cache_key ] ) ) {
			return $cache[ $cache_key ];
		}

		$files = $this->find_translation_json_files( $locales );

		if ( empty( $files ) ) {
			$cache[ $cache_key ] = $translations;
			return $translations;
		}

		$messages = [
			'' => [
				'domain' => 'messages',
				'lang'   => reset( $locales ),
			],
		];

		foreach ( $files as $f ) {
			if ( 'json' === strtolower( pathinfo( $f, PATHINFO_EXTENSION ) ) ) {
				// JSON files produced by translation plugins / `wp i18n make-json`.
				$raw = file_get_contents( $f ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				if ( false === $raw ) {
					continue;
				}
				$data = json_decode( $raw, true );
				if ( empty( $data['locale_data'] ) || ! is_array( $data['locale_data'] ) ) {
					continue;
				}
				foreach ( $data['locale_data'] as $inner ) {
					if ( ! is_array( $inner ) ) {
						continue;
					}
					if ( isset( $inner['']['plural-forms'] ) ) {
						$messages['']['plural-forms'] = $inner['']['plural-forms'];
					}
					foreach ( $inner as $msgid => $msgstr ) {
						if ( '' === $msgid ) {
							continue;
						}
						$messages[ $msgid ] = $msgstr;
					}
					break;
				}
			} else {
				// Gettext files (.mo / .l10n.php). Loco and most tools generate
				// these on EVERY site (a JSON is only produced when the plugin's
				// JS source files are present, e.g. a dev copy — not a release
				// build), so reading them is what makes JS translations work in
				// production. The whole domain (PHP + JS strings) is merged; the
				// React bundle only consumes the keys it needs.
				foreach ( $this->read_gettext_messages( $f ) as $msgid => $msgstr ) {
					if ( '' === $msgid ) {
						continue;
					}
					$messages[ $msgid ] = $msgstr;
				}
			}
		}

		$merged = wp_json_encode(
			[
				'domain'      => 'messages',
				'locale_data' => [ 'messages' => $messages ],
			]
		);

		$cache[ $cache_key ] = $merged;

		return $merged;
	}

	/**
	 * Collect all JSON translation files for the given locales across the plugin
	 * and the common language folders (newest last so later edits win).
	 *
	 * The folder list is filterable via `fmp_script_translation_dirs` so any
	 * translation plugin (WPML, etc.) or site setup that stores JSON elsewhere
	 * can register its location.
	 *
	 * @param array $locales Locale slugs to look for.
	 * @return array Absolute file paths.
	 */
	private function find_translation_json_files( array $locales ) {
		$dirs = [
			FOOD_MENU_PRO_PLUGIN_DIR_PATH . 'languages', // Plugin-shipped.
			WP_LANG_DIR . '/loco/plugins',               // Loco Translate.
			WP_LANG_DIR . '/plugins',                    // WordPress.org language packs.
			WP_LANG_DIR,                                 // wp i18n make-json / manual.
		];

		/**
		 * Filter the directories scanned for React/JS translation JSON files.
		 *
		 * @param string[] $dirs    Absolute directory paths.
		 * @param array    $locales Locale slugs being looked up.
		 */
		$dirs = (array) apply_filters( 'fmp_script_translation_dirs', $dirs, $locales );

		$found = [];

		foreach ( $dirs as $dir ) {
			foreach ( $locales as $locale ) {
				$patterns = [
					$dir . '/food-menu-pro-' . $locale . '-*.json', // Per-script JSON (tools with JS sources).
					$dir . '/food-menu-pro-' . $locale . '.json',    // Single JSON.
					$dir . '/food-menu-pro-' . $locale . '.l10n.php', // PHP gettext (WP 6.5+).
					$dir . '/food-menu-pro-' . $locale . '.mo',       // Binary gettext.
				];
				foreach ( $patterns as $pattern ) {
					$matches = glob( $pattern );
					if ( ! empty( $matches ) ) {
						$found = array_merge( $found, $matches );
					}
				}
			}
		}

		$found = array_values( array_unique( $found ) );

		usort(
			$found,
			static function ( $a, $b ) {
				return filemtime( $a ) <=> filemtime( $b );
			}
		);

		return $found;
	}

	/**
	 * Read a gettext translation file (.mo / .l10n.php) into a flat
	 * `original => [ translations ]` map suitable for Jed locale data.
	 *
	 * @param string $file Absolute path to a .mo or .l10n.php file.
	 * @return array
	 */
	private function read_gettext_messages( $file ) {
		$out = [];

		// WP 6.5+ unified reader handles both .mo and .l10n.php. A fresh handle
		// returns the full entry set (originals => translation, "\0" = plural).
		if ( class_exists( '\WP_Translation_File' ) ) {
			$moe = \WP_Translation_File::create( $file );
			if ( $moe instanceof \WP_Translation_File && null === $moe->error() ) {
				foreach ( $moe->entries() as $original => $translation ) {
					$out[ $original ] = explode( "\0", (string) $translation );
				}
			}
			return $out;
		}

		// Fallback for WP < 6.5: read .mo via the bundled pomo MO class.
		if ( '.mo' === substr( $file, -3 ) && class_exists( '\MO' ) ) {
			$mo = new \MO();
			if ( $mo->import_from_file( $file ) ) {
				foreach ( $mo->entries as $entry ) {
					$key         = $entry->context ? $entry->context . "\4" . $entry->singular : $entry->singular;
					$out[ $key ] = $entry->translations;
				}
			}
		}

		return $out;
	}
}
