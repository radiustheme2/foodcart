<?php
/**
 * Scripts Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers;

use RT\FoodMenu\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Scripts Class.
 */
class ScriptsController {
	use \RT\FoodMenuPro\Traits\SingletonTrait;

	/**
	 * Styles.
	 *
	 * @var array
	 */
	private $styles = [];

	/**
	 * Scripts.
	 *
	 * @var array
	 */
	private $scripts = [];

	/**
	 * Class Init.
	 *
	 * @return void
	 */
	protected function init() {
		$this->get_assets();

		if ( empty( $this->styles ) && empty( $this->scripts ) ) {
			return;
		}

		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : FMP()->options['version'];

		wp_deregister_style( 'fmp-frontend' );
		wp_deregister_script( 'fmp-frontend' );
		wp_deregister_script( 'fmp-elementorfmp-elementorfmp-elementor' );
		foreach ( $this->styles as $style ) {
			wp_register_style( $style['handle'], $style['src'], '', $version );
		}

		foreach ( $this->scripts as $script ) {
			wp_register_script( $script['handle'], $script['src'], $script['deps'], $version, $script['footer'] );
		}

		\add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts' ] );
		\add_action( 'wp_enqueue_scripts', [ $this, 'frontend_script' ] );
	}

	/**
	 * Frontend scripts.
	 *
	 * @return void
	 */
	public function frontend_script() {
		\wp_enqueue_style( 'fmp-swiper' );
		\wp_enqueue_style( 'fmp-scrollbar' );
		\wp_enqueue_style( 'fmp-fontawsome' );
		\wp_enqueue_style( 'fmp-modal' );

		if ( is_rtl() ) {
			\wp_enqueue_style( 'fmp-rtl' );
		}

		\wp_enqueue_style( 'fmp-frontend' );

		if ( did_action( 'elementor/loaded' ) ) {
			\wp_enqueue_style( 'fmp-elementor' );
		}

		if ( is_single() && get_post_type() == TLPFoodMenu()->post_type ) {
			\wp_enqueue_script( 'fmp-image-load' );
			\wp_enqueue_script( 'fmp-swiper' );
			\wp_enqueue_script( 'fmp-single-food' );
		}
	}

	/**
	 * Admin scripts.
	 *
	 * @return void
	 */
	public function admin_scripts() {
		global $pagenow, $typenow;

		// validate page.
		if ( ! in_array( $pagenow, [ 'edit.php', 'post.php', 'post-new.php' ] ) ) {
			return;
		}

		if ( TLPFoodMenu()->post_type != $typenow && 'product' != $typenow ) {
			return;
		}

		\wp_enqueue_script(
			[
				'ace_code_highlighter_js',
				'ace_mode_js',
				'fmp-admin',
			]
		);

		\wp_enqueue_style(
			[
				'fmp-fontawsome',
				'fmp-admin',
			]
		);

		$nonce = wp_create_nonce( Fns::nonceText() );

		\wp_localize_script(
			'fmp-admin',
			'fmp_var',
			[
				'nonceID'        => esc_attr( Fns::nonceId() ),
				'nonce'          => esc_attr( $nonce ),
				'ajaxurl'        => esc_url( admin_url( 'admin-ajax.php' ) ),
				'pickupDelivery' => [
					'dayExist' => esc_html__( 'day exist. Please check another day', 'food-menu-pro' ),
				],
				'shouldSort'     => $this->condition_check()
			]
		);
	}

	public function condition_check() {

		//phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['orderby'] ) && $_GET['orderby'] !== 'menu_order' ) {
			return false;
		}

		// return if post status filtering.
		if ( isset( $_GET['post_status'] ) && $_GET['post_status'] !== 'all' ) {
			return false;
		}

		// return if post author filtering.
		if ( isset( $_GET['filter_action'] ) ) {
			return false;
		}

		// return if post author filtering.
		if ( isset( $_GET['author'] ) ) {
			return false;
		}
		//phpcs:enable WordPress.Security.NonceVerification.Recommended

		return true;
	}

	/**
	 * Get all scripts.
	 *
	 * @return void
	 */
	private function get_assets() {
		$this
			->get_styles()
			->get_scripts();
	}

	/**
	 * Get styles.
	 *
	 * @return object
	 */
	private function get_styles() {
		$this->styles[] = [
			'handle' => 'fmp-fontawsome',
			'src'    => FMP()->assets_url() . 'vendor/font-awesome/css/font-awesome.min.css',
		];

		$this->styles[] = [
			'handle' => 'fmp-scrollbar',
			'src'    => FMP()->assets_url() . 'vendor/scrollbar/jquery.mCustomScrollbar.min.css',
		];

		$this->styles[] = [
			'handle' => 'fmp-swiper',
			'src'    => FMP()->assets_url() . 'vendor/swiper/swiper.min.css',
		];

		$this->styles[] = [
			'handle' => 'fmp-modal',
			'src'    => FMP()->assets_url() . 'vendor/jquery-modal/jquery.modal.min.css',
		];

		$this->styles[] = [
			'handle' => 'fmp-timepicker',
			'src'    => FMP()->assets_url() . 'vendor/timepicker/jquery.timepicker.min.css',
		];

		$this->styles[] = [
			'handle' => 'fmp-flatpickr',
			'src'    => FMP()->assets_url() . 'vendor/flatpickr/flatpickr.min.css',
		];

		$this->styles[] = [
			'handle' => 'fmp-frontend',
			'src'    => FMP()->assets_url() . 'css/foodmenu.min.css',
		];


		$this->styles[] = [
			'handle' => 'fmp-elementor',
			'src'    => FMP()->assets_url() . 'css/fmp-elementor.min.css',
		];

		/*$this->styles[] = [
			'handle' => 'fmp-rtl',
			'src'    => FMP()->assets_url() . 'css/foodmenu-rtl.css',
		];*/

		/**
		 * Admin Styles.
		 */
		if ( is_admin() ) {
			$this->styles[] = [
				'handle' => 'fmp-admin',
				'src'    => FMP()->assets_url() . 'css/admin.min.css',
			];

			$this->styles[] = [
				'handle' => 'fmp-admin-preview',
				'src'    => FMP()->assets_url() . 'css/admin-preview.min.css',
			];
		}

		return $this;
	}

	/**
	 * Get scripts.
	 *
	 * @return object
	 */
	private function get_scripts() {

		// Google Map API.
		$settings = get_option( TLPFoodMenu()->options['settings'] );
		$map_js   = 'https://maps.google.com/maps/api/js?libraries=places';
		if ( $settings ) {
			$api_key = ! empty( $settings['google_api_key'] ) ? $settings['google_api_key'] : 'AIzaSyBRiJpfKRV-hDFuQ6ynEAStJVO09g5Ecd4';
			$map_js  = $map_js . '&key=' . $api_key;
			$map_js  .= '&callback=Function.prototype';
		}

		$this->scripts[] = [
			'handle' => 'fmp-image-load',
			'src'    => FMP()->assets_url() . 'vendor/isotope/imagesloaded.pkgd.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-isotope',
			'src'    => FMP()->assets_url() . 'vendor/isotope/isotope.pkgd.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];

		$this->scripts[] = [
			'handle' => 'fmp-jzoom',
			'src'    => FMP()->assets_url() . 'vendor/jzoom/jzoom.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];

		$this->scripts[] = [
			'handle' => 'fmp-scrollbar',
			'src'    => FMP()->assets_url() . 'vendor/scrollbar/jquery.mCustomScrollbar.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];

		$this->scripts[] = [
			'handle' => 'fmp-swiper',
			'src'    => FMP()->assets_url() . 'vendor/swiper/swiper.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-actual-height',
			'src'    => FMP()->assets_url() . 'vendor/actual-height/jquery.actual.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];

		$this->scripts[] = [
			'handle' => 'fmp-modal',
			'src'    => FMP()->assets_url() . 'vendor/jquery-modal/jquery.modal.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => false,
		];

		$this->scripts[] = [
			'handle' => 'fmp-timepicker',
			'src'    => FMP()->assets_url() . 'vendor/timepicker/jquery.timepicker.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-flatpickr',
			'src'    => FMP()->assets_url() . 'vendor/flatpickr/flatpickr.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];
		$this->scripts[] = [
			'handle' => 'fmp-range-flatpickr',
			'src'    => FMP()->assets_url() . 'vendor/flatpickr/rangePlugin.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-single-food',
			'src'    => FMP()->assets_url() . 'js/single-food.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-frontend',
			'src'    => FMP()->assets_url() . 'js/foodmenu.min.js',
			'deps'   => [ 'jquery', 'fmp-actual-height', 'imagesloaded', 'fmp-addon' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-elementor',
			'src'    => FMP()->assets_url() . 'js/fmp-elementor.min.js',
			'deps'   => [ 'jquery', 'fmp-actual-height', 'imagesloaded', 'fmp-addon' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-ajax-tip',
			'src'    => FMP()->assets_url() . 'js/ajax-tip.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-pickup-delivery',
			'src'    => FMP()->assets_url() . 'js/pickup-delivery.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-google-map',
			'src'    => $map_js,
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];
		$this->scripts[] = [
			'handle' => 'fmp-addon',
			'src'    => FMP()->assets_url() . 'js/addon.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];
		$this->scripts[] = [
			'handle' => 'fmp-reservation',
			'src'    => FMP()->assets_url() . 'js/reservation.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-form-validation',
			'src'    => FMP()->assets_url() . 'vendor/jquery-validation/jquery.validate.min.js',
			'deps'   => [ 'jquery' ],
			'footer' => true,
		];

		$this->scripts[] = [
			'handle' => 'fmp-table-layout',
			'src'    => FMP()->assets_url() . 'js/table-layout.min.js',
			'deps'   => [ 'jquery', 'wp-element','wp-components' ],
			'footer' => true,
		];

		/**
		 * Admin Scripts.
		 */
		if ( is_admin() ) {
			$this->scripts[] = [
				'handle' => 'ace_code_highlighter_js',
				'src'    => FMP()->assets_url() . 'vendor/ace/ace.js',
				'deps'   => null,
				'footer' => false,
			];
			$this->scripts[] = [
				'handle' => 'ace_mode_js',
				'src'    => FMP()->assets_url() . 'vendor/ace/mode-css.js',
				'deps'   => [ 'ace_code_highlighter_js' ],
				'footer' => false,
			];
			$this->scripts[] = [
				'handle' => 'fmp-accounting',
				'src'    => FMP()->assets_url() . 'vendor/accounting/accounting.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-food',
				'src'    => FMP()->assets_url() . 'js/admin-food.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin',
				'src'    => FMP()->assets_url() . 'js/admin.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-preview',
				'src'    => FMP()->assets_url() . 'js/admin-preview.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-sc',
				'src'    => FMP()->assets_url() . 'js/admin-sc.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-taxonomy',
				'src'    => FMP()->assets_url() . 'js/admin-taxonomy.min.js',
				'deps'   => [ 'jquery', 'fmp-google-map' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-pickup-delivery',
				'src'    => FMP()->assets_url() . 'js/admin-pickup-delivery.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-addon',
				'src'    => FMP()->assets_url() . 'js/admin-addon.min.js',
				'deps'   => [ 'jquery', 'jquery-ui-sortable' ],
				'footer' => true,
			];
			$this->scripts[] = [
				'handle' => 'fmp-admin-reservation',
				'src'    => FMP()->assets_url() . 'js/admin-reservation.min.js',
				'deps'   => [ 'jquery' ],
				'footer' => true,
			];
		}

		return $this;
	}
}
