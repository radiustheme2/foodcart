<?php
/**
 * Elementor Filter Hook Class.
 *
 * @package RT_FoodMenuPro
 */

namespace RT\FoodMenuPro\Controllers;
use RT\FoodMenu\Helpers\Fns;
use RT\FoodMenu\Helpers\RenderHelpers;
use RT\FoodMenu\Models\QueryArgs;
use RT\FoodMenuPro\Controllers\ProductAddons\Frontend\FrontendPAddon;
use RT\FoodMenuPro\Elementor\GridLayout;
use RT\FoodMenuPro\Elementor\SliderLayout;
use RT\FoodMenuPro\Elementor\IsotopeLayout;

class ElementorController {
	use \RT\FoodMenuPro\Traits\SingletonTrait;
	/**
	 * Class constructor.
	 */

	public function __construct() {
		if ( ! class_exists( \RT\FoodMenu\Abstracts\ElementorWidget::class ) ) {
			return;
		}
		add_filter( 'rtfm_elementor_widget_lists', [ $this, 'el_pro_widgets' ] );
		add_filter( 'rtfm_el_add_to_cart_btn', [ $this, 'cartBtn' ], 10, 10 );
		add_action('elementor/frontend/after_enqueue_scripts', [ $this, 'elementorProStyles' ]);
		add_action( 'wp_ajax_fmp_el_pagination', [ $this, 'fmp_el_pagination' ] );
		add_action( 'wp_ajax_nopriv_fmp_el_pagination', [ $this, 'fmp_el_pagination' ] );

	}


	/**
	 * Handle AJAX request for custom post type pagination.
	 *
	 * This function processes an AJAX request to load paginated posts
	 * for a specific custom post type. It returns a JSON response
	 * containing the post HTML and pagination markup.
	 *
	 * @return void Outputs JSON response and terminates execution.
	 */
	function fmp_el_pagination() {

		$args        = [];
		ob_start();

		$el_settings = $_POST['el_settings'] ?? '{}';
		$el_query = $_POST['el_query'] ?? '{}';

		$template = $el_settings['template'] ?? 'layout-list-free-1';
		$paged       = $args['paged'] = ! empty( $_REQUEST['paged'] ) ? absint( $_REQUEST['paged'] ) : 2;
		$el_query['paged'] = $paged;
		$query = new \WP_Query( $el_query );

		if ( $query->have_posts() ) {

			while ( $query->have_posts() ) {
				$query->the_post();
				$post_id   = get_the_ID();


				$term_ids = [];

				if ( $base_arg['source']  == 'product' ) {
					$term_ids = wp_get_post_terms( $post_id, 'product_cat', [ 'fields' => 'ids' ] );
				} else {
					$term_ids = wp_get_post_terms( $post_id, 'food-menu-cat', [ 'fields' => 'ids' ] );
				}

				$termClasses = '';
				if ( ! empty( $term_ids ) && is_array( $term_ids ) ) {
					foreach ( $term_ids as $term_id ) {
						$termClasses .= ' fmp-isotope-item iso_' . esc_attr( $term_id ) . ' menu-cat-' . esc_attr( $term_id );
					}
				}

				$post_data = [
					'ID'        => $post_id,
					'title'     => get_the_title(),
					'content'   => get_the_content(),
					'excerpt'   => get_the_excerpt(),
					'permalink' => get_permalink(),
					'image'     => get_the_post_thumbnail_url( $post_id, 'full' ),
					'meta'      => [
						'price' => get_post_meta( $post_id, '_regular_price', true ),
					],
					'terms'     => wp_get_post_terms( $post_id, 'food-category', [ 'fields' => 'names' ] ),
					'term_ids'  => $term_ids,
					'term_class' => $termClasses,
				];
				$arg = array_merge( $post_data, $el_settings, [ 'pID' => $post_id ] );
				Fns::render( 'elementor/' . $template, $arg );
			}

			wp_reset_postdata();
			$response = apply_filters('fmp_ajax_response', [
				'success'   => true,
				'html'      => ob_get_clean(),
				'paged'     => $paged,
				'max_page'  => $query->max_num_pages,
			], $query, $paged );


		} else {
			$response = [
				'success' => false,
				'html'    => '<p>' . esc_html__('No posts found', 'food-menu-pro') . '</p>',
			];
		}
		wp_send_json( $response );
	}

	/**
	 * Add Pro Elementor widgets to the list via filter.
	 *
	 * @param array $widgets Array of widget class names from the free version.
	 * @return array Modified array with Pro widget classes added.
	 */
	public function el_pro_widgets( $widgets ) {
		$widgets[] = GridLayout::class;
		$widgets[] = SliderLayout::class;
		$widgets[] = IsotopeLayout::class;
		return $widgets;
	}

	/**
	 * Elementor Style
	 *
	 * @return void
	 */
	public function elementorProStyles() {
		wp_enqueue_script(
			'fmp-elementor',
			plugin_dir_url(__FILE__) . 'assets/js/fmp-elementor.min.js',
			['jquery'],
			null,
			true
		);
		wp_localize_script('fmp-elementor', 'fmp_ajax', [
			'ajaxurl' => admin_url('admin-ajax.php'),
		]);
	}

	public function cartBtn( $content, $link, $id, $type, $text, $items, $addtocart, $quantity, $add_stock, $popup = FALSE ) {
		if ( empty( $text ) ) {
			$text = esc_html__( 'Add to Cart', 'food-menu-pro' );
		}
		$addon_lists = FrontendPAddon::get_instance()->addon_lists( $id );

		$show_addtocart = in_array( 'add_to_cart', $items, true ) || $addtocart === 'yes';
		$show_quantity  = in_array( 'quantity', $items, true ) || $quantity === 'yes';
		$show_stock     = $add_stock === 'yes';

		if ( ! empty( $addon_lists ) && count( $addon_lists ) != 0 ) {
			$addon_lists = array_filter(
				$addon_lists,
				function( $item ) {
					return isset( $item['required'] ) && 1 == $item['required'];
				}
			);
		}

		if ( ( ( 'variable' === $type ) || ( ! empty( $addon_lists ) && count( $addon_lists ) > 0 ) ) && $show_addtocart ) {
			if ( ! empty( $popup ) ) {
				$content = sprintf(
					'<div class="fmp-wc-add-to-cart-wrap"><a href="%1$s" class="fmp-btn-read-more fmp-popup" data-id="%3$s">%2$s</a></div>',
					esc_url( $link ),
					esc_html__( 'Select Options', 'food-menu-pro' ),
					absint( $id )
				);

				return $content;
			} else {
				$content = sprintf(
					'<div class="fmp-wc-add-to-cart-wrap"><a href="%1$s" data-quantity="1" class="fmp-btn-read-more add-to-cart" data-product_id="%3$s" rel="nofollow">%2$s</a></div>',
					esc_url( $link ),
					esc_html__( 'Select Options', 'food-menu-pro' ),
					absint( $id )
				);
				return $content;
			}
		}

		$quantity_html = sprintf(
			'<div class="fmp-wc-quantity-wrap">
				<input class="fmp-input-text" type="number" name="quantity" step="%1$d" min="%1$d" title="%2$s" size="4" pattern="[0-9]*" inputmode="numeric" value="%1$d">
				<div class="input-group-btn">
					<span class="quantity-btn quantity-plus"><i class="fa fa-plus" aria-hidden="true"></i></span>
					<span class="quantity-btn quantity-minus"><i class="fa fa-minus" aria-hidden="true"></i></span>
				</div>
			</div>',
			1,
			esc_html__( 'Quantity', 'food-menu-pro' )
		);

		$add_to_cart_button = sprintf(
			'<a href="%1$s?add-to-cart=%2$d" class="fmp-wc-add-to-cart-btn" data-id="%2$d" data-type="%3$s">%4$s<span></span></a>',
			esc_url( $link ),
			absint( $id ),
			esc_html( $type ),
			esc_html( $text )
		);

		if ( $show_addtocart && $show_quantity ) {
			$content = sprintf(
				'<div class="fmp-wc-add-to-cart-wrap">%s%s</div>',
				$quantity_html,
				$add_to_cart_button
			);
		} elseif ( $show_addtocart && ! $show_quantity ) {
			$content = sprintf(
				'<div class="fmp-wc-add-to-cart-wrap">%s</div>',
				$add_to_cart_button
			);
		} elseif ( $show_stock ) {
			$content = sprintf(
				'<div class="fmp-wc-stock-status">%s</div>',
				esc_html__( 'In Stock', 'food-menu-pro' )
			);
		}
		return $content;
	}
}
